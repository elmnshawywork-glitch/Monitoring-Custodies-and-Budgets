-- ============================================================
--  ابدأ إديو — إعداد قاعدة بيانات Supabase (Postgres)
--  الصق هذا الملف كاملاً في: Supabase ‹ SQL Editor ‹ New query ‹ Run
--  يُنشئ الجداول + دالة api() الآمنة + بيانات أولية.
--  الواجهة تتصل بدالة واحدة فقط: rpc/api ، فلا تُكشف الجداول للعامة.
-- ============================================================

create schema if not exists ebda;

-- ---------- الجداول ----------
create table if not exists ebda.users(
  id text primary key, username text, pin text, name text, role text,
  schools text, active text default 'نعم', email text default '');
create table if not exists ebda.schools(
  id text primary key, name text, type text, period text,
  students numeric default 0, active text default 'نعم', category text default 'school');
create table if not exists ebda.lines(
  id text primary key, school_id text, section text, name text,
  allocated numeric default 0, note text default '');
create table if not exists ebda.custodies(
  id text primary key, label text, holder text, school_id text,
  note text default '', "user" text default '');
create table if not exists ebda.tranches(
  id text primary key, custody_id text, date text, amount numeric default 0, note text default '');
create table if not exists ebda.expenses(
  id text primary key, date text, school_id text, custody_id text, line_id text,
  spend_item text default '', description text default '', amount numeric default 0,
  approval text default 'pending', approved_by text default '',
  doc_url text default '', doc_name text default '',
  review_status text default '', review_note text default '',
  settled text default '', ref text default '', note text default '',
  created_by text default '', created_at text default '');
create table if not exists ebda.spend_items(id text primary key, name text);
create table if not exists ebda.holders(id text primary key, name text, title text);
create table if not exists ebda.approvers(id text primary key, name text, email text);
create table if not exists ebda.emails(id text primary key, email text, label text);
create table if not exists ebda.config(key text primary key, value text);
alter table ebda.users add column if not exists must_reset text default 'لا';
alter table ebda.expenses add column if not exists doc_type text default '';
create table if not exists ebda.salaries(id text primary key, school_id text, name text, job text, monthly numeric default 0, months numeric default 12, note text default '');
create table if not exists ebda.temp_budgets(id text primary key, school_id text, name text, dfrom text, dto text, amount numeric default 0, note text default '');
create table if not exists ebda.requests(id text primary key, school_id text, requester text, requester_name text, status text default 'pending_supervisor', note text default '', total numeric default 0, created_at text default '', custody_id text default '', decided_by text default '', acc_by text default '');
create table if not exists ebda.request_items(id text primary key, request_id text, line_id text, name text, amount numeric default 0, sup_note text default '', decision text default 'approved');
create table if not exists ebda.audit_log(id text primary key, ts text, actor text, actor_role text, action text, entity text, details text);
create table if not exists ebda.employees(
  id text primary key, school_id text, category text default 'contract',
  emp_no text default '', name text, job text default '', job_type text default '',
  qualification text default '', grad_year text default '', national_id text default '',
  birth_date text default '', phone text default '', hire_date text default '',
  work_start text default '', insurance_no text default '', account_no text default '',
  bank text default '', branch text default '', email text default '',
  ebda_start text default '', base_salary numeric default 0, contract_type text default '',
  gender text default '', address text default '', retire_date text default '',
  note text default '', active text default 'نعم', archived text default 'لا',
  archived_at text default '', archived_by text default '');
create table if not exists ebda.payslips(
  id text primary key, employee_id text, emp_name text default '', school_id text,
  month text default '', base numeric default 0, incentive numeric default 0, allowances numeric default 0,
  gross numeric default 0, ded_medical numeric default 0, ded_social numeric default 0,
  ded_tax numeric default 0, ded_other numeric default 0, ded_total numeric default 0,
  net numeric default 0, note text default '', created_by text default '', created_at text default '');
create index if not exists ix_emp_school on ebda.employees(school_id);
create index if not exists ix_pay_emp on ebda.payslips(employee_id);
create index if not exists ix_pay_school on ebda.payslips(school_id);
alter table ebda.expenses add column if not exists doc_is_link text default 'لا';
create index if not exists ix_audit_ts on ebda.audit_log(ts);
create index if not exists ix_ri_req on ebda.request_items(request_id);
create index if not exists ix_req_school on ebda.requests(school_id);
create index if not exists ix_sal_school on ebda.salaries(school_id);
create index if not exists ix_tb_school on ebda.temp_budgets(school_id);
insert into ebda.config(key,value) values ('backup_token','CHANGE_ME_TO_A_SECRET')
  on conflict (key) do nothing;

create index if not exists ix_lines_school on ebda.lines(school_id);
create index if not exists ix_cust_school on ebda.custodies(school_id);
create index if not exists ix_tr_cust on ebda.tranches(custody_id);
create index if not exists ix_exp_cust on ebda.expenses(custody_id);
create index if not exists ix_exp_school on ebda.expenses(school_id);

-- ---------- مولّد معرفات ----------
create or replace function ebda.uid() returns text language sql as
$$ select 'id' || substr(md5(clock_timestamp()::text || random()::text), 1, 14) $$;

-- ---------- أدوات مساعدة ----------
create or replace function ebda.can_school(u ebda.users, sid text) returns boolean language sql as $$
  select u.role='manager' or u.schools='*' or sid = any(string_to_array(coalesce(u.schools,''), ','))
      or sid = any(array(select trim(x) from unnest(string_to_array(coalesce(u.schools,''), ',')) x));
$$;
create or replace function ebda.sees_budgets(u ebda.users) returns boolean language sql as
$$ select u.role in ('manager','accountant') $$;
create or replace function ebda.role_emails(r text) returns text[] language sql as
$$ select array(select email from ebda.users where role=r and coalesce(active,'') like '%نعم%' and coalesce(email,'') like '%@%') $$;

-- ============================================================
--  الدالة الرئيسية api(req jsonb) — تنفّذ كل الإجراءات مع التحقق
-- ============================================================
create or replace function ebda.api(req jsonb)
returns jsonb
language plpgsql
security definer
set search_path = ebda
as $fn$
declare
  action text := req->>'action';
  a_user text := req#>>'{auth,username}';
  a_pin  text := req#>>'{auth,pin}';
  u ebda.users;
  cust ebda.custodies;
  ex ebda.expenses;
  sid text;
  newid text;
  patch jsonb;
  recs text[];
  ln jsonb;
  res jsonb;
  catv text;
  dj jsonb;
begin
  -- نسخ احتياطى كامل (برمز سرّى) — يستخدمه Apps Script للنسخ إلى جوجل شيت
  if action = 'dumpAll' then
    if coalesce(req->>'token','') <> coalesce((select value from ebda.config where key='backup_token'),'') then
      return jsonb_build_object('error','رمز النسخ الاحتياطى غير صحيح'); end if;
    return jsonb_build_object('ok',true,
      'users',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.users x),
      'schools',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.schools x),
      'lines',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.lines x),
      'custodies',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.custodies x),
      'tranches',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.tranches x),
      'expenses',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.expenses x),
      'spend_items',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.spend_items x),
      'holders',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.holders x),
      'approvers',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.approvers x),
      'emails',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.emails x),
      'salaries',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.salaries x),
      'employees',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.employees x),
      'payslips',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.payslips x),
      'temp_budgets',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.temp_budgets x),
      'requests',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.requests x),
      'request_items',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.request_items x),
      'audit_log',(select coalesce(jsonb_agg(to_jsonb(x)),'[]') from ebda.audit_log x));
  end if;
  -- تسجيل الدخول
  if action = 'login' then
    select * into u from ebda.users
      where username = (req->>'username') and pin = (req->>'pin') and coalesce(active,'') like '%نعم%' limit 1;
    if not found then return jsonb_build_object('error','بيانات الدخول غير صحيحة'); end if;
    return jsonb_build_object('ok',true,'user',jsonb_build_object('id',u.id,'username',u.username,'name',u.name,'role',u.role,'schools',u.schools,'must_reset',coalesce(u.must_reset,'لا')));
  end if;

  -- التحقق لبقية الإجراءات
  select * into u from ebda.users where username=a_user and pin=a_pin limit 1;
  if not found then return jsonb_build_object('error','انتهت الجلسة — سجّل الدخول من جديد'); end if;

  -- سجل التدقيق (لكل إجراء تعديلى)
  if action not in ('bootstrap','ping') then
    dj := req - 'auth' - 'pin' - 'dataBase64' - 'dataUrl' - 'html' - 'attachment';
    if dj ? 'user' then dj := dj #- '{user,pin}'; end if;
    insert into ebda.audit_log(id,ts,actor,actor_role,action,entity,details)
    values(ebda.uid(), now()::text, u.name, u.role, action, coalesce(req->>'id',''), left(coalesce(dj::text,''), 1500));
  end if;

  if action = 'setPassword' then
    if length(coalesce(req->>'pin',''))<3 then return jsonb_build_object('error','كلمة السر قصيرة'); end if;
    update ebda.users set pin=(req->>'pin'), must_reset='لا' where id=u.id;
    return jsonb_build_object('ok',true);
  end if;

  -- ====== طلبات العهد ======
  if action = 'addRequest' then
    if u.role not in ('custody','manager') then return jsonb_build_object('error','خاص بمسئول العهدة'); end if;
    newid := ebda.uid();
    insert into ebda.requests(id,school_id,requester,requester_name,status,note,total,created_at)
    values(newid, req#>>'{request,school_id}', u.username, u.name, 'pending_supervisor', coalesce(req#>>'{request,note}',''),
      coalesce((select sum((x->>'amount')::numeric) from jsonb_array_elements(coalesce(req#>'{request,items}','[]'::jsonb)) x),0), now()::text);
    for ln in select * from jsonb_array_elements(coalesce(req#>'{request,items}','[]'::jsonb)) loop
      insert into ebda.request_items(id,request_id,line_id,name,amount,sup_note,decision)
      values(ebda.uid(), newid, ln->>'line_id', coalesce(ln->>'name',''), coalesce((ln->>'amount')::numeric,0), '', 'approved');
    end loop;
    return jsonb_build_object('ok',true,'id',newid);
  end if;

  if action = 'updateRequestItem' then
    if u.role not in ('supervisor','manager') then return jsonb_build_object('error','صلاحية المدير المباشر مطلوبة'); end if;
    patch := req->'patch';
    update ebda.request_items set line_id=coalesce(patch->>'line_id',line_id), name=coalesce(patch->>'name',name),
      amount=coalesce((patch->>'amount')::numeric,amount), sup_note=coalesce(patch->>'sup_note',sup_note), decision=coalesce(patch->>'decision',decision)
    where id=(req->>'id');
    -- تحديث الإجمالى
    update ebda.requests set total=coalesce((select sum(amount) from ebda.request_items where request_id=(select request_id from ebda.request_items where id=(req->>'id')) and decision<>'rejected'),0)
      where id=(select request_id from ebda.request_items where id=(req->>'id'));
    return jsonb_build_object('ok',true);
  end if;

  if action = 'deleteRequestItem' then
    if u.role not in ('supervisor','manager') then return jsonb_build_object('error','صلاحية المدير المباشر مطلوبة'); end if;
    sid := (select request_id from ebda.request_items where id=(req->>'id'));
    delete from ebda.request_items where id=(req->>'id');
    update ebda.requests set total=coalesce((select sum(amount) from ebda.request_items where request_id=sid and decision<>'rejected'),0) where id=sid;
    return jsonb_build_object('ok',true);
  end if;

  if action = 'decideRequest' then
    if u.role not in ('supervisor','manager') then return jsonb_build_object('error','صلاحية المدير المباشر مطلوبة'); end if;
    if (req->>'decision')='approve' then
      update ebda.requests set status='pending_accountant', decided_by=u.name, note=coalesce(req->>'note',note) where id=(req->>'id');
    else
      update ebda.requests set status='rejected', decided_by=u.name, note=coalesce(req->>'note',note) where id=(req->>'id');
    end if;
    return jsonb_build_object('ok',true);
  end if;

  if action = 'transferRequest' then
    if u.role not in ('accountant','manager') then return jsonb_build_object('error','صلاحية المحاسب مطلوبة'); end if;
    if (req->>'decision')<>'approve' then
      update ebda.requests set status='rejected', acc_by=u.name where id=(req->>'id');
      return jsonb_build_object('ok',true);
    end if;
    declare rq ebda.requests; cid text; tot numeric;
    begin
      select * into rq from ebda.requests where id=(req->>'id');
      tot := coalesce((select sum(amount) from ebda.request_items where request_id=rq.id and decision<>'rejected'),0);
      select id into cid from ebda.custodies where school_id=rq.school_id and "user"=rq.requester limit 1;
      if cid is null then
        cid := ebda.uid();
        insert into ebda.custodies(id,label,holder,school_id,note,"user")
        values(cid, 'عهدة '||rq.requester_name, rq.requester_name, rq.school_id, 'من طلب عهدة', rq.requester);
      end if;
      insert into ebda.tranches(id,custody_id,date,amount,note)
      values(ebda.uid(), cid, now()::text, tot, 'تحويل طلب عهدة');
      update ebda.requests set status='transferred', acc_by=u.name, custody_id=cid, total=tot where id=rq.id;
    end;
    return jsonb_build_object('ok',true);
  end if;

  if action = 'ping' then
    return jsonb_build_object('ok',true,'connected',true,'db','supabase',
      'users',(select count(*) from ebda.users),'schools',(select count(*) from ebda.schools));
  end if;

  if action = 'bootstrap' then
    res := jsonb_build_object('ok',true,'me',
      jsonb_build_object('id',u.id,'username',u.username,'name',u.name,'role',u.role,'schools',u.schools,'must_reset',coalesce(u.must_reset,'لا')));
    -- الجهات المرئية
    res := res || jsonb_build_object('schools', coalesce((select jsonb_agg(to_jsonb(s)) from ebda.schools s
        where coalesce(s.active,'') like '%نعم%' and ebda.can_school(u, s.id)),'[]'::jsonb));
    -- العهد
    if u.role='custody' then
      res := res || jsonb_build_object('custodies', coalesce((select jsonb_agg(to_jsonb(c)) from ebda.custodies c
          where coalesce(c."user",'')=u.username),'[]'::jsonb));
    else
      res := res || jsonb_build_object('custodies', coalesce((select jsonb_agg(to_jsonb(c)) from ebda.custodies c
          where c.school_id in (select s.id from ebda.schools s where ebda.can_school(u,s.id)) or coalesce(c.school_id,'')=''),'[]'::jsonb));
    end if;
    -- البنود: للأدوار التى تحتاجها (مدير/محاسب/مدير مباشر) كاملة، وللمسئول أسماء فقط
    if ebda.sees_budgets(u) or u.role='supervisor' then
      res := res || jsonb_build_object('lines', coalesce((select jsonb_agg(to_jsonb(l)) from ebda.lines l
          where l.school_id in (select s.id from ebda.schools s where ebda.can_school(u,s.id))),'[]'::jsonb));
    elsif u.role='custody' then
      res := res || jsonb_build_object('lines', coalesce((select jsonb_agg(jsonb_build_object('id',l.id,'school_id',l.school_id,'section',l.section,'name',l.name)) from ebda.lines l
          where l.school_id in (select s.id from ebda.schools s where ebda.can_school(u,s.id))),'[]'::jsonb));
    else
      res := res || jsonb_build_object('lines','[]'::jsonb);
    end if;
    -- الدفعات والمصروفات (حسب العهد المرئية)
    res := res || jsonb_build_object('tranches', coalesce((select jsonb_agg(to_jsonb(t)) from ebda.tranches t
        where t.custody_id in (select c.id from ebda.custodies c where
          (u.role='custody' and coalesce(c."user",'')=u.username) or
          (u.role<>'custody' and (c.school_id in (select s.id from ebda.schools s where ebda.can_school(u,s.id)) or coalesce(c.school_id,'')='')))),'[]'::jsonb));
    if u.role='custody' then
      res := res || jsonb_build_object('expenses', coalesce((select jsonb_agg(to_jsonb(e)) from ebda.expenses e
          where e.custody_id in (select c.id from ebda.custodies c where coalesce(c."user",'')=u.username)),'[]'::jsonb));
    else
      res := res || jsonb_build_object('expenses', coalesce((select jsonb_agg(to_jsonb(e)) from ebda.expenses e
          where e.custody_id in (select c.id from ebda.custodies c where c.school_id in (select s.id from ebda.schools s where ebda.can_school(u,s.id)))
             or e.school_id in (select s.id from ebda.schools s where ebda.can_school(u,s.id))),'[]'::jsonb));
    end if;
    res := res
      || jsonb_build_object('spendItems', coalesce((select jsonb_agg(to_jsonb(x)) from ebda.spend_items x),'[]'::jsonb))
      || jsonb_build_object('holders', coalesce((select jsonb_agg(to_jsonb(x)) from ebda.holders x),'[]'::jsonb))
      || jsonb_build_object('approvers', coalesce((select jsonb_agg(to_jsonb(x)) from ebda.approvers x),'[]'::jsonb))
      || jsonb_build_object('emails', coalesce((select jsonb_agg(to_jsonb(x)) from ebda.emails x),'[]'::jsonb));
    if ebda.sees_budgets(u) then
      res := res || jsonb_build_object('salaries', coalesce((select jsonb_agg(to_jsonb(x)) from ebda.salaries x
          where x.school_id in (select s.id from ebda.schools s where ebda.can_school(u,s.id))),'[]'::jsonb));
    end if;
    if ebda.sees_budgets(u) then
      res := res || jsonb_build_object('employees', coalesce((select jsonb_agg(to_jsonb(x)) from ebda.employees x
          where x.school_id in (select s.id from ebda.schools s where ebda.can_school(u,s.id))),'[]'::jsonb));
      res := res || jsonb_build_object('payslips', coalesce((select jsonb_agg(to_jsonb(x)) from ebda.payslips x
          where x.school_id in (select s.id from ebda.schools s where ebda.can_school(u,s.id))),'[]'::jsonb));
    end if;
    -- طلبات العهد (لكل بند عناصره)
    res := res || jsonb_build_object('requests', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',rq.id,'school_id',rq.school_id,'requester',rq.requester,'requester_name',rq.requester_name,
        'status',rq.status,'note',rq.note,'total',rq.total,'created_at',rq.created_at,'custody_id',rq.custody_id,
        'decided_by',rq.decided_by,'acc_by',rq.acc_by,
        'items', coalesce((select jsonb_agg(to_jsonb(it)) from ebda.request_items it where it.request_id=rq.id),'[]'::jsonb)))
      from ebda.requests rq
      where (u.role='custody' and rq.requester=u.username)
         or (u.role<>'custody' and rq.school_id in (select s.id from ebda.schools s where ebda.can_school(u,s.id)))
    ),'[]'::jsonb));
    if u.role='manager' then
      res := res || jsonb_build_object('tempBudgets', coalesce((select jsonb_agg(to_jsonb(x)) from ebda.temp_budgets x),'[]'::jsonb));
      res := res || jsonb_build_object('audit', coalesce((select jsonb_agg(to_jsonb(a)) from (select * from ebda.audit_log order by ts desc limit 500) a),'[]'::jsonb));
    end if;
    if u.role='manager' then
      res := res || jsonb_build_object('users', coalesce((select jsonb_agg(to_jsonb(x)) from ebda.users x),'[]'::jsonb));
    elsif u.role='accountant' then
      res := res || jsonb_build_object('users', coalesce((select jsonb_agg(jsonb_build_object('id',x.id,'username',x.username,'name',x.name,'role',x.role)) from ebda.users x),'[]'::jsonb));
    end if;
    return res;
  end if;

  -- تسجيل صرف من العهدة
  if action = 'addExpense' then
    select * into cust from ebda.custodies where id = (req#>>'{expense,custody_id}');
    if not found then return jsonb_build_object('error','العهدة غير موجودة'); end if;
    if u.role<>'manager' and coalesce(cust."user",'')<>u.username then return jsonb_build_object('error','لا صلاحية على هذه العهدة'); end if;
    newid := ebda.uid();
    insert into ebda.expenses(id,date,school_id,custody_id,line_id,spend_item,description,amount,
       approval,approved_by,doc_url,doc_name,review_status,review_note,settled,ref,note,created_by,created_at)
    values(newid, req#>>'{expense,date}', req#>>'{expense,school_id}', req#>>'{expense,custody_id}',
       req#>>'{expense,line_id}', coalesce(req#>>'{expense,spend_item}',''), coalesce(req#>>'{expense,description}',''),
       coalesce((req#>>'{expense,amount}')::numeric,0),'pending','', '','','','','','','', u.name, now()::text);
    return jsonb_build_object('ok',true,'item',(select to_jsonb(e) from ebda.expenses e where e.id=newid));
  end if;

  -- شراء مركزى (محاسب/مدير) — يُخصم من الموازنة مباشرة
  if action = 'addCentral' then
    if u.role not in ('manager','accountant') then return jsonb_build_object('error','صلاحية المحاسب مطلوبة'); end if;
    newid := ebda.uid();
    insert into ebda.expenses(id,date,school_id,custody_id,line_id,spend_item,description,amount,
       approval,approved_by,doc_url,doc_name,review_status,review_note,settled,ref,note,created_by,created_at)
    values(newid, req#>>'{expense,date}', req#>>'{expense,school_id}', '', req#>>'{expense,line_id}', '',
       coalesce(req#>>'{expense,description}',''), coalesce((req#>>'{expense,amount}')::numeric,0),
       'approved', u.name, coalesce(req->>'dataUrl',''), coalesce(req->>'filename',''),
       'مستوفى','', 'نعم','','', u.name, now()::text);
    update ebda.expenses set doc_type=coalesce(req->>'doc_type', doc_type) where id=newid;
    return jsonb_build_object('ok',true,'item',(select to_jsonb(e) from ebda.expenses e where e.id=newid));
  end if;

  -- اعتماد/تعديل مصروف
  if action = 'updateExpense' then
    select * into ex from ebda.expenses where id = (req->>'id');
    patch := req->'patch';
    if patch ? 'approval' then
      if u.role not in ('manager','supervisor') then return jsonb_build_object('error','صلاحية الاعتماد مطلوبة'); end if;
    elsif u.role='manager' then
      null;
    else
      select * into cust from ebda.custodies where id = ex.custody_id;
      if not (coalesce(cust."user",'')=u.username and ex.approval='pending') then
        return jsonb_build_object('error','لا يمكن التعديل بعد اعتماد الصرف'); end if;
    end if;
    update ebda.expenses set
      date = coalesce(patch->>'date', date),
      line_id = coalesce(patch->>'line_id', line_id),
      amount = coalesce((patch->>'amount')::numeric, amount),
      description = coalesce(patch->>'description', description),
      approval = coalesce(patch->>'approval', approval),
      approved_by = coalesce(patch->>'approved_by', approved_by),
      settled = coalesce(patch->>'settled', settled),
      note = coalesce(patch->>'note', note)
    where id = (req->>'id');
    return jsonb_build_object('ok',true,'mail','الإشعارات عبر جوجل شيت/الإيميل غير مفعّلة فى وضع Supabase');
  end if;

  -- مراجعة المستند (محاسب/مدير)
  if action = 'reviewExpense' then
    if u.role not in ('manager','accountant') then return jsonb_build_object('error','صلاحية المراجعة مطلوبة'); end if;
    patch := req->'patch';
    update ebda.expenses set
      review_status = coalesce(patch->>'review_status', review_status),
      review_note = coalesce(patch->>'review_note', review_note),
      settled = coalesce(patch->>'settled', settled)
    where id = (req->>'id');
    return jsonb_build_object('ok',true,'mail','تم — الإشعار بالإيميل عبر النسخة الاحتياطية');
  end if;

  -- رفع مستند (تخزين رابط/داتا)
  if action = 'uploadDoc' then
    select * into ex from ebda.expenses where id=(req->>'id');
    if not found then return jsonb_build_object('error','المصروف غير موجود'); end if;
    select * into cust from ebda.custodies where id=ex.custody_id;
    if not (u.role='manager'
            or (cust.id is not null and coalesce(cust."user",'')=u.username)
            or (coalesce(ex.custody_id,'')='' and u.role in ('manager','accountant')))
    then return jsonb_build_object('error','لا صلاحية لرفع مستند'); end if;
    if coalesce(req->>'link','')<>'' then
      update ebda.expenses set doc_url=req->>'link', doc_name=coalesce(req->>'filename','رابط مستند'), doc_type=coalesce(req->>'doc_type', doc_type), doc_is_link='نعم' where id=(req->>'id');
      return jsonb_build_object('ok',true,'url',req->>'link');
    end if;
    update ebda.expenses set doc_url=coalesce(req->>'dataUrl',''), doc_name=coalesce(req->>'filename',''), doc_type=coalesce(req->>'doc_type', doc_type), doc_is_link='لا' where id=(req->>'id');
    return jsonb_build_object('ok',true,'url',coalesce(req->>'dataUrl',''));
  end if;

  if action = 'deleteExpense' then
    select * into ex from ebda.expenses where id=(req->>'id');
    if u.role<>'manager' then
      select * into cust from ebda.custodies where id=ex.custody_id;
      if not (coalesce(cust."user",'')=u.username and ex.approval='pending') then
        return jsonb_build_object('error','لا يمكن الحذف بعد اعتماد الصرف'); end if;
    end if;
    delete from ebda.expenses where id=(req->>'id');
    return jsonb_build_object('ok',true);
  end if;

  if action = 'emailReport' then
    if not ebda.sees_budgets(u) then return jsonb_build_object('error','لا صلاحية'); end if;
    return jsonb_build_object('ok',true,'note','الإرسال بالإيميل يتم عبر النسخة الاحتياطية (Apps Script) أو Edge Function');
  end if;

  -- إدارة العهد والدفعات: مدير أو محاسب
  if action = 'addTranche' then
    if u.role not in ('manager','accountant') then return jsonb_build_object('error','صلاحية المدير أو المحاسب مطلوبة'); end if;
    newid := ebda.uid();
    insert into ebda.tranches(id,custody_id,date,amount,note)
    values(newid, req#>>'{tranche,custody_id}', req#>>'{tranche,date}', coalesce((req#>>'{tranche,amount}')::numeric,0), coalesce(req#>>'{tranche,note}',''));
    return jsonb_build_object('ok',true,'item',(select to_jsonb(t) from ebda.tranches t where t.id=newid));
  end if;

  if action = 'addCustody' then
    if u.role not in ('manager','accountant') then return jsonb_build_object('error','صلاحية المدير أو المحاسب مطلوبة'); end if;
    newid := ebda.uid();
    insert into ebda.custodies(id,label,holder,school_id,note,"user")
    values(newid, req#>>'{custody,label}', req#>>'{custody,holder}', req#>>'{custody,school_id}', coalesce(req#>>'{custody,note}',''), coalesce(req#>>'{custody,user}',''));
    return jsonb_build_object('ok',true,'item',(select to_jsonb(c) from ebda.custodies c where c.id=newid));
  end if;

  if action = 'updateCustody' then
    if u.role not in ('manager','accountant') then return jsonb_build_object('error','صلاحية المدير أو المحاسب مطلوبة'); end if;
    patch := req->'patch';
    update ebda.custodies set label=coalesce(patch->>'label',label), holder=coalesce(patch->>'holder',holder),
      school_id=coalesce(patch->>'school_id',school_id), note=coalesce(patch->>'note',note), "user"=coalesce(patch->>'user',"user")
    where id=(req->>'id');
    return jsonb_build_object('ok',true);
  end if;

  if action = 'deleteCustody' then
    if u.role not in ('manager','accountant') then return jsonb_build_object('error','صلاحية المدير أو المحاسب مطلوبة'); end if;
    delete from ebda.expenses where custody_id=(req->>'id');
    delete from ebda.tranches where custody_id=(req->>'id');
    delete from ebda.custodies where id=(req->>'id');
    return jsonb_build_object('ok',true);
  end if;

  -- إضافة بند: المدير لأى جهة؛ المحاسب/مسئول العهدة للجهات غير المدرسية (تكوين موازنة داخلية)
  if action = 'addLine' then
    catv := (select category from ebda.schools where id = req#>>'{line,school_id}');
    if not (u.role='manager' or (u.role in ('accountant','custody') and coalesce(catv,'school')<>'school')) then
      return jsonb_build_object('error','لا صلاحية لإضافة بند لهذه الجهة'); end if;
    newid := ebda.uid();
    insert into ebda.lines(id,school_id,section,name,allocated,note)
    values(newid, req#>>'{line,school_id}', coalesce(req#>>'{line,section}',''), req#>>'{line,name}', coalesce((req#>>'{line,allocated}')::numeric,0), coalesce(req#>>'{line,note}',''));
    return jsonb_build_object('ok',true,'item',(select to_jsonb(l) from ebda.lines l where l.id=newid));
  end if;

  -- باقى الإجراءات للمدير فقط
  if u.role<>'manager' then return jsonb_build_object('error','صلاحية المدير مطلوبة'); end if;

  if action = 'resetPin' then
    update ebda.users set pin='0000', must_reset='نعم' where id=(req->>'id');
    return jsonb_build_object('ok',true);
  end if;

  if action = 'addSalary' then
    newid := ebda.uid();
    insert into ebda.salaries(id,school_id,name,job,monthly,months,note)
    values(newid, req#>>'{salary,school_id}', req#>>'{salary,name}', coalesce(req#>>'{salary,job}',''),
      coalesce((req#>>'{salary,monthly}')::numeric,0), coalesce((req#>>'{salary,months}')::numeric,12), coalesce(req#>>'{salary,note}',''));
    return jsonb_build_object('ok',true,'item',(select to_jsonb(x) from ebda.salaries x where x.id=newid));
  end if;
  if action = 'updateSalary' then
    patch := req->'patch';
    update ebda.salaries set name=coalesce(patch->>'name',name), job=coalesce(patch->>'job',job),
      monthly=coalesce((patch->>'monthly')::numeric,monthly), months=coalesce((patch->>'months')::numeric,months), note=coalesce(patch->>'note',note)
    where id=(req->>'id');
    return jsonb_build_object('ok',true);
  end if;
  if action = 'deleteSalary' then delete from ebda.salaries where id=(req->>'id'); return jsonb_build_object('ok',true); end if;

  if action = 'importSalaries' then
    sid := req->>'school_id';
    if (req->>'replace') is distinct from 'no' then delete from ebda.salaries where school_id = sid; end if;
    for ln in select * from jsonb_array_elements(coalesce(req->'rows','[]'::jsonb)) loop
      insert into ebda.salaries(id,school_id,name,job,monthly,months,note)
      values(ebda.uid(), sid, coalesce(ln->>'name',''), coalesce(ln->>'job',''),
        coalesce((ln->>'monthly')::numeric,0), coalesce((ln->>'months')::numeric,12), coalesce(ln->>'note',''));
    end loop;
    return jsonb_build_object('ok',true,'count',jsonb_array_length(coalesce(req->'rows','[]'::jsonb)));
  end if;

  if action = 'addEmployee' then
    newid := ebda.uid(); dj := req->'emp';
    insert into ebda.employees(id,school_id,category,emp_no,name,job,job_type,qualification,grad_year,national_id,birth_date,phone,hire_date,work_start,insurance_no,account_no,bank,branch,email,ebda_start,base_salary,contract_type,gender,address,retire_date,note,active,archived)
    values(newid, dj->>'school_id', coalesce(dj->>'category','contract'), coalesce(dj->>'emp_no',''), dj->>'name', coalesce(dj->>'job',''), coalesce(dj->>'job_type',''), coalesce(dj->>'qualification',''), coalesce(dj->>'grad_year',''), coalesce(dj->>'national_id',''), coalesce(dj->>'birth_date',''), coalesce(dj->>'phone',''), coalesce(dj->>'hire_date',''), coalesce(dj->>'work_start',''), coalesce(dj->>'insurance_no',''), coalesce(dj->>'account_no',''), coalesce(dj->>'bank',''), coalesce(dj->>'branch',''), coalesce(dj->>'email',''), coalesce(dj->>'ebda_start',''), coalesce((dj->>'base_salary')::numeric,0), coalesce(dj->>'contract_type',''), coalesce(dj->>'gender',''), coalesce(dj->>'address',''), coalesce(dj->>'retire_date',''), coalesce(dj->>'note',''), 'نعم','لا');
    return jsonb_build_object('ok',true,'item',(select to_jsonb(x) from ebda.employees x where x.id=newid));
  end if;
  if action = 'updateEmployee' then
    patch := req->'patch';
    update ebda.employees set
      category=coalesce(patch->>'category',category), emp_no=coalesce(patch->>'emp_no',emp_no), name=coalesce(patch->>'name',name),
      job=coalesce(patch->>'job',job), job_type=coalesce(patch->>'job_type',job_type), qualification=coalesce(patch->>'qualification',qualification),
      grad_year=coalesce(patch->>'grad_year',grad_year), national_id=coalesce(patch->>'national_id',national_id), birth_date=coalesce(patch->>'birth_date',birth_date),
      phone=coalesce(patch->>'phone',phone), hire_date=coalesce(patch->>'hire_date',hire_date), work_start=coalesce(patch->>'work_start',work_start),
      insurance_no=coalesce(patch->>'insurance_no',insurance_no), account_no=coalesce(patch->>'account_no',account_no), bank=coalesce(patch->>'bank',bank),
      branch=coalesce(patch->>'branch',branch), email=coalesce(patch->>'email',email), ebda_start=coalesce(patch->>'ebda_start',ebda_start),
      base_salary=coalesce((patch->>'base_salary')::numeric,base_salary), contract_type=coalesce(patch->>'contract_type',contract_type),
      gender=coalesce(patch->>'gender',gender), address=coalesce(patch->>'address',address), retire_date=coalesce(patch->>'retire_date',retire_date),
      note=coalesce(patch->>'note',note), school_id=coalesce(patch->>'school_id',school_id)
    where id=(req->>'id');
    return jsonb_build_object('ok',true);
  end if;
  if action = 'archiveEmployee' then
    update ebda.employees set archived='نعم', active='لا', archived_at=now()::text, archived_by=u.name where id=(req->>'id');
    return jsonb_build_object('ok',true);
  end if;
  if action = 'restoreEmployee' then
    update ebda.employees set archived='لا', active='نعم', archived_at='', archived_by='' where id=(req->>'id');
    return jsonb_build_object('ok',true);
  end if;
  if action = 'deleteEmployee' then
    delete from ebda.employees where id=(req->>'id');
    return jsonb_build_object('ok',true);
  end if;
  if action = 'importEmployees' then
    sid := req->>'school_id';
    for ln in select * from jsonb_array_elements(coalesce(req->'rows','[]'::jsonb)) loop
      insert into ebda.employees(id,school_id,category,emp_no,name,job,job_type,qualification,grad_year,national_id,birth_date,phone,hire_date,work_start,insurance_no,account_no,bank,branch,email,ebda_start,base_salary,contract_type,gender,address,retire_date,note,active,archived)
      values(ebda.uid(), sid, coalesce(ln->>'category','contract'), coalesce(ln->>'emp_no',''), coalesce(ln->>'name',''), coalesce(ln->>'job',''), coalesce(ln->>'job_type',''), coalesce(ln->>'qualification',''), coalesce(ln->>'grad_year',''), coalesce(ln->>'national_id',''), coalesce(ln->>'birth_date',''), coalesce(ln->>'phone',''), coalesce(ln->>'hire_date',''), coalesce(ln->>'work_start',''), coalesce(ln->>'insurance_no',''), coalesce(ln->>'account_no',''), coalesce(ln->>'bank',''), coalesce(ln->>'branch',''), coalesce(ln->>'email',''), coalesce(ln->>'ebda_start',''), coalesce((ln->>'base_salary')::numeric,0), coalesce(ln->>'contract_type',''), coalesce(ln->>'gender',''), coalesce(ln->>'address',''), coalesce(ln->>'retire_date',''), coalesce(ln->>'note',''), 'نعم','لا');
    end loop;
    return jsonb_build_object('ok',true,'count',jsonb_array_length(coalesce(req->'rows','[]'::jsonb)));
  end if;
  if action = 'addPayslip' then
    newid := ebda.uid(); dj := req->'slip';
    insert into ebda.payslips(id,employee_id,emp_name,school_id,month,base,incentive,allowances,gross,ded_medical,ded_social,ded_tax,ded_other,ded_total,net,note,created_by,created_at)
    values(newid, dj->>'employee_id', coalesce(dj->>'emp_name',''), dj->>'school_id', coalesce(dj->>'month',''),
      coalesce((dj->>'base')::numeric,0), coalesce((dj->>'incentive')::numeric,0), coalesce((dj->>'allowances')::numeric,0), coalesce((dj->>'gross')::numeric,0),
      coalesce((dj->>'ded_medical')::numeric,0), coalesce((dj->>'ded_social')::numeric,0), coalesce((dj->>'ded_tax')::numeric,0), coalesce((dj->>'ded_other')::numeric,0),
      coalesce((dj->>'ded_total')::numeric,0), coalesce((dj->>'net')::numeric,0), coalesce(dj->>'note',''), u.name, now()::text);
    return jsonb_build_object('ok',true,'item',(select to_jsonb(x) from ebda.payslips x where x.id=newid));
  end if;
  if action = 'updatePayslip' then
    patch := req->'patch';
    update ebda.payslips set base=coalesce((patch->>'base')::numeric,base), incentive=coalesce((patch->>'incentive')::numeric,incentive),
      allowances=coalesce((patch->>'allowances')::numeric,allowances), gross=coalesce((patch->>'gross')::numeric,gross),
      ded_medical=coalesce((patch->>'ded_medical')::numeric,ded_medical), ded_social=coalesce((patch->>'ded_social')::numeric,ded_social),
      ded_tax=coalesce((patch->>'ded_tax')::numeric,ded_tax), ded_other=coalesce((patch->>'ded_other')::numeric,ded_other),
      ded_total=coalesce((patch->>'ded_total')::numeric,ded_total), net=coalesce((patch->>'net')::numeric,net), note=coalesce(patch->>'note',note)
    where id=(req->>'id');
    return jsonb_build_object('ok',true);
  end if;
  if action = 'deletePayslip' then delete from ebda.payslips where id=(req->>'id'); return jsonb_build_object('ok',true); end if;
  if action = 'addPayslipsBatch' then
    for ln in select * from jsonb_array_elements(coalesce(req->'rows','[]'::jsonb)) loop
      insert into ebda.payslips(id,employee_id,emp_name,school_id,month,base,incentive,allowances,gross,ded_medical,ded_social,ded_tax,ded_other,ded_total,net,note,created_by,created_at)
      values(ebda.uid(), ln->>'employee_id', coalesce(ln->>'emp_name',''), ln->>'school_id', coalesce(ln->>'month',''),
        coalesce((ln->>'base')::numeric,0), coalesce((ln->>'incentive')::numeric,0), coalesce((ln->>'allowances')::numeric,0), coalesce((ln->>'gross')::numeric,0),
        coalesce((ln->>'ded_medical')::numeric,0), coalesce((ln->>'ded_social')::numeric,0), coalesce((ln->>'ded_tax')::numeric,0), coalesce((ln->>'ded_other')::numeric,0),
        coalesce((ln->>'ded_total')::numeric,0), coalesce((ln->>'net')::numeric,0), coalesce(ln->>'note',''), u.name, now()::text);
    end loop;
    return jsonb_build_object('ok',true,'count',jsonb_array_length(coalesce(req->'rows','[]'::jsonb)));
  end if;

  if action = 'addTempBudget' then
    newid := ebda.uid();
    insert into ebda.temp_budgets(id,school_id,name,dfrom,dto,amount,note)
    values(newid, req#>>'{tb,school_id}', req#>>'{tb,name}', req#>>'{tb,dfrom}', req#>>'{tb,dto}',
      coalesce((req#>>'{tb,amount}')::numeric,0), coalesce(req#>>'{tb,note}',''));
    return jsonb_build_object('ok',true,'item',(select to_jsonb(x) from ebda.temp_budgets x where x.id=newid));
  end if;
  if action = 'deleteTempBudget' then delete from ebda.temp_budgets where id=(req->>'id'); return jsonb_build_object('ok',true); end if;

  if action = 'addSchool' then
    newid := ebda.uid();
    insert into ebda.schools(id,name,type,period,students,active,category)
    values(newid, req#>>'{school,name}', coalesce(req#>>'{school,type}',''), coalesce(req#>>'{school,period}',''),
       coalesce((req#>>'{school,students}')::numeric,0), 'نعم', coalesce(req#>>'{school,category}','school'));
    return jsonb_build_object('ok',true,'item',(select to_jsonb(s) from ebda.schools s where s.id=newid));
  end if;
  if action = 'updateSchool' then
    patch := req->'patch';
    update ebda.schools set name=coalesce(patch->>'name',name), type=coalesce(patch->>'type',type),
      period=coalesce(patch->>'period',period), students=coalesce((patch->>'students')::numeric,students),
      category=coalesce(patch->>'category',category), active=coalesce(patch->>'active',active)
    where id=(req->>'id');
    return jsonb_build_object('ok',true);
  end if;
  if action = 'deleteSchool' then delete from ebda.schools where id=(req->>'id'); return jsonb_build_object('ok',true); end if;

  if action = 'updateLine' then
    patch := req->'patch';
    update ebda.lines set section=coalesce(patch->>'section',section), name=coalesce(patch->>'name',name),
      allocated=coalesce((patch->>'allocated')::numeric,allocated), note=coalesce(patch->>'note',note)
    where id=(req->>'id');
    return jsonb_build_object('ok',true);
  end if;
  if action = 'deleteLine' then delete from ebda.lines where id=(req->>'id'); return jsonb_build_object('ok',true); end if;

  if action = 'importBudget' then
    sid := req->>'school_id';
    if req ? 'newSchool' then
      newid := ebda.uid();
      insert into ebda.schools(id,name,type,period,students,active,category)
      values(newid, req#>>'{newSchool,name}', coalesce(req#>>'{newSchool,type}',''), coalesce(req#>>'{newSchool,period}',''),
         0, 'نعم', coalesce(req#>>'{newSchool,category}','school'));
      sid := newid;
    end if;
    delete from ebda.lines where school_id = sid;
    for ln in select * from jsonb_array_elements(coalesce(req->'lines','[]'::jsonb)) loop
      insert into ebda.lines(id,school_id,section,name,allocated,note)
      values(ebda.uid(), sid, coalesce(ln->>'section',''), coalesce(ln->>'name',''), coalesce((ln->>'allocated')::numeric,0), '');
    end loop;
    return jsonb_build_object('ok',true,'school_id',sid,'count',jsonb_array_length(coalesce(req->'lines','[]'::jsonb)));
  end if;

  if action = 'addSpendItem' then newid:=ebda.uid(); insert into ebda.spend_items(id,name) values(newid, req#>>'{item,name}'); return jsonb_build_object('ok',true,'item',(select to_jsonb(x) from ebda.spend_items x where x.id=newid)); end if;
  if action = 'deleteSpendItem' then delete from ebda.spend_items where id=(req->>'id'); return jsonb_build_object('ok',true); end if;
  if action = 'addHolder' then newid:=ebda.uid(); insert into ebda.holders(id,name,title) values(newid, req#>>'{item,name}', coalesce(req#>>'{item,title}','')); return jsonb_build_object('ok',true,'item',(select to_jsonb(x) from ebda.holders x where x.id=newid)); end if;
  if action = 'deleteHolder' then delete from ebda.holders where id=(req->>'id'); return jsonb_build_object('ok',true); end if;

  if action = 'addUser' then
    newid := ebda.uid();
    insert into ebda.users(id,username,pin,name,role,schools,active,email)
    values(newid, req#>>'{user,username}', req#>>'{user,pin}', req#>>'{user,name}', coalesce(req#>>'{user,role}','custody'),
       coalesce(req#>>'{user,schools}',''), coalesce(req#>>'{user,active}','نعم'), coalesce(req#>>'{user,email}',''));
    return jsonb_build_object('ok',true,'item',(select to_jsonb(x) from ebda.users x where x.id=newid));
  end if;
  if action = 'updateUser' then
    patch := req->'patch';
    update ebda.users set username=coalesce(patch->>'username',username), pin=coalesce(patch->>'pin',pin),
      name=coalesce(patch->>'name',name), role=coalesce(patch->>'role',role), schools=coalesce(patch->>'schools',schools),
      active=coalesce(patch->>'active',active), email=coalesce(patch->>'email',email)
    where id=(req->>'id');
    return jsonb_build_object('ok',true);
  end if;
  if action = 'deleteUser' then delete from ebda.users where id=(req->>'id'); return jsonb_build_object('ok',true); end if;

  return jsonb_build_object('error','إجراء غير معروف: '||coalesce(action,''));
end;
$fn$;

-- ---------- الصلاحيات: كشف الدالة فقط للعامة، لا الجداول ----------
-- غلاف فى public ليكتشفه PostgREST (الجداول تبقى فى ebda غير مكشوفة)
create or replace function public.api(req jsonb) returns jsonb
  language sql security definer set search_path = ebda, public
  as $wrap$ select ebda.api(req) $wrap$;

revoke all on all tables in schema ebda from anon, authenticated;
grant usage on schema ebda to anon, authenticated;
grant execute on function ebda.api(jsonb) to anon, authenticated;
grant execute on function public.api(jsonb) to anon, authenticated;

-- ---------- بذور أولية ----------
create or replace function ebda.seed() returns text language plpgsql as $seed$
declare badr text; dam text; comp text; trg text; trv text;
begin
  if exists(select 1 from ebda.users) then return 'موجود مسبقاً'; end if;
  insert into ebda.users(id,username,pin,name,role,schools,active,email) values (ebda.uid(),'admin','1234','المدير العام','manager','*','نعم','');
  insert into ebda.spend_items(id,name) select ebda.uid(), x from unnest(array[
    'أدوات مكتبية ونظافة ومستهلكات وبوفيه','مستهلكات للورش التدريبية','انتقالات','صيانة المنشأة والورش','مصاريف نثرية','بوفيه']) x;
  insert into ebda.holders(id,name,title) values (ebda.uid(),'أحمد سمير','مدير مدرسة'),(ebda.uid(),'منى فؤاد','منسق');
  insert into ebda.approvers(id,name,email) values (ebda.uid(),'المدير المالى','finance@ebda.com.eg'),(ebda.uid(),'رئيس العمليات','ops@ebda.com.eg');
  insert into ebda.emails(id,email,label) values (ebda.uid(),'ebda.edu@ebda.com.eg','الإدارة');
  badr:=ebda.uid(); dam:=ebda.uid(); comp:=ebda.uid(); trg:=ebda.uid(); trv:=ebda.uid();
  insert into ebda.schools(id,name,type,period,students,active,category) values
   (badr,'مدرسة ابدأ للعلوم التقنية — بدر','مدرسة','2026/2027',253,'نعم','school'),
   (dam,'مدرسة ابدأ للعلوم التقنية — دمياط','مدرسة','2026/2027',255,'نعم','school'),
   (comp,'الشركة — العهدة الداخلية','الشركة','2026/2027',0,'نعم','company'),
   (trg,'التدريب العام','تدريب','2026/2027',0,'نعم','training_general'),
   (trv,'التدريب المهنى','تدريب','2026/2027',0,'نعم','training_vocational');
  return 'تم';
end; $seed$;
select ebda.seed();
