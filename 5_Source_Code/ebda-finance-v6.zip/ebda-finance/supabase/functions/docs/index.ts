// Edge Function «docs»: رفع المستندات إلى Supabase Storage (حاوية خاصة ebda-docs) وقراءتها بروابط مؤقتة.
// الصلاحية تُحسم فى قاعدة البيانات (docAuth) بتوكن المستخدم؛ والمفتاح الخدمى لا يغادر الخادم.
//   POST {token, action:"upload", expense_id, filename, mime, dataBase64, doc_type}
//   POST {token, action:"url", expense_id}      → {url} صالح لمدة ساعة
import { CORS, env, json, rpc } from "../_shared/rpc.ts";

const BUCKET = "ebda-docs";
const MAX = 10 * 1024 * 1024;
const ALLOWED = /^(image\/(png|jpe?g|webp|gif|heic)|application\/pdf)$/i;

function b64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
const safeName = (n: string) => (n || "document").replace(/[^\p{L}\p{N}._-]+/gu, "_").slice(-80);

export async function handle(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  const base = env("SUPABASE_URL").replace(/\/+$/, "") + "/storage/v1";
  const srv = env("SUPABASE_SERVICE_ROLE_KEY");
  const sh = { Authorization: "Bearer " + srv, apikey: srv };
  try {
    const body = await req.json();
    const { token, action, expense_id } = body;
    if (!token || !expense_id) return json({ error: "طلب غير صحيح" }, 400);

    if (action === "upload") {
      const auth = await rpc(token, "docAuth", { expense_id, mode: "upload" });
      const mime = String(body.mime || "");
      if (!ALLOWED.test(mime)) return json({ error: "نوع الملف غير مسموح (صورة أو PDF فقط)" }, 400);
      const bytes = b64ToBytes(String(body.dataBase64 || ""));
      if (!bytes.length || bytes.length > MAX) return json({ error: "حجم الملف غير مسموح (حتى 10 ميجا)" }, 400);
      const path = auth.path + Date.now() + "_" + safeName(String(body.filename || ""));
      const up = await fetch(`${base}/object/${BUCKET}/${encodeURI(path)}`, {
        method: "POST", headers: { ...sh, "Content-Type": mime, "x-upsert": "false" }, body: bytes,
      });
      if (!up.ok) return json({ error: "فشل الرفع: " + (await up.text()).slice(0, 200) }, 502);
      // تسجيل المستند على المصروف عبر api() بنفس صلاحيات المستخدم
      await rpc(token, "uploadDoc", { id: expense_id, link: "storage:" + path, filename: body.filename || "مستند", doc_type: body.doc_type || "" });
      if (auth.current) {  // حذف النسخة السابقة
        await fetch(`${base}/object/${BUCKET}`, { method: "DELETE", headers: { ...sh, "Content-Type": "application/json" }, body: JSON.stringify({ prefixes: [auth.current] }) });
      }
      return json({ ok: true, url: "storage:" + path });
    }

    if (action === "url") {
      const auth = await rpc(token, "docAuth", { expense_id, mode: "read" });
      if (!auth.current) return json({ error: "لا يوجد مستند مخزّن لهذا المصروف" }, 404);
      const s = await fetch(`${base}/object/sign/${BUCKET}/${encodeURI(auth.current)}`, {
        method: "POST", headers: { ...sh, "Content-Type": "application/json" }, body: JSON.stringify({ expiresIn: 3600 }),
      });
      const d = await s.json();
      if (!s.ok || !d.signedURL) return json({ error: "تعذّر إنشاء رابط المستند" }, 502);
      return json({ ok: true, url: base + d.signedURL });
    }
    return json({ error: "إجراء غير معروف" }, 400);
  } catch (e) {
    return json({ ok: false, error: String((e as Error).message || e) }, 400);
  }
}

if (typeof Deno !== "undefined" && (Deno as any).serve) Deno.serve(handle);
