// يستدعى دالة api() بتوكن جلسة المستخدم نفسه — فتُطبَّق كل صلاحيات قاعدة البيانات كما هى.
export const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
export function env(name: string): string {
  const v = Deno.env.get(name);
  if (!v) throw new Error("missing env " + name);
  return v;
}
export function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });
}
export async function rpc(token: string, action: string, payload: Record<string, unknown> = {}) {
  const url = env("SUPABASE_URL").replace(/\/+$/, "") + "/rest/v1/rpc/api";
  const key = env("SUPABASE_ANON_KEY");
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", apikey: key, Authorization: "Bearer " + key },
    body: JSON.stringify({ req: { action, ...payload, auth: { token } } }),
  });
  const data = await res.json();
  if (!data || data.error) throw new Error((data && data.error) || "rpc failed");
  return data;
}
