// Edge Function «notify»: إرسال إشعارات البريد بعد الاعتماد/الرفض/التسوية/طلبات العهد.
// المستلمون والمحتوى تُحدَّد داخل قاعدة البيانات (notifyInfo) بعد التحقق من صلاحية صاحب التوكن،
// فلا يستطيع أحد استخدام الدالة لإرسال بريد عشوائى.
// الأسرار المطلوبة: RESEND_API_KEY ، NOTIFY_FROM (مثال: "ابدأ إديو <noreply@ebda.com.eg>")
import { CORS, env, json, rpc } from "../_shared/rpc.ts";

const EVENTS = new Set(["expense_new", "expense_decided", "expense_fin", "expense_review",
  "request_new", "request_decided", "request_transferred", "custody_submitted"]);

export async function handle(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  try {
    const { token, event, id } = await req.json();
    if (!token || !EVENTS.has(event) || !id) return json({ error: "طلب غير صحيح" }, 400);
    const info = await rpc(token, "notifyInfo", { event, id });
    const to: string[] = info.to || [];
    if (!to.length) return json({ ok: true, sent: 0, note: "لا يوجد مستلمون بإيميل مسجّل" });
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: "Bearer " + env("RESEND_API_KEY"), "Content-Type": "application/json" },
      body: JSON.stringify({ from: env("NOTIFY_FROM"), to, subject: info.subject, html: info.html }),
    });
    if (!r.ok) return json({ ok: false, error: "فشل إرسال البريد: " + (await r.text()).slice(0, 200) }, 502);
    return json({ ok: true, sent: to.length });
  } catch (e) {
    return json({ ok: false, error: String((e as Error).message || e) }, 400);
  }
}

if (typeof Deno !== "undefined" && (Deno as any).serve) Deno.serve(handle);
