"""Targeted, verifiable patches to the compiled frontend (bundle.js).
Each patch asserts its anchor occurs exactly the expected number of times, so a wrong
or already-applied patch fails loudly instead of corrupting the bundle.
usage: python3 patch_bundle.py <in bundle.js> <out bundle.js>"""
import sys

src, dst = sys.argv[1], sys.argv[2]
s = open(src, encoding='utf8').read()
if 'EBDA_PATCH_V1' in s:
    sys.exit('bundle already patched')


def U(t):  # Arabic -> \uXXXX escapes (same style as the bundle)
    return ''.join(c if ord(c) < 128 else '\\u%04X' % ord(c) for c in t)


def P(old, new, count=1, name=''):
    global s
    n = s.count(old)
    assert n == count, f'patch {name!r}: anchor found {n} times, expected {count}: {old[:80]}'
    s = s.replace(old, new)


# 1) أسماء الأدوار الجديدة (القيم المخزنة تبقى manager/accountant/supervisor/custody)
OLD_LBL = {'manager': 'مدير البرنامج', 'accountant': 'محاسب المتابعة', 'supervisor': 'مدير مباشر', 'custody': 'مسئول عهدة'}
NEW_LBL = {'manager': 'الأدمن', 'accountant': 'المدير المالى', 'supervisor': 'المدير المباشر', 'custody': 'مسئول العهدة'}
old_map = '{' + ','.join(f'{k}:"{U(v)}"' for k, v in OLD_LBL.items()) + '}'
new_map = '{' + ','.join(f'{k}:"{U(v)}"' for k, v in NEW_LBL.items()) + '}'
P(old_map, new_map, 2, 'role label maps')
for k, old_t, new_t in [
    ('manager', 'مدير البرنامج (كل شىء)', 'الأدمن (كل الصلاحيات وإدارة المستخدمين)'),
    ('accountant', 'محاسب المتابعة (موازنات بلا تعديل + مراجعة المستندات)', 'المدير المالى (الموازنات والعهد والاعتماد المالى والتسوية)'),
    ('supervisor', 'مدير مباشر (موازنات بلا تعديل + اعتماد)', 'المدير المباشر (اعتماد طلبات ومصروفات جهاته فقط)'),
    ('custody', 'مسئول عهدة (تسجيل الصرف ورفع المستندات)', 'مسئول العهدة (عهدته فقط: تسجيل الصرف والمستندات وطلب عهدة)')]:
    P(f'{{value:"{k}"}},"{U(old_t)}"', f'{{value:"{k}"}},"{U(new_t)}"', 1, 'role option ' + k)

# 2) نموذج المستخدم: كلمة السر لا تُرسل من الخادم بعد الآن (مشفّرة) — اتركها فارغة عند التعديل للإبقاء عليها
P('[d,c]=T(t?t.pin:"")', '[d,c]=T("")', 1, 'user form pin init')
P('x=()=>{if(!i.trim()||!s.trim()||!d)return;let C={name:i.trim(),username:s.trim(),pin:String(d),',
  'x=()=>{if(!i.trim()||!s.trim()||!t&&!d)return;let C={name:i.trim(),username:s.trim(),pin:d?String(d):"",', 1, 'user form save')

# 3) الأثر على الموازنة: بعد الاعتماد المالى (أو التسوية القديمة)، والمرفوض مالياً لا يُخصم من العهدة
P('o=u.approval!=="rejected",d=it(u.settled);',
  'o=u.approval!=="rejected"&&u.fin_approval!=="rejected",d=u.approval==="approved"&&u.fin_approval!=="rejected"&&(it(u.settled)||u.fin_approval==="approved");',
  1, 'budget impact rule')

# 4) شارة الحالة: إضافة مرحلة الاعتماد المالى
P('function Md({s:t,sett:l}){', 'function Md({s:t,sett:l,fin:EF}){', 1, 'Md signature')
P('return a.createElement("span",null,a.createElement("span",{className:"chip "+i},n),t==="approved"&&(l?',
  'return a.createElement("span",null,a.createElement("span",{className:"chip "+i},n),t==="approved"&&EF!==void 0&&(EF==="approved"?'
  f'a.createElement("span",{{className:"chip green"}},"{U(" معتمد مالياً")}"):EF==="rejected"?a.createElement("span",{{className:"chip red"}},"{U(" مرفوض مالياً")}"):'
  f'a.createElement("span",{{className:"chip amber"}},"{U(" بانتظار الاعتماد المالى")}")),t==="approved"&&(l?', 1, 'Md fin chip')
P('a.createElement(Md,{s:E.approval,sett:it(E.settled)})', 'a.createElement(Md,{s:E.approval,sett:it(E.settled),fin:E.fin_approval||""})', 1, 'Md call')

# 5) أزرار الاعتماد المالى + التسوية بعد الاعتماد المالى فقط + رقم العملية
P('n&&E.approval==="approved"&&E.doc_url&&!it(E.settled)&&a.createElement("button",{className:"btn teal sm",onClick:()=>u({type:"review",payload:E})}',
  f'n&&E.approval==="approved"&&!E.fin_approval&&a.createElement("button",{{className:"btn primary sm",onClick:()=>{{(typeof window=="undefined"||window.confirm("{U("اعتماد هذا المصروف مالياً؟ سيُخصم من الموازنة")}"))&&i("reviewExpense",{{id:E.id,patch:{{fin_approval:"approved"}}}}).then(()=>s("{U("تم الاعتماد المالى")}")).catch(()=>{{}})}}}},"{U("اعتماد مالى")}"),'
  f'n&&E.approval==="approved"&&!E.fin_approval&&a.createElement("button",{{className:"btn danger-ghost sm",onClick:()=>{{let RN=typeof window=="undefined"?"":window.prompt("{U("سبب الرفض المالى")}");RN&&i("reviewExpense",{{id:E.id,patch:{{fin_approval:"rejected",fin_note:RN}}}}).then(()=>s("{U("تم الرفض المالى")}")).catch(()=>{{}})}}}},"{U("رفض مالى")}"),'
  'n&&E.approval==="approved"&&E.fin_approval==="approved"&&E.doc_url&&!it(E.settled)&&a.createElement("button",{className:"btn teal sm",onClick:()=>u({type:"review",payload:E})}',
  1, 'fin approve buttons')
P(f'a.createElement("span",null,"{U("البند: ")}",a.createElement("b",null,Bu(t,E.line_id)||E.spend_item||"\\u2014")),',
  f'E.txn_no&&a.createElement("span",null,"{U("رقم العملية: ")}",a.createElement("b",null,E.txn_no)),a.createElement("span",null,"{U("البند: ")}",a.createElement("b",null,Bu(t,E.line_id)||E.spend_item||"\\u2014")),',
  1, 'txn no in expense card')
P('E.review_note&&a.createElement("div",{style:{fontSize:12.5,color:"var(--red)",marginTop:6,background:"#FDF2F2",padding:"6px 10px",borderRadius:8}},',
  f'E.fin_note&&a.createElement("div",{{style:{{fontSize:12.5,color:"var(--red)",marginTop:6,background:"#FDF2F2",padding:"6px 10px",borderRadius:8}}}},"{U("ملاحظة المدير المالى: ")}",E.fin_note),'
  'E.review_note&&a.createElement("div",{style:{fontSize:12.5,color:"var(--red)",marginTop:6,background:"#FDF2F2",padding:"6px 10px",borderRadius:8}},', 1, 'fin note')

# 6) فلتر المصروفات: «بانتظار الاعتماد المالى» + مراجعة المستند بعد الاعتماد المالى
P('||m==="review"&&!(E.approval==="approved"&&E.doc_url&&!it(E.settled)&&',
  '||m==="fin"&&!(E.approval==="approved"&&!E.fin_approval)||m==="review"&&!(E.approval==="approved"&&E.fin_approval==="approved"&&E.doc_url&&!it(E.settled)&&', 1, 'filter fin')
P(f'a.createElement("option",{{value:"needdoc"}},',
  f'a.createElement("option",{{value:"fin"}},"{U("بانتظار الاعتماد المالى")}"),a.createElement("option",{{value:"needdoc"}},', 1, 'filter option fin')

# 7) حالات طلب العهدة (مع المرحلة المحسوبة stage من الخادم)
P(f'pending_accountant:["{U("بانتظار تحويل المحاسب")}","navy"],transferred:["{U("تم التحويل للموظف")}","green"],',
  f'pending_accountant:["{U("معتمد من المدير المباشر · بانتظار الاعتماد المالى")}","navy"],transferred:["{U("معتمد مالياً · تم التحويل للعهدة")}","green"],'
  f'spent:["{U("تم الصرف من العهدة")}","teal"],settled:["{U("تمت التسوية")}","green"],', 1, 'request status labels')
P('let[b,f]=r[N.status]||["\\u2014","gray"]', 'let[b,f]=r[N.stage||N.status]||r[N.status]||["\\u2014","gray"]', 1, 'request stage')

# 8) أنواع الجهات: مشروعات/برامج/دورات التدريب
NEWCAT = [('training_project', 'مشروع تدريب'), ('training_program', 'برنامج تدريب'), ('training_course', 'دورة تدريبية')]
P(f'training_vocational:"{U("تدريب مهنى")}"}},Td=',
  f'training_vocational:"{U("تدريب مهنى")}",' + ','.join(f'{k}:"{U(v)}"' for k, v in NEWCAT) + '},Td=', 1, 'Tt categories')
P(f'["training_vocational","{U("تدريب مهنى")}"]],Od=',
  f'["training_vocational","{U("تدريب مهنى")}"],' + ','.join(f'["{k}","{U(v)}"]' for k, v in NEWCAT) + '],Od=', 1, 'Hv categories')
P(f'["training_vocational","{U("تدريب مهنى")}"]],Sl=',
  f'["training_vocational","{U("تدريب مهنى")}"],' + ','.join(f'["{k}","{U(v)}"]' for k, v in NEWCAT) + '],Sl=', 1, 'Od categories')
P(f'{{cat:"training_vocational",label:"{U("مهنى")}"}}]',
  f'{{cat:"training_vocational",label:"{U("مهنى")}"}},' + ','.join(f'{{cat:"{k}",label:"{U(lbl)}"}}' for k, lbl in [('training_project','مشروعات'),('training_program','برامج'),('training_course','دورات')]) + ']', 1, 'custody groups')

# 9) العهدة: الكود والحالة + تقديم للتسوية / تسوية / إغلاق / إعادة فتح، والحذف للأدمن فقط
CS = {'open': ('مفتوحة', 'green'), 'pending_settlement': ('فى انتظار التسوية', 'amber'), 'settled': ('تمت التسوية', 'navy'), 'closed': ('مغلقة', 'gray')}
cs_map = '{' + ','.join(f'{k}:["{U(v[0])}","{v[1]}"]' for k, v in CS.items()) + '}'
P('a.createElement("b",null,t.label),',
  f'a.createElement("b",null,t.label),t.code&&a.createElement("span",{{className:"chip gray",style:{{marginInlineStart:6}}}},t.code),'
  f'(()=>{{let ST=t.status||"open",CM={cs_map},[TX,CL]=CM[ST]||CM.open;ST==="open"&&r>0&&(TX="{U("بها مصروفات")}",CL="teal");return a.createElement("span",{{className:"chip "+CL,style:{{marginInlineStart:6}}}},TX)}})(),',
  1, 'custody code/status chip')
P('i&&a.createElement(h0,{data:l,custody:t,act:s,showToast:o}),',
  f'i&&(t.status||"open")==="open"&&a.createElement(h0,{{data:l,custody:t,act:s,showToast:o}}),(t.status||"open")!=="open"&&a.createElement("div",{{className:"warn-banner"}},"{U("العهدة ليست مفتوحة — لا يمكن تسجيل مصروفات جديدة عليها. بعد التسوية اطلب عهدة جديدة.")}"),',
  1, 'record only on open custody')
ACT = (f'l.me&&l.me.role==="custody"&&String(t.user||"")===String(l.me.username)&&(t.status||"open")==="open"&&a.createElement("button",{{className:"btn primary sm",onClick:()=>{{(typeof window=="undefined"||window.confirm("{U("تقديم العهدة للتسوية؟ لن تستطيع إضافة مصروفات بعدها")}"))&&s("updateCustody",{{id:t.id,patch:{{status:"pending_settlement"}}}}).then(()=>o("{U("تم تقديم العهدة للتسوية")}")).catch(()=>{{}})}}}},"{U("تقديم للتسوية")}"),'
       f'u&&["open","pending_settlement"].indexOf(t.status||"open")>=0&&a.createElement("button",{{className:"btn teal sm",onClick:()=>{{(typeof window=="undefined"||window.confirm("{U("اعتماد تسوية العهدة؟")}"))&&s("updateCustody",{{id:t.id,patch:{{status:"settled"}}}}).then(()=>o("{U("تمت تسوية العهدة")}")).catch(()=>{{}})}}}},"{U("اعتماد التسوية")}"),'
       f'u&&(t.status||"open")==="settled"&&a.createElement("button",{{className:"btn ghost sm",onClick:()=>s("updateCustody",{{id:t.id,patch:{{status:"closed"}}}}).then(()=>o("{U("تم إغلاق العهدة")}")).catch(()=>{{}})}},"{U("إغلاق العهدة")}"),'
       f'u&&["settled","closed","pending_settlement"].indexOf(t.status||"open")>=0&&a.createElement("button",{{className:"btn ghost sm",onClick:()=>s("updateCustody",{{id:t.id,patch:{{status:"open"}}}}).then(()=>o("{U("أُعيد فتح العهدة")}")).catch(()=>{{}})}},"{U("إعادة فتح")}"),')
P('margin:"10px 0"}},u&&a.createElement("button",{className:"btn teal sm",onClick:()=>d({type:"tranche",payload:t})}',
  'margin:"10px 0"}},' + ACT + 'u&&(t.status||"open")==="open"&&a.createElement("button",{className:"btn teal sm",onClick:()=>d({type:"tranche",payload:t})}',
  1, 'custody actions')
P('u&&a.createElement("button",{className:"btn danger-ghost sm",onClick:()=>{(typeo', 'n&&a.createElement("button",{className:"btn danger-ghost sm",onClick:()=>{(typeo', 1, 'delete custody admin only')

s = '/*EBDA_PATCH_V1 roles+financial-approval+custody-lifecycle*/' + s
open(dst, 'w', encoding='utf8').write(s)
print('patched OK ->', dst)
