  -- ================================================================ v6: البحث فى المصروفات والتقارير الديناميكية — على الخادم
  -- (فلترة + تجميع + ترقيم صفحات داخل قاعدة البيانات، وتُرسل النتائج المطلوبة فقط، وكل ذلك داخل نطاق المستخدم)
  if action in ('searchExpenses','report') then
    declare
      f jsonb := coalesce(req->'filters','{}'::jsonb);
      rkind text := coalesce(req->>'kind', 'expenses');
      star boolean := coalesce(u.schools,'')='*' or urole='admin';
      sch text[] := ebda.scope_arr(u);
      lo text := coalesce(nullif(req#>>'{filters,from}',''), '0000');
      hi text := coalesce(nullif(req#>>'{filters,to}',''), '9999');
      ps int := least(greatest(coalesce(nullif(req->>'page_size','')::int, 50), 1), case when action='report' then 5000 else 500 end);
      pg int := greatest(coalesce(nullif(req->>'page','')::int, 1) - 1, 0);
      odays int := ebda.cfg_int('custody_overdue_days', 30);
      can_appr boolean := ebda.can(u,'expense.approve');
      can_fin boolean := ebda.can(u,'expense.fin_approve');
      stages text[] := case when jsonb_typeof(req#>'{filters,stages}')='array' then array(select jsonb_array_elements_text(req#>'{filters,stages}')) else '{}'::text[] end;
    begin
    if action = 'searchExpenses' or rkind = 'expenses' then
      return (with v as materialized (
        select e.id, e.date, e.txn_no, e.amount, e.custody_id, e.school_id, e.line_id, e.created_by_id, ebda.expense_stage(e) stage
        from (select * from ebda.expenses where urole = 'admin' union all select * from ebda.vis_expenses(u) where urole <> 'admin') e
        where true
          and (coalesce(f->>'school_id','') = '' or e.school_id = f->>'school_id')
          and (coalesce(f->>'custody_id','') = '' or e.custody_id = f->>'custody_id')
          and (coalesce(f->>'line_id','') = '' or e.line_id = f->>'line_id')
          and (coalesce(f->>'spend_item','') = '' or e.spend_item = f->>'spend_item')
          and (coalesce(f->>'from','') = '' or e.date >= f->>'from')
          and (coalesce(f->>'to','') = '' or e.date <= f->>'to')
          and (coalesce(f->>'q','') = '' or e.txn_no ilike '%'||(f->>'q')||'%' or e.description ilike '%'||(f->>'q')||'%'
               or coalesce(e.supplier,'') ilike '%'||(f->>'q')||'%' or coalesce(e.doc_no,'') ilike '%'||(f->>'q')||'%')
          and (coalesce(f->>'import_batch','') = '' or e.import_batch = f->>'import_batch')
          and (cardinality(stages) = 0 or ebda.expense_stage(e) = any(stages))
          and (coalesce(f->>'no_doc','') <> '1' or coalesce(e.doc_url,'') = '')
          and (coalesce(f->>'incomplete','') <> '1' or coalesce(e.review_status,'') like '%ناقص%')
      ), base as (
        select v.*, o.manager_id as mgr_id from v
        left join ebda.custodies c on c.id = v.custody_id
        left join ebda.users o on o.id = c.user_id
        where (coalesce(f->>'holder_id','') = '' or c.user_id = f->>'holder_id')
          and (coalesce(f->>'holder','') = '' or coalesce(nullif(c.holder,''), c.label, '') = f->>'holder')
          and (coalesce(f->>'manager_id','') = '' or o.manager_id = f->>'manager_id')
          and (coalesce(f->>'kind','') = '' or c.kind = f->>'kind')
          and (coalesce(f->>'title','') = '' or c.title = f->>'title')
          and (coalesce(f->>'mine','') <> '1' or c.user_id = u.id)
          and (coalesce(f->>'my_queue','') <> '1' or (
                 (v.stage = 'pending_manager' and can_appr and c.id is not null
                   and not ebda.owns_custody(u, c) and coalesce(v.created_by_id,'') <> u.id
                   and (urole = 'admin' or (coalesce(o.manager_id,'') <> '' and o.manager_id = u.id)
                        or (coalesce(o.manager_id,'') = '' and (star or c.school_id = any(sch)))))
              or (v.stage in ('pending_finance','reviewed') and can_fin
                   and not (c.id is not null and ebda.owns_custody(u, c)) and coalesce(v.created_by_id,'') <> u.id)
              or (v.stage in ('draft','returned','fin_returned') and c.id is not null and ebda.owns_custody(u, c))))
      ), page as (
        select base.id, base.stage, base.mgr_id from base
        order by case when coalesce(req->>'sort','') = 'amount' then null else base.date end desc nulls last,
                 case when coalesce(req->>'sort','') = 'amount' then base.amount end desc nulls last,
                 base.txn_no desc
        limit ps offset pg * ps
      )
      select jsonb_build_object('ok', true,
        'total', (select count(*) from base),
        'sum', (select coalesce(sum(amount),0) from base where stage not in ('cancelled','rejected','fin_rejected')),
        'by_stage', coalesce((select jsonb_object_agg(stage, jsonb_build_object('n', cnt, 'amount', amt)) from
                     (select stage, count(*) cnt, sum(amount) amt from base group by stage) z), '{}'::jsonb),
        'rows', coalesce((select jsonb_agg(jsonb_build_object(
            'id', e.id, 'txn_no', e.txn_no, 'date', e.date, 'school_id', e.school_id, 'school', s.name, 'category', s.category,
            'custody_id', e.custody_id, 'custody_code', coalesce(c.code, 'شراء مركزى'), 'custody_title', coalesce(nullif(c.title,''), c.label, ''),
            'custody_kind', coalesce(c.kind,''), 'holder', coalesce(nullif(c.holder,''), c.label, ''), 'holder_id', coalesce(c.user_id,''),
            'manager_id', coalesce(p.mgr_id,''), 'manager', coalesce(m.name,''),
            'line_id', e.line_id, 'line', coalesce(l.name,''), 'section', coalesce(l.section,''), 'spend_item', coalesce(e.spend_item,''),
            'description', e.description, 'amount', e.amount, 'pay_method', coalesce(e.pay_method,''), 'stage', p.stage,
            'approval', e.approval, 'approved_by', coalesce(e.approved_by,''), 'approved_at', coalesce(e.approved_at,''), 'approval_note', coalesce(e.approval_note,''),
            'fin_approval', coalesce(e.fin_approval,''), 'fin_by', coalesce(e.fin_by,''), 'fin_at', coalesce(e.fin_at,''), 'fin_note', coalesce(e.fin_note,''),
            'settled', coalesce(e.settled,''), 'settled_by', coalesce(e.settled_by,''), 'settled_at', coalesce(e.settled_at,''),
            'review_status', coalesce(e.review_status,''), 'review_note', coalesce(e.review_note,''),
            'return_reason', coalesce(e.return_reason,''), 'returned_by', coalesce(e.returned_by,''), 'returned_at', coalesce(e.returned_at,''),
            'cancel_reason', coalesce(e.cancel_reason,''), 'cancelled_by', coalesce(e.cancelled_by,''), 'cancelled_at', coalesce(e.cancelled_at,''),
            'created_by', coalesce(e.created_by,''), 'created_by_id', coalesce(e.created_by_id,''), 'created_at', coalesce(e.created_at,''),
            'submitted_at', coalesce(e.submitted_at,''), 'doc_name', coalesce(e.doc_name,''), 'doc_type', coalesce(e.doc_type,''),
            'doc_url', case when e.doc_url like 'data:%' then 'inline:' else coalesce(e.doc_url,'') end)
            || jsonb_build_object('supplier', coalesce(e.supplier,''), 'doc_no', coalesce(e.doc_no,''), 'import_batch', coalesce(e.import_batch,''))
            order by case when coalesce(req->>'sort','') = 'amount' then null else e.date end desc nulls last,
                     case when coalesce(req->>'sort','') = 'amount' then e.amount end desc nulls last, e.txn_no desc)
          from page p join ebda.expenses e on e.id = p.id
          left join ebda.custodies c on c.id = e.custody_id left join ebda.schools s on s.id = e.school_id
          left join ebda.lines l on l.id = e.line_id left join ebda.users m on m.id = p.mgr_id), '[]'::jsonb)));
    end if;

    if rkind = 'custodyHolder' then   -- تقرير حالة عهد مسئول/مسئولين (فلتر واحد أو أكثر)
      return (with vc as materialized (
        select c.* from ebda.vis_custodies(u) c
        where (coalesce(f->>'holder_id','')='' or c.user_id = f->>'holder_id')
          and (coalesce(f->>'holder','')='' or coalesce(nullif(c.holder,''), c.label, '') = f->>'holder')
          and (coalesce(f->>'school_id','')='' or c.school_id = f->>'school_id')
          and (coalesce(f->>'title','')='' or c.title = f->>'title')
          and (coalesce(f->>'kind','')='' or c.kind = f->>'kind')
      ), tr as (
        select t.custody_id, sum(t.amount) s, bool_or(t.date between lo and hi) inr from ebda.tranches t where t.custody_id = any(array(select id from vc)) group by 1
      ), ea as (
        select e.custody_id,
          sum(e.amount) filter (where ebda.active_on_custody(e)) spent,
          sum(e.amount) filter (where ebda.active_on_custody(e) and (coalesce(f->>'line_id','')='' or e.line_id=f->>'line_id') and e.date between lo and hi) f_spent,
          count(*) filter (where coalesce(e.cancelled_at,'')='' and ebda.expense_stage(e) in ('pending_manager','pending_finance')) under_review,
          count(*) filter (where ebda.active_on_custody(e) and e.approval='approved' and coalesce(e.settled,'') not like '%نعم%') unsettled,
          count(*) filter (where coalesce(e.cancelled_at,'')='' and coalesce(e.settled,'') not like '%نعم%'
             and (e.approval in ('rejected','returned') or e.fin_approval in ('rejected','returned') or coalesce(e.review_status,'') like '%ناقص%' or coalesce(e.review_note,'')<>'')) notes,
          bool_or(e.date between lo and hi) inr, bool_or(e.line_id = f->>'line_id') has_line
        from ebda.expenses e where e.custody_id = any(array(select id from vc)) group by 1
      ), cs as (
        select vc.*, s.name as s_name, coalesce(tr.s,0) received, coalesce(ea.spent,0) spent, coalesce(ea.f_spent,0) f_spent,
               coalesce(ea.under_review,0) under_review, coalesce(ea.unsettled,0) unsettled, coalesce(ea.notes,0) notes,
               greatest(ebda.days_since(vc.opened_at), 0) as age
        from vc left join ebda.schools s on s.id = vc.school_id left join tr on tr.custody_id = vc.id left join ea on ea.custody_id = vc.id
        where (coalesce(f->>'line_id','')='' or coalesce(ea.has_line,false)
               or exists(select 1 from ebda.custody_lines cl where cl.custody_id = vc.id and cl.line_id = f->>'line_id'))
          and ((coalesce(f->>'from','')='' and coalesce(f->>'to','')='') or left(coalesce(vc.opened_at,''),10) between lo and hi
               or coalesce(ea.inr,false) or coalesce(tr.inr,false))
      ), st as (
        select cs.*, case
            when coalesce(nullif(cs.status,''),'open') = 'open' and coalesce(cs.approval,'approved') = 'approved' and cs.notes > 0 then 'notes'
            when coalesce(nullif(cs.status,''),'open') = 'open' and coalesce(cs.approval,'approved') = 'approved' and cs.age > odays then 'overdue'
            else coalesce(nullif(cs.status,''),'open') end as state
        from cs
      ), fl as (
        select * from st
        where (coalesce(f->>'state','')='' or st.state = f->>'state')
          and (coalesce(f->>'settle','')='' or (f->>'settle'='settled' and st.state in ('settled','closed'))
               or (f->>'settle'='unsettled' and st.state not in ('settled','closed','cancelled')))
      )
      select jsonb_build_object('ok', true, 'kind', 'custodyHolder',
        'summary', jsonb_build_object(
          'holders', coalesce((select jsonb_agg(distinct coalesce(nullif(holder,''), label, '')) from fl), '[]'::jsonb),
          'count', (select count(*) from fl),
          'received', (select coalesce(sum(received),0) from fl where state <> 'cancelled'),
          'spent', (select coalesce(sum(spent),0) from fl where state <> 'cancelled'),
          'remaining', (select coalesce(sum(received - spent),0) from fl where state <> 'cancelled'),
          'filtered_spent', (select coalesce(sum(f_spent),0) from fl where state <> 'cancelled'),
          'open', (select count(*) from fl where state in ('open','notes','overdue','pending_settlement')),
          'settled', (select count(*) from fl where state in ('settled','closed')),
          'overdue', (select count(*) from fl where state = 'overdue'),
          'cancelled', (select count(*) from fl where state = 'cancelled'),
          'under_review', (select coalesce(sum(under_review),0) from fl where state <> 'cancelled'),
          'unsettled', (select coalesce(sum(unsettled),0) from fl where state <> 'cancelled'),
          'overdue_days', odays),
        'rows', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'code', code, 'title', coalesce(title,''), 'kind', coalesce(kind,''),
            'school_id', school_id, 'school', s_name, 'holder', coalesce(nullif(holder,''), label, ''), 'holder_id', coalesce(user_id,''),
            'opened_at', coalesce(opened_at,''), 'approval', coalesce(approval,'approved'), 'state', state, 'age', age,
            'received', received, 'spent', spent, 'remaining', received - spent, 'filtered_spent', f_spent,
            'under_review', under_review, 'unsettled', unsettled, 'notes', notes) order by code)
            from (select * from fl order by code limit 5000) z), '[]'::jsonb)));
    end if;

    if rkind = 'budget' then   -- تقرير الموازنة: المكان · السنة · النوع · البند · المخصص · المصروف · المتبقى · النسبة · الحالة (شهر أو سنة)
      return (with ents as materialized (
        select s.* from ebda.schools s where (star or s.id = any(sch))
          and (coalesce(f->>'school_id','')='' or s.id = f->>'school_id')
          and (coalesce(f->>'period','')='' or f->>'period'='all' or s.period = f->>'period')
          and (coalesce(f->>'category','')='' or f->>'category'='all' or coalesce(nullif(s.category,''),'school') = f->>'category')
      ), ls as (
        select l.*, e.name as e_name, e.period as e_period, coalesce(nullif(e.category,''),'school') as e_cat,
               ebda.fy_from(e.period) as f_from, ebda.fy_to(e.period) as f_to
        from ebda.lines l join ents e on e.id = l.school_id
        where coalesce(l.deleted_at,'')=''
          and (coalesce(f->>'line_id','')='' or l.id = f->>'line_id')
          and (coalesce(f->>'section','')='' or l.section = f->>'section')
      ), sp as (
        select z.line_id, sum(z.amount) filter (where coalesce(nullif(f->>'month',''),'0')::int = 0 or z.m = (f->>'month')::int) as amt
        from ebda.line_fy_spend(u) z group by 1
      ), r as (
        select ls.*, case when coalesce(nullif(f->>'month',''),'0')::int = 0 then coalesce(ls.allocated,0)
                          else ebda.plan_month(ls.monthly_plan, ls.allocated, (f->>'month')::int) end as alloc,
               coalesce(sp.amt,0) as spent
        from ls left join sp on sp.line_id = ls.id
      ), fs as (
        select r.*, ebda.budget_state(r.alloc, r.spent) as state from r
      ), gs as (
        select * from fs where coalesce(f->>'state','')='' or fs.state = f->>'state'
      )
      select jsonb_build_object('ok', true, 'kind', 'budget',
        'summary', jsonb_build_object('lines', (select count(*) from gs), 'alloc', (select coalesce(sum(alloc),0) from gs),
          'spent', (select coalesce(sum(spent),0) from gs), 'remaining', (select coalesce(sum(alloc - spent),0) from gs),
          'over', (select count(*) from gs where state='over'), 'reached', (select count(*) from gs where state='reached'),
          'near', (select count(*) from gs where state='near'), 'within', (select count(*) from gs where state='within')),
        'rows', coalesce((select jsonb_agg(jsonb_build_object('line_id', id, 'school_id', school_id, 'school', e_name, 'period', coalesce(e_period,''),
            'category', e_cat, 'section', coalesce(section,''), 'line', name, 'active', coalesce(active,'نعم'),
            'alloc', alloc, 'spent', spent, 'remaining', alloc - spent,
            'pct', case when alloc > 0.5 then spent / alloc when spent > 0.5 then 1 else 0 end, 'state', state)
            order by e_name, section, name) from gs), '[]'::jsonb)));
    end if;

    if rkind = 'financial' then   -- التقرير المالى الشامل: الموازنات + العهد + المصروفات + التسويات
      return (with ents as materialized (
        select s.* from ebda.schools s where (star or s.id = any(sch))
          and (coalesce(f->>'school_id','')='' or s.id = f->>'school_id')
          and (coalesce(f->>'period','')='' or f->>'period'='all' or s.period = f->>'period')
      ), ls as (
        select l.id, l.name, coalesce(l.allocated,0) alloc, ebda.fy_from(e.period) f_from, ebda.fy_to(e.period) f_to, e.name e_name
        from ebda.lines l join ents e on e.id=l.school_id where coalesce(l.deleted_at,'')=''
      ), lspent as (
        select z.line_id, sum(z.amount) s from ebda.line_fy_spend(u) z group by 1
      ), lsp as (
        select ls.id, ls.name, ls.e_name, ls.alloc, coalesce(lspent.s,0) spent from ls left join lspent on lspent.line_id = ls.id
      ), exx as materialized (
        select e.amount, ebda.expense_stage(e) stage
        from (select * from ebda.expenses where urole = 'admin' union all select * from ebda.vis_expenses(u) where urole <> 'admin') e
        where e.school_id in (select id from ents)
          and (coalesce(f->>'from','')='' or e.date >= f->>'from') and (coalesce(f->>'to','')='' or e.date <= f->>'to')
      ), vc as materialized (
        select c.* from ebda.vis_custodies(u) c where c.school_id in (select id from ents) and coalesce(c.status,'') <> 'cancelled'
      ), tr as (select t.custody_id, sum(t.amount) s from ebda.tranches t where t.custody_id = any(array(select id from vc)) group by 1
      ), ea as (
        select e.custody_id, sum(e.amount) filter (where ebda.active_on_custody(e)) spent,
          count(*) filter (where coalesce(e.cancelled_at,'')='' and coalesce(e.settled,'') not like '%نعم%'
             and (e.approval in ('rejected','returned') or e.fin_approval in ('rejected','returned') or coalesce(e.review_status,'') like '%ناقص%' or coalesce(e.review_note,'')<>'')) notes
        from ebda.expenses e where e.custody_id = any(array(select id from vc)) group by 1
      ), cu as (
        select vc.*, coalesce(tr.s,0) received, coalesce(ea.spent,0) spent, coalesce(ea.notes,0) notes
        from vc left join tr on tr.custody_id = vc.id left join ea on ea.custody_id = vc.id
      ), od as (
        select cu.* from cu where coalesce(nullif(cu.status,''),'open')='open' and coalesce(cu.approval,'approved')='approved'
          and greatest(ebda.days_since(cu.opened_at),0) > odays and cu.notes = 0
      )
      select jsonb_build_object('ok', true, 'kind', 'financial', 'summary', jsonb_build_object(
          'budget_total', (select coalesce(sum(alloc),0) from lsp),
          'budget_spent', (select coalesce(sum(spent),0) from lsp),
          'budget_remaining', (select coalesce(sum(alloc - spent),0) from lsp),
          'custody_total', (select coalesce(sum(received),0) from cu),
          'custody_spent', (select coalesce(sum(spent),0) from cu),
          'custody_remaining', (select coalesce(sum(received - spent),0) from cu),
          'expenses_total', (select coalesce(sum(amount),0) from exx where stage not in ('cancelled','rejected','fin_rejected')),
          'expenses_count', (select count(*) from exx where stage not in ('cancelled','rejected','fin_rejected')),
          'pending_manager', (select jsonb_build_object('n', count(*), 'amount', coalesce(sum(amount),0)) from exx where stage='pending_manager'),
          'pending_finance', (select jsonb_build_object('n', count(*), 'amount', coalesce(sum(amount),0)) from exx where stage='pending_finance'),
          'returned', (select jsonb_build_object('n', count(*), 'amount', coalesce(sum(amount),0)) from exx where stage in ('returned','fin_returned','draft')),
          'settled', (select jsonb_build_object('n', count(*), 'amount', coalesce(sum(amount),0)) from exx where stage='settled'),
          'unsettled', (select jsonb_build_object('n', count(*), 'amount', coalesce(sum(amount),0)) from exx where stage in ('pending_finance','reviewed')),
          'cancelled', (select jsonb_build_object('n', count(*), 'amount', coalesce(sum(amount),0)) from exx where stage='cancelled'),
          'over_lines', (select count(*) from lsp where ebda.budget_state(alloc, spent)='over'),
          'overdue_custodies', (select count(*) from od)),
        'over_lines', coalesce((select jsonb_agg(jsonb_build_object('line_id', id, 'line', name, 'school', e_name, 'alloc', alloc, 'spent', spent, 'over', spent - alloc)
                         order by spent - alloc desc) from (select * from lsp where ebda.budget_state(alloc, spent)='over' order by spent - alloc desc limit 500) z), '[]'::jsonb),
        'overdue_custodies', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'code', code, 'holder', coalesce(nullif(holder,''), label, ''),
                         'age', greatest(ebda.days_since(opened_at),0), 'remaining', received - spent) order by opened_at) from (select * from od order by opened_at limit 500) z), '[]'::jsonb)));
    end if;

    if rkind = 'lineMonths' then   -- المصروف المحتسب لكل بند لكل شهر من السنة المالية (للوحة المتابعة — يُحسب على الخادم)
      return jsonb_build_object('ok', true, 'line_months', ebda.line_months(u));
    end if;
    return ebda.err('نوع تقرير غير معروف');
    end;
  end if;
