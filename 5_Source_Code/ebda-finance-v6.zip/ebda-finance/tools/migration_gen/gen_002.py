"""Generates supabase/migrations/002_sessions_warnings_notify_docs.sql from the tested api() in 001.
The core keeps every 001 rule; changes are applied with exact, asserted replacements."""
import re, pathlib
root = pathlib.Path(__file__).resolve().parents[2]/'supabase'/'migrations'
s = (root / '001_rbac_scope_workflow.sql').read_text(encoding='utf8')
a = s.index('create or replace function ebda.api(req jsonb)')
b = s.index('$fn$;', a) + len('$fn$;')
core = s[a:b]

def R(old, new, count=1):
    global core
    n = core.count(old)
    assert n == count, (old[:70], n)
    core = core.replace(old, new)

R('create or replace function ebda.api(req jsonb)', 'create or replace function ebda.api_core(req jsonb)')
# --- authentication: trusted session (set by the wrapper) OR legacy username+pin (if still allowed)
R("""  select * into u from ebda.users where username=a_user and coalesce(active,'') like '%نعم%' order by id limit 1;
  if not found or not ebda.pin_ok(u.pin, a_pin) then return ebda.err('انتهت الجلسة — سجّل الدخول من جديد'); end if;""",
"""  if coalesce(current_setting('ebda.auth_uid', true),'') <> '' then
    select * into u from ebda.users where id=current_setting('ebda.auth_uid', true) and coalesce(active,'') like '%نعم%';
    if not found then return ebda.err('انتهت الجلسة — سجّل الدخول من جديد'); end if;
  else
    if coalesce((select value from ebda.config where key='allow_pin_auth'),'yes') = 'no' then
      return ebda.err('انتهت الجلسة — سجّل الدخول من جديد'); end if;
    select * into u from ebda.users where username=a_user and coalesce(active,'') like '%نعم%' order by id limit 1;
    if not found or not ebda.pin_ok(u.pin, a_pin) then return ebda.err('انتهت الجلسة — سجّل الدخول من جديد'); end if;
  end if;""")
# --- audit: don't log read-only helper actions
R("if action not in ('bootstrap','ping') then", "if action not in ('bootstrap','ping','lineStatus','notifyInfo','docAuth') then")
# --- password change revokes the user's other sessions
R("""    update ebda.users set pin=ebda.pin_hash(req->>'pin'), must_reset='لا' where id=u.id;
    return jsonb_build_object('ok',true);
  end if;""",
"""    update ebda.users set pin=ebda.pin_hash(req->>'pin'), must_reset='لا' where id=u.id;
    delete from ebda.sessions where user_id=u.id and token_hash <> coalesce(current_setting('ebda.session_hash', true),'');
    return jsonb_build_object('ok',true);
  end if;

  -- ================================================================ مساعدات القراءة (بدون سجل تدقيق)
  if action = 'lineStatus' then   -- تنبيه تجاوز البند قبل/بعد التسجيل
    return ebda.line_status(u, req->>'line_id', coalesce((req->>'amount')::numeric,0), coalesce(req->>'exclude_id',''));
  end if;
  if action = 'notifyInfo' then   -- يستدعيه Edge Function «notify» بتوكن المستخدم نفسه
    return ebda.notify_info(u, req->>'event', req->>'id');
  end if;
  if action = 'docAuth' then      -- يستدعيه Edge Function «docs» للتحقق قبل رفع/قراءة مستند من Storage
    select * into ex from ebda.expenses where id=(req->>'expense_id');
    if not found then return ebda.err('المصروف غير موجود'); end if;
    select * into cust from ebda.custodies where id=ex.custody_id;
    if (req->>'mode')='upload' then
      if not (urole='admin' or (cust.id is not null and coalesce(cust."user",'')=u.username)
              or (urole='finance_manager' and ebda.can_expense(u, ex))) then return ebda.err('لا صلاحية لرفع مستند'); end if;
    elsif not ebda.can_expense(u, ex) then return ebda.err('لا صلاحية على هذا المستند');
    end if;
    return jsonb_build_object('ok',true,'path', coalesce(nullif(ex.school_id,''),'central')||'/'||ex.id||'/',
      'current', case when ex.doc_url like 'storage:%' then substr(ex.doc_url, 9) else '' end);
  end if;""")
# --- over-budget warnings returned with the result
R("""    return jsonb_build_object('ok',true,'item',(select to_jsonb(e) from ebda.expenses e where e.id=newid));
  end if;

  if action = 'addCentral' then""",
"""    return jsonb_build_object('ok',true,'item',(select to_jsonb(e) from ebda.expenses e where e.id=newid))
           || ebda.over_warning(u, req#>>'{expense,line_id}');
  end if;

  if action = 'addCentral' then""")
R("""    return jsonb_build_object('ok',true,'item',(select to_jsonb(e) from ebda.expenses e where e.id=newid));
  end if;

  if action = 'updateExpense' then""",
"""    return jsonb_build_object('ok',true,'item',(select to_jsonb(e) from ebda.expenses e where e.id=newid))
           || ebda.over_warning(u, req#>>'{expense,line_id}');
  end if;

  if action = 'updateExpense' then""")
i = core.index("if action = 'reviewExpense' then")
j = core.index("return jsonb_build_object('ok',true,'mail','');", i)
core = core[:j] + "return jsonb_build_object('ok',true,'mail','') || case when patch->>'fin_approval'='approved' then ebda.over_warning(u, ex.line_id) else '{}'::jsonb end;" + core[j + len("return jsonb_build_object('ok',true,'mail','');"):]
# --- sessions die with password resets / deactivation / deletion
R("      update ebda.users set pin=ebda.pin_hash('0000'), must_reset='نعم' where id=xu.id;",
  "      update ebda.users set pin=ebda.pin_hash('0000'), must_reset='نعم' where id=xu.id;\n      delete from ebda.sessions where user_id=xu.id;")
R("      delete from ebda.users where id=xu.id;", "      delete from ebda.sessions where user_id=xu.id;\n      delete from ebda.users where id=xu.id;")
R("""    where id=xu.id;
    return jsonb_build_object('ok',true);""",
"""    where id=xu.id;
    if length(coalesce(dj->>'pin',''))>=4 or coalesce(dj->>'active','نعم') not like '%نعم%' or dj ? 'role' or dj ? 'username' then
      delete from ebda.sessions where user_id=xu.id;
    end if;
    return jsonb_build_object('ok',true);""")

head = ((pathlib.Path(__file__).parent/'002_head.sql').read_text(encoding='utf8'))
tail = ((pathlib.Path(__file__).parent/'002_tail.sql').read_text(encoding='utf8'))
out = head + '\n-- ============================================================================\n--  الدالة الأساسية (نفس قواعد Migration 001 + المصادقة بالجلسة + التنبيهات)\n-- ============================================================================\n' + core + '\n' + tail
(root / '002_sessions_warnings_notify_docs.sql').write_text(out, encoding='utf8')
print('written', len(out))
