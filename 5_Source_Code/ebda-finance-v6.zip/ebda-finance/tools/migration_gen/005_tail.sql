
-- ---------------------------------------------------------------- الصلاحيات: الدالة العامة فقط (كما فى 002) — جداول النسخ الاحتياطى غير متاحة لأى دور عام
revoke all on all tables in schema ebda from anon, authenticated;
revoke all on all sequences in schema ebda from anon, authenticated;
revoke execute on all functions in schema ebda from public, anon, authenticated;
grant usage on schema ebda to anon, authenticated;
grant execute on function ebda.api(jsonb) to anon, authenticated;
grant execute on function public.api(jsonb) to anon, authenticated;

insert into ebda.config(key,value) values ('schema_version','5') on conflict (key) do update set value='5';
