-- ============================================================================
--  ابدأ إديو — Migration 002: جلسات دخول بتوكن + تنبيه تجاوز البند + الإشعارات + المستندات على Storage
--  يُشغَّل بعد Migration 001. آمن لإعادة التشغيل. لا يحذف أى بيانات.
--
--  • تسجيل الدخول يُرجع توكن جلسة (عشوائى 256-bit، يُخزَّن مُجزّأً SHA-256 فقط) بدل حفظ كلمة السر فى المتصفح.
--    الجلسة تنتهى بعد عدم النشاط (session_idle_hours) أو بعد مدة أقصاها (session_max_days)،
--    وتُلغى تلقائياً عند تغيير كلمة السر أو تعطيل/حذف المستخدم أو تغيير دوره.
--  • التوافق: الواجهة القديمة (اسم مستخدم + PIN مع كل طلب) تظل تعمل ما دام allow_pin_auth = 'yes'.
--    بعد تحديث كل المستخدمين للواجهة الجديدة: update ebda.config set value='no' where key='allow_pin_auth';
--  • lineStatus / تحذير تلقائى عند تسجيل أو اعتماد مصروف يتجاوز المتبقى من البند.
--  • notifyInfo / docAuth: يستخدمهما Edge Functions «notify» و«docs» (المستلمون والصلاحيات تُحدَّد هنا لا فى المتصفح).
-- ============================================================================

create table if not exists ebda.sessions(
  id text primary key, token_hash text unique not null, user_id text not null,
  created_at timestamptz default now(), last_seen timestamptz default now(), expires_at timestamptz not null,
  user_agent text default '');
create index if not exists ix_sessions_user on ebda.sessions(user_id);
revoke all on ebda.sessions from anon, authenticated;

insert into ebda.config(key,value) values
  ('allow_pin_auth','yes'), ('session_idle_hours','12'), ('session_max_days','7'), ('app_url','')
on conflict (key) do nothing;

-- مجموع المصروفات «فى المسار» على البند: المعتمد مالياً + المعلّق (غير المرفوض)
create or replace function ebda.line_pipeline(lid text, excl text default '') returns numeric language sql stable as $$
  select coalesce(sum(e.amount),0) from ebda.expenses e
   where e.line_id=lid and e.id<>coalesce(excl,'') and e.approval<>'rejected' and coalesce(e.fin_approval,'')<>'rejected' $$;

create or replace function ebda.line_status(u ebda.users, lid text, amt numeric, excl text) returns jsonb
language plpgsql stable security definer set search_path = ebda as $$
declare l ebda.lines; counted numeric; pipe numeric; rem numeric; isover boolean;
begin
  select * into l from ebda.lines where id=lid;
  if not found then return jsonb_build_object('ok',true,'known',false); end if;
  if not ebda.can_school(u, l.school_id) then return ebda.err('هذا البند ليس ضمن نطاقك'); end if;
  counted := coalesce((select sum(e.amount) from ebda.expenses e where e.line_id=l.id and e.id<>coalesce(excl,'') and ebda.counts_in_budget(e)),0);
  pipe := ebda.line_pipeline(l.id, excl);
  rem := coalesce(l.allocated,0) - pipe;
  isover := coalesce(l.allocated,0) > 0 and (pipe + coalesce(amt,0)) > coalesce(l.allocated,0)
            or coalesce(l.allocated,0) = 0 and coalesce(amt,0) > 0;
  if ebda.role_key(u.role)='custody_officer' then   -- بدون أرقام الموازنة
    return jsonb_build_object('ok',true,'known',true,'over',isover,
      'message', case when isover then 'تنبيه: هذا المصروف يتجاوز المتبقى من بند الموازنة — سيُراجع من المدير المالى' else '' end);
  end if;
  return jsonb_build_object('ok',true,'known',true,'over',isover,'allocated',coalesce(l.allocated,0),
    'counted',counted,'pipeline',pipe,'remaining',rem,'after',rem-coalesce(amt,0),
    'message', case when isover then 'تنبيه تجاوز: المتبقى من البند '||to_char(rem,'FM999,999,999,990')||' ج.م والمصروف '||to_char(coalesce(amt,0),'FM999,999,999,990')||' ج.م' else '' end);
end $$;

-- تحذير يُضاف لنتيجة التسجيل/الاعتماد إذا تجاوز إجمالى البند مخصصه
create or replace function ebda.over_warning(u ebda.users, lid text) returns jsonb
language plpgsql stable security definer set search_path = ebda as $$
declare l ebda.lines; pipe numeric;
begin
  if coalesce(lid,'')='' then return '{}'::jsonb; end if;
  select * into l from ebda.lines where id=lid;
  if not found then return '{}'::jsonb; end if;
  pipe := ebda.line_pipeline(l.id);
  if pipe <= coalesce(l.allocated,0) then return '{}'::jsonb; end if;
  if ebda.role_key(u.role)='custody_officer' then
    return jsonb_build_object('warning','تنبيه: بند «'||l.name||'» تجاوز المخصص له — يوجد عجز وسيُراجع من المدير المالى');
  end if;
  return jsonb_build_object('warning','تنبيه عجز: بند «'||l.name||'» تجاوز مخصصه بمبلغ '||to_char(pipe-coalesce(l.allocated,0),'FM999,999,999,990')||' ج.م');
end $$;

create or replace function ebda.emails_for(rk text, sid text) returns text[] language sql stable as $$
  select coalesce(array_agg(distinct z.email),'{}') from ebda.users z
   where ebda.role_key(z.role)=rk and coalesce(z.active,'') like '%نعم%' and coalesce(z.email,'') like '%@%' and ebda.can_school(z, sid) $$;
create or replace function ebda.email_of(uname text) returns text[] language sql stable as $$
  select coalesce(array_agg(z.email),'{}') from ebda.users z
   where z.username=uname and coalesce(z.active,'') like '%نعم%' and coalesce(z.email,'') like '%@%' $$;

-- محتوى الإشعار والمستلمون: يُبنى فى قاعدة البيانات (لا يستطيع المتصفح إرسال بريد لأى أحد بأى محتوى)
create or replace function ebda.notify_info(u ebda.users, ev text, rid text) returns jsonb
language plpgsql stable security definer set search_path = ebda as $$
declare ex ebda.expenses; cust ebda.custodies; rq ebda.requests; sch ebda.schools; lname text;
  rcpt text[] := '{}'; subj text; rows text := ''; app text := coalesce((select value from ebda.config where key='app_url'),'');
  st text;
begin
  if ev in ('expense_new','expense_decided','expense_fin','expense_review') then
    select * into ex from ebda.expenses where id=rid;
    if not found or not ebda.can_expense(u, ex) then return ebda.err('لا صلاحية'); end if;
    select * into cust from ebda.custodies where id=ex.custody_id;
    select * into sch from ebda.schools where id=ex.school_id;
    lname := coalesce((select name from ebda.lines where id=ex.line_id),'—');
    rows := '<tr><td>رقم العملية</td><td>'||coalesce(ex.txn_no,'')||'</td></tr><tr><td>الجهة</td><td>'||coalesce(sch.name,'')||'</td></tr>'
         || '<tr><td>العهدة</td><td>'||coalesce(cust.code,'شراء مركزى')||' — '||coalesce(cust.holder,'')||'</td></tr>'
         || '<tr><td>البند</td><td>'||lname||'</td></tr><tr><td>الوصف</td><td>'||coalesce(ex.description,'')||'</td></tr>'
         || '<tr><td>المبلغ</td><td>'||to_char(ex.amount,'FM999,999,999,990.00')||' ج.م</td></tr>';
    if ev='expense_new' then
      rcpt := ebda.emails_for('direct_manager', ex.school_id); subj := 'مصروف جديد بانتظار اعتمادك — '||coalesce(ex.txn_no,'');
    elsif ev='expense_decided' then
      st := case ex.approval when 'approved' then 'تم اعتماده من المدير المباشر' when 'rejected' then 'رُفض من المدير المباشر' else 'معلق' end;
      rcpt := ebda.email_of(cust."user") || case when ex.approval='approved' then ebda.emails_for('finance_manager', ex.school_id) else '{}'::text[] end;
      subj := 'المصروف '||coalesce(ex.txn_no,'')||': '||st; rows := rows||'<tr><td>الحالة</td><td>'||st||'</td></tr>';
    elsif ev='expense_fin' then
      st := case ex.fin_approval when 'approved' then 'معتمد مالياً' when 'rejected' then 'مرفوض مالياً' else 'بانتظار الاعتماد المالى' end;
      rcpt := ebda.email_of(cust."user"); subj := 'المصروف '||coalesce(ex.txn_no,'')||': '||st;
      rows := rows||'<tr><td>الحالة</td><td>'||st||'</td></tr>'||case when coalesce(ex.fin_note,'')<>'' then '<tr><td>ملاحظة</td><td>'||ex.fin_note||'</td></tr>' else '' end;
    else
      st := case when coalesce(ex.settled,'') like '%نعم%' then 'تمت التسوية' else 'المستند يحتاج استيفاء' end;
      rcpt := ebda.email_of(cust."user"); subj := 'المصروف '||coalesce(ex.txn_no,'')||': '||st;
      rows := rows||'<tr><td>الحالة</td><td>'||st||'</td></tr>'||case when coalesce(ex.review_note,'')<>'' then '<tr><td>ملاحظة</td><td>'||ex.review_note||'</td></tr>' else '' end;
    end if;
  elsif ev in ('request_new','request_decided','request_transferred') then
    select * into rq from ebda.requests where id=rid;
    if not found or not (ebda.can_school(u, rq.school_id) or rq.requester=u.username) then return ebda.err('لا صلاحية'); end if;
    select * into sch from ebda.schools where id=rq.school_id;
    rows := '<tr><td>رقم الطلب</td><td>'||coalesce(rq.req_no,'')||'</td></tr><tr><td>الجهة</td><td>'||coalesce(sch.name,'')||'</td></tr>'
         || '<tr><td>مقدم الطلب</td><td>'||coalesce(rq.requester_name,'')||'</td></tr><tr><td>الإجمالى</td><td>'||to_char(rq.total,'FM999,999,999,990.00')||' ج.م</td></tr>';
    if ev='request_new' then
      rcpt := ebda.emails_for('direct_manager', rq.school_id); subj := 'طلب عهدة جديد بانتظار اعتمادك — '||coalesce(rq.req_no,'');
    elsif ev='request_decided' then
      rcpt := ebda.email_of(rq.requester) || case when rq.status='pending_accountant' then ebda.emails_for('finance_manager', rq.school_id) else '{}'::text[] end;
      subj := 'طلب العهدة '||coalesce(rq.req_no,'')||': '||case rq.status when 'pending_accountant' then 'اعتمده المدير المباشر — بانتظار الاعتماد المالى' else 'مرفوض' end;
    else
      rcpt := ebda.email_of(rq.requester);
      subj := 'طلب العهدة '||coalesce(rq.req_no,'')||': '||case rq.status when 'transferred' then 'معتمد مالياً وتم التحويل للعهدة' else 'مرفوض مالياً' end;
    end if;
  elsif ev='custody_submitted' then
    select * into cust from ebda.custodies where id=rid;
    if not found or not ebda.can_custody(u, cust) then return ebda.err('لا صلاحية'); end if;
    select * into sch from ebda.schools where id=cust.school_id;
    rcpt := ebda.emails_for('finance_manager', cust.school_id); subj := 'عهدة مقدّمة للتسوية — '||coalesce(cust.code,'');
    rows := '<tr><td>العهدة</td><td>'||coalesce(cust.code,'')||'</td></tr><tr><td>مسئول العهدة</td><td>'||coalesce(cust.holder,'')||'</td></tr><tr><td>الجهة</td><td>'||coalesce(sch.name,'')||'</td></tr>';
  else
    return ebda.err('حدث غير معروف');
  end if;
  rcpt := array(select distinct x from unnest(rcpt) x where x is not null and x like '%@%' and x <> coalesce(u.email,''));
  return jsonb_build_object('ok',true,'to',to_jsonb(rcpt),'subject',subj,
    'html','<div dir="rtl" style="font-family:Arial,sans-serif;color:#16232F"><h3 style="color:#123C5A">'||subj||'</h3>'
      ||'<table style="border-collapse:collapse;font-size:14px">'||replace(replace(rows,'<td>','<td style="border:1px solid #ddd;padding:6px 10px">'),'<tr>','<tr>')||'</table>'
      ||case when app<>'' then '<p><a href="'||app||'">فتح النظام</a></p>' else '' end
      ||'<p style="color:#888;font-size:11px">ابدأ إديو — نظام متابعة الموازنات والعهد · بواسطة '||coalesce(u.name,'')||'</p></div>');
end $$;
