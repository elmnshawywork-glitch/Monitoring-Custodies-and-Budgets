  -- ================================================================ v4: أسماء العهد (Master Data)
  if action = 'saveCustodyName' then
    if urole<>'admin' then return ebda.err('إدارة أسماء العهد للأدمن فقط'); end if;
    dj := req->'item';
    if coalesce(btrim(dj->>'name'),'')='' then return ebda.err('اكتب اسم العهدة'); end if;
    if exists(select 1 from ebda.custody_names z where ebda.norm_txt(z.name)=ebda.norm_txt(dj->>'name') and z.id<>coalesce(dj->>'id','')) then
      return ebda.err('هذا الاسم موجود بالفعل'); end if;
    if coalesce(dj->>'id','')='' then
      newid := ebda.uid();
      insert into ebda.custody_names(id,name,active,sort,sections)
      values(newid, btrim(dj->>'name'), coalesce(nullif(dj->>'active',''),'نعم'), coalesce(nullif(dj->>'sort','')::int, 99), coalesce(dj->>'sections',''));
    else
      newid := dj->>'id';
      update ebda.custody_names set name=btrim(dj->>'name'), active=coalesce(nullif(dj->>'active',''),active),
        sort=coalesce(nullif(dj->>'sort','')::int,sort), sections=coalesce(dj->>'sections',sections) where id=newid;
      if not found then return ebda.err('الاسم غير موجود'); end if;
    end if;
    return jsonb_build_object('ok',true,'id',newid);
  end if;

  -- ================================================================ v4: دورة اعتماد العهدة · الإلغاء · التوزيع على البنود
  if action in ('submitCustody','approveCustody','cancelCustody','setCustodyLines') then
    select * into cust from ebda.custodies where id=coalesce(req->>'id', req->>'custody_id');
    if not found then return ebda.err('العهدة غير موجودة'); end if;
    if not ebda.can_custody(u, cust) then return ebda.err('هذه العهدة ليست ضمن نطاقك'); end if;
    if coalesce(cust.status,'open')='cancelled' then return ebda.err('العهدة ملغاة بالفعل'); end if;

    if action = 'submitCustody' then  -- مسودة ← مراجعة
      if not ebda.can(u,'custody.create') then return ebda.err('لا صلاحية'); end if;
      if coalesce(cust.approval,'approved')<>'draft' then return ebda.err('العهدة ليست مسودة'); end if;
      update ebda.custodies set approval='review', submitted_by=u.name where id=cust.id;
      return jsonb_build_object('ok',true);
    end if;

    if action = 'approveCustody' then  -- مراجعة/مسودة ← معتمدة
      if not ebda.can(u,'custody.approve') then return ebda.err('صلاحية اعتماد العهد مطلوبة (الأدمن أو المدير المالى)'); end if;
      if coalesce(cust.approval,'approved')='approved' then return ebda.err('العهدة معتمدة بالفعل'); end if;
      if not exists(select 1 from ebda.tranches t where t.custody_id=cust.id and t.amount>0) then return ebda.err('لا يمكن اعتماد عهدة بدون قيمة'); end if;
      update ebda.custodies set approval='approved', approved_by=u.name, approved_at=now()::text where id=cust.id;
      return jsonb_build_object('ok',true);
    end if;

    if action = 'cancelCustody' then  -- للأدمن فقط، حتى بعد الاعتماد — لا حذف: الحالة «ملغاة» مع السبب
      if urole<>'admin' then return ebda.err('إلغاء العهدة للأدمن فقط'); end if;
      if length(coalesce(btrim(req->>'reason'),''))<3 then return ebda.err('اكتب سبب الإلغاء'); end if;
      update ebda.custodies set status='cancelled', cancel_reason=btrim(req->>'reason'), cancelled_by=u.name, cancelled_at=now()::text where id=cust.id;
      return jsonb_build_object('ok',true);
    end if;

    -- setCustodyLines: المخصص داخل العهدة لكل بند
    if not ebda.can(u,'custody.create') then return ebda.err('لا صلاحية لتعديل توزيع العهدة'); end if;
    if coalesce(cust.approval,'approved')='approved' and urole<>'admin' then return ebda.err('العهدة معتمدة — تعديل توزيعها للأدمن فقط'); end if;
    if coalesce(cust.status,'open') in ('closed','settled') then return ebda.err('لا يمكن تعديل عهدة مسوّاة/مغلقة'); end if;
    for ln in select * from jsonb_array_elements(coalesce(req->'lines','[]'::jsonb)) loop
      if not exists(select 1 from ebda.lines l where l.id=ln->>'line_id' and l.school_id=cust.school_id and coalesce(l.deleted_at,'')='') then
        return ebda.err('بند غير تابع لمكان العهدة'); end if;
      if not ebda.num_ok(ln->>'amount') or coalesce(nullif(btrim(ln->>'amount'),'')::numeric,0) < 0 then return ebda.err('مبلغ توزيع غير صحيح'); end if;
    end loop;
    if exists(select 1 from ebda.custody_lines cl where cl.custody_id=cust.id
              and not exists(select 1 from jsonb_array_elements(coalesce(req->'lines','[]'::jsonb)) x where x->>'line_id'=cl.line_id)
              and exists(select 1 from ebda.expenses e where e.custody_id=cust.id and e.line_id=cl.line_id)) then
      return ebda.err('لا يمكن إزالة بند عليه مصروفات من توزيع العهدة'); end if;
    delete from ebda.custody_lines cl where cl.custody_id=cust.id
      and not exists(select 1 from jsonb_array_elements(coalesce(req->'lines','[]'::jsonb)) x where x->>'line_id'=cl.line_id);
    for ln in select * from jsonb_array_elements(coalesce(req->'lines','[]'::jsonb)) loop
      insert into ebda.custody_lines(id,custody_id,line_id,amount,note)
      values(ebda.uid(), cust.id, ln->>'line_id', coalesce(nullif(btrim(ln->>'amount'),'')::numeric,0), coalesce(ln->>'note',''))
      on conflict (custody_id,line_id) do update set amount=excluded.amount, note=excluded.note;
    end loop;
    return jsonb_build_object('ok',true);
  end if;

  -- ================================================================ v4: حذف الموازنة (حذف منطقى للأدمن فقط) واسترجاعها
  if action in ('deleteBudget','restoreBudget') then
    if urole<>'admin' then return ebda.err('حذف الموازنة للأدمن فقط'); end if;
    sid := req->>'school_id';
    if sid is null or not exists(select 1 from ebda.schools s where s.id=sid) then return ebda.err('المكان غير موجود'); end if;
    if action = 'deleteBudget' then
      if length(coalesce(btrim(req->>'reason'),''))<3 then return ebda.err('اكتب سبب الحذف'); end if;
      n := (select count(*) from ebda.expenses e join ebda.lines l on l.id=e.line_id where l.school_id=sid and coalesce(l.deleted_at,'')='');
      if n > 0 then return ebda.err('لا يمكن حذف موازنة مرتبط بها '||n||' مصروف — المصروفات والتقارير تعتمد عليها'); end if;
      if exists(select 1 from ebda.custody_lines cl join ebda.lines l on l.id=cl.line_id where l.school_id=sid and coalesce(l.deleted_at,'')='') then
        return ebda.err('لا يمكن حذف موازنة موزعة على عهد'); end if;
      if exists(select 1 from ebda.request_items it join ebda.lines l on l.id=it.line_id join ebda.requests r on r.id=it.request_id
                where l.school_id=sid and coalesce(l.deleted_at,'')='' and r.status in ('pending_supervisor','pending_accountant')) then
        return ebda.err('توجد طلبات عهد معلّقة على بنود هذه الموازنة'); end if;
      n := (select count(*) from ebda.lines l where l.school_id=sid and coalesce(l.deleted_at,'')='');
      if n = 0 then return ebda.err('لا توجد موازنة لحذفها'); end if;
      update ebda.lines set deleted_at=now()::text, deleted_by=u.name, delete_reason=btrim(req->>'reason')
      where school_id=sid and coalesce(deleted_at,'')='';
      return jsonb_build_object('ok',true,'count',n);
    end if;
    -- استرجاع: البنود التى لا يوجد مثلها حالياً فقط (لا تكرار)
    update ebda.lines l set deleted_at='', deleted_by='', delete_reason=''
    where l.school_id=sid and coalesce(l.deleted_at,'')<>''
      and not exists(select 1 from ebda.lines a where a.school_id=sid and coalesce(a.deleted_at,'')='' and a.id<>l.id
                     and ebda.norm_txt(a.name)=ebda.norm_txt(l.name) and ebda.norm_txt(a.section)=ebda.norm_txt(l.section));
    get diagnostics n_new = row_count;
    return jsonb_build_object('ok',true,'count',n_new);
  end if;

  -- ================================================================ v4: الرواتب الشهرية (Payroll)
  if action = 'importPayroll' then
    if not ebda.can(u,'payroll.import') then return ebda.err('صلاحية استيراد الرواتب مطلوبة'); end if;
    sid := req->>'school_id';
    if sid is null or not exists(select 1 from ebda.schools s where s.id=sid) then return ebda.err('المكان غير موجود'); end if;
    if not ebda.can_school(u, sid) then return ebda.err('هذا المكان ليس ضمن نطاقك'); end if;
    if coalesce(req->>'month','') !~ '^[0-9]{4}-[0-9]{2}$' then return ebda.err('الشهر غير صحيح'); end if;
    if exists(select 1 from ebda.payroll_periods p where p.school_id=sid and p.month=req->>'month' and p.status='approved') then
      return ebda.err('رواتب هذا الشهر معتمدة — يجب إعادة فتحها (للأدمن) قبل الاستيراد'); end if;
    if jsonb_typeof(coalesce(req->'rows','null'::jsonb))<>'array' or jsonb_array_length(req->'rows')=0 then return ebda.err('لا توجد بيانات'); end if;
    -- (1) تحقق كامل قبل أى حفظ
    for ln in select * from jsonb_array_elements(req->'rows') loop
      if coalesce(btrim(ln->>'name'),'')='' then return ebda.err('يوجد سطر بدون اسم موظف'); end if;
      if not (ebda.num_ok(ln->>'salary') and ebda.num_ok(ln->>'net') and ebda.num_ok(ln->>'ded_total') and ebda.num_ok(ln->>'absent_days')
              and ebda.num_ok(ln->>'permissions') and ebda.num_ok(ln->>'deduct_days') and ebda.num_ok(ln->>'month_days') and ebda.num_ok(ln->>'allowances')
              and ebda.num_ok(ln->>'direct_ded') and ebda.num_ok(ln->>'leave_opening') and ebda.num_ok(ln->>'leave_used') and ebda.num_ok(ln->>'leave_balance')) then
        return ebda.err('قيمة رقمية غير صحيحة للموظف: '||(ln->>'name')); end if;
      if coalesce(ln->>'employee_id','')<>'' and not exists(select 1 from ebda.employees e where e.id=ln->>'employee_id' and e.school_id=sid) then
        return ebda.err('الموظف المطابق غير تابع لهذا المكان: '||(ln->>'name')); end if;
    end loop;
    -- (2) الموظف: مطابقة بالمعرّف ثم الرقم القومى ثم الاسم — لا يُنشأ الموظف مرة أخرى كل شهر
    for ln in select * from jsonb_array_elements(req->'rows') loop
      lid := nullif(ln->>'employee_id','');
      nk := regexp_replace(coalesce(ln->>'national_id',''),'[^0-9]','','g');
      if lid is null and nk<>'' then select e.id into lid from ebda.employees e where e.school_id=sid and e.national_key=nk order by e.id limit 1; end if;
      if lid is null then select e.id into lid from ebda.employees e where e.school_id=sid and ebda.norm_txt(e.name)=ebda.norm_txt(ln->>'name') order by e.id limit 1; end if;
      if lid is null then
        lid := ebda.uid();
        insert into ebda.employees(id,school_id,category,name,job,national_id,national_key,account_no,bank,ebda_start,hire_date,base_salary,
            staff_group,assignment,work_type,insurance_status,emp_no,active,archived)
        values(lid, sid, case when ln->>'staff_group'='gov' then 'gov' else 'contract' end, btrim(ln->>'name'), coalesce(ln->>'job',''),
            coalesce(ln->>'national_id',''), nk, coalesce(ln->>'account_no',''), coalesce(ln->>'bank',''), coalesce(ln->>'start_date',''), coalesce(ln->>'start_date',''),
            coalesce(nullif(btrim(ln->>'salary'),'')::numeric,0), coalesce(ln->>'staff_group',''), coalesce(ln->>'assignment',''), coalesce(ln->>'work_type',''),
            coalesce(ln->>'insurance_status',''), coalesce(ln->>'emp_no',''), 'نعم','لا');
        n_emp := n_emp + 1;
      else
        update ebda.employees set job=coalesce(nullif(ln->>'job',''),job), assignment=coalesce(nullif(ln->>'assignment',''),assignment),
          work_type=coalesce(nullif(ln->>'work_type',''),work_type), staff_group=coalesce(nullif(ln->>'staff_group',''),staff_group),
          national_id=case when coalesce(national_id,'')='' then coalesce(ln->>'national_id','') else national_id end,
          national_key=case when coalesce(national_key,'')='' then nk else national_key end,
          account_no=coalesce(nullif(ln->>'account_no',''),account_no), bank=coalesce(nullif(ln->>'bank',''),bank),
          ebda_start=coalesce(nullif(ln->>'start_date',''),ebda_start), base_salary=coalesce(nullif(btrim(ln->>'salary'),'')::numeric,base_salary),
          insurance_status=coalesce(nullif(ln->>'insurance_status',''),insurance_status), emp_no=coalesce(nullif(ln->>'emp_no',''),emp_no)
        where id=lid;
      end if;
      -- بيانات العاملين فقط (مثل شيت «مؤثرات الرواتب»: الكود والحالة التأمينية) — بدون قسيمة شهرية
      if coalesce(ln->>'employee_only','')='1' then continue; end if;
      -- (3) قسيمة الشهر: سطر واحد لكل موظف لكل شهر (تحديث عند إعادة الاستيراد مع الإبقاء على المؤثرات)
      pid := null;
      select p.id into pid from ebda.payslips p where p.employee_id=lid and p.month=req->>'month' order by p.id limit 1;
      if pid is null then
        pid := ebda.uid();
        insert into ebda.payslips(id,employee_id,emp_name,school_id,month,created_by,created_at,adjustments) values(pid, lid, btrim(ln->>'name'), sid, req->>'month', u.name, now()::text, '{}'::jsonb);
        n_new := n_new + 1;
      else
        n_upd := n_upd + 1;
      end if;
      update ebda.payslips set emp_name=btrim(ln->>'name'), staff_group=coalesce(ln->>'staff_group',''), job=coalesce(ln->>'job',''),
        base=coalesce(nullif(btrim(ln->>'salary'),'')::numeric,0), allowances=coalesce(nullif(btrim(ln->>'allowances'),'')::numeric,0),
        gross=coalesce(nullif(btrim(ln->>'salary'),'')::numeric,0)+coalesce(nullif(btrim(ln->>'allowances'),'')::numeric,0),
        ded_total=coalesce(nullif(btrim(ln->>'ded_total'),'')::numeric,0), direct_ded=coalesce(nullif(btrim(ln->>'direct_ded'),'')::numeric,0),
        month_days=coalesce(nullif(btrim(ln->>'month_days'),'')::numeric,0), work_days=coalesce(nullif(btrim(ln->>'work_days'),'')::numeric,0),
        attend_days=coalesce(nullif(btrim(ln->>'attend_days'),'')::numeric,0), rest_days=coalesce(nullif(btrim(ln->>'rest_days'),'')::numeric,0),
        absent_days=coalesce(nullif(btrim(ln->>'absent_days'),'')::numeric,0), permissions=coalesce(nullif(btrim(ln->>'permissions'),'')::numeric,0),
        deduct_days=coalesce(nullif(btrim(ln->>'deduct_days'),'')::numeric,0),
        leave_opening=coalesce(nullif(btrim(ln->>'leave_opening'),'')::numeric,0), leave_used=coalesce(nullif(btrim(ln->>'leave_used'),'')::numeric,0),
        leave_balance=coalesce(nullif(btrim(ln->>'leave_balance'),'')::numeric,0),
        task_pct=coalesce(nullif(btrim(ln->>'task_pct'),'')::numeric,0), quality_pct=coalesce(nullif(btrim(ln->>'quality_pct'),'')::numeric,0),
        avg_pct=coalesce(nullif(btrim(ln->>'avg_pct'),'')::numeric,0),
        net_import=coalesce(nullif(btrim(ln->>'net'),'')::numeric,0), note=coalesce(ln->>'note',''), source_file=coalesce(req->>'file_name',''),
        updated_at=now()::text
      where id=pid;
      update ebda.payslips set net=ebda.payslip_net(net_import, adjustments) where id=pid;
    end loop;
    if n_new + n_upd > 0 then
      insert into ebda.payroll_periods(id,school_id,month,status,file_name,imported_at,imported_by)
      values(ebda.uid(), sid, req->>'month', 'draft', coalesce(req->>'file_name',''), now()::text, u.name)
      on conflict (school_id,month) do update set file_name=excluded.file_name, imported_at=excluded.imported_at, imported_by=excluded.imported_by;
    end if;
    return jsonb_build_object('ok',true,'employees_added',n_emp,'payslips_added',n_new,'payslips_updated',n_upd);
  end if;

  if action = 'adjustPayslip' then  -- المؤثرات على الراتب (عناصر الراتب من Master Data)
    if not ebda.can(u,'payroll.import') then return ebda.err('صلاحية تعديل الرواتب مطلوبة'); end if;
    select p.school_id, p.month into sid, nk from ebda.payslips p where p.id=(req->>'id');
    if sid is null then return ebda.err('السطر غير موجود'); end if;
    if not ebda.can_school(u, sid) then return ebda.err('هذا المكان ليس ضمن نطاقك'); end if;
    if exists(select 1 from ebda.payroll_periods pp where pp.school_id=sid and pp.month=nk and pp.status='approved') then
      return ebda.err('رواتب هذا الشهر معتمدة — لا يمكن التعديل'); end if;
    if jsonb_typeof(coalesce(req->'adjustments','{}'::jsonb))<>'object' then return ebda.err('بيانات غير صحيحة'); end if;
    if exists(select 1 from jsonb_each_text(req->'adjustments') a where not ebda.num_ok(a.value) or coalesce(nullif(btrim(a.value),'')::numeric,0)<0
              or not exists(select 1 from ebda.payroll_components c where c.code=a.key and c.active like '%نعم%')) then
      return ebda.err('عنصر راتب غير معروف أو قيمة غير صحيحة'); end if;
    update ebda.payslips set adjustments=(select coalesce(jsonb_object_agg(a.key, a.value::numeric),'{}'::jsonb)
                                         from jsonb_each_text(req->'adjustments') a where coalesce(nullif(btrim(a.value),'')::numeric,0)<>0),
      note=coalesce(req->>'note', note), updated_at=now()::text
    where id=(req->>'id');
    update ebda.payslips set net=ebda.payslip_net(net_import, adjustments) where id=(req->>'id');
    return jsonb_build_object('ok',true,'net',(select net from ebda.payslips where id=(req->>'id')));
  end if;

  if action in ('approvePayroll','reopenPayroll') then
    sid := req->>'school_id';
    if not ebda.can_school(u, sid) then return ebda.err('هذا المكان ليس ضمن نطاقك'); end if;
    select p.id into pid from ebda.payroll_periods p where p.school_id=sid and p.month=req->>'month';
    if pid is null then return ebda.err('لا توجد رواتب مستوردة لهذا الشهر'); end if;
    if action='approvePayroll' then
      if not ebda.can(u,'payroll.approve') then return ebda.err('صلاحية اعتماد الرواتب مطلوبة'); end if;
      update ebda.payroll_periods set status='approved', approved_by=u.name, approved_at=now()::text where id=pid;
    else
      if urole<>'admin' then return ebda.err('إعادة فتح رواتب معتمدة للأدمن فقط'); end if;
      update ebda.payroll_periods set status='draft', approved_by='', approved_at='' where id=pid;
    end if;
    return jsonb_build_object('ok',true);
  end if;

  if action = 'savePayrollComponent' then
    if urole<>'admin' then return ebda.err('إدارة عناصر الراتب للأدمن فقط'); end if;
    dj := req->'item';
    if coalesce(btrim(dj->>'name'),'')='' then return ebda.err('اكتب اسم العنصر'); end if;
    if coalesce(dj->>'kind','') not in ('earning','deduction') then return ebda.err('نوع العنصر: إضافة أو خصم'); end if;
    if coalesce(dj->>'id','')='' then
      if coalesce(dj->>'code','') !~ '^[a-z][a-z0-9_]{1,30}$' then return ebda.err('الرمز بالإنجليزية الصغيرة (مثال: transport)'); end if;
      if exists(select 1 from ebda.payroll_components c where c.code=dj->>'code') then return ebda.err('الرمز موجود بالفعل'); end if;
      insert into ebda.payroll_components(id,code,name,kind,active,sort,system)
      values(ebda.uid(), dj->>'code', btrim(dj->>'name'), dj->>'kind', coalesce(nullif(dj->>'active',''),'نعم'), coalesce(nullif(dj->>'sort','')::int,99), 'لا');
    else
      update ebda.payroll_components set name=btrim(dj->>'name'), kind=dj->>'kind', active=coalesce(nullif(dj->>'active',''),active),
        sort=coalesce(nullif(dj->>'sort','')::int,sort) where id=dj->>'id';
    end if;
    return jsonb_build_object('ok',true);
  end if;

  if action = 'savePayrollMap' then
    if not ebda.can(u,'payroll.import') then return ebda.err('لا صلاحية'); end if;
    update ebda.config set value=coalesce(req->>'map','') where key='payroll_map';
    return jsonb_build_object('ok',true);
  end if;
