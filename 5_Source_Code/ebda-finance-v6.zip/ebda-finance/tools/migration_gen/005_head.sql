-- ============================================================================
--  ابدأ إديو — Migration 005: دورة المصروف الكاملة · المدير المباشر (Assignment) · الملكية بالمعرّف
--  الفصل بين المهام · تعطيل الجهات والبنود · أنواع العهد والموازنات · النسخ الاحتياطى والاستعادة · الأداء
--  آمن للتكرار. لا يحذف بيانات، ولا يعيد إنشاء المستخدمين، ولا يغيّر كلمات السر أو المعرّفات أو الصلاحيات الحالية.
--  يُشغَّل بعد 001 → 004.
-- ============================================================================
set search_path = ebda, public, extensions;

-- ---------------------------------------------------------------- أعمدة جديدة (كلها اختيارية بقيم افتراضية)
alter table ebda.users     add column if not exists manager_id text default '';   -- المدير المباشر لمسئول العهدة (معرّف المستخدم)
alter table ebda.users     add column if not exists dept text default '';         -- القسم (نطاق إضافى)
alter table ebda.custodies add column if not exists user_id text default '';      -- مالك العهدة بالمعرّف (يُملأ تلقائياً من اسم الدخول)
alter table ebda.requests  add column if not exists requester_id text default '';
alter table ebda.lines     add column if not exists active text default 'نعم';    -- البند المعطّل لا يقبل إدخالات جديدة ويبقى فى التقارير
alter table ebda.expenses  add column if not exists created_by_id text default '';
alter table ebda.expenses  add column if not exists approved_by_id text default '';
alter table ebda.expenses  add column if not exists approval_note text default '';
alter table ebda.expenses  add column if not exists submitted_at text default '';
alter table ebda.expenses  add column if not exists returned_by text default '';
alter table ebda.expenses  add column if not exists returned_at text default '';
alter table ebda.expenses  add column if not exists return_reason text default '';
alter table ebda.expenses  add column if not exists fin_by_id text default '';
alter table ebda.expenses  add column if not exists settled_by text default '';
alter table ebda.expenses  add column if not exists settled_by_id text default '';
alter table ebda.expenses  add column if not exists cancelled_at text default '';
alter table ebda.expenses  add column if not exists cancelled_by text default '';
alter table ebda.expenses  add column if not exists cancel_reason text default '';
alter table ebda.employees add column if not exists dept text default '';
alter table ebda.employees add column if not exists manager_user_id text default '';
alter table ebda.employees add column if not exists birth_place text default '';
alter table ebda.employees add column if not exists secondment_status text default '';  -- حالة الندب / المأمورية
alter table ebda.employees add column if not exists serial_no text default '';

update ebda.lines set active='نعم' where active is null;
update ebda.users set manager_id='' where manager_id is null;

-- ---------------------------------------------------------------- الملكية بالمعرّف وليس بالاسم الظاهر
-- (1) العهدة/الطلب: يُستنتج معرّف المالك من اسم الدخول عند الإضافة أو التغيير
create or replace function ebda.fill_owner_ids() returns trigger language plpgsql security definer set search_path = ebda as $fo$
begin
  if tg_table_name = 'custodies' then
    if tg_op = 'INSERT' or new."user" is distinct from old."user" or coalesce(new.user_id,'') = '' then
      new.user_id := coalesce((select z.id from ebda.users z where z.username = new."user" and coalesce(new."user",'')<>'' order by z.id limit 1), '');
    end if;
  elsif tg_table_name = 'requests' then
    if tg_op = 'INSERT' or new.requester is distinct from old.requester or coalesce(new.requester_id,'') = '' then
      new.requester_id := coalesce((select z.id from ebda.users z where z.username = new.requester and coalesce(new.requester,'')<>'' order by z.id limit 1), '');
    end if;
  end if;
  return new;
end $fo$;
drop trigger if exists trg_owner_custodies on ebda.custodies;
create trigger trg_owner_custodies before insert or update on ebda.custodies for each row execute function ebda.fill_owner_ids();
drop trigger if exists trg_owner_requests on ebda.requests;
create trigger trg_owner_requests before insert or update on ebda.requests for each row execute function ebda.fill_owner_ids();

-- (2) تغيير اسم الدخول لا يفقد المستخدم عهده ولا طلباته
create or replace function ebda.cascade_username() returns trigger language plpgsql security definer set search_path = ebda as $cu$
begin
  if new.username is distinct from old.username then
    update ebda.custodies set "user" = new.username where user_id = new.id;
    update ebda.requests  set requester = new.username where requester_id = new.id;
  end if;
  return null;
end $cu$;
drop trigger if exists trg_cascade_username on ebda.users;
create trigger trg_cascade_username after update of username on ebda.users for each row execute function ebda.cascade_username();

-- (3) ملء المعرّفات للبيانات الحالية (بدون تغيير أى قيمة أخرى)
update ebda.custodies c set user_id = z.id from ebda.users z where coalesce(c.user_id,'')='' and z.username = c."user" and coalesce(c."user",'')<>'';
update ebda.requests r set requester_id = z.id from ebda.users z where coalesce(r.requester_id,'')='' and z.username = r.requester and coalesce(r.requester,'')<>'';

create or replace function ebda.owns_custody(u ebda.users, c ebda.custodies) returns boolean language sql stable as $$
  select c.id is not null and case when coalesce(c.user_id,'')<>'' then c.user_id = u.id else coalesce(c."user",'')<>'' and c."user" = u.username end $$;

create or replace function ebda.can_custody(u ebda.users, c ebda.custodies) returns boolean language sql stable as $$
  select case
    when c.id is null then false
    when ebda.role_key(u.role)='admin' then true
    when ebda.role_key(u.role)='custody_officer' then ebda.owns_custody(u, c)
    when coalesce(c.school_id,'')='' then ebda.role_key(u.role)='finance_manager'
    else ebda.can_school(u, c.school_id) end $$;

-- المدير المباشر المكلَّف: إذا كان لمسئول العهدة مدير مباشر محدد فهو وحده (أو الأدمن) من يعتمد مصروفاته،
-- وإلا يبقى السلوك الحالى (المدير المباشر حسب نطاق المكان).
create or replace function ebda.owner_of(c ebda.custodies) returns ebda.users language sql stable as $$
  select z from ebda.users z where (coalesce(c.user_id,'')<>'' and z.id=c.user_id) or (coalesce(c.user_id,'')='' and z.username=c."user" and coalesce(c."user",'')<>'')
  order by z.id limit 1 $$;
create or replace function ebda.is_assigned_manager(u ebda.users, c ebda.custodies) returns boolean language plpgsql stable as $am$
declare o ebda.users;
begin
  if ebda.role_key(u.role)='admin' then return true; end if;
  if c.id is null then return ebda.can_school(u, null); end if;
  o := ebda.owner_of(c);
  if o.id is not null and coalesce(o.manager_id,'')<>'' then return o.manager_id = u.id; end if;
  return ebda.can_school(u, c.school_id);
end $am$;

-- ---------------------------------------------------------------- حالة المصروف (مصدر واحد للحالة — نفس المنطق فى الواجهة lib/expense.js)
create or replace function ebda.expense_stage(e ebda.expenses) returns text language sql immutable as $$
  select case
    when coalesce(e.cancelled_at,'')<>'' then 'cancelled'
    when e.approval='draft' then 'draft'
    when e.approval='returned' then 'returned'
    when e.approval='rejected' then 'rejected'
    when coalesce(e.approval,'pending')='pending' then 'pending_manager'
    when coalesce(e.settled,'') like '%نعم%' and coalesce(e.fin_approval,'')<>'rejected' then 'settled'
    when e.fin_approval='rejected' then 'fin_rejected'
    when e.fin_approval='returned' then 'fin_returned'
    when e.fin_approval='approved' then 'reviewed'
    else 'pending_finance' end $$;

-- المصروف المحتسب على الموازنة: معتمد من المدير المباشر + معتمد مالياً/مسوّى + غير ملغى
create or replace function ebda.counts_in_budget(e ebda.expenses) returns boolean language sql immutable as $$
  select coalesce(e.approval,'')='approved' and (coalesce(e.fin_approval,'')='approved' or coalesce(e.settled,'') like '%نعم%')
     and coalesce(e.fin_approval,'')<>'rejected' and coalesce(e.cancelled_at,'')='' $$;
-- المصروف القائم على العهدة (يُخصم من رصيدها): غير مرفوض وغير ملغى
create or replace function ebda.active_on_custody(e ebda.expenses) returns boolean language sql immutable as $$
  select coalesce(e.approval,'')<>'rejected' and coalesce(e.fin_approval,'')<>'rejected' and coalesce(e.cancelled_at,'')='' $$;

-- ---------------------------------------------------------------- Master Data: أنواع العهد وأنواع الموازنات (الجهات)
create table if not exists ebda.custody_kinds(id text primary key, name text not null, active text default 'نعم', sort int default 0);
insert into ebda.custody_kinds(id,name,sort)
select v.id, v.name, v.sort from (values ('ck_ops','عهدة تشغيلية',1),('ck_petty','عهدة نثرية مستديمة',2),('ck_purpose','عهدة لغرض محدد',3),
                                          ('ck_activity','عهدة نشاط / تدريب',4),('ck_other','أخرى',5)) v(id,name,sort)
where not exists (select 1 from ebda.custody_kinds);
-- أى نوع مستخدم فعلياً فى العهد الحالية ولم يكن فى القائمة يُضاف (لا يضيع تصنيف قديم)
insert into ebda.custody_kinds(id,name,sort)
select 'ck_'||substr(md5(k),1,10), k, 50 from (select distinct btrim(kind) k from ebda.custodies where coalesce(btrim(kind),'')<>'') x
where not exists (select 1 from ebda.custody_kinds z where z.name = x.k)
on conflict (id) do nothing;

create table if not exists ebda.entity_types(code text primary key, label text not null, active text default 'نعم', sort int default 0);
insert into ebda.entity_types(code,label,sort) values
  ('school','مدرسة',1),('company','الشركة الداخلية',2),('training_general','تدريب عام',3),('training_vocational','تدريب مهنى',4),
  ('training_project','مشروع تدريب',5),('training_program','برنامج تدريب',6),('training_course','دورة تدريبية',7)
on conflict (code) do nothing;
insert into ebda.entity_types(code,label,sort)
select distinct s.category, s.category, 50 from ebda.schools s where coalesce(s.category,'')<>'' on conflict (code) do nothing;

-- ---------------------------------------------------------------- النسخ الاحتياطى (داخل قاعدة البيانات — لا يصل إليها إلا الأدمن عبر الـ API)
create table if not exists ebda.backups(
  id text primary key, name text not null, kind text default 'manual', created_at timestamptz default now(), created_by text default '',
  size_bytes bigint default 0, counts jsonb default '{}'::jsonb, note text default '', data jsonb not null);
create index if not exists ix_backups_created on ebda.backups(created_at desc);

-- الجداول التى تشملها النسخة (بترتيب الاستعادة). الجلسات والنسخ نفسها لا تُنسخ.
create or replace function ebda.backup_tables() returns text[] language sql immutable as $$
  select array['config','users','schools','entity_types','lines','custody_names','custody_kinds','custodies','custody_lines','tranches',
               'expenses','requests','request_items','spend_items','holders','approvers','emails','salaries','temp_budgets',
               'employees','payroll_components','payroll_periods','payslips','import_batches','audit_log','audit_changes'] $$;

create or replace function ebda.make_backup(p_kind text, p_actor text, p_note text) returns jsonb
language plpgsql security definer set search_path = ebda as $mb$
declare t text; d jsonb := '{}'::jsonb; c jsonb := '{}'::jsonb; v jsonb; nm text; bid text := ebda.uid(); sz bigint;
begin
  foreach t in array ebda.backup_tables() loop
    if to_regclass('ebda.'||t) is null then continue; end if;
    execute format('select coalesce(jsonb_agg(to_jsonb(x)), ''[]''::jsonb) from ebda.%I x', t) into v;
    d := d || jsonb_build_object(t, v);
    c := c || jsonb_build_object(t, jsonb_array_length(v));
  end loop;
  d := d || jsonb_build_object('_meta', jsonb_build_object('schema_version', (select value from ebda.config where key='schema_version'),
                                                           'created_at', now()::text, 'tables', ebda.backup_tables()));
  nm := case when p_kind='safety' then 'SafetyBackup_' else 'Backup_' end || to_char(now() at time zone 'Africa/Cairo', 'YYYY-MM-DD_HH24-MI-SS');
  sz := octet_length(d::text);
  insert into ebda.backups(id,name,kind,created_by,size_bytes,counts,note,data) values(bid, nm, p_kind, coalesce(p_actor,''), sz, c, coalesce(p_note,''), d);
  return jsonb_build_object('id',bid,'name',nm,'kind',p_kind,'size_bytes',sz,'counts',c,'created_at',now()::text);
end $mb$;

-- الاستعادة: نسخة أمان تلقائية للحالة الحالية أولاً، ثم إحلال البيانات فى معاملة واحدة (إما كلها أو لا شىء).
-- سجل التدقيق لا يُمسح أبداً: يُدمج (تُضاف السطور غير الموجودة فقط) حتى لا يضيع أثر ما حدث بعد النسخة.
create or replace function ebda.restore_backup(p_id text, p_actor text) returns jsonb
language plpgsql security definer set search_path = ebda as $rb$
declare b ebda.backups; t text; safety jsonb; n int; restored jsonb := '{}'::jsonb; cols text;
begin
  select * into b from ebda.backups where id = p_id;
  if not found then return ebda.err('النسخة غير موجودة'); end if;
  safety := ebda.make_backup('safety', p_actor, 'قبل استعادة '||b.name);
  perform set_config('ebda.restoring', '1', true);
  foreach t in array ebda.backup_tables() loop
    if to_regclass('ebda.'||t) is null or not (b.data ? t) then continue; end if;
    select string_agg(format('%I', a.attname), ',' order by a.attnum) into cols
      from pg_attribute a where a.attrelid = ('ebda.'||t)::regclass and a.attnum > 0 and not a.attisdropped;
    if t in ('audit_log','audit_changes') then
      execute format('insert into ebda.%1$I(%2$s) select %2$s from jsonb_populate_recordset(null::ebda.%1$I, $1) r where not exists (select 1 from ebda.%1$I x where x.id = r.id)', t, cols)
        using b.data->t;
    else
      execute format('delete from ebda.%I', t);
      execute format('insert into ebda.%1$I(%2$s) select %2$s from jsonb_populate_recordset(null::ebda.%1$I, $1)', t, cols) using b.data->t;
    end if;
    get diagnostics n = row_count;
    restored := restored || jsonb_build_object(t, n);
  end loop;
  -- الأرقام المسلسلة لا ترجع للخلف (منع تكرار أرقام العمليات) — وإعادة بناء التجميعات من البيانات المستعادة
  perform set_config('ebda.restoring', '', true);
  perform ebda.rebuild_line_agg();
  return jsonb_build_object('ok', true, 'restored', b.name, 'safety_backup', safety, 'rows', restored);
end $rb$;

-- ---------------------------------------------------------------- تتبع التعديلات: لا يُسجَّل كل سطر أثناء الاستعادة (تُسجَّل العملية نفسها)
create or replace function ebda.track_change() returns trigger
language plpgsql security definer set search_path = ebda as $tc$
declare
  o jsonb; nw jsonb;
  k text; od jsonb := '{}'::jsonb; nd jsonb := '{}'::jsonb; sid text;
  hide text[] := array['pin','updated_at','updated_by','last_login'];
begin
  if coalesce(current_setting('ebda.restoring', true),'') = '1' then return null; end if;
  o  := case when tg_op in ('UPDATE','DELETE') then to_jsonb(old) else null end;
  nw := case when tg_op in ('UPDATE','INSERT') then to_jsonb(new) else null end;
  -- لا تُسجَّل كلمات السر ولا محتوى الملفات
  if o  is not null then o  := o  - 'pin'; if coalesce(o->>'doc_url','')  like 'data:%' then o  := o  || '{"doc_url":"[ملف مرفق]"}'; end if; end if;
  if nw is not null then nw := nw - 'pin'; if coalesce(nw->>'doc_url','') like 'data:%' then nw := nw || '{"doc_url":"[ملف مرفق]"}'; end if; end if;
  if tg_op = 'UPDATE' then
    for k in select jsonb_object_keys(nw) loop
      if k = any(hide) then continue; end if;
      if (o->k) is distinct from (nw->k) then od := od || jsonb_build_object(k, o->k); nd := nd || jsonb_build_object(k, nw->k); end if;
    end loop;
    if (to_jsonb(old)->>'pin') is distinct from (to_jsonb(new)->>'pin') then nd := nd || '{"pin":"(تم تغيير كلمة السر)"}'; end if;
    if nd = '{}'::jsonb then return null; end if;
  else
    od := o; nd := nw;
  end if;
  sid := coalesce(nw->>'school_id', o->>'school_id', '');
  if tg_table_name in ('tranches','custody_lines') then
    sid := coalesce((select c.school_id from ebda.custodies c where c.id = coalesce(nw->>'custody_id', o->>'custody_id')), '');
  end if;
  insert into ebda.audit_changes(actor_id, tbl, row_id, op, school_id, old_v, new_v)
  values (coalesce(current_setting('ebda.auth_uid', true),''), tg_table_name, coalesce(nw->>'id', o->>'id', ''), lower(tg_op), sid,
          case when tg_op='INSERT' then null else od end, case when tg_op='DELETE' then null else nd end);
  return null;
end $tc$;

do $tr$
declare t text;
begin
  foreach t in array array['custody_kinds','entity_types'] loop
    execute format('drop trigger if exists trg_track_%1$s on ebda.%1$I', t);
    execute format('create trigger trg_track_%1$s after insert or update or delete on ebda.%1$I for each row execute function ebda.track_change()', t);
  end loop;
end $tr$;

-- ---------------------------------------------------------------- فهارس الأداء
create index if not exists ix_exp_date        on ebda.expenses(date);
create index if not exists ix_exp_school_date on ebda.expenses(school_id, date);
create index if not exists ix_exp_approval    on ebda.expenses(approval);
create index if not exists ix_exp_created_by  on ebda.expenses(created_by_id);
create index if not exists ix_cust_user_id    on ebda.custodies(user_id);
create index if not exists ix_users_username  on ebda.users(username);
create index if not exists ix_users_manager   on ebda.users(manager_id);
create index if not exists ix_req_requester   on ebda.requests(requester_id);
create index if not exists ix_sessions_exp    on ebda.sessions(expires_at);
create index if not exists ix_sessions_seen   on ebda.sessions(last_seen);
create index if not exists ix_auditch_row     on ebda.audit_changes(tbl, row_id);
create index if not exists ix_pay_month_only  on ebda.payslips(month);
create index if not exists ix_cl_line         on ebda.custody_lines(line_id);

-- ---------------------------------------------------------------- إعدادات
insert into ebda.config(key,value) values ('require_doc_to_settle','no') on conflict (key) do nothing;

-- ---------------------------------------------------------------- الجلسة: تحديث «آخر نشاط» مرة كل دقيقة على الأكثر (بدلاً من كتابة مع كل طلب قراءة)
create or replace function ebda.api(req jsonb)
returns jsonb language plpgsql security definer set search_path = ebda as $w$
declare
  action text := req->>'action';
  tok text := req#>>'{auth,token}';
  th text; sess ebda.sessions; res jsonb;
  idle int := coalesce(nullif((select value from ebda.config where key='session_idle_hours'),'')::int, 12);
  maxd int := coalesce(nullif((select value from ebda.config where key='session_max_days'),'')::int, 7);
begin
  perform set_config('ebda.auth_uid', '', true);
  perform set_config('ebda.session_hash', '', true);
  if action = 'login' then
    res := ebda.api_core(req);
    if res ? 'ok' then
      tok := encode(extensions.gen_random_bytes(32), 'hex');
      insert into ebda.sessions(id, token_hash, user_id, created_at, last_seen, expires_at, user_agent)
      values (ebda.uid(), encode(extensions.digest(tok, 'sha256'), 'hex'), res#>>'{user,id}', now(), now(),
              now() + make_interval(days => maxd), left(coalesce(req->>'ua',''), 200));
      delete from ebda.sessions where expires_at < now() or last_seen < now() - make_interval(hours => idle);
      res := res || jsonb_build_object('token', tok, 'session_idle_hours', idle);
    end if;
    return res;
  end if;
  if coalesce(tok,'') <> '' then
    th := encode(extensions.digest(tok, 'sha256'), 'hex');
    if action = 'logout' then delete from ebda.sessions where token_hash = th; return jsonb_build_object('ok', true); end if;
    select * into sess from ebda.sessions
     where token_hash = th and expires_at > now() and last_seen > now() - make_interval(hours => idle);
    if not found then return ebda.err('انتهت الجلسة — سجّل الدخول من جديد'); end if;
    if sess.last_seen < now() - interval '60 seconds' then
      update ebda.sessions set last_seen = now() where id = sess.id;
    end if;
    perform set_config('ebda.auth_uid', sess.user_id, true);
    perform set_config('ebda.session_hash', th, true);
    req := req - 'auth';
  elsif action = 'logout' then
    return jsonb_build_object('ok', true);
  end if;
  return ebda.api_core(req);
end $w$;

-- ---------------------------------------------------------------- مساعدات التقارير والحسابات على الخادم (نفس قواعد الواجهة lib/model.js و lib/budget.js)
-- النطاق مرة واحدة (بدلاً من تحليل نص المدارس لكل صف)
create or replace function ebda.scope_arr(u ebda.users) returns text[] language sql immutable as $$
  select array_remove(string_to_array(regexp_replace(coalesce(u.schools,''), '\s', '', 'g'), ','), '') $$;

-- العهد المسموح بها (نفس قاعدة can_custody) بخطة استعلام مناسبة لكل دور
create or replace function ebda.vis_custodies(u ebda.users) returns setof ebda.custodies
language plpgsql stable security definer set search_path = ebda as $vc$
declare rk text := ebda.role_key(u.role); star boolean := coalesce(u.schools,'')='*'; sch text[] := ebda.scope_arr(u);
begin
  if rk = 'admin' then return query select * from ebda.custodies;
  elsif rk = 'custody_officer' then
    return query select * from ebda.custodies c where c.user_id = u.id
      union all select * from ebda.custodies c where coalesce(c.user_id,'')='' and c."user" = u.username and coalesce(u.username,'')<>'';
  else
    return query select * from ebda.custodies c
      where (coalesce(c.school_id,'')='' and rk='finance_manager') or (coalesce(c.school_id,'')<>'' and (star or c.school_id = any(sch)));
  end if;
end $vc$;

-- معرّفات المصروفات المسموح بها (نفس قاعدة can_expense) — مجموعة واحدة بدون استدعاء دالة لكل صف،
-- وتُرجع المعرّفات فقط (خفيفة) ثم تُربط بالجدول بـ hash join
create or replace function ebda.vis_expense_ids(u ebda.users) returns setof text
language plpgsql stable security definer set search_path = ebda as $vi$
declare rk text := ebda.role_key(u.role); star boolean := coalesce(u.schools,'')='*'; sch text[] := ebda.scope_arr(u);
begin
  if rk = 'admin' then return query select e.id from ebda.expenses e;
  elsif rk = 'custody_officer' then
    return query select e.id from ebda.expenses e where e.custody_id = any(array(
      select c.id from ebda.custodies c where c.user_id = u.id
      union all select c.id from ebda.custodies c where coalesce(c.user_id,'')='' and c."user" = u.username and coalesce(u.username,'')<>''));
  elsif star then
    return query select e.id from ebda.expenses e left join ebda.custodies c on c.id = e.custody_id
      where c.id is null or coalesce(c.school_id,'')<>'' or rk='finance_manager';
  else
    return query select e.id from ebda.expenses e where e.school_id = any(sch)
      union all
      select e.id from ebda.expenses e join ebda.custodies c on c.id = e.custody_id
      where coalesce(c.school_id,'')='' and rk='finance_manager';
  end if;
end $vi$;

-- المصروفات المسموح بها (صفوف كاملة) بخطة مناسبة لكل دور (فهرس العهدة لمسئول العهدة، فهرس المكان للمدير)
-- ملاحظة: للأدمن تستخدم الاستعلامات الجدول مباشرة (union all) بدلاً من هذه الدالة لتجنب تجميع كل الصفوف فى الذاكرة
create or replace function ebda.vis_expenses(u ebda.users) returns setof ebda.expenses
language plpgsql stable security definer set search_path = ebda as $ve$
declare rk text := ebda.role_key(u.role); star boolean := coalesce(u.schools,'')='*'; sch text[] := ebda.scope_arr(u);
begin
  if rk = 'admin' then return query select * from ebda.expenses;
  elsif rk = 'custody_officer' then
    return query select e.* from ebda.expenses e where e.custody_id = any(array(
      select c.id from ebda.custodies c where c.user_id = u.id
      union all select c.id from ebda.custodies c where coalesce(c.user_id,'')='' and c."user" = u.username and coalesce(u.username,'')<>''));
  elsif star then
    return query select e.* from ebda.expenses e left join ebda.custodies c on c.id = e.custody_id
      where c.id is null or coalesce(c.school_id,'')<>'' or rk='finance_manager';
  else
    -- مكان المصروف = مكان عهدته دائماً (يُفرض عند التسجيل)، فيكفى فهرس المكان
    return query select e.* from ebda.expenses e where e.school_id = any(sch)
      union all
      select e.* from ebda.expenses e join ebda.custodies c on c.id = e.custody_id
      where coalesce(c.school_id,'')='' and rk='finance_manager';
  end if;
end $ve$;

-- حدود السنة المالية من period مثل «2026/2027» ← 2026-09-01 .. 2027-08-31 (بدون سنة = بدون حدود)
create or replace function ebda.fy_from(p text) returns text language sql immutable as $$
  select case when coalesce(p,'') ~ '\d{4}' then substring(p from '\d{4}') || '-09-01' else '0000-00-00' end $$;
create or replace function ebda.fy_to(p text) returns text language sql immutable as $$
  select case when coalesce(p,'') ~ '\d{4}' then (substring(p from '\d{4}')::int + 1)::text || '-08-31' else '9999-99-99' end $$;

-- مخصص البند لشهر من السنة المالية: monthly_plan (12 قيمة) إن وُجد، وإلا السنوى ÷ 12
create or replace function ebda.plan_month(p_plan text, p_alloc numeric, m int) returns numeric language plpgsql immutable as $pm$
declare j jsonb;
begin
  begin
    j := nullif(btrim(coalesce(p_plan,'')),'')::jsonb;
  exception when others then j := null;
  end;
  if j is not null and jsonb_typeof(j)='array' and jsonb_array_length(j)=12 then
    begin
      return coalesce(nullif(j->>(m-1),'')::numeric, 0);
    exception when others then return 0;
    end;
  end if;
  return coalesce(p_alloc,0) / 12;
end $pm$;

-- حالة البند (نفس budgetStatus فى الواجهة، بهامش نصف جنيه)
create or replace function ebda.budget_state(alloc numeric, spent numeric) returns text language sql immutable as $$
  select case when coalesce(alloc,0) <= 0.5 and coalesce(spent,0) <= 0.5 then 'none'
              when coalesce(alloc,0) <= 0.5 then 'over'
              when spent > alloc + 0.5 then 'over'
              when spent >= alloc - 0.5 then 'reached'
              when spent / alloc >= 0.9 then 'near'
              else 'within' end $$;

-- عمر العهدة بالأيام من تاريخ فتحها
create or replace function ebda.days_since(d text) returns int language sql stable as $$
  select case when coalesce(d,'') ~ '^\d{4}-\d{2}-\d{2}' then (current_date - left(d,10)::date) else 0 end $$;

-- المصروف المحتسب على الموازنة لكل بند لكل شهر من السنة المالية للجهة (نفس budgetModel فى الواجهة) — {line_id: [12 قيمة]}
-- جدول تجميعى للمصروف المحتسب لكل (بند، جهة، سنة مالية، شهر) يُحدَّث داخل نفس المعاملة بـ Trigger
-- (لا يوجد Cache قديم: أى تسجيل/اعتماد/إلغاء مصروف يُحدّثه فوراً)، فتقرأ اللوحة والتقارير أرقاماً جاهزة بدلاً من مسح كل المصروفات.
create table if not exists ebda.agg_line_month(line_id text not null, school_id text not null, fy int not null, m int not null,
  amount numeric not null default 0, primary key(line_id, school_id, fy, m));
create index if not exists ix_agg_lm_school on ebda.agg_line_month(school_id);

create or replace function ebda.exp_fy(d text) returns int language sql immutable as $$
  select case when coalesce(d,'') ~ '^\d{4}-\d{2}' then case when substr(d,6,2)::int >= 9 then substr(d,1,4)::int else substr(d,1,4)::int - 1 end end $$;

create or replace function ebda.agg_line_month_trg() returns trigger language plpgsql security definer set search_path = ebda as $am$
begin
  if coalesce(current_setting('ebda.restoring', true),'') = '1' then return null; end if;
  if tg_op in ('UPDATE','DELETE') and ebda.counts_in_budget(old) and coalesce(old.line_id,'')<>'' and ebda.exp_fy(old.date) is not null then
    update ebda.agg_line_month set amount = amount - coalesce(old.amount,0)
     where line_id = old.line_id and school_id = coalesce(old.school_id,'') and fy = ebda.exp_fy(old.date) and m = ebda.fy_month(old.date);
  end if;
  if tg_op in ('UPDATE','INSERT') and ebda.counts_in_budget(new) and coalesce(new.line_id,'')<>'' and ebda.exp_fy(new.date) is not null then
    insert into ebda.agg_line_month(line_id, school_id, fy, m, amount)
    values (new.line_id, coalesce(new.school_id,''), ebda.exp_fy(new.date), ebda.fy_month(new.date), coalesce(new.amount,0))
    on conflict (line_id, school_id, fy, m) do update set amount = ebda.agg_line_month.amount + excluded.amount;
  end if;
  return null;
end $am$;
drop trigger if exists trg_agg_line_month on ebda.expenses;
create trigger trg_agg_line_month after insert or update or delete on ebda.expenses for each row execute function ebda.agg_line_month_trg();

create or replace function ebda.rebuild_line_agg() returns void language sql security definer set search_path = ebda as $rb$
  delete from ebda.agg_line_month;
  insert into ebda.agg_line_month(line_id, school_id, fy, m, amount)
  select x.line_id, coalesce(x.school_id,''), ebda.exp_fy(x.date), ebda.fy_month(x.date), sum(x.amount)
  from ebda.expenses x where ebda.counts_in_budget(x) and coalesce(x.line_id,'')<>'' and ebda.exp_fy(x.date) is not null
  group by 1, 2, 3, 4 $rb$;
do $ra$ begin perform ebda.rebuild_line_agg(); end $ra$;

-- المصروف المحتسب لكل بند لكل شهر داخل السنة المالية لجهته — تجميع فى مرور واحد على المصروفات (بدون ربط صف بصف)،
-- ثم مطابقة سنة المصروف المالية مع سنة الجهة. أساس line_months وتقارير الموازنة (نفس قاعدة budgetModel فى الواجهة).
create or replace function ebda.line_fy_spend(u ebda.users) returns table(line_id text, school_id text, m int, amount numeric)
language plpgsql stable security definer set search_path = ebda as $lf$
declare star boolean := coalesce(u.schools,'')='*' or ebda.role_key(u.role)='admin'; sch text[] := ebda.scope_arr(u);
begin
  return query
  select a.line_id, a.school_id, a.m, a.amount from ebda.agg_line_month a
  join ebda.schools s on s.id = a.school_id
  join ebda.lines l on l.id = a.line_id and coalesce(l.deleted_at,'') = ''
  where (star or a.school_id = any(sch)) and a.amount <> 0
    and (coalesce(s.period,'') !~ '\d{4}' or a.fy = substring(s.period from '\d{4}')::int);
end $lf$;

create or replace function ebda.line_months(u ebda.users) returns jsonb language sql stable as $lm$
  with z as materialized (select line_id, m, sum(amount) amount from ebda.line_fy_spend(u) group by 1, 2)
  select coalesce(jsonb_object_agg(line_id, arr), '{}'::jsonb) from (
    select k.line_id, jsonb_agg(coalesce(a.amount, 0) order by gs) arr
    from (select distinct line_id from z) k cross join generate_series(1, 12) gs
    left join z a on a.line_id = k.line_id and a.m = gs
    group by k.line_id) q $lm$;

-- ---------------------------------------------------------------- bootstrap قابل للتوسع (v6)
-- • يُبنى الرد مرة واحدة (بدون نسخ متكرر لكائن ضخم) • كل التجميعات محسوبة داخل قاعدة البيانات
-- • عند كثرة المصروفات (> bootstrap_full_limit) تُرسل «نافذة عمل» فقط: آخر bootstrap_expense_days يوماً + كل ما لم يكتمل
--   (مسودة/بانتظار/معاد/بانتظار التسوية)، والباقى متاح بالبحث والتقارير على الخادم. الأرقام كلها من التجميعات الكاملة.
insert into ebda.config(key,value) values ('bootstrap_full_limit','3000'),('bootstrap_expense_days','60'),('bootstrap_expense_max','5000'),('bootstrap_payslip_months','2')
on conflict (key) do nothing;

create or replace function ebda.cfg_int(k text, d int) returns int language sql stable as $$
  select coalesce(nullif((select value from ebda.config where key=k),'')::int, d) $$;

-- (التعريف فى 005_bootstrap.sql)

