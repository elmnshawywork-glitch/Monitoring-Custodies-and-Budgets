-- ============================================================================
--  ابدأ إديو — Migration 003: استيراد الموازنة (دمج آمن) + تتبع التعديلات + العهد والمصروفات
--  يُشغَّل بعد 001 و 002 (Supabase ‹ SQL Editor ‹ New query ‹ الصق ‹ Run). آمن لإعادة التشغيل.
--
--  ما يفعله (إضافات فقط، لا حذف ولا إعادة إنشاء لأى بيانات):
--   • أعمدة جديدة: custodies.kind / purpose · expenses.pay_method · audit_log.txid
--   • جدول جديد ebda.audit_changes: القيمة القديمة والجديدة لكل إضافة/تعديل/حذف (يُملأ تلقائياً بـ Triggers)
--   • importBudget بوضع «دمج» (mode='merge'): يحدّث البنود المطابقة ويضيف الجديدة فقط — لا يحذف أى بند
--   • منع تكرار البند (نفس الجهة + نفس القسم + نفس الاسم) فى الإضافة والتعديل والاستيراد
--   • إنشاء عهدة بقيمتها الأساسية فى خطوة واحدة · طريقة الدفع للمصروف · تسجيل التصدير فى تتبع التعديلات
--  ⚠ بعد هذا الملف لا تُعِد تشغيل 002 (يعيد الإصدار السابق من الدالة). أعد تشغيل 003 فقط إن لزم.
-- ============================================================================

-- ---------------------------------------------------------------- أعمدة جديدة (لا تغيّر الموجود)
alter table ebda.custodies add column if not exists kind text default '';
alter table ebda.custodies add column if not exists purpose text default '';
alter table ebda.expenses  add column if not exists pay_method text default '';
alter table ebda.audit_log add column if not exists txid bigint;
alter table ebda.audit_log alter column txid set default txid_current();

insert into ebda.config(key,value) values ('custody_overdue_days','30') on conflict (key) do nothing;

-- ---------------------------------------------------------------- تطبيع النصوص العربية (للمطابقة ومنع التكرار)
-- نفس القواعد مطبقة فى الواجهة (frontend/src/lib/budget.js → normAr)
create or replace function ebda.norm_txt(t text) returns text language sql immutable as $$
  select btrim(regexp_replace(
           regexp_replace(
             btrim(regexp_replace(
               translate(lower(coalesce(t,'')), 'أإآٱىةـًٌٍَُِّْ', 'اااايه'),
             '[^0-9a-zء-ي]+', ' ', 'g')),
           '^(اولا|ثانيا|ثالثا|رابعا|خامسا|سادسا|سابعا|ثامنا|تاسعا|عاشرا)( |$)', ''),
         ' +', ' ', 'g'))
$$;

-- ---------------------------------------------------------------- تتبع التعديلات: القيمة القديمة والجديدة
create table if not exists ebda.audit_changes(
  id bigserial primary key,
  txid bigint default txid_current(),
  ts timestamptz default now(),
  actor_id text default '',
  tbl text, row_id text, op text,
  school_id text default '',
  old_v jsonb, new_v jsonb);
create index if not exists ix_auditch_tx on ebda.audit_changes(txid);
create index if not exists ix_audit_tx on ebda.audit_log(txid);

create or replace function ebda.track_change() returns trigger
language plpgsql security definer set search_path = ebda as $tc$
declare
  o jsonb := case when tg_op in ('UPDATE','DELETE') then to_jsonb(old) else null end;
  nw jsonb := case when tg_op in ('UPDATE','INSERT') then to_jsonb(new) else null end;
  k text; od jsonb := '{}'::jsonb; nd jsonb := '{}'::jsonb; sid text;
  hide text[] := array['pin','updated_at','updated_by','last_login'];
begin
  -- لا تُسجَّل كلمات السر ولا محتوى الملفات
  if o  is not null then o  := o  - 'pin'; if coalesce(o->>'doc_url','')  like 'data:%' then o  := o  || '{"doc_url":"[ملف مرفق]"}'; end if; end if;
  if nw is not null then nw := nw - 'pin'; if coalesce(nw->>'doc_url','') like 'data:%' then nw := nw || '{"doc_url":"[ملف مرفق]"}'; end if; end if;
  if tg_op = 'UPDATE' then
    for k in select jsonb_object_keys(nw) loop
      if k = any(hide) then continue; end if;
      if (o->k) is distinct from (nw->k) then od := od || jsonb_build_object(k, o->k); nd := nd || jsonb_build_object(k, nw->k); end if;
    end loop;
    if (to_jsonb(old)->>'pin') is distinct from (to_jsonb(new)->>'pin') then nd := nd || '{"pin":"(تم تغيير كلمة السر)"}'; end if;
    if nd = '{}'::jsonb then return null; end if;
  else
    od := o; nd := nw;
  end if;
  sid := coalesce(nw->>'school_id', o->>'school_id', '');
  if tg_table_name = 'tranches' then
    sid := coalesce((select c.school_id from ebda.custodies c where c.id = coalesce(nw->>'custody_id', o->>'custody_id')), '');
  end if;
  insert into ebda.audit_changes(actor_id, tbl, row_id, op, school_id, old_v, new_v)
  values (coalesce(current_setting('ebda.auth_uid', true),''), tg_table_name, coalesce(nw->>'id', o->>'id', ''), lower(tg_op), sid,
          case when tg_op='INSERT' then null else od end, case when tg_op='DELETE' then null else nd end);
  return null;
end $tc$;

do $tr$
declare t text;
begin
  foreach t in array array['schools','lines','custodies','tranches','expenses','requests','users','temp_budgets'] loop
    execute format('drop trigger if exists trg_track_%1$s on ebda.%1$I', t);
    execute format('create trigger trg_track_%1$s after insert or update or delete on ebda.%1$I for each row execute function ebda.track_change()', t);
  end loop;
end $tr$;
