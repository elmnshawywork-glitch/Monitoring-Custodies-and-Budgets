-- ============================================================================
--  ابدأ إديو — Migration 004: صلاحيات مرنة · دورة اعتماد العهدة وإلغاؤها · أسماء العهد وتوزيعها على البنود
--                            · حذف الموازنة (حذف منطقى) · نظام الرواتب الشهرى (Payroll)
--  يُشغَّل بعد 001 و 002 و 003. آمن لإعادة التشغيل. إضافات فقط — لا حذف ولا إعادة إنشاء لأى بيانات.
--  ⚠ بعد هذا الملف لا تُعِد تشغيل 002 أو 003 وحدهما (يعيدان إصداراً سابقاً من الدالة). أعد تشغيل 004 فقط.
-- ============================================================================

-- ---------------------------------------------------------------- العهد: الاسم · الاعتماد · الإلغاء · المسئول من العاملين
alter table ebda.custodies add column if not exists title text default '';
alter table ebda.custodies add column if not exists approval text default 'approved';   -- draft | review | approved (العهد الحالية تبقى معتمدة)
alter table ebda.custodies add column if not exists approved_by text default '';
alter table ebda.custodies add column if not exists approved_at text default '';
alter table ebda.custodies add column if not exists submitted_by text default '';
alter table ebda.custodies add column if not exists cancel_reason text default '';
alter table ebda.custodies add column if not exists cancelled_by text default '';
alter table ebda.custodies add column if not exists cancelled_at text default '';
alter table ebda.custodies add column if not exists holder_emp_id text default '';
update ebda.custodies set approval='approved' where approval is null or approval='';

-- أسماء العهد (Master Data) — يديرها الأدمن؛ sections = الأقسام/البنود المرتبطة (اختيارى) لتصفية البنود تلقائياً
create table if not exists ebda.custody_names(id text primary key, name text not null, active text default 'نعم', sort int default 0, sections text default '');
insert into ebda.custody_names(id,name,sort)
select v.id, v.name, v.sort from (values ('cn_ops','عهدة تشغيلية',1),('cn_purch','عهدة مشتريات',2),('cn_maint','عهدة صيانة',3),('cn_petty','عهدة نثريات',4),('cn_trans','عهدة انتقالات',5)) v(id,name,sort)
where not exists (select 1 from ebda.custody_names);

-- توزيع العهدة على بنود الموازنة (المخصص داخل العهدة لكل بند)
create table if not exists ebda.custody_lines(id text primary key, custody_id text not null, line_id text not null, amount numeric default 0, note text default '');
create unique index if not exists ux_custody_lines on ebda.custody_lines(custody_id, line_id);

-- ---------------------------------------------------------------- الموازنة: حذف منطقى (Soft Delete) قابل للاسترجاع
alter table ebda.lines add column if not exists deleted_at text default '';
alter table ebda.lines add column if not exists deleted_by text default '';
alter table ebda.lines add column if not exists delete_reason text default '';

-- ---------------------------------------------------------------- الرواتب الشهرية (Payroll)
alter table ebda.employees add column if not exists staff_group text default '';      -- private | gov | cleaning | security | hq
alter table ebda.employees add column if not exists assignment text default '';       -- جهة التعيين
alter table ebda.employees add column if not exists work_type text default '';        -- نوع الدوام
alter table ebda.employees add column if not exists insurance_status text default ''; -- مؤمن عليه / غير مؤمن عليه / حكومى
alter table ebda.employees add column if not exists national_key text default '';     -- الرقم القومى بعد التطبيع (مفتاح منع التكرار)
update ebda.employees set national_key=regexp_replace(coalesce(national_id,''),'[^0-9]','','g') where coalesce(national_key,'')='' and coalesce(national_id,'')<>'';
create index if not exists ix_emp_nkey on ebda.employees(national_key);

alter table ebda.payslips add column if not exists staff_group text default '';
alter table ebda.payslips add column if not exists job text default '';
alter table ebda.payslips add column if not exists month_days numeric default 0;
alter table ebda.payslips add column if not exists work_days numeric default 0;
alter table ebda.payslips add column if not exists attend_days numeric default 0;
alter table ebda.payslips add column if not exists rest_days numeric default 0;
alter table ebda.payslips add column if not exists absent_days numeric default 0;
alter table ebda.payslips add column if not exists permissions numeric default 0;
alter table ebda.payslips add column if not exists deduct_days numeric default 0;
alter table ebda.payslips add column if not exists direct_ded numeric default 0;
alter table ebda.payslips add column if not exists leave_opening numeric default 0;
alter table ebda.payslips add column if not exists leave_used numeric default 0;
alter table ebda.payslips add column if not exists leave_balance numeric default 0;
alter table ebda.payslips add column if not exists task_pct numeric default 0;
alter table ebda.payslips add column if not exists quality_pct numeric default 0;
alter table ebda.payslips add column if not exists avg_pct numeric default 0;
alter table ebda.payslips add column if not exists net_import numeric default 0;      -- الصافى كما فى التقرير الشهرى (قبل المؤثرات)
alter table ebda.payslips add column if not exists adjustments jsonb default '{}'::jsonb;  -- المؤثرات {code: amount}
alter table ebda.payslips add column if not exists source_file text default '';
alter table ebda.payslips add column if not exists updated_at text default '';
create index if not exists ix_pay_month on ebda.payslips(school_id, month);

-- عناصر الراتب (Master Data) — تُضاف عناصر جديدة دون تعديل الكود. kind: earning (يُضاف) | deduction (يُخصم)
create table if not exists ebda.payroll_components(id text primary key, code text unique, name text, kind text default 'deduction', active text default 'نعم', sort int default 0, system text default 'لا');
insert into ebda.payroll_components(id,code,name,kind,sort,system) values
  ('pc_bonus','bonus','مكافأة','earning',1,'نعم'),
  ('pc_incent','incentive','حافز إضافى','earning',2,'نعم'),
  ('pc_allow','allowance','بدلات','earning',3,'نعم'),
  ('pc_ot_h','overtime_hour','إضافى ساعات','earning',4,'نعم'),
  ('pc_ot_d','overtime_day','إضافى أيام','earning',5,'نعم'),
  ('pc_ded_h','deduct_hour','خصم ساعات / تأخير','deduction',6,'نعم'),
  ('pc_ded_d','deduct_day','خصم أيام','deduction',7,'نعم'),
  ('pc_adv','advance','سلفة','deduction',8,'نعم'),
  ('pc_ins','insurance','تأمينات','deduction',9,'نعم'),
  ('pc_tax','tax','ضرائب','deduction',10,'نعم'),
  ('pc_other','other_deduction','استقطاعات أخرى','deduction',11,'نعم')
on conflict (id) do nothing;

-- فترة الرواتب لكل مكان وشهر (مسودة ← معتمدة)
create table if not exists ebda.payroll_periods(id text primary key, school_id text, month text, status text default 'draft',
  file_name text default '', imported_at text default '', imported_by text default '', approved_by text default '', approved_at text default '');
create unique index if not exists ux_payroll_period on ebda.payroll_periods(school_id, month);

insert into ebda.config(key,value) values ('payroll_map','') on conflict (key) do nothing;

-- ---------------------------------------------------------------- الصلاحيات: Role (الدور) + Permissions (ما يستطيع) + Scope (أين)
-- الافتراضى لكل دور = سلوك النظام الحالى تماماً. users.perms يضيف (+perm أو perm) أو يسحب (-perm) صلاحية لمستخدم بعينه.
create or replace function ebda.perm_defaults(rk text) returns text[] language sql immutable as $$
  select case rk
    when 'admin' then array['budget.edit','custody.create','custody.approve','expense.record','expense.approve','expense.fin_approve',
                            'request.approve','request.fin_approve','payroll.view','payroll.import','payroll.approve','manage_users']
    when 'finance_manager' then array['budget.edit','custody.create','custody.approve','expense.fin_approve','request.fin_approve',
                            'payroll.view','payroll.import','payroll.approve']
    when 'direct_manager' then array['expense.approve','request.approve']
    when 'custody_officer' then array['expense.record']
    else array[]::text[] end
$$;
create or replace function ebda.perms_of(u ebda.users) returns text[] language sql stable as $$
  select array(
    select p from unnest(ebda.perm_defaults(ebda.rk(u))) p
    where not (('-'||p) = any(string_to_array(regexp_replace(coalesce(u.perms,''),'\s','','g'), ',')))
    union
    select ltrim(x,'+') from unnest(string_to_array(regexp_replace(coalesce(u.perms,''),'\s','','g'), ',')) x
    where x <> '' and left(x,1) <> '-')
$$;
create or replace function ebda.can(u ebda.users, p text) returns boolean language sql stable as $$
  select ebda.rk(u)='admin' or p = any(ebda.perms_of(u))
$$;

-- تتبع التعديلات: نفس الدالة مع ربط توزيع العهدة بمكانها
create or replace function ebda.track_change() returns trigger
language plpgsql security definer set search_path = ebda as $tc$
declare
  o jsonb := case when tg_op in ('UPDATE','DELETE') then to_jsonb(old) else null end;
  nw jsonb := case when tg_op in ('UPDATE','INSERT') then to_jsonb(new) else null end;
  k text; od jsonb := '{}'::jsonb; nd jsonb := '{}'::jsonb; sid text;
  hide text[] := array['pin','updated_at','updated_by','last_login'];
begin
  -- لا تُسجَّل كلمات السر ولا محتوى الملفات
  if o  is not null then o  := o  - 'pin'; if coalesce(o->>'doc_url','')  like 'data:%' then o  := o  || '{"doc_url":"[ملف مرفق]"}'; end if; end if;
  if nw is not null then nw := nw - 'pin'; if coalesce(nw->>'doc_url','') like 'data:%' then nw := nw || '{"doc_url":"[ملف مرفق]"}'; end if; end if;
  if tg_op = 'UPDATE' then
    for k in select jsonb_object_keys(nw) loop
      if k = any(hide) then continue; end if;
      if (o->k) is distinct from (nw->k) then od := od || jsonb_build_object(k, o->k); nd := nd || jsonb_build_object(k, nw->k); end if;
    end loop;
    if (to_jsonb(old)->>'pin') is distinct from (to_jsonb(new)->>'pin') then nd := nd || '{"pin":"(تم تغيير كلمة السر)"}'; end if;
    if nd = '{}'::jsonb then return null; end if;
  else
    od := o; nd := nw;
  end if;
  sid := coalesce(nw->>'school_id', o->>'school_id', '');
  if tg_table_name in ('tranches','custody_lines') then
    sid := coalesce((select c.school_id from ebda.custodies c where c.id = coalesce(nw->>'custody_id', o->>'custody_id')), '');
  end if;
  insert into ebda.audit_changes(actor_id, tbl, row_id, op, school_id, old_v, new_v)
  values (coalesce(current_setting('ebda.auth_uid', true),''), tg_table_name, coalesce(nw->>'id', o->>'id', ''), lower(tg_op), sid,
          case when tg_op='INSERT' then null else od end, case when tg_op='DELETE' then null else nd end);
  return null;
end $tc$;

-- تتبع التعديلات للجداول الجديدة والرواتب
do $tr$
declare t text;
begin
  foreach t in array array['custody_lines','custody_names','payslips','employees','payroll_periods','payroll_components'] loop
    execute format('drop trigger if exists trg_track_%1$s on ebda.%1$I', t);
    execute format('create trigger trg_track_%1$s after insert or update or delete on ebda.%1$I for each row execute function ebda.track_change()', t);
  end loop;
end $tr$;

-- ---------------------------------------------------------------- مساعدات
create or replace function ebda.num_ok(t text) returns boolean language sql immutable as $$
  select coalesce(t,'') ~ '^\s*-?[0-9]*\.?[0-9]*\s*$'
$$;
-- صافى الراتب = الصافى من التقرير الشهرى + المؤثرات (الإضافات تُضاف، الاستقطاعات تُخصم) حسب عناصر الراتب
create or replace function ebda.payslip_net(base_net numeric, adj jsonb) returns numeric language sql stable as $$
  select coalesce(base_net,0) + coalesce((select sum(case when c.kind='earning' then 1 else -1 end * coalesce(nullif(a.value,'')::numeric,0))
     from jsonb_each_text(coalesce(adj,'{}'::jsonb)) a join ebda.payroll_components c on c.code=a.key),0)
$$;
