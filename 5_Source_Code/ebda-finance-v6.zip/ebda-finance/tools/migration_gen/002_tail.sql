
-- ============================================================================
--  الواجهة العامة api(): تسجيل الدخول ينشئ جلسة، وكل طلب يحمل التوكن (أو PIN للتوافق)
-- ============================================================================
create or replace function ebda.api(req jsonb)
returns jsonb language plpgsql security definer set search_path = ebda as $w$
declare
  action text := req->>'action';
  tok text := req#>>'{auth,token}';
  th text; sess ebda.sessions; res jsonb;
  idle int := coalesce(nullif((select value from ebda.config where key='session_idle_hours'),'')::int, 12);
  maxd int := coalesce(nullif((select value from ebda.config where key='session_max_days'),'')::int, 7);
begin
  perform set_config('ebda.auth_uid', '', true);
  perform set_config('ebda.session_hash', '', true);
  if action = 'login' then
    res := ebda.api_core(req);
    if res ? 'ok' then
      tok := encode(extensions.gen_random_bytes(32), 'hex');
      insert into ebda.sessions(id, token_hash, user_id, created_at, last_seen, expires_at, user_agent)
      values (ebda.uid(), encode(extensions.digest(tok, 'sha256'), 'hex'), res#>>'{user,id}', now(), now(),
              now() + make_interval(days => maxd), left(coalesce(req->>'ua',''), 200));
      delete from ebda.sessions where expires_at < now() or last_seen < now() - make_interval(hours => idle);
      res := res || jsonb_build_object('token', tok, 'session_idle_hours', idle);
    end if;
    return res;
  end if;
  if coalesce(tok,'') <> '' then
    th := encode(extensions.digest(tok, 'sha256'), 'hex');
    if action = 'logout' then delete from ebda.sessions where token_hash = th; return jsonb_build_object('ok', true); end if;
    select * into sess from ebda.sessions
     where token_hash = th and expires_at > now() and last_seen > now() - make_interval(hours => idle);
    if not found then return ebda.err('انتهت الجلسة — سجّل الدخول من جديد'); end if;
    update ebda.sessions set last_seen = now() where id = sess.id;
    perform set_config('ebda.auth_uid', sess.user_id, true);
    perform set_config('ebda.session_hash', th, true);
    req := req - 'auth';
  elsif action = 'logout' then
    return jsonb_build_object('ok', true);
  end if;
  return ebda.api_core(req);
end $w$;

-- ---------------------------------------------------------------- مستودع المستندات (Supabase Storage)
do $st$
begin
  if to_regclass('storage.buckets') is not null then
    insert into storage.buckets(id, name, public) values ('ebda-docs', 'ebda-docs', false) on conflict (id) do nothing;
  end if;
end $st$;

-- ---------------------------------------------------------------- الصلاحيات: الدالة العامة فقط
create or replace function public.api(req jsonb) returns jsonb
  language sql security definer set search_path = ebda, public
  as $wrap$ select ebda.api(req) $wrap$;
revoke all on all tables in schema ebda from anon, authenticated;
revoke all on all sequences in schema ebda from anon, authenticated;
revoke execute on all functions in schema ebda from public, anon, authenticated;
grant usage on schema ebda to anon, authenticated;
grant execute on function ebda.api(jsonb) to anon, authenticated;
grant execute on function public.api(jsonb) to anon, authenticated;

insert into ebda.config(key,value) values ('schema_version','2') on conflict (key) do update set value='2';
