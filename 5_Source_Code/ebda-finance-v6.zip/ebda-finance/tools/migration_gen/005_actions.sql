  -- ================================================================ v6: دورة المصروف
  if action = 'submitExpense' then   -- مسودة / معاد للتعديل ← بانتظار المدير المباشر · معاد من المدير المالى ← المراجعة المالية
    select * into ex from ebda.expenses where id=(req->>'id');
    if not found then return ebda.err('المصروف غير موجود'); end if;
    select * into cust from ebda.custodies where id=ex.custody_id;
    if not (urole='admin' or ebda.owns_custody(u, cust)) then return ebda.err('الإرسال لصاحب المصروف فقط'); end if;
    if coalesce(ex.cancelled_at,'')<>'' then return ebda.err('المصروف ملغى'); end if;
    if ex.approval in ('draft','returned') then
      update ebda.expenses set approval='pending', submitted_at=now()::text, updated_by=u.name, updated_at=now()::text where id=ex.id;
      return jsonb_build_object('ok',true,'stage','pending_manager');
    elsif ex.approval='approved' and ex.fin_approval='returned' then
      update ebda.expenses set fin_approval='', submitted_at=now()::text, updated_by=u.name, updated_at=now()::text where id=ex.id;
      return jsonb_build_object('ok',true,'stage','pending_finance');
    end if;
    return ebda.err('المصروف ليس مسودة ولا معاداً للتعديل');
  end if;

  if action = 'cancelExpense' then   -- للأدمن فقط، فى أى مرحلة: لا حذف — الحالة «ملغى» مع السبب (يخرج من الموازنة ورصيد العهدة)
    if urole<>'admin' then return ebda.err('إلغاء المصروف للأدمن فقط'); end if;
    select * into ex from ebda.expenses where id=(req->>'id');
    if not found then return ebda.err('المصروف غير موجود'); end if;
    if coalesce(ex.cancelled_at,'')<>'' then return ebda.err('المصروف ملغى بالفعل'); end if;
    if length(coalesce(btrim(req->>'reason'),''))<3 then return ebda.err('اكتب سبب الإلغاء'); end if;
    update ebda.expenses set cancelled_at=now()::text, cancelled_by=u.name, cancel_reason=btrim(req->>'reason'),
      updated_by=u.name, updated_at=now()::text where id=ex.id;
    return jsonb_build_object('ok',true);
  end if;

  if action = 'unapproveExpense' then   -- إلغاء الاعتماد (للأدمن): يعود المصروف لاعتماد المدير المباشر
    if urole<>'admin' then return ebda.err('إلغاء الاعتماد للأدمن فقط'); end if;
    select * into ex from ebda.expenses where id=(req->>'id');
    if not found then return ebda.err('المصروف غير موجود'); end if;
    if coalesce(ex.cancelled_at,'')<>'' then return ebda.err('المصروف ملغى'); end if;
    if length(coalesce(btrim(req->>'reason'),''))<3 then return ebda.err('اكتب سبب إلغاء الاعتماد'); end if;
    update ebda.expenses set approval='pending', approved_by='', approved_by_id='', approved_at='', approval_note='',
      fin_approval='', fin_by='', fin_by_id='', fin_at='', settled='', settled_at='', settled_by='', settled_by_id='',
      return_reason='إلغاء اعتماد بواسطة الأدمن: '||btrim(req->>'reason'), updated_by=u.name, updated_at=now()::text
    where id=ex.id;
    return jsonb_build_object('ok',true);
  end if;

  if action = 'getDoc' then   -- فتح مستند مرفوع داخل النظام (لا يُرسَل محتوى الملفات مع تحميل الصفحة)
    select * into ex from ebda.expenses where id=(req->>'id');
    if not found then return ebda.err('المصروف غير موجود'); end if;
    if not ebda.can_expense(u, ex) then return ebda.err('لا صلاحية على هذا المستند'); end if;
    return jsonb_build_object('ok',true,'url',coalesce(ex.doc_url,''),'name',coalesce(ex.doc_name,''));
  end if;

  if action = 'expenseHistory' then   -- كل خطوات المصروف من «تتبع التعديلات»
    select * into ex from ebda.expenses where id=(req->>'id');
    if not found then return ebda.err('المصروف غير موجود'); end if;
    if not ebda.can_expense(u, ex) then return ebda.err('لا صلاحية على هذا المصروف'); end if;
    return jsonb_build_object('ok',true,'items', coalesce((
      select jsonb_agg(jsonb_build_object('ts', l.ts, 'actor', l.actor, 'role', l.actor_role, 'action', l.action,
                                          'old', c.old_v - 'doc_url', 'new', c.new_v - 'doc_url') order by l.ts)
      from ebda.audit_changes c join ebda.audit_log l on l.txid = c.txid
      where c.tbl='expenses' and c.row_id=ex.id),'[]'::jsonb));
  end if;

  -- ================================================================ v6: Master Data (أنواع العهد · أنواع الموازنات/الجهات)
  if action = 'saveCustodyKind' then
    if urole<>'admin' then return ebda.err('إدارة أنواع العهد للأدمن فقط'); end if;
    dj := req->'item';
    if coalesce(btrim(dj->>'name'),'')='' then return ebda.err('اكتب اسم النوع'); end if;
    if exists(select 1 from ebda.custody_kinds z where ebda.norm_txt(z.name)=ebda.norm_txt(dj->>'name') and z.id<>coalesce(dj->>'id','')) then
      return ebda.err('هذا النوع موجود بالفعل'); end if;
    if coalesce(dj->>'id','')='' then
      newid := ebda.uid();
      insert into ebda.custody_kinds(id,name,active,sort) values(newid, btrim(dj->>'name'), coalesce(nullif(dj->>'active',''),'نعم'), coalesce(nullif(dj->>'sort','')::int,99));
    else
      newid := dj->>'id';
      -- تغيير الاسم ينعكس على العهد القديمة (التصنيف مخزّن كنص)
      update ebda.custodies c set kind=btrim(dj->>'name') from ebda.custody_kinds z where z.id=newid and c.kind=z.name and z.name<>btrim(dj->>'name');
      update ebda.custody_kinds set name=btrim(dj->>'name'), active=coalesce(nullif(dj->>'active',''),active), sort=coalesce(nullif(dj->>'sort','')::int,sort) where id=newid;
      if not found then return ebda.err('النوع غير موجود'); end if;
    end if;
    return jsonb_build_object('ok',true,'id',newid);
  end if;

  if action = 'saveEntityType' then
    if urole<>'admin' then return ebda.err('إدارة أنواع الموازنات للأدمن فقط'); end if;
    dj := req->'item';
    if coalesce(btrim(dj->>'label'),'')='' then return ebda.err('اكتب اسم النوع'); end if;
    if coalesce(dj->>'code','')='' then
      newid := 'et_'||substr(md5(dj->>'label'||clock_timestamp()::text),1,8);
      insert into ebda.entity_types(code,label,active,sort) values(newid, btrim(dj->>'label'), coalesce(nullif(dj->>'active',''),'نعم'), coalesce(nullif(dj->>'sort','')::int,99));
    else
      newid := dj->>'code';
      update ebda.entity_types set label=btrim(dj->>'label'), active=coalesce(nullif(dj->>'active',''),active), sort=coalesce(nullif(dj->>'sort','')::int,sort) where code=newid;
      if not found then return ebda.err('النوع غير موجود'); end if;
    end if;
    return jsonb_build_object('ok',true,'code',newid);
  end if;

  if action = 'setLineActive' then   -- تعطيل/تفعيل بند (للأدمن): المعطّل لا يقبل إدخالات جديدة ويبقى بتاريخه فى التقارير
    if urole<>'admin' then return ebda.err('تعطيل البنود للأدمن فقط'); end if;
    if not exists(select 1 from ebda.lines where id=(req->>'id')) then return ebda.err('البند غير موجود'); end if;
    update ebda.lines set active=case when coalesce(req->>'active','') like '%نعم%' then 'نعم' else 'لا' end where id=(req->>'id');
    return jsonb_build_object('ok',true);
  end if;

  if action = 'setSetting' then   -- إعدادات يغيّرها الأدمن من الواجهة (قائمة محددة فقط)
    if urole<>'admin' then return ebda.err('الإعدادات للأدمن فقط'); end if;
    if coalesce(req->>'key','') not in ('require_doc_to_settle','custody_overdue_days') then return ebda.err('إعداد غير معروف'); end if;
    if req->>'key'='require_doc_to_settle' and coalesce(req->>'value','') not in ('yes','no') then return ebda.err('قيمة غير صحيحة'); end if;
    if req->>'key'='custody_overdue_days' and coalesce(req->>'value','') !~ '^[0-9]{1,4}$' then return ebda.err('عدد أيام غير صحيح'); end if;
    insert into ebda.config(key,value) values(req->>'key', req->>'value') on conflict (key) do update set value=excluded.value;
    return jsonb_build_object('ok',true);
  end if;

  -- ================================================================ v6: النسخ الاحتياطى والاستعادة (للأدمن فقط)
  if action in ('createBackup','downloadBackup','restoreBackup','backupInfo') then
    if urole<>'admin' then return ebda.err('النسخ الاحتياطى للأدمن فقط'); end if;
    if action = 'createBackup' then
      return jsonb_build_object('ok',true,'backup', ebda.make_backup('manual', u.name, coalesce(req->>'note','')));
    end if;
    if action = 'backupInfo' then
      return jsonb_build_object('ok',true,'item',(select jsonb_build_object('id',b.id,'name',b.name,'kind',b.kind,'created_at',b.created_at,'created_by',b.created_by,
             'size_bytes',b.size_bytes,'counts',b.counts,'note',b.note,'schema_version',b.data#>>'{_meta,schema_version}') from ebda.backups b where b.id=(req->>'id')));
    end if;
    if action = 'downloadBackup' then
      return jsonb_build_object('ok',true,'name',(select name from ebda.backups where id=(req->>'id')),
                                'data',(select data from ebda.backups where id=(req->>'id')));
    end if;
    -- restoreBackup: يتطلب كتابة اسم النسخة للتأكيد
    if coalesce(req->>'confirm','') <> coalesce((select name from ebda.backups where id=(req->>'id')),'~') then
      return ebda.err('للتأكيد اكتب اسم النسخة كما هو'); end if;
    nk := (select value from ebda.config where key='schema_version');
    res := ebda.restore_backup(req->>'id', u.name);
    if res ? 'error' then return res; end if;
    update ebda.config set value=nk where key='schema_version';   -- إصدار قاعدة البيانات الحالى لا يتغير بالاستعادة
    return res;
  end if;

  -- ================================================================ v6: استيراد العاملين الآمن (معاينة ← تحقق ← تأكيد) — بدون تكرار وبدون حذف
  -- الموظف له معرّف ثابت: يُطابَق بالرقم القومى (فى كل الأماكن) ثم بالرقم الوظيفى ثم بالاسم داخل المكان.
  -- ---------------------------------------------------------------- استيراد ملف المصروفات والعهد (معاينة ← استيراد)
  if action = 'importExpensesFile' then
    return ebda.import_expenses(u, req);
  end if;
  if action = 'importBatches' then
    if not (urole = 'admin' or ebda.can(u,'expense.import')) then return ebda.err('صلاحية استيراد المصروفات مطلوبة'); end if;
    return jsonb_build_object('ok', true, 'batches', coalesce((select jsonb_agg(jsonb_build_object('id', b.id, 'file_name', b.file_name, 'actor', b.actor,
        'created_at', b.created_at, 'approve_mode', b.approve_mode, 'rows_n', b.rows_n, 'imported_n', b.imported_n, 'amount', b.amount,
        'summary', b.summary, 'exceptions_n', jsonb_array_length(b.exceptions), 'reverted_at', b.reverted_at, 'reverted_by', b.reverted_by,
        'exceptions', case when b.id = req->>'id' then b.exceptions else null end) order by b.created_at desc)
      from (select * from ebda.import_batches z where urole = 'admin' or z.actor_id = u.id order by z.created_at desc limit 100) b), '[]'::jsonb));
  end if;
  if action = 'revertImport' then
    if urole <> 'admin' then return ebda.err('التراجع عن الاستيراد للأدمن فقط'); end if;
    return ebda.revert_import(u, req->>'id', req->>'reason');
  end if;

  if action = 'importEmployeesSafe' then
    if not (ebda.can(u,'payroll.import') or urole='admin') then return ebda.err('صلاحية استيراد العاملين مطلوبة'); end if;
    sid := req->>'school_id';
    if sid is null or not exists(select 1 from ebda.schools s where s.id=sid) then return ebda.err('اختر المكان'); end if;
    if not ebda.can_school(u, sid) then return ebda.err('هذا المكان ليس ضمن نطاقك'); end if;
    if jsonb_typeof(coalesce(req->'rows','null'::jsonb))<>'array' then return ebda.err('لا توجد بيانات'); end if;
    catv := case when req->>'category'='gov' then 'gov' else 'contract' end;
    declare
      fields text[] := array['serial_no','emp_no','name','job','job_type','qualification','grad_year','national_id','birth_date','birth_place','phone',
                             'hire_date','work_start','gender','secondment_status','address','retire_date','email','bank','account_no','branch',
                             'insurance_no','base_salary','contract_type','dept','note'];
      f text; nm text; ek ebda.employees; eid text; st text; reasons jsonb; changes jsonb; out jsonb := '[]'::jsonb;
      seen_nk text[] := '{}'; seen_nm text[] := '{}'; i int := 0;
      c_new int := 0; c_upd int := 0; c_same int := 0; c_dup int := 0; c_err int := 0; c_warn int := 0;
      commit_ boolean := coalesce(req->>'mode','preview') = 'commit';
      rw jsonb;
    begin
      for rw in select * from jsonb_array_elements(req->'rows') loop
        i := i + 1; reasons := '[]'::jsonb; changes := '[]'::jsonb; eid := null; ek := null;
        nm := btrim(coalesce(rw->>'name',''));
        nk := regexp_replace(translate(coalesce(rw->>'national_id',''), '٠١٢٣٤٥٦٧٨٩', '0123456789'), '[^0-9]', '', 'g');
        if nm = '' then
          st := 'error'; reasons := reasons || to_jsonb('اسم الموظف مطلوب'::text);
        elsif coalesce(rw->>'base_salary','') <> '' and not ebda.num_ok(rw->>'base_salary') then
          st := 'error'; reasons := reasons || to_jsonb('الراتب/الحافز ليس رقماً'::text);
        elsif (nk <> '' and nk = any(seen_nk)) or (nk = '' and ebda.norm_txt(nm) = any(seen_nm)) then
          st := 'duplicate'; reasons := reasons || to_jsonb(case when nk<>'' then 'الرقم القومى مكرر داخل الملف' else 'الاسم مكرر داخل الملف' end);
        else
          if nk <> '' and length(nk) <> 14 then reasons := reasons || to_jsonb('الرقم القومى ليس 14 رقماً'::text); end if;
          if nk = '' then reasons := reasons || to_jsonb('الرقم القومى غير موجود'::text); end if;
          if coalesce(rw->>'phone','') = '' then reasons := reasons || to_jsonb('رقم الهاتف غير موجود'::text); end if;
          if nk <> '' then select * into ek from ebda.employees e where e.national_key = nk order by e.id limit 1; end if;
          if ek.id is null and coalesce(rw->>'emp_no','')<>'' then
            select * into ek from ebda.employees e where e.school_id=sid and e.emp_no = rw->>'emp_no' order by e.id limit 1; end if;
          if ek.id is null then
            select * into ek from ebda.employees e where e.school_id=sid and ebda.norm_txt(e.name)=ebda.norm_txt(nm) order by e.id limit 1; end if;
          if ek.id is null then
            st := 'new';
          else
            eid := ek.id;
            foreach f in array fields loop
              if coalesce(btrim(rw->>f),'') <> '' and coalesce(to_jsonb(ek)->>f,'') is distinct from btrim(rw->>f)
                 and not (f='base_salary' and ebda.num_ok(rw->>f) and coalesce(ek.base_salary,0) = nullif(btrim(rw->>f),'')::numeric) then
                changes := changes || to_jsonb(f);
              end if;
            end loop;
            if ek.school_id is distinct from sid then
              changes := changes || to_jsonb('school_id'::text);
              reasons := reasons || to_jsonb(('مسجل فى مكان آخر: ' || coalesce((select s.name from ebda.schools s where s.id=ek.school_id),'—') || ' — سيُنقل لهذا المكان')::text);
            end if;
            st := case when jsonb_array_length(changes) > 0 then 'updated' else 'same' end;
          end if;
          if nk <> '' then seen_nk := seen_nk || nk; else seen_nm := seen_nm || ebda.norm_txt(nm); end if;
        end if;
        if st = 'new' then c_new := c_new + 1; elsif st = 'updated' then c_upd := c_upd + 1; elsif st = 'same' then c_same := c_same + 1;
        elsif st = 'duplicate' then c_dup := c_dup + 1; else c_err := c_err + 1; end if;
        if st in ('new','updated','same') and jsonb_array_length(reasons) > 0 then c_warn := c_warn + 1; end if;
        if commit_ and st = 'new' then
          eid := ebda.uid();
          insert into ebda.employees(id,school_id,category,emp_no,serial_no,name,job,job_type,qualification,grad_year,national_id,national_key,birth_date,birth_place,phone,
              hire_date,work_start,gender,secondment_status,address,retire_date,email,bank,account_no,branch,insurance_no,base_salary,contract_type,dept,note,
              staff_group,active,archived)
          values(eid, sid, catv, coalesce(rw->>'emp_no',''), coalesce(rw->>'serial_no',''), nm, coalesce(rw->>'job',''), coalesce(rw->>'job_type',''),
              coalesce(rw->>'qualification',''), coalesce(rw->>'grad_year',''), coalesce(rw->>'national_id',''), nk, coalesce(rw->>'birth_date',''),
              coalesce(rw->>'birth_place',''), coalesce(rw->>'phone',''), coalesce(rw->>'hire_date',''), coalesce(rw->>'work_start',''), coalesce(rw->>'gender',''),
              coalesce(rw->>'secondment_status',''), coalesce(rw->>'address',''), coalesce(rw->>'retire_date',''), coalesce(rw->>'email',''), coalesce(rw->>'bank',''),
              coalesce(rw->>'account_no',''), coalesce(rw->>'branch',''), coalesce(rw->>'insurance_no',''), coalesce(nullif(btrim(rw->>'base_salary'),'')::numeric,0),
              coalesce(nullif(rw->>'contract_type',''), case when catv='gov' then 'منتدب' else '' end), coalesce(rw->>'dept',''), coalesce(rw->>'note',''),
              case when catv='gov' then 'gov' else '' end, 'نعم', 'لا');
        elsif commit_ and st = 'updated' then
          -- تحديث الحقول القادمة فى الملف فقط — لا يُمسح أى حقل موجود بقيمة فارغة
          update ebda.employees set school_id=sid,
            emp_no=coalesce(nullif(btrim(rw->>'emp_no'),''),emp_no), serial_no=coalesce(nullif(btrim(rw->>'serial_no'),''),serial_no),
            name=nm, job=coalesce(nullif(btrim(rw->>'job'),''),job), job_type=coalesce(nullif(btrim(rw->>'job_type'),''),job_type),
            qualification=coalesce(nullif(btrim(rw->>'qualification'),''),qualification), grad_year=coalesce(nullif(btrim(rw->>'grad_year'),''),grad_year),
            national_id=coalesce(nullif(btrim(rw->>'national_id'),''),national_id), national_key=coalesce(nullif(nk,''),national_key),
            birth_date=coalesce(nullif(btrim(rw->>'birth_date'),''),birth_date), birth_place=coalesce(nullif(btrim(rw->>'birth_place'),''),birth_place),
            phone=coalesce(nullif(btrim(rw->>'phone'),''),phone), hire_date=coalesce(nullif(btrim(rw->>'hire_date'),''),hire_date),
            work_start=coalesce(nullif(btrim(rw->>'work_start'),''),work_start), gender=coalesce(nullif(btrim(rw->>'gender'),''),gender),
            secondment_status=coalesce(nullif(btrim(rw->>'secondment_status'),''),secondment_status), address=coalesce(nullif(btrim(rw->>'address'),''),address),
            retire_date=coalesce(nullif(btrim(rw->>'retire_date'),''),retire_date), email=coalesce(nullif(btrim(rw->>'email'),''),email),
            bank=coalesce(nullif(btrim(rw->>'bank'),''),bank), account_no=coalesce(nullif(btrim(rw->>'account_no'),''),account_no),
            branch=coalesce(nullif(btrim(rw->>'branch'),''),branch), insurance_no=coalesce(nullif(btrim(rw->>'insurance_no'),''),insurance_no),
            base_salary=coalesce(nullif(btrim(rw->>'base_salary'),'')::numeric,base_salary), contract_type=coalesce(nullif(btrim(rw->>'contract_type'),''),contract_type),
            dept=coalesce(nullif(btrim(rw->>'dept'),''),dept), note=coalesce(nullif(btrim(rw->>'note'),''),note)
          where id=eid;
        end if;
        out := out || jsonb_build_object('i', i, 'name', nm, 'national_id', coalesce(rw->>'national_id',''), 'status', st, 'reasons', reasons,
                                         'changes', changes, 'employee_id', coalesce(eid,''));
      end loop;
      return jsonb_build_object('ok', true, 'mode', case when commit_ then 'commit' else 'preview' end,
        'counts', jsonb_build_object('new', c_new, 'updated', c_upd, 'same', c_same, 'duplicate', c_dup, 'error', c_err, 'warnings', c_warn),
        'rows', out);
    end;
  end if;

  if action = 'payrollMonth' then   -- قسائم شهر أقدم من نافذة التحميل (تُطلب عند اختياره فقط)
    if not (ebda.sees_budgets(u) or ebda.can(u,'payroll.view')) then return ebda.err('لا صلاحية لعرض الرواتب'); end if;
    if coalesce(req->>'month','') !~ '^[0-9]{4}-[0-9]{2}$' then return ebda.err('الشهر غير صحيح'); end if;
    return jsonb_build_object('ok',true,'payslips', coalesce((select jsonb_agg(to_jsonb(z)) from ebda.payslips z
      where z.month = req->>'month' and ebda.can_school(u, z.school_id)),'[]'::jsonb));
  end if;
