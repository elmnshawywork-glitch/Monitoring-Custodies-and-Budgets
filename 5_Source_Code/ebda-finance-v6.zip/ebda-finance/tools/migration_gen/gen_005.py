"""Generates supabase/migrations/005_workflow_backup_performance.sql from the tested api_core in 004.
All 001-004 rules are kept; changes are exact, asserted replacements + one block of new actions (005_actions.sql + 005_reports.sql)."""
import pathlib
here = pathlib.Path(__file__).parent
root = here.resolve().parents[1] / 'supabase' / 'migrations'
s4 = (root / '004_permissions_custody_payroll.sql').read_text(encoding='utf8')
a = s4.index('create or replace function ebda.api_core(req jsonb)')
b = s4.index('$fn$;', a) + len('$fn$;')
core = s4[a:b]


def R(old, new, count=1):
    global core
    n = core.count(old)
    assert n == count, (old[:120], n)
    core = core.replace(old, new)


# ---------------------------------------------------------------- read-only helpers are not written to the audit log
R("if action not in ('bootstrap','ping','lineStatus','notifyInfo','docAuth') then",
  "if action not in ('bootstrap','ping','lineStatus','notifyInfo','docAuth','getDoc','expenseHistory','backupInfo','searchExpenses','report','payrollMonth','importBatches')\n"
  "     and not (action in ('importExpensesFile','importEmployeesSafe') and coalesce(req->>'mode','preview') <> 'commit') then")
# ملفات الاستيراد: لا تُنسخ الصفوف كلها فى سجل التدقيق (تُحفظ فى دفعة الاستيراد) — عددها فقط
R("    if dj ? 'user' then dj := dj #- '{user,pin}'; end if;",
  "    if dj ? 'user' then dj := dj #- '{user,pin}'; end if;\n"
  "    if action in ('importExpensesFile','importEmployeesSafe') then dj := (dj - 'rows') || jsonb_build_object('rows_n', jsonb_array_length(coalesce(req->'rows','[]'::jsonb))); end if;")

# ---------------------------------------------------------------- ownership by user id (username changes keep ownership)
n_own = core.count("""coalesce(cust."user",'')=u.username""")
assert n_own == 7, n_own
core = core.replace("""coalesce(cust."user",'')=u.username""", "ebda.owns_custody(u, cust)")
R("""coalesce(cust."user",'')<>u.username""", "not ebda.owns_custody(u, cust)")
R("""    if rq.requester = u.username and urole<>'admin' then return ebda.err('لا يمكنك اعتماد طلبك بنفسك'); end if;""",
  """    if urole<>'admin' and ((coalesce(rq.requester_id,'')<>'' and rq.requester_id=u.id) or rq.requester = u.username) then return ebda.err('لا يمكنك اعتماد طلبك بنفسك'); end if;""", count=2)
R("""      where (urole='custody_officer' and r.requester=u.username)""",
  """      where (urole='custody_officer' and ((coalesce(r.requester_id,'')<>'' and r.requester_id=u.id) or (coalesce(r.requester_id,'')='' and r.requester=u.username)))""")
# المدير المباشر المكلَّف بمسئول العهدة هو من يقرر على طلبه
R("""    if rq.status <> 'pending_supervisor' then return ebda.err('الطلب ليس فى مرحلة اعتماد المدير المباشر'); end if;""",
  """    if rq.status <> 'pending_supervisor' then return ebda.err('الطلب ليس فى مرحلة اعتماد المدير المباشر'); end if;
    if urole<>'admin' and exists(select 1 from ebda.users z where z.id=rq.requester_id and coalesce(z.manager_id,'')<>'' and z.manager_id<>u.id) then
      return ebda.err('هذا الطلب تابع لمسئول عهدة مرتبط بمدير مباشر آخر'); end if;""")

# ---------------------------------------------------------------- inactive (disabled) budget lines: no new entries
R("""    if coalesce(req#>>'{expense,line_id}','')<>'' and exists(select 1 from ebda.lines l where l.id=req#>>'{expense,line_id}' and coalesce(l.deleted_at,'')<>'') then
      return ebda.err('بند الموازنة محذوف'); end if;""",
  """    if coalesce(req#>>'{expense,line_id}','')<>'' and exists(select 1 from ebda.lines l where l.id=req#>>'{expense,line_id}' and coalesce(l.deleted_at,'')<>'') then
      return ebda.err('بند الموازنة محذوف'); end if;
    if coalesce(req#>>'{expense,line_id}','')<>'' and exists(select 1 from ebda.lines l where l.id=req#>>'{expense,line_id}' and coalesce(l.active,'نعم') not like '%نعم%') then
      return ebda.err('بند الموازنة معطّل — لا يقبل مصروفات جديدة'); end if;
    if coalesce(btrim(req#>>'{expense,doc_link}'),'')<>'' and btrim(req#>>'{expense,doc_link}') !~* '^https?://' then
      return ebda.err('رابط المستند يجب أن يبدأ بـ http:// أو https://'); end if;""")
R("""      if not exists(select 1 from ebda.lines l where l.id=ln->>'line_id' and l.school_id=req#>>'{custody,school_id}' and coalesce(l.deleted_at,'')='') then
        return ebda.err('بند غير تابع لمكان العهدة'); end if;""",
  """      if not exists(select 1 from ebda.lines l where l.id=ln->>'line_id' and l.school_id=req#>>'{custody,school_id}' and coalesce(l.deleted_at,'')='') then
        return ebda.err('بند غير تابع لمكان العهدة'); end if;
      if exists(select 1 from ebda.lines l where l.id=ln->>'line_id' and coalesce(l.active,'نعم') not like '%نعم%') then
        return ebda.err('بند معطّل — لا يمكن التوزيع عليه'); end if;""")
R("""      if not exists(select 1 from ebda.lines l where l.id=ln->>'line_id' and l.school_id=cust.school_id and coalesce(l.deleted_at,'')='') then
        return ebda.err('بند غير تابع لمكان العهدة'); end if;""",
  """      if not exists(select 1 from ebda.lines l where l.id=ln->>'line_id' and l.school_id=cust.school_id and coalesce(l.deleted_at,'')='') then
        return ebda.err('بند غير تابع لمكان العهدة'); end if;
      if exists(select 1 from ebda.lines l where l.id=ln->>'line_id' and coalesce(l.active,'نعم') not like '%نعم%')
         and not exists(select 1 from ebda.custody_lines cl where cl.custody_id=cust.id and cl.line_id=ln->>'line_id') then
        return ebda.err('بند معطّل — لا يمكن التوزيع عليه'); end if;""")
R("""              where coalesce(it->>'line_id','')<>'' and not exists(select 1 from ebda.lines l where l.id=it->>'line_id' and l.school_id=sid)) then
      return ebda.err('بند غير تابع لهذه الجهة'); end if;""",
  """              where coalesce(it->>'line_id','')<>'' and not exists(select 1 from ebda.lines l where l.id=it->>'line_id' and l.school_id=sid)) then
      return ebda.err('بند غير تابع لهذه الجهة'); end if;
    if exists(select 1 from jsonb_array_elements(coalesce(req#>'{request,items}','[]'::jsonb)) it join ebda.lines l on l.id=it->>'line_id'
              where coalesce(l.active,'نعم') not like '%نعم%') then
      return ebda.err('بند معطّل — لا يقبل طلبات جديدة'); end if;""")

# ---------------------------------------------------------------- addExpense: draft, document link, ids
R("""       (req#>>'{expense,amount}')::numeric,'pending','', '','','','','','',coalesce(req#>>'{expense,note}',''), u.name, now()::text,""",
  """       (req#>>'{expense,amount}')::numeric, case when coalesce(req#>>'{expense,draft}','') in ('1','true','نعم') then 'draft' else 'pending' end,
       '', '','','','','','',coalesce(req#>>'{expense,note}',''), u.name, now()::text,""")
R("""    update ebda.expenses set pay_method=coalesce(req#>>'{expense,pay_method}','') where id=newid;
    return jsonb_build_object('ok',true,'item',(select to_jsonb(e) from ebda.expenses e where e.id=newid))
           || ebda.over_warning(u, req#>>'{expense,line_id}');
  end if;

  if action = 'addCentral' then""",
  """    update ebda.expenses set pay_method=coalesce(req#>>'{expense,pay_method}',''), created_by_id=u.id,
      submitted_at=case when approval='pending' then now()::text else '' end where id=newid;
    -- رابط المستند المؤيد (فاتورة/إيصال/Drive/OneDrive/SharePoint...) يُسجَّل مع المصروف
    if coalesce(btrim(req#>>'{expense,doc_link}'),'') ~* '^https?://' then
      update ebda.expenses set doc_url=btrim(req#>>'{expense,doc_link}'), doc_is_link='نعم',
        doc_name=coalesce(nullif(req#>>'{expense,doc_name}',''),'رابط مستند'), doc_type=coalesce(req#>>'{expense,doc_type}','') where id=newid;
    end if;
    return jsonb_build_object('ok',true,'item',(select to_jsonb(e) - 'doc_url' || jsonb_build_object('doc_url', case when e.doc_url like 'data:%' then 'inline:' else coalesce(e.doc_url,'') end)
                                                from ebda.expenses e where e.id=newid))
           || ebda.over_warning(u, req#>>'{expense,line_id}');
  end if;

  if action = 'addCentral' then""")
R("""       'EXP-'||lpad(nextval('ebda.seq_exp')::text,5,'0'), coalesce(req->>'doc_type',''));
    update ebda.expenses set pay_method=coalesce(req#>>'{expense,pay_method}','') where id=newid;""",
  """       'EXP-'||lpad(nextval('ebda.seq_exp')::text,5,'0'), coalesce(req->>'doc_type',''));
    update ebda.expenses set pay_method=coalesce(req#>>'{expense,pay_method}',''), created_by_id=u.id, approved_by_id=u.id, fin_by_id=u.id,
      settled_by=u.name, settled_by_id=u.id where id=newid;""")

# ---------------------------------------------------------------- direct-manager decision: assigned manager only, reason, return-for-edit, separation of duties
R("""      if not ebda.can(u,'expense.approve') then return ebda.err('صلاحية اعتماد المصروفات مطلوبة'); end if;
      if urole<>'admin' and ebda.owns_custody(u, cust) then return ebda.err('لا يمكنك اعتماد مصروفك بنفسك'); end if;
      if urole<>'admin' and ex.approval<>'pending' then return ebda.err('تم اتخاذ القرار على هذا المصروف من قبل'); end if;
      if patch->>'approval' not in ('approved','rejected','pending') then return ebda.err('قيمة اعتماد غير صحيحة'); end if;
      update ebda.expenses set approval=patch->>'approval', approved_by=u.name, approved_at=now()::text,
        note=coalesce(patch->>'note', note), updated_by=u.name, updated_at=now()::text
      where id=ex.id;""",
  """      if not ebda.can(u,'expense.approve') then return ebda.err('صلاحية اعتماد المصروفات مطلوبة'); end if;
      if coalesce(ex.cancelled_at,'')<>'' then return ebda.err('المصروف ملغى'); end if;
      -- الفصل بين المهام: لا يعتمد أحد مصروفاً هو صاحب عهدته أو منشئه (إلا الأدمن)
      if urole<>'admin' and (ebda.owns_custody(u, cust) or coalesce(ex.created_by_id,'')=u.id) then return ebda.err('لا يمكنك اعتماد مصروفك بنفسك'); end if;
      if urole<>'admin' and cust.id is not null and not ebda.is_assigned_manager(u, cust) then
        return ebda.err('هذا المصروف تابع لمسئول عهدة مرتبط بمدير مباشر آخر'); end if;
      if urole<>'admin' and ex.approval<>'pending' then return ebda.err('تم اتخاذ القرار على هذا المصروف من قبل'); end if;
      if patch->>'approval' not in ('approved','rejected','returned','pending') then return ebda.err('قيمة اعتماد غير صحيحة'); end if;
      if patch->>'approval' in ('rejected','returned') and length(btrim(coalesce(patch->>'note','')))<2 then
        return ebda.err('اكتب سبب الرفض أو الإعادة للتعديل'); end if;
      update ebda.expenses set approval=patch->>'approval', approved_by=u.name, approved_by_id=u.id, approved_at=now()::text,
        approval_note=coalesce(patch->>'note',''),
        returned_by=case when patch->>'approval'='returned' then u.name else returned_by end,
        returned_at=case when patch->>'approval'='returned' then now()::text else returned_at end,
        return_reason=case when patch->>'approval'='returned' then btrim(patch->>'note') else return_reason end,
        updated_by=u.name, updated_at=now()::text
      where id=ex.id;""")
# تعديل صاحب المصروف: المسودة / قبل الاعتماد / بعد الإعادة للتعديل (من المدير المباشر أو المالى)
R("""    if not (urole='admin' or (ebda.owns_custody(u, cust) and ex.approval='pending')) then
      return ebda.err('لا يمكن التعديل بعد اعتماد الصرف'); end if;""",
  """    if not (urole='admin' or (ebda.owns_custody(u, cust) and coalesce(ex.cancelled_at,'')=''
            and (ex.approval in ('pending','draft','returned') or (ex.approval='approved' and ex.fin_approval='returned')))) then
      return ebda.err('لا يمكن التعديل بعد اعتماد الصرف'); end if;
    if patch ? 'date' and coalesce(patch->>'date','') > to_char(now() + interval '1 day','YYYY-MM-DD') then return ebda.err('تاريخ المصروف فى المستقبل'); end if;
    if patch ? 'line_id' and patch->>'line_id' is distinct from ex.line_id and exists(select 1 from ebda.lines l where l.id=patch->>'line_id' and coalesce(l.active,'نعم') not like '%نعم%') then
      return ebda.err('بند الموازنة معطّل — لا يقبل مصروفات جديدة'); end if;
    -- تغيير المبلغ أو البند بعد اعتماد المدير المباشر يعيد المصروف لاعتماده من جديد
    if urole<>'admin' and ex.approval='approved' and ((patch ? 'amount' and (patch->>'amount')::numeric is distinct from ex.amount)
                                                   or (patch ? 'line_id' and patch->>'line_id' is distinct from ex.line_id)) then
      update ebda.expenses set approval='returned', fin_approval='', return_reason='تم تعديل المبلغ/البند بعد الاعتماد — يلزم اعتماد جديد' where id=ex.id;
    end if;""")

# ---------------------------------------------------------------- financial review: separation of duties, return-for-edit, settlement by
R("""    if urole<>'admin' and cust.id is not null and ebda.owns_custody(u, cust) then return ebda.err('لا يمكنك اعتماد مصروفك بنفسك'); end if;
    patch := req->'patch';""",
  """    if urole<>'admin' and ((cust.id is not null and ebda.owns_custody(u, cust)) or coalesce(ex.created_by_id,'')=u.id) then
      return ebda.err('لا يمكنك مراجعة مصروف أنت صاحبه أو منشئه'); end if;
    if coalesce(ex.cancelled_at,'')<>'' then return ebda.err('المصروف ملغى'); end if;
    patch := req->'patch';
    if patch ? 'fin_approval' and coalesce(patch->>'fin_approval','') in ('rejected','returned') and length(btrim(coalesce(patch->>'fin_note','')))<2 then
      return ebda.err('اكتب سبب الرفض أو الإعادة للتعديل'); end if;
    if coalesce(patch->>'settled','') like '%نعم%' and coalesce(patch->>'fin_approval', ex.fin_approval)='returned' then
      return ebda.err('لا يمكن تسوية مصروف معاد للتعديل'); end if;
    if coalesce(patch->>'settled','') like '%نعم%' and urole<>'admin' and coalesce(ex.doc_url,'')=''
       and coalesce((select value from ebda.config where key='require_doc_to_settle'),'no')='yes' then
      return ebda.err('لا يمكن التسوية بدون المستند المؤيد'); end if;""")
R("""    if patch ? 'fin_approval' and coalesce(patch->>'fin_approval','') not in ('','approved','rejected') then return ebda.err('قيمة اعتماد مالى غير صحيحة'); end if;""",
  """    if patch ? 'fin_approval' and coalesce(patch->>'fin_approval','') not in ('','approved','rejected','returned') then return ebda.err('قيمة اعتماد مالى غير صحيحة'); end if;""")
R("""      settled_at = case when patch ? 'settled' then case when coalesce(patch->>'settled','') like '%نعم%' then now()::text else '' end else settled_at end,
      updated_by=u.name, updated_at=now()::text
    where id = ex.id;""",
  """      settled_at = case when patch ? 'settled' then case when coalesce(patch->>'settled','') like '%نعم%' then now()::text else '' end else settled_at end,
      updated_by=u.name, updated_at=now()::text
    where id = ex.id;
    update ebda.expenses set
      fin_by_id = case when patch ? 'fin_approval' or coalesce(patch->>'settled','') like '%نعم%' then u.id else fin_by_id end,
      settled_by = case when patch ? 'settled' then case when coalesce(patch->>'settled','') like '%نعم%' then u.name else '' end else settled_by end,
      settled_by_id = case when patch ? 'settled' then case when coalesce(patch->>'settled','') like '%نعم%' then u.id else '' end else settled_by_id end,
      returned_by = case when patch->>'fin_approval'='returned' then u.name else returned_by end,
      returned_at = case when patch->>'fin_approval'='returned' then now()::text else returned_at end,
      return_reason = case when patch->>'fin_approval'='returned' then btrim(patch->>'fin_note') else return_reason end
    where id = ex.id;""")

# ---------------------------------------------------------------- documents: not on cancelled expenses
R("""  if action = 'uploadDoc' then
    select * into ex from ebda.expenses where id=(req->>'id');
    if not found then return ebda.err('المصروف غير موجود'); end if;""",
  """  if action = 'uploadDoc' then
    select * into ex from ebda.expenses where id=(req->>'id');
    if not found then return ebda.err('المصروف غير موجود'); end if;
    if coalesce(ex.cancelled_at,'')<>'' then return ebda.err('المصروف ملغى'); end if;
    if coalesce(req->>'link','')<>'' and btrim(req->>'link') !~* '^(https?://|storage:)' then return ebda.err('رابط المستند يجب أن يبدأ بـ http:// أو https://'); end if;""")

# ---------------------------------------------------------------- delete: only before any decision; afterwards the admin cancels (history stays)
R("""    if urole<>'admin' then
      select * into cust from ebda.custodies where id=ex.custody_id;
      if not (ebda.owns_custody(u, cust) and ex.approval='pending') then
        return ebda.err('لا يمكن الحذف بعد اعتماد الصرف'); end if;
    end if;""",
  """    if urole<>'admin' then
      select * into cust from ebda.custodies where id=ex.custody_id;
      if not (ebda.owns_custody(u, cust) and ex.approval in ('pending','draft','returned') and coalesce(ex.fin_approval,'')='') then
        return ebda.err('لا يمكن الحذف بعد اعتماد الصرف'); end if;
    elsif coalesce(ex.fin_approval,'')='approved' or coalesce(ex.settled,'') like '%نعم%' then
      return ebda.err('المصروف معتمد مالياً/مسوّى — استخدم «إلغاء المصروف» حتى يبقى أثره فى التقارير وتتبع التعديلات');
    end if;""")

# ---------------------------------------------------------------- bootstrap
# الجهات: كل جهات النطاق (المعطّلة تبقى للتاريخ والتقارير وتُستبعد من الإدخال الجديد فى الواجهة)
R("""    res := res || jsonb_build_object('schools', coalesce((select jsonb_agg(to_jsonb(s)) from ebda.schools s
        where coalesce(s.active,'') like '%نعم%' and ebda.can_school(u, s.id)),'[]'::jsonb));""",
  """    res := res || jsonb_build_object('schools', coalesce((select jsonb_agg(to_jsonb(s) order by (coalesce(s.active,'') like '%نعم%') desc, s.name) from ebda.schools s
        where ebda.can_school(u, s.id)),'[]'::jsonb));
    res := res || jsonb_build_object('custody_kinds', coalesce((select jsonb_agg(to_jsonb(z) order by z.sort, z.name) from ebda.custody_kinds z),'[]'::jsonb));
    res := res || jsonb_build_object('entity_types', coalesce((select jsonb_agg(to_jsonb(z) order by z.sort) from ebda.entity_types z),'[]'::jsonb));
    -- فريق المدير المباشر (مسئولو العهد المرتبطون به) + مديرو كل مسئول (لعرض من يعتمد)
    res := res || jsonb_build_object('team', coalesce((select jsonb_agg(jsonb_build_object('id',z.id,'username',z.username,'name',z.name))
        from ebda.users z where z.manager_id=u.id),'[]'::jsonb));
    res := res || jsonb_build_object('managers', coalesce((select jsonb_agg(jsonb_build_object('id',z.id,'name',z.name,'role_key',ebda.role_key(z.role)))
        from ebda.users z where ebda.role_key(z.role) in ('direct_manager','admin') and coalesce(z.active,'') like '%نعم%'),'[]'::jsonb));""")
R("""          'spent',(select coalesce(sum(e.amount),0) from ebda.expenses e where e.custody_id=c.id and e.approval<>'rejected' and coalesce(e.fin_approval,'')<>'rejected'),""",
  """          'spent',(select coalesce(sum(e.amount),0) from ebda.expenses e where e.custody_id=c.id and ebda.active_on_custody(e)),
          'manager_id',(select coalesce(o.manager_id,'') from ebda.users o where o.id=c.user_id),""")
# المصروفات: بدون محتوى الملفات المرفوعة داخل القاعدة (يُفتح عند الطلب بـ getDoc) — مجموعة واحدة بدلاً من استعلام لكل صف
R("""    res := res || jsonb_build_object('expenses', coalesce((select jsonb_agg(to_jsonb(e)) from ebda.expenses e
        where ebda.can_expense(u, e)),'[]'::jsonb));""",
  """    res := res || jsonb_build_object('expenses', coalesce((select jsonb_agg(to_jsonb(e) - 'doc_url' || jsonb_build_object('doc_url',
          case when e.doc_url like 'data:%' then 'inline:' else coalesce(e.doc_url,'') end))
        from ebda.expenses e left join ebda.custodies c on c.id=e.custody_id
        where urole='admin'
           or (c.id is not null and ebda.can_custody(u, c))
           or (c.id is null and urole<>'custody_officer' and ebda.can_school(u, e.school_id))),'[]'::jsonb));
    res := jsonb_set(res, '{settings,require_doc_to_settle}', to_jsonb(coalesce((select value from ebda.config where key='require_doc_to_settle'),'no')));
    -- أرقام الموازنة الشهرية محسوبة على الخادم (اللوحة لا تجمع آلاف المصروفات على الجهاز)
    if urole in ('admin','finance_manager','direct_manager') then
      res := res || jsonb_build_object('line_months', ebda.line_months(u));
    end if;""")
R("""      res := res || jsonb_build_object('tempBudgets', coalesce((select jsonb_agg(to_jsonb(z)) from ebda.temp_budgets z),'[]'::jsonb));""",
  """      res := res || jsonb_build_object('tempBudgets', coalesce((select jsonb_agg(to_jsonb(z)) from ebda.temp_budgets z),'[]'::jsonb));
      res := res || jsonb_build_object('backups', coalesce((select jsonb_agg(jsonb_build_object('id',b.id,'name',b.name,'kind',b.kind,'created_at',b.created_at,
          'created_by',b.created_by,'size_bytes',b.size_bytes,'counts',b.counts,'note',b.note) order by b.created_at desc) from ebda.backups b),'[]'::jsonb));""")
R("""      res := res || jsonb_build_object('users', coalesce((select jsonb_agg(jsonb_build_object('id',z.id,'username',z.username,'name',z.name,'role',z.role,'role_label',ebda.role_label(z.role))) from ebda.users z),'[]'::jsonb));""",
  """      res := res || jsonb_build_object('users', coalesce((select jsonb_agg(jsonb_build_object('id',z.id,'username',z.username,'name',z.name,'role',z.role,'role_label',ebda.role_label(z.role),'manager_id',coalesce(z.manager_id,''))) from ebda.users z),'[]'::jsonb));""")

# ---------------------------------------------------------------- users: direct manager (assignment) + department
R("""      insert into ebda.users(id,username,pin,name,role,schools,active,email,perms,must_reset)
      values(newid, dj->>'username', ebda.pin_hash(dj->>'pin'), dj->>'name', coalesce(ebda.role_legacy(dj->>'role'),'custody'),
         coalesce(dj->>'schools',''), coalesce(dj->>'active','نعم'), coalesce(dj->>'email',''), coalesce(dj->>'perms',''), 'نعم');""",
  """      if coalesce(dj->>'manager_id','')<>'' and not exists(select 1 from ebda.users z where z.id=dj->>'manager_id') then return ebda.err('المدير المباشر غير موجود'); end if;
      insert into ebda.users(id,username,pin,name,role,schools,active,email,perms,must_reset,manager_id,dept)
      values(newid, dj->>'username', ebda.pin_hash(dj->>'pin'), dj->>'name', coalesce(ebda.role_legacy(dj->>'role'),'custody'),
         coalesce(dj->>'schools',''), coalesce(dj->>'active','نعم'), coalesce(dj->>'email',''), coalesce(dj->>'perms',''), 'نعم',
         coalesce(dj->>'manager_id',''), coalesce(dj->>'dept',''));""")
R("""    if dj ? 'username' and exists(select 1 from ebda.users z where z.username=dj->>'username' and z.id<>xu.id) then return ebda.err('اسم المستخدم مستخدم من قبل'); end if;""",
  """    if dj ? 'username' and exists(select 1 from ebda.users z where z.username=dj->>'username' and z.id<>xu.id) then return ebda.err('اسم المستخدم مستخدم من قبل'); end if;
    if coalesce(dj->>'manager_id','')<>'' and (dj->>'manager_id'=xu.id or not exists(select 1 from ebda.users z where z.id=dj->>'manager_id')) then
      return ebda.err('المدير المباشر غير صحيح'); end if;""")
R("""      active=coalesce(dj->>'active',active), email=coalesce(dj->>'email',email), perms=coalesce(dj->>'perms',perms)
    where id=xu.id;""",
  """      active=coalesce(dj->>'active',active), email=coalesce(dj->>'email',email), perms=coalesce(dj->>'perms',perms),
      manager_id=coalesce(dj->>'manager_id',manager_id), dept=coalesce(dj->>'dept',dept)
    where id=xu.id;""")
# لا يُحذف مستخدم له عهد أو مصروفات (يُعطَّل بدلاً من ذلك حتى لا يضيع التاريخ)
R("""      delete from ebda.sessions where user_id=xu.id;
      delete from ebda.users where id=xu.id;""",
  """      if exists(select 1 from ebda.custodies c where c.user_id=xu.id) or exists(select 1 from ebda.expenses e where e.created_by_id=xu.id)
         or exists(select 1 from ebda.users z where z.manager_id=xu.id) then
        return ebda.err('لا يمكن حذف مستخدم له عهد أو مصروفات أو فريق — عطّله بدلاً من الحذف'); end if;
      delete from ebda.sessions where user_id=xu.id;
      delete from ebda.users where id=xu.id;""")

# ---------------------------------------------------------------- employees: links (dept / direct manager / place)
R("""  if action = 'archiveEmployee' then""",
  """  if action = 'linkEmployee' then
    update ebda.employees set dept=coalesce(req#>>'{patch,dept}',dept), manager_user_id=coalesce(req#>>'{patch,manager_user_id}',manager_user_id),
      school_id=coalesce(req#>>'{patch,school_id}',school_id), job=coalesce(req#>>'{patch,job}',job), contract_type=coalesce(req#>>'{patch,contract_type}',contract_type)
    where id=(req->>'id');
    return jsonb_build_object('ok',true);
  end if;
  if action = 'archiveEmployee' then""")

# ---------------------------------------------------------------- employees: extra master-record fields + links
R("""      note=coalesce(patch->>'note',note), school_id=coalesce(patch->>'school_id',school_id)
    where id=(req->>'id');""",
  """      note=coalesce(patch->>'note',note), school_id=coalesce(patch->>'school_id',school_id),
      dept=coalesce(patch->>'dept',dept), manager_user_id=coalesce(patch->>'manager_user_id',manager_user_id),
      birth_place=coalesce(patch->>'birth_place',birth_place), secondment_status=coalesce(patch->>'secondment_status',secondment_status),
      serial_no=coalesce(patch->>'serial_no',serial_no),
      national_key=case when patch ? 'national_id' then regexp_replace(translate(coalesce(patch->>'national_id',''), '٠١٢٣٤٥٦٧٨٩', '0123456789'), '[^0-9]', '', 'g') else national_key end
    where id=(req->>'id');""")
R("""    return jsonb_build_object('ok',true,'item',(select to_jsonb(z) from ebda.employees z where z.id=newid));
  end if;
  if action = 'updateEmployee' then""",
  """    update ebda.employees set dept=coalesce(dj->>'dept',''), manager_user_id=coalesce(dj->>'manager_user_id',''), birth_place=coalesce(dj->>'birth_place',''),
      secondment_status=coalesce(dj->>'secondment_status',''), serial_no=coalesce(dj->>'serial_no',''),
      national_key=regexp_replace(translate(coalesce(dj->>'national_id',''), '٠١٢٣٤٥٦٧٨٩', '0123456789'), '[^0-9]', '', 'g') where id=newid;
    return jsonb_build_object('ok',true,'item',(select to_jsonb(z) from ebda.employees z where z.id=newid));
  end if;
  if action = 'updateEmployee' then""")

R("""  if action = 'addEmployee' then
    newid := ebda.uid(); dj := req->'emp';""",
  """  if action = 'addEmployee' then
    newid := ebda.uid(); dj := req->'emp';
    -- منع تكرار الموظف عند الإضافة اليدوية أيضاً (نفس الرقم القومى)
    nk := regexp_replace(translate(coalesce(dj->>'national_id',''), '٠١٢٣٤٥٦٧٨٩', '0123456789'), '[^0-9]', '', 'g');
    if nk <> '' and exists(select 1 from ebda.employees z where z.national_key = nk) then
      return ebda.err('يوجد موظف مسجل بنفس الرقم القومى — عدّل بياناته بدلاً من إضافته مرة أخرى'); end if;""")

# ---------------------------------------------------------------- bootstrap: replaced by the scalable server-side version (same data contract + aggregates)
i = core.index("  if action = 'bootstrap' then")
j = core.index("    return res;\n  end if;", i) + len("    return res;\n  end if;")
core = core[:i] + """  if action = 'bootstrap' then
    return ebda.bootstrap_v6(u);
  end if;""" + core[j:]

# ---------------------------------------------------------------- new actions (before the admin-only section)
NEW = (here / '005_actions.sql').read_text(encoding='utf8')
rep = here / '005_reports.sql'
if rep.exists():
    NEW += '\n' + rep.read_text(encoding='utf8')
R("""
  -- ================================================================ باقى الإجراءات للأدمن فقط (كما فى النظام الحالى)""",
  NEW + """
  -- ================================================================ باقى الإجراءات للأدمن فقط (كما فى النظام الحالى)""")

head = (here / '005_head.sql').read_text(encoding='utf8') + '\n' + (here / '005_bootstrap.sql').read_text(encoding='utf8') + '\n' + (here / '005_import.sql').read_text(encoding='utf8')
tail = (here / '005_tail.sql').read_text(encoding='utf8')
out = (head + '\n\n-- ============================================================================\n'
       '--  الدالة الأساسية (قواعد 001 → 004 + الإضافات أعلاه)\n-- ============================================================================\n' + core + '\n' + tail)
(root / '005_workflow_backup_performance.sql').write_text(out, encoding='utf8')
print('written', len(out))
