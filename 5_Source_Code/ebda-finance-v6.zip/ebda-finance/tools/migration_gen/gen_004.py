"""Generates supabase/migrations/004_permissions_custody_payroll.sql from the tested api_core in 003.
All 001-003 rules are kept; changes are exact, asserted replacements + one block of new actions."""
import pathlib
here = pathlib.Path(__file__).parent
root = here.resolve().parents[1] / 'supabase' / 'migrations'
s3 = (root / '003_import_audit_custody.sql').read_text(encoding='utf8')
a = s3.index('create or replace function ebda.api_core(req jsonb)')
b = s3.index('$fn$;', a) + len('$fn$;')
core = s3[a:b]
s1 = (root / '001_rbac_scope_workflow.sql').read_text(encoding='utf8')
sx = s1[s1.index('create or replace function ebda.sync_export()'):s1.index('$sx$;', s1.index('create or replace function ebda.sync_export()')) + len('$sx$;')]


def R(old, new, count=1, text=None):
    global core
    n = core.count(old)
    assert n == count, (old[:90], n)
    core = core.replace(old, new)


# ---------------------------------------------------------------- variables
R("  lid text;\nbegin", "  lid text;\n  nk text;\n  pid text;\n  n_emp int := 0;\nbegin")

# ---------------------------------------------------------------- permissions instead of fixed roles (role defaults = current behaviour)
R("""  if action = 'addTranche' then
    if urole not in ('admin','finance_manager') then return ebda.err('صلاحية المدير المالى مطلوبة'); end if;""",
  """  if action = 'addTranche' then
    if not ebda.can(u,'custody.create') then return ebda.err('لا صلاحية لإضافة دفعات للعهد'); end if;""")
R("""  if action = 'addCustody' then
    if urole not in ('admin','finance_manager') then return ebda.err('صلاحية المدير المالى مطلوبة'); end if;""",
  """  if action = 'addCustody' then
    if not ebda.can(u,'custody.create') then return ebda.err('لا صلاحية لإنشاء العهد'); end if;
    for ln in select * from jsonb_array_elements(coalesce(req#>'{custody,lines}','[]'::jsonb)) loop
      if not exists(select 1 from ebda.lines l where l.id=ln->>'line_id' and l.school_id=req#>>'{custody,school_id}' and coalesce(l.deleted_at,'')='') then
        return ebda.err('بند غير تابع لمكان العهدة'); end if;
      if not ebda.num_ok(ln->>'amount') then return ebda.err('مبلغ توزيع غير صحيح'); end if;
    end loop;""")
R("""    if urole not in ('admin','finance_manager') then return ebda.err('صلاحية المدير المالى مطلوبة'); end if;
    if not ebda.can_custody(u, cust) then return ebda.err('هذه العهدة ليست ضمن نطاقك'); end if;
    if patch ? 'school_id'""",
  """    if not (ebda.can(u,'custody.create') or ebda.can(u,'custody.approve')) then return ebda.err('لا صلاحية لتعديل العهد'); end if;
    if not ebda.can_custody(u, cust) then return ebda.err('هذه العهدة ليست ضمن نطاقك'); end if;
    if coalesce(cust.status,'open')='cancelled' then return ebda.err('العهدة ملغاة — لا يمكن تعديلها'); end if;
    if coalesce(cust.approval,'approved')='approved' and urole<>'admin'
       and (patch ? 'school_id' or patch ? 'holder' or patch ? 'user' or patch ? 'title' or patch ? 'kind' or patch ? 'label') then
      return ebda.err('العهدة معتمدة — تعديل بياناتها الأساسية للأدمن فقط'); end if;
    if patch ? 'school_id'""")
R("""    if urole not in ('admin','finance_manager') then return ebda.err('إضافة بنود الموازنة للأدمن والمدير المالى فقط'); end if;""",
  """    if not ebda.can(u,'budget.edit') then return ebda.err('لا صلاحية لإضافة بنود الموازنة'); end if;""")
R("""  if action in ('updateLine','deleteLine') then
    if urole not in ('admin','finance_manager') then return ebda.err('صلاحية الأدمن أو المدير المالى مطلوبة'); end if;""",
  """  if action in ('updateLine','deleteLine') then
    if not ebda.can(u,'budget.edit') then return ebda.err('لا صلاحية لتعديل الموازنة'); end if;""")
R("""  if action = 'importBudget' and coalesce(req->>'mode','') = 'merge' then
    if urole not in ('admin','finance_manager') then return ebda.err('صلاحية الأدمن أو المدير المالى مطلوبة'); end if;""",
  """  if action = 'importBudget' and coalesce(req->>'mode','') = 'merge' then
    if not ebda.can(u,'budget.edit') then return ebda.err('لا صلاحية لاستيراد الموازنة'); end if;""")
R("""  if action = 'importBudget' then
    if urole not in ('admin','finance_manager') then return ebda.err('صلاحية الأدمن أو المدير المالى مطلوبة'); end if;""",
  """  if action = 'importBudget' then
    if not ebda.can(u,'budget.edit') then return ebda.err('لا صلاحية لاستيراد الموازنة'); end if;""")
R("""  if action = 'reviewExpense' then
    if urole not in ('admin','finance_manager') then return ebda.err('صلاحية المدير المالى مطلوبة'); end if;""",
  """  if action = 'reviewExpense' then
    if not ebda.can(u,'expense.fin_approve') then return ebda.err('صلاحية الاعتماد المالى مطلوبة'); end if;""")
R("""    if urole not in ('direct_manager','admin') then return ebda.err('صلاحية المدير المباشر مطلوبة'); end if;""",
  """    if not ebda.can(u,'request.approve') then return ebda.err('صلاحية اعتماد الطلبات مطلوبة'); end if;""", count=2)
R("""    if urole not in ('finance_manager','admin') then return ebda.err('صلاحية المدير المالى مطلوبة'); end if;""",
  """    if not ebda.can(u,'request.fin_approve') then return ebda.err('صلاحية الاعتماد المالى للطلبات مطلوبة'); end if;""")
R("""      if urole not in ('admin','direct_manager') then return ebda.err('صلاحية المدير المباشر مطلوبة'); end if;""",
  """      if not ebda.can(u,'expense.approve') then return ebda.err('صلاحية اعتماد المصروفات مطلوبة'); end if;""")

# ---------------------------------------------------------------- custody: lifecycle + logical checks on expenses
R("""    if coalesce(cust.status,'open') in ('settled','closed') then return ebda.err('العهدة مسوّاة/مغلقة — أنشئ عهدة جديدة'); end if;""",
  """    if coalesce(cust.status,'open') in ('settled','closed','cancelled') then return ebda.err('العهدة مسوّاة/مغلقة/ملغاة — أنشئ عهدة جديدة'); end if;""")
i = core.index("if action = 'addExpense' then")
j = core.index("if coalesce((req#>>'{expense,amount}')::numeric,0) <= 0", i)
core = core[:j] + """if coalesce(cust.status,'open')='cancelled' then return ebda.err('العهدة ملغاة — لا يمكن الصرف منها'); end if;
    if coalesce(cust.approval,'approved')<>'approved' then return ebda.err('العهدة لم تُعتمد بعد — لا يمكن الصرف منها'); end if;
    if not ebda.can(u,'expense.record') then return ebda.err('لا صلاحية لتسجيل المصروفات'); end if;
    if exists(select 1 from ebda.custody_lines cl where cl.custody_id=cust.id)
       and not exists(select 1 from ebda.custody_lines cl where cl.custody_id=cust.id and cl.line_id=coalesce(req#>>'{expense,line_id}','')) then
      return ebda.err('هذا البند غير مخصص لهذه العهدة — اختر بنداً من بنود العهدة'); end if;
    if coalesce(req#>>'{expense,date}','') > to_char(now() + interval '1 day','YYYY-MM-DD') then return ebda.err('تاريخ المصروف فى المستقبل'); end if;
    if coalesce(req#>>'{expense,line_id}','')<>'' and exists(select 1 from ebda.lines l where l.id=req#>>'{expense,line_id}' and coalesce(l.deleted_at,'')<>'') then
      return ebda.err('بند الموازنة محذوف'); end if;
    """ + core[j:]

R("""           coalesce(nullif(req#>>'{custody,date}',''), now()::text), coalesce(req#>>'{custody,kind}',''), coalesce(req#>>'{custody,purpose}',''));""",
  """           coalesce(nullif(req#>>'{custody,date}',''), now()::text), coalesce(req#>>'{custody,kind}',''), coalesce(req#>>'{custody,purpose}',''));
    -- الاسم/المسئول من العاملين/حالة الاعتماد (المسودة لمن لا يملك صلاحية الاعتماد)
    update ebda.custodies set title=coalesce(req#>>'{custody,title}',''), holder_emp_id=coalesce(req#>>'{custody,holder_emp_id}',''),
      approval = case when coalesce(req#>>'{custody,approval}','approved') in ('draft','review') then req#>>'{custody,approval}'
                      when ebda.can(u,'custody.approve') then 'approved' else 'draft' end
    where id=newid;
    update ebda.custodies set approved_by=u.name, approved_at=now()::text where id=newid and approval='approved';
    for ln in select * from jsonb_array_elements(coalesce(req#>'{custody,lines}','[]'::jsonb)) loop
      if not exists(select 1 from ebda.lines l where l.id=ln->>'line_id' and l.school_id=req#>>'{custody,school_id}' and coalesce(l.deleted_at,'')='') then
        raise exception 'بند غير تابع لمكان العهدة'; end if;
      insert into ebda.custody_lines(id,custody_id,line_id,amount) values(ebda.uid(), newid, ln->>'line_id', coalesce(nullif(btrim(ln->>'amount'),'')::numeric,0))
      on conflict (custody_id,line_id) do update set amount=excluded.amount;
    end loop;""")
R("""      'tranches', coalesce((select jsonb_agg(to_jsonb(t)) from ebda.tranches t where t.custody_id=newid),'[]'::jsonb));""",
  """      'tranches', coalesce((select jsonb_agg(to_jsonb(t)) from ebda.tranches t where t.custody_id=newid),'[]'::jsonb),
      'custody_lines', coalesce((select jsonb_agg(to_jsonb(t)) from ebda.custody_lines t where t.custody_id=newid),'[]'::jsonb));""")

R("""      kind=coalesce(patch->>'kind',kind), purpose=coalesce(patch->>'purpose',purpose),""",
  """      kind=coalesce(patch->>'kind',kind), purpose=coalesce(patch->>'purpose',purpose),
      title=coalesce(patch->>'title',title), holder_emp_id=coalesce(patch->>'holder_emp_id',holder_emp_id),""")

# ---------------------------------------------------------------- soft-deleted budget lines are invisible / not duplicates
R("""          where ebda.can_school(u, l.school_id)),'[]'::jsonb));""",
  """          where ebda.can_school(u, l.school_id) and coalesce(l.deleted_at,'')=''),'[]'::jsonb));""", count=2)
R("""    if exists(select 1 from ebda.lines l where l.school_id=req#>>'{line,school_id}'""",
  """    if exists(select 1 from ebda.lines l where l.school_id=req#>>'{line,school_id}' and coalesce(l.deleted_at,'')=''""")
R("""            and l.school_id=me.school_id and l.id<>me.id""", """            and l.school_id=me.school_id and l.id<>me.id and coalesce(l.deleted_at,'')=''""")
R("""        select l.id into lid from ebda.lines l where l.school_id=sid
""", """        select l.id into lid from ebda.lines l where l.school_id=sid and coalesce(l.deleted_at,'')=''
""")

# ---------------------------------------------------------------- bootstrap: permissions, master data, allocations, payroll
R("""    res := res || jsonb_build_object('settings', jsonb_build_object(""",
  """    res := jsonb_set(res, '{me,permissions}', to_jsonb(ebda.perms_of(u)));
    res := res || jsonb_build_object('custody_names', coalesce((select jsonb_agg(to_jsonb(z) order by z.sort, z.name) from ebda.custody_names z),'[]'::jsonb));
    res := res || jsonb_build_object('custody_lines', coalesce((select jsonb_agg(to_jsonb(cl)) from ebda.custody_lines cl
        join ebda.custodies c on c.id=cl.custody_id where ebda.can_custody(u, c)),'[]'::jsonb));
    res := res || jsonb_build_object('settings', jsonb_build_object(""")
R("""    if ebda.sees_budgets(u) then
      res := res || jsonb_build_object('salaries',""",
  """    if ebda.sees_budgets(u) or ebda.can(u,'payroll.view') then
      res := res || jsonb_build_object('payroll_periods', coalesce((select jsonb_agg(to_jsonb(z)) from ebda.payroll_periods z where ebda.can_school(u, z.school_id)),'[]'::jsonb));
      res := res || jsonb_build_object('payroll_components', coalesce((select jsonb_agg(to_jsonb(z) order by z.sort) from ebda.payroll_components z),'[]'::jsonb));
      res := res || jsonb_build_object('payroll_map', coalesce((select value from ebda.config where key='payroll_map'),''));
      res := res || jsonb_build_object('salaries',""")
R("""      res := res || jsonb_build_object('tempBudgets',""",
  """      res := res || jsonb_build_object('deletedBudgets', coalesce((select jsonb_agg(x) from (
          select l.school_id, count(*) as lines, sum(l.allocated) as total, max(l.deleted_at) as deleted_at, max(l.deleted_by) as deleted_by, max(l.delete_reason) as reason
          from ebda.lines l where coalesce(l.deleted_at,'')<>'' group by l.school_id) x),'[]'::jsonb));
      res := res || jsonb_build_object('tempBudgets',""")

# ---------------------------------------------------------------- new actions (before the admin-only section)
NEW = (here / '004_actions.sql').read_text(encoding='utf8')
R("""  -- ================================================================ باقى الإجراءات للأدمن فقط (كما فى النظام الحالى)""",
  NEW + """
  -- ================================================================ باقى الإجراءات للأدمن فقط (كما فى النظام الحالى)""")

# audit labels: don't log read-only helpers (unchanged list) — nothing else to change.

sx = sx.replace("from ebda.lines l join ebda.schools s on s.id=l.school_id), '[]'::jsonb));",
                "from ebda.lines l join ebda.schools s on s.id=l.school_id where coalesce(l.deleted_at,'')=''), '[]'::jsonb));")
assert "where coalesce(l.deleted_at,'')=''), '[]'::jsonb));" in sx

head = (here / '004_head.sql').read_text(encoding='utf8')
tail = (here / '004_tail.sql').read_text(encoding='utf8')
out = (head + '\n-- مزامنة الشيتات: تجاهل البنود المحذوفة منطقياً\n' + sx + '\n\n-- ============================================================================\n'
       '--  الدالة الأساسية (قواعد 001 → 003 + الإضافات أعلاه)\n-- ============================================================================\n' + core + '\n' + tail)
(root / '004_permissions_custody_payroll.sql').write_text(out, encoding='utf8')
print('written', len(out))
