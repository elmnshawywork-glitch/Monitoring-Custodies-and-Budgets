create or replace function ebda.bootstrap_v6(u ebda.users) returns jsonb
language plpgsql stable security definer set search_path = ebda as $bs$
declare
  urole text := ebda.role_key(u.role);
  sees_amounts boolean := ebda.role_key(u.role) in ('admin','finance_manager','direct_manager');
  sees_pay boolean := ebda.sees_budgets(u) or ebda.can(u,'payroll.view');
  star boolean := coalesce(u.schools,'')='*' or ebda.role_key(u.role)='admin';
  sch text[] := ebda.scope_arr(u);
  full_lim int := ebda.cfg_int('bootstrap_full_limit', 3000);
  max_ship int := ebda.cfg_int('bootstrap_expense_max', 5000);
  since text := to_char(current_date - ebda.cfg_int('bootstrap_expense_days', 60), 'YYYY-MM-DD');
  pay_months int := ebda.cfg_int('bootstrap_payslip_months', 2);
  res jsonb;
  j_admin jsonb := '{}'::jsonb; j_users jsonb := null; j_pay jsonb := null; n_pay bigint := 0; pay_from text := '';
begin
  -- كل الأجزاء الثقيلة فى استعلام واحد: العهد والمصروفات المرئية تُحسب مرة واحدة (materialized) ثم تُبنى منها كل الأجزاء والتجميعات
  with vc as materialized (select * from ebda.vis_custodies(u)),
  ve as materialized (
    select e.id, e.custody_id, e.line_id, e.school_id, e.amount, e.date, e.txn_no, e.approval, e.fin_approval, e.settled, e.cancelled_at,
           e.review_status, e.review_note, e.spend_item,
           ebda.counts_in_budget(e) as cnt, ebda.active_on_custody(e) as act, ebda.expense_stage(e) as stg
    from ebda.expenses e where urole = 'admin'
    union all
    select e.id, e.custody_id, e.line_id, e.school_id, e.amount, e.date, e.txn_no, e.approval, e.fin_approval, e.settled, e.cancelled_at,
           e.review_status, e.review_note, e.spend_item,
           ebda.counts_in_budget(e), ebda.active_on_custody(e), ebda.expense_stage(e)
    from ebda.vis_expenses(u) e where urole <> 'admin'),
  w as (select count(*) as total, count(*) > full_lim as windowed from ve),
  ship_ids as (
    select ve.id from ve, w
    where not w.windowed or ve.date >= since or ve.stg in ('draft','pending_manager','returned','pending_finance','fin_returned','reviewed')
    order by (ve.stg in ('draft','pending_manager','returned','pending_finance','fin_returned','reviewed')) desc, ve.date desc, ve.txn_no desc
    limit case when (select windowed from w) then max_ship else null end),
  ship as (select e.* from ebda.expenses e join ship_ids using (id)),
  stages as (select stg, count(*) n, sum(amount) amount from ve group by stg),
  tagg as (select t.custody_id, sum(t.amount) s from ebda.tranches t where t.custody_id = any(array(select id from vc)) group by 1),
  cagg as (
    select custody_id, sum(amount) filter (where act) spent, count(*) n,
           count(*) filter (where approval='pending' and coalesce(cancelled_at,'')='') pending_n,
           count(*) filter (where act and approval='approved' and coalesce(settled,'') not like '%نعم%') unsettled_n,
           count(*) filter (where coalesce(cancelled_at,'')='' and coalesce(settled,'') not like '%نعم%'
              and (approval in ('rejected','returned') or fin_approval in ('rejected','returned') or coalesce(review_status,'') like '%ناقص%' or coalesce(review_note,'')<>'')) notes_n
    from ve where coalesce(custody_id,'')<>'' group by 1),
  clagg as (select custody_id || '|' || coalesce(line_id,'') k, sum(amount) s from ve where act and coalesce(custody_id,'')<>'' group by 1),
  -- تجميعات الموازنة فى مرور واحد على المصروفات (GROUPING SETS)
  g as (
    select grouping(line_id, school_id, item, m) gid, line_id, school_id, item, m,
           sum(amount) filter (where cnt) counted, sum(amount) filter (where act and not cnt) pend, count(*) n
    from (select line_id, school_id, amount, cnt, act,
                 coalesce(nullif(spend_item,''), case when coalesce(custody_id,'')<>'' then 'مصروف عهدة (غير مصنّف)' else 'شراء مركزى' end) item,
                 ebda.fy_month(date) m from ve where sees_amounts) z
    group by grouping sets ((line_id), (school_id), (school_id, item, m), (school_id, m)))
  select jsonb_build_object(
    'expenses', coalesce((select jsonb_agg(to_jsonb(ship) - 'doc_url' - 'ref'
                          || jsonb_build_object('doc_url', case when ship.doc_url like 'data:%' then 'inline:' else coalesce(ship.doc_url,'') end)) from ship), '[]'::jsonb),
    'window', (select jsonb_build_object('windowed', w.windowed, 'since', case when w.windowed then since else '' end,
                      'shipped', (select count(*) from ship), 'total', w.total) from w),
    'custodies', coalesce((select jsonb_agg(to_jsonb(vc) || jsonb_build_object(
        'received', coalesce(tagg.s,0), 'spent', coalesce(cagg.spent,0), 'exp_count', coalesce(cagg.n,0),
        'pending_n', coalesce(cagg.pending_n,0), 'unsettled_n', coalesce(cagg.unsettled_n,0), 'notes_n', coalesce(cagg.notes_n,0),
        'manager_id', coalesce(o.manager_id,'')))
      from vc left join tagg on tagg.custody_id = vc.id left join cagg on cagg.custody_id = vc.id left join ebda.users o on o.id = vc.user_id), '[]'::jsonb),
    'tranches', coalesce((select jsonb_agg(to_jsonb(t)) from ebda.tranches t where t.custody_id = any(array(select id from vc))), '[]'::jsonb),
    'custody_lines', coalesce((select jsonb_agg(to_jsonb(cl)) from ebda.custody_lines cl where cl.custody_id = any(array(select id from vc))), '[]'::jsonb),
    'agg', jsonb_build_object('custody_line_spent', coalesce((select jsonb_object_agg(k, s) from clagg where k not like '%|'), '{}'::jsonb),
                              'stages', coalesce((select jsonb_object_agg(stg, jsonb_build_object('n', n, 'amount', amount)) from stages), '{}'::jsonb))
      || case when sees_amounts then jsonb_build_object(
        'line_spent', coalesce((select jsonb_object_agg(line_id, counted) from g where gid = 7 and coalesce(line_id,'')<>'' and counted is not null), '{}'::jsonb),
        'line_exp_count', coalesce((select jsonb_object_agg(line_id, n) from g where gid = 7 and coalesce(line_id,'')<>''), '{}'::jsonb),
        'school_spent', coalesce((select jsonb_object_agg(school_id, counted) from g where gid = 11 and counted is not null), '{}'::jsonb),
        'school_pending', coalesce((select jsonb_object_agg(school_id, pend) from g where gid = 11 and pend is not null), '{}'::jsonb),
        'spend_types', coalesce((select jsonb_agg(jsonb_build_object('school_id', school_id, 'item', item, 'm', m, 'amount', counted)) from g where gid = 8 and counted is not null), '[]'::jsonb),
        'month_spent', coalesce((select jsonb_agg(jsonb_build_object('school_id', school_id, 'm', m, 'amount', counted)) from g where gid = 10 and m is not null and counted is not null), '[]'::jsonb))
      else '{}'::jsonb end,
    'requests', coalesce((select jsonb_agg(to_jsonb(r) || jsonb_build_object(
        'stage', case when r.status='transferred' and exists(select 1 from ebda.custodies c where c.id=r.custody_id and c.status in ('settled','closed')) then 'settled'
                      when r.status='transferred' and exists(select 1 from ebda.expenses e where e.custody_id=r.custody_id and e.created_at>=r.fin_at) then 'spent'
                      else r.status end,
        'items', coalesce((select jsonb_agg(to_jsonb(it)) from ebda.request_items it where it.request_id=r.id),'[]'::jsonb)))
      from ebda.requests r
      where (urole='custody_officer' and ((coalesce(r.requester_id,'')<>'' and r.requester_id=u.id) or (coalesce(r.requester_id,'')='' and r.requester=u.username)))
         or (urole<>'custody_officer' and (star or r.school_id = any(sch)))), '[]'::jsonb)
  ) into res;

  res := res || jsonb_build_object(
    'ok', true, 'schema_version', 1,
    'me', jsonb_build_object('id',u.id,'username',u.username,'name',u.name,'role',coalesce(ebda.role_legacy(u.role),u.role),
            'role_key',urole,'role_label',ebda.role_label(u.role),'schools',u.schools,'perms',coalesce(u.perms,''),
            'must_reset',coalesce(u.must_reset,'لا'),'permissions',to_jsonb(ebda.perms_of(u)),'manager_id',coalesce(u.manager_id,'')),
    'schools', coalesce((select jsonb_agg(to_jsonb(s) order by (coalesce(s.active,'') like '%نعم%') desc, s.name) from ebda.schools s where star or s.id = any(sch)),'[]'::jsonb),
    'lines', case when sees_amounts
      then coalesce((select jsonb_agg(to_jsonb(l)) from ebda.lines l where (star or l.school_id = any(sch)) and coalesce(l.deleted_at,'')=''),'[]'::jsonb)
      else coalesce((select jsonb_agg(jsonb_build_object('id',l.id,'school_id',l.school_id,'section',l.section,'name',l.name,'active',coalesce(l.active,'نعم'))) from ebda.lines l
                     where (star or l.school_id = any(sch)) and coalesce(l.deleted_at,'')=''),'[]'::jsonb) end,
    'custody_names', coalesce((select jsonb_agg(to_jsonb(z) order by z.sort, z.name) from ebda.custody_names z),'[]'::jsonb),
    'custody_kinds', coalesce((select jsonb_agg(to_jsonb(z) order by z.sort, z.name) from ebda.custody_kinds z),'[]'::jsonb),
    'entity_types', coalesce((select jsonb_agg(to_jsonb(z) order by z.sort) from ebda.entity_types z),'[]'::jsonb),
    'team', coalesce((select jsonb_agg(jsonb_build_object('id',z.id,'username',z.username,'name',z.name)) from ebda.users z where z.manager_id=u.id),'[]'::jsonb),
    'managers', coalesce((select jsonb_agg(jsonb_build_object('id',z.id,'name',z.name,'role_key',ebda.role_key(z.role)))
        from ebda.users z where ebda.role_key(z.role) in ('direct_manager','admin') and coalesce(z.active,'') like '%نعم%'
          and (case when urole = 'custody_officer' then z.id = coalesce(u.manager_id,'')
                    else star or ebda.role_key(z.role)='admin' or coalesce(z.schools,'')='*' or ebda.scope_arr(z) && sch end)),'[]'::jsonb),
    'spendItems', coalesce((select jsonb_agg(to_jsonb(z)) from ebda.spend_items z),'[]'::jsonb),
    'holders', coalesce((select jsonb_agg(to_jsonb(z)) from ebda.holders z),'[]'::jsonb),
    'approvers', coalesce((select jsonb_agg(to_jsonb(z)) from ebda.approvers z),'[]'::jsonb),
    'emails', coalesce((select jsonb_agg(to_jsonb(z)) from ebda.emails z),'[]'::jsonb),
    'settings', jsonb_build_object('custody_overdue_days', ebda.cfg_int('custody_overdue_days', 30),
        'require_doc_to_settle', coalesce((select value from ebda.config where key='require_doc_to_settle'),'no')));
  if sees_amounts then res := res || jsonb_build_object('line_months', ebda.line_months(u)); end if;

  if sees_pay then
    select count(*) into n_pay from ebda.payslips z where star or z.school_id = any(sch);
    if n_pay > ebda.cfg_int('bootstrap_payslip_limit', 5000) then
      -- آخر N شهر به قسائم فعلاً (وليس شهوراً تقويمية) — والأقدم يُطلب عند اختياره (payrollMonth)
      select coalesce(min(m), '') into pay_from from (select distinct z.month m from ebda.payslips z
        where (star or z.school_id = any(sch)) and z.month ~ '^[0-9]{4}-[0-9]{2}$' order by 1 desc limit pay_months) q;
    end if;
    res := res || jsonb_build_object(
      'payroll_periods', coalesce((select jsonb_agg(to_jsonb(z)) from ebda.payroll_periods z where star or z.school_id = any(sch)),'[]'::jsonb),
      'payroll_components', coalesce((select jsonb_agg(to_jsonb(z) order by z.sort) from ebda.payroll_components z),'[]'::jsonb),
      'payroll_map', coalesce((select value from ebda.config where key='payroll_map'),''),
      'salaries', coalesce((select jsonb_agg(to_jsonb(z)) from ebda.salaries z where star or z.school_id = any(sch)),'[]'::jsonb),
      'employees', coalesce((select jsonb_agg(to_jsonb(z)) from ebda.employees z where star or z.school_id = any(sch)),'[]'::jsonb),
      'payslips', coalesce((select jsonb_agg(to_jsonb(z)) from ebda.payslips z where (star or z.school_id = any(sch)) and (pay_from = '' or z.month >= pay_from)),'[]'::jsonb),
      'payslips_window', jsonb_build_object('windowed', pay_from <> '', 'from', pay_from, 'total', n_pay),
      -- ملخص كل الشهور (للمقارنات والتحليلات) محسوب على الخادم
      'payroll_months', coalesce((select jsonb_agg(jsonb_build_object('month', month, 'school_id', school_id, 'net', net, 'n', n) order by month) from (
          select z.month, z.school_id, sum(z.net) net, count(*) n from ebda.payslips z where star or z.school_id = any(sch) group by 1, 2) q),'[]'::jsonb));
  end if;

  if urole='admin' then
    res := res || jsonb_build_object(
      'deletedBudgets', coalesce((select jsonb_agg(x) from (
          select l.school_id, count(*) as lines, sum(l.allocated) as total, max(l.deleted_at) as deleted_at, max(l.deleted_by) as deleted_by, max(l.delete_reason) as reason
          from ebda.lines l where coalesce(l.deleted_at,'')<>'' group by l.school_id) x),'[]'::jsonb),
      'tempBudgets', coalesce((select jsonb_agg(to_jsonb(z)) from ebda.temp_budgets z),'[]'::jsonb),
      'backups', coalesce((select jsonb_agg(jsonb_build_object('id',b.id,'name',b.name,'kind',b.kind,'created_at',b.created_at,
          'created_by',b.created_by,'size_bytes',b.size_bytes,'counts',b.counts,'note',b.note) order by b.created_at desc) from ebda.backups b),'[]'::jsonb),
      'audit', coalesce((select jsonb_agg(to_jsonb(a)) from (select * from ebda.audit_log order by ts desc limit 1000) a),'[]'::jsonb),
      'audit_changes', coalesce((select jsonb_agg(to_jsonb(c)) from ebda.audit_changes c
          where c.txid in (select q.txid from (select txid from ebda.audit_log where txid is not null order by ts desc limit 1000) q)),'[]'::jsonb));
  end if;
  if ebda.can_manage_users(u) then
    res := res || jsonb_build_object('users', coalesce((select jsonb_agg(ebda.user_public(z)) from ebda.users z),'[]'::jsonb));
  elsif urole='finance_manager' then
    res := res || jsonb_build_object('users', coalesce((select jsonb_agg(jsonb_build_object('id',z.id,'username',z.username,'name',z.name,'role',z.role,
        'role_label',ebda.role_label(z.role),'manager_id',coalesce(z.manager_id,''))) from ebda.users z
        where star or coalesce(z.schools,'')='*' or ebda.role_key(z.role)='admin' or ebda.scope_arr(z) && sch),'[]'::jsonb));
  end if;
  return res;
end $bs$;
