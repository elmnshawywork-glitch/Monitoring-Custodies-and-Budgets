"""استيراد ملف المصروفات والعهد (القالب المعتمد): قراءة الملف بنفس قارئ الواجهة ← معاينة ← استيراد ← التحقق من:
إنشاء العهد تلقائياً وربطها (المسئول/المدرسة/القيمة/التاريخ)، ربط المصروفات بالبنود والشهور، اكتشاف التكرار، تقرير الاستثناءات
دون إيقاف الاستيراد، تحديث الموازنة (المنصرف الفعلى/الشهرى/المتبقى/النسبة) وأرصدة العهد، عدم الاستيراد مرتين، الصلاحيات، التراجع.
Run: bash reset.sh && python3 test_api_005_import.py"""
import json, subprocess, psycopg2, pathlib, os, tempfile
HERE = pathlib.Path(__file__).parent
conn = psycopg2.connect(host=os.environ.get('PGHOST', '/var/tmp/pg'), port=int(os.environ.get('PGPORT', '5433')), user='postgres', dbname='postgres'); conn.autocommit = True
cur = conn.cursor()
fails = 0
def check(n, c, d=''):
    global fails; print(('PASS ' if c else 'FAIL ') + n + ('' if c else f' -> {d}')); fails += (not c)
def sql(q, *a):
    cur.execute("reset role"); cur.execute(q, a or None); return cur.fetchall() if cur.description else None
def one(q, *a): return sql(q, *a)[0][0]
def raw(req):
    cur.execute("set role anon"); cur.execute("select public.api(%s::jsonb)", (json.dumps(req),)); r = cur.fetchone()[0]; cur.execute("reset role"); return r
PINS = {'admin': '1234', 'custody1': '1111', 'custody2': '5555', 'acc1': '2222', 'sup1': '3333', 'sup2': '4444'}
TOK = {}
def api(who, action, **kw):
    if who not in TOK: TOK[who] = raw({'action': 'login', 'username': who, 'pin': PINS[who]})['token']
    return raw(dict(action=action, auth={'token': TOK[who]}, **kw))
ok = lambda r: isinstance(r, dict) and r.get('ok') is True
err = lambda r: isinstance(r, dict) and 'error' in r
badr = one("select id from ebda.schools where name like '%%بدر%%'")
dam = one("select id from ebda.schools where name like '%%دمياط%%'")
FIX = HERE / 'fixtures' / 'مصاريف_مدرسة_ابدأ_نموذج.xlsx'
if not FIX.exists(): subprocess.run(['python3', str(HERE / 'fixtures' / 'make_expenses_fixture.py')], check=True)

# ---------------------------------------------------------------- 1) قراءة الملف بقارئ الواجهة نفسه (بدون أى ربط أعمدة)
def parse(path, schools):
    with tempfile.NamedTemporaryFile('w', suffix='.json', delete=False) as f: json.dump(schools, f)
    out = subprocess.run(['node', str(HERE / 'import' / 'parse_expenses.mjs'), str(path), f.name], capture_output=True, text=True, cwd=HERE.parent / 'frontend')
    assert out.returncode == 0, out.stderr
    return json.loads(out.stdout)
schools = [{'id': i, 'name': n} for i, n in sql("select id, name from ebda.schools")]
P = parse(FIX, schools)
sh = {s['name']: s for s in P['sheets']}
check('3 expense sheets recognized automatically, notes sheet ignored', [s['name'] for s in P['sheets'] if s['recognized']] == ['مصروفات دمياط', 'عهدة بدر', 'عهد قائمة'] and not sh['ملاحظات']['recognized'])
check('all standard columns recognized in the standard sheet', set(sh['مصروفات دمياط']['columns']) >= {'custody_no', 'holder', 'custody_amount', 'custody_date', 'date', 'month', 'main', 'sub', 'description', 'supplier', 'doc_no', 'amount'}, sh['مصروفات دمياط']['columns'])
check('two-row merged header understood (المصروف/البند)', sh['عهدة بدر']['twoRows'] and set(sh['عهدة بدر']['columns']) >= {'date', 'description', 'amount', 'main', 'sub', 'supplier', 'doc_no'}, sh['عهدة بدر'])
check('total rows skipped, 14 data rows read', len(P['rows']) == 14, len(P['rows']))
R = {r['r']: r for r in P['rows']}
check('custody block above the table applied (B-7 / holder / 15000 / date)', all(r['custody_no'] == 'B-7' and r['custody_amount'] == '15000' and r['custody_date'] == '2026-09-02' and r['holder'] == 'أحمد مسئول عهدة بدر'
      for k, r in R.items() if k.startswith('عهدة بدر')))
check('merged custody cells filled for following expenses', R['مصروفات دمياط — صف 6']['custody_no'] == 'D-1' and R['مصروفات دمياط — صف 10']['holder'] == 'منى مسئول عهدة دمياط')
P_badr = parse(FIX, [x for x in schools if x['id'] == badr])
check('limited-scope user (sees only Badr): Damietta sheet NOT guessed as Badr from generic words («مدرسة ابدأ»)',
      all(not r['school_id'] for r in P_badr['rows'] if r['r'].startswith('مصروفات دمياط')) and all(r['school_id'] == badr for r in P_badr['rows'] if r['r'].startswith('عهدة بدر')))
check('school from sheet name / distinctive word («بدر») resolved', R['مصروفات دمياط — صف 4']['school_id'] == dam and R['عهد قائمة — صف 3']['school_id'] == badr)
check('dates: Excel serials and Arabic-digit text dates', R['مصروفات دمياط — صف 4']['date'] == '2026-09-03' and R['مصروفات دمياط — صف 10']['date'] == '2026-09-15')
check('amount with thousands separator normalized', R['مصروفات دمياط — صف 5']['amount'] == '2250')
check('other columns kept as notes (extra)', R['مصروفات دمياط — صف 4']['extra'] == {'ملاحظات': 'تم الاستلام'})

# ---------------------------------------------------------------- 2) المعاينة (لا تكتب شيئاً)
for w in ('admin', 'acc1', 'custody1', 'sup1'): api(w, 'ping')
n_exp, n_cust, n_audit = one("select count(*) from ebda.expenses"), one("select count(*) from ebda.custodies"), one("select count(*) from ebda.audit_log")
pv = api('acc1', 'importExpensesFile', mode='preview', rows=P['rows'], file_name='مصاريف مدرسة ابدأ.xlsx')
check('finance manager (Badr scope) cannot import Damietta rows — out-of-scope rows reported, not imported', ok(pv) and
      all(x['status'] == 'error' for x in pv['rows'] if x['school_id'] is None and 'دمياط' in x['r']), [x for x in pv['rows'] if 'دمياط' in x['r']][:1])
pv = api('admin', 'importExpensesFile', mode='preview', rows=P['rows'], file_name='مصاريف مدرسة ابدأ.xlsx', approve_mode='approved')
check('preview ok', ok(pv), pv)
check('preview writes nothing (no expense, no custody, no audit entry)', (one("select count(*) from ebda.expenses"), one("select count(*) from ebda.custodies"), one("select count(*) from ebda.audit_log")) == (n_exp, n_cust, n_audit))
S = pv['summary']
print('   summary:', S)
check('summary: 14 rows · 8 importable · 2 duplicates · 4 need review', (S['rows'], S['importable'], S['duplicate'], S['error']) == (14, 8, 2, 4), S)
check('total amount = 22550', float(S['amount']) == 22550, S['amount'])
check('2 new custodies (D-1, B-7) + 1 existing (أحمد)', (S['new_custodies'], S['existing_custodies']) == (2, 1), S)
st = {x['r']: x for x in pv['rows']}
def reason(k): x = st[k]; return ' · '.join(x['errors'] + ([x['duplicate_of']] if x['duplicate_of'] else []) + x['warnings'])
check('duplicate inside the file detected', st['مصروفات دمياط — صف 7']['status'] == 'duplicate' and 'داخل الملف' in reason('مصروفات دمياط — صف 7'))
check('already-recorded expense detected (EXP of e1)', st['عهد قائمة — صف 2']['status'] == 'duplicate' and 'مسجل من قبل' in reason('عهد قائمة — صف 2'), reason('عهد قائمة — صف 2'))
check('unknown budget line → exception (import continues)', st['مصروفات دمياط — صف 8']['status'] == 'error' and 'بند غير معروف' in reason('مصروفات دمياط — صف 8'))
check('invalid amount → exception', 'قيمة المصروف غير صحيحة' in reason('مصروفات دمياط — صف 9'))
check('future date → exception', 'المستقبل' in reason('عهدة بدر — صف 10'))
check('unknown school → exception', 'المدرسة غير معروفة' in reason('عهد قائمة — صف 4'))
check('month taken from the date; mismatch with the month column is a warning', st['مصروفات دمياط — صف 10']['month'] == '2026-09' and st['مصروفات دمياط — صف 10']['status'] == 'warning'
      and 'لا يطابق' in reason('مصروفات دمياط — صف 10'))
check('approximate line match flagged as a warning («الزى» ← «الزى المدرسى»)', st['عهدة بدر — صف 9']['status'] == 'warning' and st['عهدة بدر — صف 9']['line'] == 'الزى المدرسى')
check('line from main category only (no sub) resolved', st['عهد قائمة — صف 3']['line_id'] == 'l_b1')
check('existing custody matched by holder name in the school', st['عهد قائمة — صف 3']['custody'] == one("select code from ebda.custodies where id='c_b1'") or st['عهد قائمة — صف 3']['custody'] == '')
months = {k: float(v) for k, v in S['months'].items()}
check('amounts by month from the expense date', months == {'2026-09': 21750.0, '2026-10': 800.0}, months)
L = {l['line_id']: l for l in pv['lines']}
check('budget impact shown per line (allocated / before / imported / after / remaining / %)', set(L) == {'l_b1', 'l_b2', 'l_d1'} and float(L['l_d1']['imported']) == 4850, L.get('l_d1'))

# ---------------------------------------------------------------- 3) الاستيراد (ضغطة واحدة)
before_b1 = one("select coalesce(sum(amount),0) from ebda.agg_line_month where line_id='l_b1'")
cm = api('admin', 'importExpensesFile', mode='commit', rows=P['rows'], file_name='مصاريف مدرسة ابدأ.xlsx', approve_mode='approved')
check('commit ok with batch id', ok(cm) and cm.get('batch_id'), cm.get('error'))
bid = cm['batch_id']
check('8 expenses inserted, linked to the batch', one("select count(*) from ebda.expenses where import_batch=%s", bid) == 8)
d1 = sql("select id, code, holder, school_id, user_id, \"user\", opened_at, ext_ref, approval, status from ebda.custodies where ext_ref='D-1'")
check('custody D-1 created automatically: holder + school + linked user + date', len(d1) == 1 and d1[0][2] == 'منى مسئول عهدة دمياط' and d1[0][3] == dam and d1[0][4] == 'u_c2'
      and d1[0][6] == '2026-09-01' and d1[0][8] == 'approved' and d1[0][9] == 'open', d1)
check('custody amount recorded as its first tranche', one("select sum(amount) from ebda.tranches where custody_id=%s", d1[0][0]) == 12000)
b7 = sql("select id, user_id, school_id from ebda.custodies where ext_ref='B-7'")
check('custody B-7 created for Badr and linked to custody1', b7 and b7[0][1] == 'u_c1' and b7[0][2] == badr, b7)
ex = sql("select date, school_id, custody_id, line_id, amount, supplier, doc_no, approval, fin_approval, ebda.expense_stage(e) from ebda.expenses e where import_batch=%s and doc_no='F-102'", bid)
check('expense linked: school → custody → line → date → amount, supplier and document no kept', ex and ex[0][:7] == ('2026-09-10', dam, d1[0][0], 'l_d1', 2250, 'مكتبة الأمل', 'F-102'), ex)
check('admin import as actual approved expenses → stage reviewed (counts in budget)', ex[0][7:] == ('approved', 'approved', 'reviewed'), ex[0][7:])
check('note keeps the source row and extra columns', 'صف 4' in one("select note from ebda.expenses where import_batch=%s and doc_no='F-101'", bid) and 'تم الاستلام' in one("select note from ebda.expenses where import_batch=%s and doc_no='F-101'", bid))
after_b1 = one("select coalesce(sum(amount),0) from ebda.agg_line_month where line_id='l_b1'")
check('budget actual for «مطبوعات بدر» increased by imported amount (3000 + 700)', after_b1 - before_b1 == 3700, (before_b1, after_b1))
L2 = {l['line_id']: l for l in cm['lines']}
check('commit result: actual before/after consistent with preview', float(L2['l_b1']['actual_before']) == float(L['l_b1']['actual_before']) and float(L2['l_b1']['actual_after']) == float(L['l_b1']['actual_after']))
# الموازنة والتقارير من الخادم (نفس دوال الشاشات)
bt = api('admin', 'bootstrap')
check('monthly actual (line_months) shows September for the imported Damietta line', bt['line_months']['l_d1'][0] == 4050 and bt['line_months']['l_d1'][1] == 800, bt['line_months'].get('l_d1'))
rep = api('admin', 'report', kind='budget', filters={'school_id': dam})
row = [r for r in rep.get('rows', []) if r.get('line_id') == 'l_d1' or r.get('id') == 'l_d1']
check('budget report: spent / remaining / % for the line', row and float(row[0].get('spent', 0)) == 4850 and float(row[0].get('remaining', 0)) == 38250 - 4850, row[:1])
cb = [c for c in bt['custodies'] if c['id'] == d1[0][0]][0]
check('custody balance: received 12000, spent 4850', float(cb['received']) == 12000 and float(cb['spent']) == 4850, cb)
check('import is one audit entry (rows not copied), plus field history per expense', one("select count(*) from ebda.audit_log where action='importExpensesFile'") == 1
      and 'rows_n' in one("select details::text from ebda.audit_log where action='importExpensesFile'")
      and one("select count(*) from ebda.audit_changes where tbl='expenses' and op='insert' and row_id in (select id from ebda.expenses where import_batch=%s)", bid) == 8)
srch = api('acc1', 'searchExpenses', filters={'q': 'مطبعة النور'})
check('search by supplier works (finance sees only Badr rows)', ok(srch) and srch['total'] == 1 and srch['rows'][0]['supplier'] == 'مطبعة النور', srch.get('total'))

# ---------------------------------------------------------------- 4) رفع نفس الملف مرة أخرى: لا يتكرر شىء
again = api('admin', 'importExpensesFile', mode='preview', rows=P['rows'], approve_mode='approved')
check('same file again → every previously imported row is a duplicate, nothing importable', again['summary']['importable'] == 0 and again['summary']['duplicate'] == 10, again['summary'])
check('same file again → existing custodies matched by file number (no new custody)', again['summary']['new_custodies'] == 0)

# ---------------------------------------------------------------- 5) دورة الاعتماد للمدير المالى + الصلاحيات
rows_fin = [{'r': 'x1', 'school_id': badr, 'custody_no': 'B-7', 'date': '2026-09-20', 'main': 'تشغيل', 'sub': 'مطبوعات', 'description': 'استيراد مالية', 'amount': '450', 'doc_no': 'FN-1'}]
r = api('acc1', 'importExpensesFile', mode='commit', rows=rows_fin, approve_mode='approved')
st2 = sql("select approval, fin_approval, ebda.expense_stage(e) from ebda.expenses e where doc_no='FN-1'")
check('finance import enters the workflow (approve_mode ignored for non-admin) → pending direct manager', ok(r) and r['approve_mode'] == 'workflow' and st2 == [('pending', '', 'pending_manager')], (r.get('error'), st2))
check('the assigned direct manager can approve the imported expense', ok(api('sup1', 'updateExpense', id=one("select id from ebda.expenses where doc_no='FN-1'"), patch={'approval': 'approved', 'note': 'ok'})))
check('custody officer cannot import (no expense.import)', err(api('custody1', 'importExpensesFile', mode='preview', rows=rows_fin)))
check('direct manager cannot import', err(api('sup1', 'importExpensesFile', mode='preview', rows=rows_fin)))
api('admin', 'updateUser', id='u_c1', patch={'perms': '+expense.import'})
r = api('custody1', 'importExpensesFile', mode='preview', rows=[dict(rows_fin[0], custody_no='B-7', doc_no='FN-2')])
check('custody officer granted expense.import can import on his own custody only', ok(r) and r['summary']['importable'] == 1, r)
r = api('custody1', 'importExpensesFile', mode='preview', rows=[{'r': 'y', 'school_id': badr, 'custody_no': 'NEW-9', 'holder': 'شخص', 'date': '2026-09-20', 'sub': 'مطبوعات', 'amount': '5'}])
check('… but cannot create new custodies (needs custody.create + approve)', r['summary']['error'] == 1 and 'صلاحية' in ' '.join(r['rows'][0]['errors']), r['rows'][0])
api('admin', 'updateUser', id='u_c1', patch={'perms': ''})
check('empty file refused', err(api('admin', 'importExpensesFile', mode='preview', rows=[])))

# ---------------------------------------------------------------- 6) سجل الدفعات + التراجع (إلغاء — لا حذف)
bl = api('admin', 'importBatches')
check('import batches list (file, user, counts)', ok(bl) and any(b['id'] == bid and b['imported_n'] == 8 and b['exceptions_n'] == 8 for b in bl['batches']), bl.get('batches', [])[:1])
check('revert requires admin', err(api('acc1', 'revertImport', id=bid, reason='خطأ')))
check('revert requires a reason', err(api('admin', 'revertImport', id=bid, reason='')))
rv = api('admin', 'revertImport', id=bid, reason='ملف خاطئ')
check('revert cancels the batch expenses (soft) and its unused custodies', ok(rv) and rv['cancelled_expenses'] == 8, rv)
check('expenses still exist (cancelled, not deleted)', one("select count(*) from ebda.expenses where import_batch=%s and cancelled_at<>''", bid) == 8)
check('budget actual back to before the import', one("select coalesce(sum(amount),0) from ebda.agg_line_month where line_id='l_b1'") == before_b1)
check('custody D-1 cancelled (no remaining expenses), B-7 kept (FN-1 on it)', one("select status from ebda.custodies where ext_ref='D-1'") == 'cancelled' and one("select status from ebda.custodies where ext_ref='B-7'") == 'open')
check('revert twice refused', err(api('admin', 'revertImport', id=bid, reason='مرة أخرى')))
recalc = sql("""select line_id, coalesce(school_id,''), ebda.exp_fy(date), ebda.fy_month(date), sum(amount) from ebda.expenses x
               where ebda.counts_in_budget(x) and coalesce(line_id,'')<>'' and ebda.exp_fy(date) is not null group by 1,2,3,4 order by 1,2,3,4""")
stored = sql("select line_id, school_id, fy, m, amount from ebda.agg_line_month where amount <> 0 order by 1,2,3,4")
check('budget aggregate = full recalculation after import + revert', [tuple(map(str, r)) for r in recalc] == [tuple(map(str, r)) for r in stored])
check('import_batches included in backups', 'import_batches' in one("select array_to_string(ebda.backup_tables(), ',')"))

print(f'\n{fails} failures'); raise SystemExit(1 if fails else 0)
