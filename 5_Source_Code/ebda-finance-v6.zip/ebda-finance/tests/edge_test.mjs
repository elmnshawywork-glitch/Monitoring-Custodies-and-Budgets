import { execSync } from 'node:child_process';
// Prepare: fresh DB is expected (bash reset.sh); give the direct manager an email so notify has a recipient.
execSync(`psql -h /var/tmp/pg -p 5433 -U postgres -qc "update ebda.users set email='sup1@x.com' where username='sup1'"`);
// Runs the Edge Functions in Node with a Deno shim; rpc goes to the local Postgres-backed server; Storage/Resend are mocked.
globalThis.Deno = { env: { get: k => ({ SUPABASE_URL: 'http://localhost:8765', SUPABASE_ANON_KEY: 'anon', SUPABASE_SERVICE_ROLE_KEY: 'srv', RESEND_API_KEY: 're_x', NOTIFY_FROM: 'EBDA <n@x.com>' })[k] } };
const realFetch = globalThis.fetch; const calls = [];
globalThis.fetch = async (url, opt = {}) => {
  url = String(url);
  if (url.startsWith('http://localhost:8765/rest')) return realFetch(url, opt);
  calls.push({ url, method: opt.method, headers: opt.headers, body: opt.body });
  if (url.includes('api.resend.com')) return new Response(JSON.stringify({ id: 'm1' }), { status: 200 });
  if (url.includes('/object/sign/')) return new Response(JSON.stringify({ signedURL: '/object/sign/ebda-docs/x?token=abc' }), { status: 200 });
  return new Response('{}', { status: 200 });
};
const { handle: notify } = await import('./.build/fn_notify.mjs');
const { handle: docs } = await import('./.build/fn_docs.mjs');
let fails = 0; const check = (n, c, d = '') => { console.log((c ? 'PASS ' : 'FAIL ') + n + (c ? '' : ' -> ' + d)); if (!c) fails++; };
const rpc = async (req) => (await (await realFetch('http://localhost:8765/rest/v1/rpc/api', { method: 'POST', body: JSON.stringify({ req }) })).json());
const post = (h, b) => h(new Request('http://x/', { method: 'POST', body: JSON.stringify(b) }));
const T = (await rpc({ action: 'login', username: 'custody1', pin: '1111' })).token;
const add = await rpc({ action: 'addExpense', auth: { token: T }, expense: { custody_id: 'c_b1', line_id: 'l_b1', amount: 50, date: '2026-09-22', description: 'اختبار' } });
const id = add.item.id;
// notify
let r = await (await post(notify, { token: T, event: 'expense_new', id })).json();
const mail = calls.find(c => c.url.includes('resend'));
check('notify sends via Resend to direct manager', r.ok && r.sent === 1 && JSON.parse(mail.body).to[0] === 'sup1@x.com', JSON.stringify(r));
check('notify subject contains txn', JSON.parse(mail.body).subject.includes('EXP-'));
r = await (await post(notify, { token: 'bad', event: 'expense_new', id })).json();
check('notify rejects bad token', r.ok === false, JSON.stringify(r));
r = await (await post(notify, { token: T, event: 'hack', id })).json();
check('notify rejects unknown event', !!r.error);
// docs upload
const pdf = Buffer.from('%PDF-1.4 test').toString('base64');
r = await (await post(docs, { token: T, action: 'upload', expense_id: id, filename: 'فاتورة 1.pdf', mime: 'application/pdf', dataBase64: pdf, doc_type: 'فاتورة' })).json();
const up = calls.find(c => c.method === 'POST' && c.url.includes('/storage/v1/object/ebda-docs/'));
check('docs upload stores in private bucket with service key', r.ok && up && up.headers.Authorization === 'Bearer srv', JSON.stringify(r));
const b = await rpc({ action: 'bootstrap', auth: { token: T } });
const e = b.expenses.find(x => x.id === id);
check('expense now references storage path (no base64 in DB)', e.doc_url.startsWith('storage:') && e.doc_name === 'فاتورة 1.pdf', e.doc_url);
r = await (await post(docs, { token: T, action: 'upload', expense_id: id, filename: 'x.exe', mime: 'application/x-msdownload', dataBase64: pdf })).json();
check('docs rejects non image/pdf', !!r.error);
const T2 = (await rpc({ action: 'login', username: 'custody2', pin: '5555' })).token;
r = await (await post(docs, { token: T2, action: 'url', expense_id: id })).json();
check('other custody officer cannot get signed url', !!r.error, JSON.stringify(r));
const S = (await rpc({ action: 'login', username: 'sup1', pin: '3333' })).token;
r = await (await post(docs, { token: S, action: 'url', expense_id: id })).json();
check('direct manager in scope gets signed url', r.ok && r.url.startsWith('http://localhost:8765/storage/v1/object/sign/'), JSON.stringify(r));
r = await (await post(docs, { token: T, action: 'upload', expense_id: id, filename: 'b.png', mime: 'image/png', dataBase64: pdf })).json();
const del = calls.find(c => c.method === 'DELETE');
check('re-upload deletes previous object', r.ok && del && JSON.parse(del.body).prefixes[0].includes('فاتورة') , del && del.body);
console.log(`\n${fails} failures`); process.exit(fails ? 1 : 0);
