"""Tests for migration 002: sessions, over-budget warnings, notifyInfo, docAuth."""
import json, sys, psycopg2
conn = psycopg2.connect(host='/var/tmp/pg', port=5433, user='postgres', dbname='postgres'); conn.autocommit = True
cur = conn.cursor(); cur.execute("set role anon")
fails = 0
def raw(req): cur.execute("select public.api(%s::jsonb)", (json.dumps(req),)); return cur.fetchone()[0]
def api(tok, action, **kw): return raw(dict(action=action, auth={'token': tok}, **kw))
def check(n, c, d=''):
    global fails; print(('PASS ' if c else 'FAIL ') + n + ('' if c else f' -> {d}')); fails += (not c)
ok = lambda r: isinstance(r, dict) and r.get('ok') is True
err = lambda r: isinstance(r, dict) and 'error' in r
def sql(q, *a):
    cur.execute("reset role"); cur.execute(q, a); r = cur.fetchall() if cur.description else None; cur.execute("set role anon"); return r

L = raw({'action': 'login', 'username': 'custody1', 'pin': '1111', 'ua': 'pytest'})
check('login returns session token', ok(L) and len(L.get('token', '')) == 64, L)
T1 = L['token']
check('token stored only as hash', sql("select count(*) from ebda.sessions where token_hash=%s", T1)[0][0] == 0 and sql("select count(*) from ebda.sessions")[0][0] >= 1)
b = api(T1, 'bootstrap'); check('bootstrap with token', ok(b) and b['me']['username'] == 'custody1', b)
check('bad token rejected', err(api('f' * 64, 'bootstrap')))
check('token cannot be combined to impersonate (auth replaced by session)', api(T1, 'bootstrap', **{})['me']['username'] == 'custody1')

# warnings: line l_b1 allocated 37950; pipeline e1 1000 pending + e2 2000 approved
r = api(T1, 'lineStatus', line_id='l_b1', amount=40000)
check('custody lineStatus says over without numbers', ok(r) and r['over'] is True and 'allocated' not in r and r['message'], r)
r = api(T1, 'lineStatus', line_id='l_b1', amount=100)
check('custody lineStatus not over for small amount', ok(r) and r['over'] is False, r)
check('custody cannot query out-of-scope line', err(api(T1, 'lineStatus', line_id='l_d1', amount=1)))
r = api(T1, 'addExpense', expense={'custody_id': 'c_b1', 'amount': 36000, 'line_id': 'l_b1', 'date': '2026-09-20', 'description': 'كبير'})
check('addExpense over budget -> saved + warning (no numbers for custody)', ok(r) and 'warning' in r and 'ج.م' not in r['warning'], r)
big = r['item']['id']
A = raw({'action': 'login', 'username': 'acc1', 'pin': '2222'})['token']
r = api(A, 'lineStatus', line_id='l_b1', amount=0)
check('finance lineStatus shows numbers', ok(r) and r['allocated'] == 37950 and r['pipeline'] == 39000, r)
r = api(A, 'addCentral', expense={'school_id': sql("select school_id from ebda.lines where id='l_b1'")[0][0], 'line_id': 'l_b1', 'amount': 10, 'date': '2026-09-21'})
check('addCentral over -> warning with numbers', ok(r) and 'ج.م' in r.get('warning', ''), r)

# notifyInfo
for u, p, e in [('sup1', '3333', 'sup1@x.com'), ('acc1', '2222', 'acc1@x.com'), ('custody1', '1111', 'c1@x.com'), ('sup2', '4444', 'sup2@x.com')]:
    sql("update ebda.users set email=%s where username=%s", e, u)
n = api(T1, 'notifyInfo', event='expense_new', id=big)
check('expense_new notifies badr direct manager only', ok(n) and n['to'] == ['sup1@x.com'] and 'EXP-' in n['subject'], n)
S = raw({'action': 'login', 'username': 'sup1', 'pin': '3333'})['token']
api(S, 'updateExpense', id=big, patch={'approval': 'approved'})
n = api(S, 'notifyInfo', event='expense_decided', id=big)
check('expense_decided -> custody owner + finance', ok(n) and sorted(n['to']) == ['acc1@x.com', 'c1@x.com'], n)
check('notifyInfo out of scope rejected', err(api(raw({'action': 'login', 'username': 'sup2', 'pin': '4444'})['token'], 'notifyInfo', event='expense_new', id=big)))
check('unknown event rejected', err(api(T1, 'notifyInfo', event='spam', id=big)))
r = api(A, 'reviewExpense', id=big, patch={'fin_approval': 'approved'})
check('fin approval of over-budget expense returns deficit warning', ok(r) and 'عجز' in r.get('warning', ''), r)

# docAuth
r = api(T1, 'docAuth', expense_id=big, mode='upload'); check('owner may upload doc', ok(r) and r['path'].endswith(big + '/'), r)
check('other custody cannot read doc', err(api(raw({'action': 'login', 'username': 'custody2', 'pin': '5555'})['token'], 'docAuth', expense_id=big, mode='read')))
check('direct manager may read doc in scope', ok(api(S, 'docAuth', expense_id=big, mode='read')))
check('direct manager may not upload', err(api(S, 'docAuth', expense_id=big, mode='upload')))

# session lifecycle
check('logout ok', ok(api(T1, 'logout')))
check('token dead after logout', err(api(T1, 'bootstrap')))
T2 = raw({'action': 'login', 'username': 'custody1', 'pin': '1111'})['token']
check('setPassword keeps current session', ok(api(T2, 'setPassword', pin='9876')) and ok(api(T2, 'bootstrap')))
AD = raw({'action': 'login', 'username': 'admin', 'pin': '1234'})['token']
check('admin reset pin kills user sessions', ok(api(AD, 'resetPin', id='u_c1')) and err(api(T2, 'bootstrap')))
T3 = raw({'action': 'login', 'username': 'acc1', 'pin': '2222'})['token']
api(AD, 'updateUser', id='u_a1', patch={'active': 'لا'})
check('deactivation kills sessions', err(api(T3, 'bootstrap')))
api(AD, 'updateUser', id='u_a1', patch={'active': 'نعم'})
sql("update ebda.sessions set last_seen=now()-interval '13 hours'")
check('idle session expires', err(api(AD, 'bootstrap')))
# pin compatibility switch
check('legacy pin auth works while allowed', ok(raw({'action': 'bootstrap', 'auth': {'username': 'sup1', 'pin': '3333'}})))
sql("update ebda.config set value='no' where key='allow_pin_auth'")
check('legacy pin auth blocked when disabled', err(raw({'action': 'bootstrap', 'auth': {'username': 'sup1', 'pin': '3333'}})))
T4 = raw({'action': 'login', 'username': 'sup1', 'pin': '3333'})['token']
check('token auth still works when pin auth disabled', ok(api(T4, 'bootstrap')))
sql("update ebda.config set value='yes' where key='allow_pin_auth'")
try:
    cur.execute("select count(*) from ebda.sessions"); check('anon cannot read sessions', False)
except Exception:
    conn.rollback() if not conn.autocommit else None; check('anon cannot read sessions', True)
try:
    cur.execute("select ebda.api_core('{\"action\":\"ping\"}'::jsonb)"); check('anon cannot call api_core directly', False)
except Exception:
    check('anon cannot call api_core directly', True)
print(f'\n{fails} failures'); sys.exit(1 if fails else 0)
