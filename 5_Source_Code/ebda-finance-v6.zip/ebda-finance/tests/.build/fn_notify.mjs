// ../supabase/functions/_shared/rpc.ts
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
function env(name) {
  const v = Deno.env.get(name);
  if (!v) throw new Error("missing env " + name);
  return v;
}
function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });
}
async function rpc(token, action, payload = {}) {
  const url = env("SUPABASE_URL").replace(/\/+$/, "") + "/rest/v1/rpc/api";
  const key = env("SUPABASE_ANON_KEY");
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", apikey: key, Authorization: "Bearer " + key },
    body: JSON.stringify({ req: { action, ...payload, auth: { token } } })
  });
  const data = await res.json();
  if (!data || data.error) throw new Error(data && data.error || "rpc failed");
  return data;
}

// ../supabase/functions/notify/index.ts
var EVENTS = /* @__PURE__ */ new Set([
  "expense_new",
  "expense_decided",
  "expense_fin",
  "expense_review",
  "request_new",
  "request_decided",
  "request_transferred",
  "custody_submitted"
]);
async function handle(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  try {
    const { token, event, id } = await req.json();
    if (!token || !EVENTS.has(event) || !id) return json({ error: "\u0637\u0644\u0628 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D" }, 400);
    const info = await rpc(token, "notifyInfo", { event, id });
    const to = info.to || [];
    if (!to.length) return json({ ok: true, sent: 0, note: "\u0644\u0627 \u064A\u0648\u062C\u062F \u0645\u0633\u062A\u0644\u0645\u0648\u0646 \u0628\u0625\u064A\u0645\u064A\u0644 \u0645\u0633\u062C\u0651\u0644" });
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: "Bearer " + env("RESEND_API_KEY"), "Content-Type": "application/json" },
      body: JSON.stringify({ from: env("NOTIFY_FROM"), to, subject: info.subject, html: info.html })
    });
    if (!r.ok) return json({ ok: false, error: "\u0641\u0634\u0644 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0628\u0631\u064A\u062F: " + (await r.text()).slice(0, 200) }, 502);
    return json({ ok: true, sent: to.length });
  } catch (e) {
    return json({ ok: false, error: String(e.message || e) }, 400);
  }
}
if (typeof Deno !== "undefined" && Deno.serve) Deno.serve(handle);
export {
  handle
};
