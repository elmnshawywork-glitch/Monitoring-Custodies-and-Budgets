// ../supabase/functions/_shared/rpc.ts
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
function env(name) {
  const v = Deno.env.get(name);
  if (!v) throw new Error("missing env " + name);
  return v;
}
function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });
}
async function rpc(token, action, payload = {}) {
  const url = env("SUPABASE_URL").replace(/\/+$/, "") + "/rest/v1/rpc/api";
  const key = env("SUPABASE_ANON_KEY");
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", apikey: key, Authorization: "Bearer " + key },
    body: JSON.stringify({ req: { action, ...payload, auth: { token } } })
  });
  const data = await res.json();
  if (!data || data.error) throw new Error(data && data.error || "rpc failed");
  return data;
}

// ../supabase/functions/docs/index.ts
var BUCKET = "ebda-docs";
var MAX = 10 * 1024 * 1024;
var ALLOWED = /^(image\/(png|jpe?g|webp|gif|heic)|application\/pdf)$/i;
function b64ToBytes(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
var safeName = (n) => (n || "document").replace(/[^\p{L}\p{N}._-]+/gu, "_").slice(-80);
async function handle(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  const base = env("SUPABASE_URL").replace(/\/+$/, "") + "/storage/v1";
  const srv = env("SUPABASE_SERVICE_ROLE_KEY");
  const sh = { Authorization: "Bearer " + srv, apikey: srv };
  try {
    const body = await req.json();
    const { token, action, expense_id } = body;
    if (!token || !expense_id) return json({ error: "\u0637\u0644\u0628 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D" }, 400);
    if (action === "upload") {
      const auth = await rpc(token, "docAuth", { expense_id, mode: "upload" });
      const mime = String(body.mime || "");
      if (!ALLOWED.test(mime)) return json({ error: "\u0646\u0648\u0639 \u0627\u0644\u0645\u0644\u0641 \u063A\u064A\u0631 \u0645\u0633\u0645\u0648\u062D (\u0635\u0648\u0631\u0629 \u0623\u0648 PDF \u0641\u0642\u0637)" }, 400);
      const bytes = b64ToBytes(String(body.dataBase64 || ""));
      if (!bytes.length || bytes.length > MAX) return json({ error: "\u062D\u062C\u0645 \u0627\u0644\u0645\u0644\u0641 \u063A\u064A\u0631 \u0645\u0633\u0645\u0648\u062D (\u062D\u062A\u0649 10 \u0645\u064A\u062C\u0627)" }, 400);
      const path = auth.path + Date.now() + "_" + safeName(String(body.filename || ""));
      const up = await fetch(`${base}/object/${BUCKET}/${encodeURI(path)}`, {
        method: "POST",
        headers: { ...sh, "Content-Type": mime, "x-upsert": "false" },
        body: bytes
      });
      if (!up.ok) return json({ error: "\u0641\u0634\u0644 \u0627\u0644\u0631\u0641\u0639: " + (await up.text()).slice(0, 200) }, 502);
      await rpc(token, "uploadDoc", { id: expense_id, link: "storage:" + path, filename: body.filename || "\u0645\u0633\u062A\u0646\u062F", doc_type: body.doc_type || "" });
      if (auth.current) {
        await fetch(`${base}/object/${BUCKET}`, { method: "DELETE", headers: { ...sh, "Content-Type": "application/json" }, body: JSON.stringify({ prefixes: [auth.current] }) });
      }
      return json({ ok: true, url: "storage:" + path });
    }
    if (action === "url") {
      const auth = await rpc(token, "docAuth", { expense_id, mode: "read" });
      if (!auth.current) return json({ error: "\u0644\u0627 \u064A\u0648\u062C\u062F \u0645\u0633\u062A\u0646\u062F \u0645\u062E\u0632\u0651\u0646 \u0644\u0647\u0630\u0627 \u0627\u0644\u0645\u0635\u0631\u0648\u0641" }, 404);
      const s = await fetch(`${base}/object/sign/${BUCKET}/${encodeURI(auth.current)}`, {
        method: "POST",
        headers: { ...sh, "Content-Type": "application/json" },
        body: JSON.stringify({ expiresIn: 3600 })
      });
      const d = await s.json();
      if (!s.ok || !d.signedURL) return json({ error: "\u062A\u0639\u0630\u0651\u0631 \u0625\u0646\u0634\u0627\u0621 \u0631\u0627\u0628\u0637 \u0627\u0644\u0645\u0633\u062A\u0646\u062F" }, 502);
      return json({ ok: true, url: base + d.signedURL });
    }
    return json({ error: "\u0625\u062C\u0631\u0627\u0621 \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641" }, 400);
  } catch (e) {
    return json({ ok: false, error: String(e.message || e) }, 400);
  }
}
if (typeof Deno !== "undefined" && Deno.serve) Deno.serve(handle);
export {
  handle
};
