-- simulate production data BEFORE migration (old api, plaintext pins)
do $$
declare badr text; dam text; l1 text; l2 text; l3 text; c1 text;
begin
  select id into badr from ebda.schools where name like '%بدر%';
  select id into dam from ebda.schools where name like '%دمياط%';
  insert into ebda.users(id,username,pin,name,role,schools,active,email) values
   ('u_c1','custody1','1111','أحمد مسئول عهدة بدر','custody',badr,'نعم',''),
   ('u_c2','custody2','5555','منى مسئول عهدة دمياط','custody',dam,'نعم',''),
   ('u_a1','acc1','2222','سارة المحاسب','accountant',badr,'نعم',''),
   ('u_s1','sup1','3333','خالد مدير مباشر بدر','supervisor',badr,'نعم',''),
   ('u_s2','sup2','4444','مدير مباشر دمياط','supervisor',dam,'نعم',''),
   ('u_x','olduser','9999','معطل','custody',badr,'لا','');
  insert into ebda.lines(id,school_id,section,name,allocated) values
   ('l_b1',badr,'تشغيل','مطبوعات',37950),('l_b2',badr,'تشغيل','الزى المدرسى',180000),('l_d1',dam,'تشغيل','مطبوعات',38250);
  insert into ebda.custodies(id,label,holder,school_id,note,"user") values
   ('c_b1','عهدة أحمد','أحمد',badr,'','custody1'),('c_d1','عهدة منى','منى',dam,'','custody2');
  insert into ebda.tranches(id,custody_id,date,amount,note) values ('t1','c_b1','2026-09-01',20000,''),('t2','c_d1','2026-09-01',10000,'');
  insert into ebda.expenses(id,date,school_id,custody_id,line_id,description,amount,approval,approved_by,settled,created_by,created_at,doc_url,doc_is_link) values
   ('e1','2026-09-05',badr,'c_b1','l_b1','طباعة pending',1000,'pending','','','أحمد','2026-09-05 10:00','', 'لا'),
   ('e2','2026-09-06',badr,'c_b1','l_b1','طباعة approved',2000,'approved','خالد','','أحمد','2026-09-06 10:00','data:xx','لا'),
   ('e3','2026-10-06',badr,'c_b1','l_b2','زى settled',3000,'approved','خالد','نعم','أحمد','2026-10-06 10:00','https://drive/x','نعم'),
   ('e4','2026-09-20',badr,'','l_b2','central',5000,'approved','سارة','نعم','سارة','2026-09-20 10:00','',''),
   ('e5','2026-09-07',dam,'c_d1','l_d1','دمياط pending',700,'pending','','','منى','2026-09-07 10:00','','');
  insert into ebda.requests(id,school_id,requester,requester_name,status,total,created_at) values
   ('r1',badr,'custody1','أحمد','pending_supervisor',4000,'2026-09-10 09:00'),
   ('r2',dam,'custody2','منى','pending_supervisor',1500,'2026-09-10 09:00');
  insert into ebda.request_items(id,request_id,line_id,name,amount,decision) values
   ('ri1','r1','l_b1','',4000,'approved'),('ri2','r2','l_d1','',1500,'approved');
  update ebda.config set value='s3cret-token-xyz' where key='backup_token';
end $$;
