// يشغّل نفس قارئ الواجهة (frontend/src/lib/expenseImport.js) على ملف Excel داخل Node ويطبع الصفوف الموحّدة JSON
// node parse_expenses.mjs <file.xlsx> <schools.json> [lines.json]
import fs from "fs";
import path from "path";
import { createRequire } from "module";
import url from "url";
const here = path.dirname(url.fileURLToPath(import.meta.url));
const root = path.resolve(here, "../..");
const require = createRequire(import.meta.url);
const { build } = createRequire(path.join(root, "frontend/package.json"))("esbuild");
globalThis.window = { XLSX: require(path.join(root, "vendor/xlsx.full.min.js")) };
const out = path.join(here, ".parser.cjs");
await build({ entryPoints: [path.join(root, "frontend/src/lib/expenseImport.js")], bundle: true, format: "cjs", platform: "node", outfile: out, logLevel: "silent" });
const { readExpenseWorkbook } = require(out);
const [file, schoolsF, linesF] = process.argv.slice(2);
const buf = fs.readFileSync(file);
const f = { name: path.basename(file), arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };
const data = { schools: JSON.parse(fs.readFileSync(schoolsF, "utf8")), lines: linesF ? JSON.parse(fs.readFileSync(linesF, "utf8")) : [] };
const r = await readExpenseWorkbook(f, data);
process.stdout.write(JSON.stringify(r));
