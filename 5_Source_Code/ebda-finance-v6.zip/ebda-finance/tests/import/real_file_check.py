"""تجربة الملف الحقيقى «مصاريف مدرسة ابدأ.xlsx» على قاعدة اختبار: تُحمَّل بنود موازنة المدرستين من ملف الموازنات الأصلى
(نفس أسماء البنود العشرين)، ثم يُقرأ ملف المصروفات بقارئ الواجهة ← معاينة ← استيراد، ويُطبع الملخص والاستثناءات.
Run: bash ../reset.sh && python3 real_file_check.py <مصاريف مدرسة ابدأ.xlsx> <ملف الموازنات.xlsx>"""
import json, sys, subprocess, tempfile, pathlib, collections, re, openpyxl, psycopg2
HERE = pathlib.Path(__file__).parent
EXP, BUD = sys.argv[1], sys.argv[2]
c = psycopg2.connect(host='/var/tmp/pg', port=5433, user='postgres', dbname='postgres'); c.autocommit = True; cur = c.cursor()
def one(q, *a): cur.execute(q, a or None); return cur.fetchone()[0]
def api(action, **kw):
    cur.execute("set role anon")
    cur.execute("select public.api(%s::jsonb)", (json.dumps({'action': 'login', 'username': 'admin', 'pin': '1234'}),)); t = cur.fetchone()[0]['token']
    cur.execute("select public.api(%s::jsonb)", (json.dumps(dict(action=action, auth={'token': t}, **kw)),)); r = cur.fetchone()[0]
    cur.execute("reset role"); return r
badr = one("select id from ebda.schools where name like '%%بدر%%'"); dam = one("select id from ebda.schools where name like '%%دمياط%%'")
wb = openpyxl.load_workbook(BUD, data_only=True)
n = 0
for sheet, sid in [('مصروفات_دمياط', dam), ('مصروفات_بدر', badr)]:
    sec = ''
    for r in wb[sheet].iter_rows(min_row=4, values_only=True):
        strs = [x for x in r if isinstance(x, str) and x.strip()]; nums = [x for x in r if isinstance(x, (int, float)) and not isinstance(x, bool)]
        if not strs: continue
        name, val = strs[0], (nums[0] if nums else None)
        if re.match(r'^(أولاً|ثانياً|ثالثاً|رابعاً|خامساً)', str(name)): sec = str(name).split(':')[1].split('(')[0].strip() if ':' in str(name) else str(name); continue
        if str(name).startswith('إجمالى') or str(name).startswith('الإجمالى') or not isinstance(val, (int, float)): continue
        cur.execute("insert into ebda.lines(id,school_id,section,name,allocated) values(%s,%s,%s,%s,%s) on conflict do nothing", (f'rl_{sid}_{n}', sid, sec, str(name).strip(), val)); n += 1
print('budget lines loaded:', n)
schools = [{'id': i, 'name': nm} for i, nm in (cur.execute("select id, name from ebda.schools") or cur.fetchall())]
lines = [{'id': i, 'name': nm, 'section': s, 'school_id': sc} for i, nm, s, sc in (cur.execute("select id, name, section, school_id from ebda.lines") or cur.fetchall())]
with tempfile.NamedTemporaryFile('w', suffix='.json', delete=False) as f1: json.dump(schools, f1)
with tempfile.NamedTemporaryFile('w', suffix='.json', delete=False) as f2: json.dump(lines, f2)
out = subprocess.run(['node', str(HERE / 'parse_expenses.mjs'), EXP, f1.name, f2.name], capture_output=True, text=True, cwd=HERE.parent.parent / 'frontend')
P = json.loads(out.stdout)
print('\nأوراق الملف:')
for s in P['sheets']:
    print(f"  {s['name']:<22} {'✓' if s['recognized'] else '—'} صفوف={s['rows']:<4} مدرسة={'✓' if s.get('school_id') else '✗'} عهدة={[x['amount'] for x in s.get('receipts', [])]} أعمدة={s.get('columns')} {('تبديل: ' + ' ↔ '.join(s['swapped'])) if s.get('swapped') else ''}")
rows = [r for r in P['rows'] if r.get('school_id')]   # الأوراق التى عُرفت مدرستها تلقائياً
print('\nصفوف من أوراق معروفة المدرسة:', len(rows), 'من', len(P['rows']))
pv = api('importExpensesFile', mode='preview', rows=rows, file_name=pathlib.Path(EXP).name, approve_mode='approved')
print('\nالمعاينة:', json.dumps(pv['summary'], ensure_ascii=False))
why = collections.Counter()
for r in pv['rows']:
    if r['status'] in ('error', 'duplicate', 'warning'):
        for m in r['errors'] + ([r['duplicate_of']] if r['duplicate_of'] else []) + r['warnings']: why[r['status'] + ': ' + re.sub(r'[:(].*', '', m)] += 1
for k, v in why.most_common(): print(f'   {v:>4}  {k}')
for r in pv['rows']:
    if r['status'] == 'error': print('   •', r['r'], '|', ' · '.join(r['errors'])[:160])
cm = api('importExpensesFile', mode='commit', rows=rows, file_name=pathlib.Path(EXP).name, approve_mode='approved')
print('\nالاستيراد:', cm.get('ok'), 'دفعة', cm.get('batch_id'), 'مستورد', cm['summary']['importable'])
for cu in cm['custodies']: print('   عهدة', cu['code'], cu['holder'], cu['school'], 'قيمة', cu['received'], 'منصرف', cu['imported'], 'متبقى', cu['remaining_after'])
print('   بنود الموازنة المتأثرة:', len(cm['lines']))
for l in cm['lines'][:40]: print(f"     {l['school'][-6:]} | {l['line']:<40} مخصص {l['allocated']:>10} فعلى {l['actual_after']:>9} متبقى {l['remaining_after']:>10} {l['pct_after']}% {l['state']}")
again = api('importExpensesFile', mode='preview', rows=rows, approve_mode='approved')
print('\nإعادة رفع نفس الملف:', json.dumps(again['summary'], ensure_ascii=False))
