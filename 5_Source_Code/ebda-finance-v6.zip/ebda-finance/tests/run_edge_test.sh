#!/bin/bash
# Transpile the Deno Edge Functions to Node ESM and run them against the local mock server (tests/e2e/server.py on :8765).
set -e
cd "$(dirname "$0")"
ES=../frontend/node_modules/.bin/esbuild
for f in notify docs; do $ES ../supabase/functions/$f/index.ts --bundle --format=esm --platform=neutral --outfile=.build/fn_$f.mjs --log-level=warning; done
node edge_test.mjs
