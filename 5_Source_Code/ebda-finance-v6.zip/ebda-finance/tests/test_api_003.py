"""Tests for migration 003: safe budget import (merge), duplicate prevention, audit trail old/new,
custody creation with base amount, payment method, export logging — and that existing data is untouched."""
import json, subprocess, sys, psycopg2, pathlib
HERE = pathlib.Path(__file__).parent
PSQL = ['psql', '-h', '/var/tmp/pg', '-p', '5433', '-U', 'postgres', '-q', '-v', 'ON_ERROR_STOP=1']
conn = psycopg2.connect(host='/var/tmp/pg', port=5433, user='postgres', dbname='postgres'); conn.autocommit = True
cur = conn.cursor()
fails = 0
def check(n, c, d=''):
    global fails; print(('PASS ' if c else 'FAIL ') + n + ('' if c else f' -> {d}')); fails += (not c)
def sql(q, *a):
    cur.execute("reset role"); cur.execute(q, a or None); return cur.fetchall() if cur.description else None
def raw(req):
    cur.execute("set role anon"); cur.execute("select public.api(%s::jsonb)", (json.dumps(req),)); r = cur.fetchone()[0]; cur.execute("reset role"); return r
def login(u, p): return raw({'action': 'login', 'username': u, 'pin': p})['token']
def api(tok, action, **kw): return raw(dict(action=action, auth={'token': tok}, **kw))
ok = lambda r: isinstance(r, dict) and r.get('ok') is True
err = lambda r: isinstance(r, dict) and 'error' in r

# ---------------------------------------------------------------- 003 on top of existing data: nothing lost
TABLES = ['users', 'schools', 'lines', 'custodies', 'tranches', 'expenses', 'requests', 'request_items', 'audit_log']
def snapshot():
    return {t: sql(f"select md5(coalesce(string_agg(md5((to_jsonb(x) - 'kind' - 'purpose' - 'pay_method' - 'txid')::text), ',' order by x.id), '')) , count(*) from ebda.{t} x")[0] for t in TABLES}
before = snapshot()
mig = (HERE.parent / 'supabase' / 'migrations' / '003_import_audit_custody.sql')
subprocess.run(PSQL + ['-f', str(mig)], check=True, capture_output=True)
subprocess.run(PSQL + ['-f', str(mig)], check=True, capture_output=True)
after = snapshot()
# audit_log gained a txid column (null for old rows) — compare counts for it, full content for the rest
check('003 on existing data (twice) keeps every existing row unchanged',
      all(before[t] == after[t] for t in TABLES),
      [t for t in TABLES if before[t] != after[t]])
check('schema_version = 3', sql("select value from ebda.config where key='schema_version'")[0][0] == '3')
check('anon cannot read the new audit table', sql("select has_table_privilege('anon','ebda.audit_changes','select')")[0][0] is False)

A = login('admin', '1234'); F = login('acc1', '2222'); S = login('sup1', '3333'); C = login('custody1', '1111')
badr = sql("select id from ebda.schools where name like '%بدر%'")[0][0]
dam = sql("select id from ebda.schools where name like '%دمياط%'")[0][0]
n_lines = sql("select count(*) from ebda.lines")[0][0]

# ---------------------------------------------------------------- normalisation used for matching
check('norm_txt unifies hamza/ya/ta-marbuta and strips ordinals',
      sql("select ebda.norm_txt('أولاً : تكلفة التدريس'), ebda.norm_txt('تكلفة  التدريس'), ebda.norm_txt('مستهلكات معامل '), ebda.norm_txt('مستهلكات معامل')")[0]
      == ('تكلفه التدريس', 'تكلفه التدريس', 'مستهلكات معامل', 'مستهلكات معامل'))

# ---------------------------------------------------------------- manual add: validation + no duplicates
r = api(F, 'addLine', line={'school_id': badr, 'section': 'تشغيل', 'name': 'مطبوعات', 'allocated': 1})
check('addLine rejects duplicate (same entity+section+name)', err(r) and 'موجود' in r['error'], r)
r = api(F, 'addLine', line={'school_id': badr, 'section': 'تشغيل ', 'name': ' مطبوعات', 'allocated': 1})
check('addLine duplicate check ignores spacing', err(r), r)
r = api(F, 'addLine', line={'school_id': badr, 'section': 'تشغيل', 'name': 'بند جديد', 'allocated': 'abc'})
check('addLine rejects non-numeric amount', err(r), r)
r = api(F, 'addLine', line={'school_id': badr, 'section': 'تشغيل', 'name': '', 'allocated': 5})
check('addLine rejects empty name', err(r), r)
r = api(F, 'addLine', line={'school_id': badr, 'section': 'تشغيل', 'name': 'أحبار طابعة', 'allocated': 12000, 'note': 'يدوى'})
check('addLine adds a new line', ok(r) and r['item']['allocated'] == 12000, r)
new_line = r['item']['id']
r = api(F, 'addLine', line={'school_id': dam, 'section': 'تشغيل', 'name': 'أحبار طابعة', 'allocated': 1})
check('addLine outside scope rejected', err(r), r)
r = api(F, 'updateLine', id=new_line, patch={'name': 'مطبوعات'})
check('updateLine cannot rename into an existing line', err(r), r)
r = api(F, 'updateLine', id=new_line, patch={'allocated': 15000})
check('updateLine amount works', ok(r) and sql("select allocated from ebda.lines where id=%s", new_line)[0][0] == 15000, r)

# ---------------------------------------------------------------- import (merge)
alloc_b1 = sql("select allocated from ebda.lines where id='l_b1'")[0][0]
r = api(F, 'importBudget', mode='merge', lines=[
    {'school_id': badr, 'section': 'تشغيل', 'name': 'مطبوعات', 'allocated': 37950},           # unchanged (same normalised key)
    {'school_id': badr, 'line_id': 'l_b2', 'section': 'تكلفة التشغيل', 'name': 'الزى المدرسى', 'allocated': 175000},  # matched by user → update
    {'school_id': badr, 'section': 'تكلفة التدريس', 'name': 'تدريب المعلمين', 'allocated': 150000},  # new
    {'school_id': badr, 'section': 'تكلفة التدريس', 'name': 'تدريب المعلمين', 'allocated': 150000},  # duplicate in file → no second row
])
check('merge import returns added/updated/unchanged', ok(r) and r['added'] == 1 and r['updated'] == 1 and r['unchanged'] == 2, r)
check('merge import never deletes lines', sql("select count(*) from ebda.lines")[0][0] == n_lines + 2)
check('matched line updated, id kept, expenses still linked',
      sql("select allocated from ebda.lines where id='l_b2'")[0][0] == 175000 and sql("select count(*) from ebda.expenses where line_id='l_b2'")[0][0] == 2)
check('no duplicate line created from repeated rows', sql("select count(*) from ebda.lines where school_id=%s and name='تدريب المعلمين'", badr)[0][0] == 1)
check('unchanged line untouched', sql("select allocated from ebda.lines where id='l_b1'")[0][0] == alloc_b1)
cnt = sql("select count(*) from ebda.lines")[0][0]
r = api(F, 'importBudget', mode='merge', lines=[{'school_id': badr, 'name': 'سليم', 'allocated': 1}, {'school_id': badr, 'name': 'خطأ', 'allocated': '12x'}])
check('invalid row rejects the whole import (no partial write)', err(r) and sql("select count(*) from ebda.lines")[0][0] == cnt, r)
r = api(F, 'importBudget', mode='merge', lines=[{'school_id': dam, 'name': 'خارج النطاق', 'allocated': 1}])
check('import into an entity outside scope rejected', err(r), r)
r = api(S, 'importBudget', mode='merge', lines=[{'school_id': badr, 'name': 'x', 'allocated': 1}])
check('direct manager cannot import', err(r), r)
r = api(F, 'importBudget', mode='merge', lines=[{'school_id': badr, 'line_id': 'l_d1', 'name': 'x', 'allocated': 1}])
check('matched line must belong to the same entity', err(r), r)
r = api(A, 'importBudget', mode='merge', lines=[{'school_id': badr, 'line_id': new_line, 'section': 'تشغيل', 'name': 'أحبار وخراطيش', 'allocated': 15000, 'rename': '1'}])
check('optional rename keeps id', ok(r) and r['updated'] == 1 and sql("select name from ebda.lines where id=%s", new_line)[0][0] == 'أحبار وخراطيش', r)
r = api(A, 'importBudget', school_id=dam, lines=[{'name': 'x', 'allocated': 1}])
check('old replace mode still protected when expenses exist', err(r), r)

# ---------------------------------------------------------------- custody in one step + payment method
r = api(F, 'addCustody', custody={'school_id': badr, 'holder': 'أحمد', 'user': 'custody1', 'kind': 'تشغيلية', 'purpose': 'رحلة ميدانية', 'amount': 8000, 'date': '2026-10-01', 'note': 'n'})
check('addCustody with base amount creates the tranche', ok(r) and r['item']['received'] == 8000 and r['item']['kind'] == 'تشغيلية' and len(r['tranches']) == 1, r)
cid = r['item']['id']
check('custody keeps given date and code', r['item']['opened_at'] == '2026-10-01' and r['item']['code'].startswith('CUST-'))
r = api(F, 'addCustody', custody={'school_id': badr, 'holder': 'x', 'amount': '-5'})
check('addCustody rejects negative amount', err(r), r)
r = api(F, 'updateCustody', id=cid, patch={'purpose': 'رحلة ميدانية للصف الثالث'})
check('updateCustody edits purpose', ok(r) and sql("select purpose from ebda.custodies where id=%s", cid)[0][0] == 'رحلة ميدانية للصف الثالث')
r = api(C, 'addExpense', expense={'custody_id': cid, 'line_id': 'l_b1', 'amount': 300, 'date': '2026-10-02', 'description': 'أتوبيس', 'pay_method': 'نقدى'})
check('addExpense stores payment method', ok(r) and r['item']['pay_method'] == 'نقدى', r)
eid = r['item']['id']
r = api(C, 'updateExpense', id=eid, patch={'pay_method': 'تحويل بنكى'})
check('owner can change payment method before approval', ok(r) and sql("select pay_method from ebda.expenses where id=%s", eid)[0][0] == 'تحويل بنكى', r)

# ---------------------------------------------------------------- audit trail: who / what / old / new / where
r = api(F, 'logExport', report='تقرير العهد', format='excel', filters={'school': badr})
check('logExport ok', ok(r), r)
b = api(A, 'bootstrap')
aud, ch = b.get('audit', []), b.get('audit_changes', [])
check('admin bootstrap has audit + changes', len(aud) > 0 and len(ch) > 0)
up = [c for c in ch if c['tbl'] == 'lines' and c['op'] == 'update' and c['row_id'] == 'l_b2']
check('change rows hold old and new values', up and up[0]['old_v'].get('allocated') == 180000 and up[0]['new_v'].get('allocated') == 175000, up[:1])
check('changes carry the entity (school)', up and up[0]['school_id'] == badr)
imp = [a for a in aud if a['action'] == 'importBudget']
check('change rows link to their audit entry (txid)', imp and any(c['txid'] == i['txid'] and c['row_id'] == 'l_b2' for i in imp for c in ch))
check('export recorded in the trail', any(a['action'] == 'logExport' and 'تقرير العهد' in (a.get('details') or '') for a in aud))
ins = [c for c in ch if c['tbl'] == 'tranches' and c['op'] == 'insert']
check('tranche insert mapped to the custody entity', ins and ins[0]['school_id'] == badr, ins[:1])
api(C, 'setPassword', pin='7777')
pw = [c for c in api(A, 'bootstrap')['audit_changes'] if c['tbl'] == 'users']
check('password never stored in the trail', pw and all('7777' not in json.dumps(c, ensure_ascii=False) and '$2' not in json.dumps(c) for c in pw), pw[:1])
check('non-admin gets no audit data', 'audit_changes' not in api(F, 'bootstrap') and 'audit' not in api(S, 'bootstrap'))
check('bootstrap has settings for overdue custodies', api(S, 'bootstrap').get('settings', {}).get('custody_overdue_days') == 30)
d = sql("select count(*) from ebda.audit_changes where tbl='users' and op='update' and row_id='u_a1'")[0][0]
login('acc1', '2222')
check('login (last_login) does not flood the trail', sql("select count(*) from ebda.audit_changes where tbl='users' and op='update' and row_id='u_a1'")[0][0] == d)

print(f'\n{fails} failures'); sys.exit(1 if fails else 0)
