#!/bin/bash
# Recreate a clean local DB: original setup + legacy seed + migrations (each twice to prove idempotency).
# Requires local Postgres; override with PGHOST/PGPORT (default socket /var/tmp/pg, port 5433).
set -e
cd "$(dirname "$0")"
P="psql -h ${PGHOST:-/var/tmp/pg} -p ${PGPORT:-5433} -U postgres -q -v ON_ERROR_STOP=1"
$P -c "drop schema if exists ebda cascade; drop function if exists public.api(jsonb);" 2>/dev/null
$P -f ../supabase/supabase_setup.sql >/dev/null
$P -f legacy_seed.sql
MIGS="../supabase/migrations/001_rbac_scope_workflow.sql ../supabase/migrations/002_sessions_warnings_notify_docs.sql"
# bash reset.sh 002  → stop after 002 (used by test_api_003.py to apply 003 on existing data itself)
# bash reset.sh 003  → stop after 003 (test_api_004.py applies 004 itself)
# bash reset.sh 004  → stop after 004 (test_api_005.py applies 005 itself)
[ "$1" != "002" ] && MIGS="$MIGS ../supabase/migrations/003_import_audit_custody.sql"
[ "$1" != "002" ] && [ "$1" != "003" ] && MIGS="$MIGS ../supabase/migrations/004_permissions_custody_payroll.sql"
[ "$1" != "002" ] && [ "$1" != "003" ] && [ "$1" != "004" ] && MIGS="$MIGS ../supabase/migrations/005_workflow_backup_performance.sql"
for m in $MIGS; do
  $P -f $m 2>&1 | grep -v NOTICE || true
  $P -f $m 2>&1 | grep -v NOTICE || true
done
