"""Browser E2E for v5 (migration 004 + new screens). Runs against tests/e2e/server.py on :8765 after `bash ../reset.sh`.
Run from the folder that holds site/ (the mock server's web root).
Covers the v5 test list: login + password visibility, users/permissions/scope, budget delete (soft, audited),
custody create (draft) / submit / approve / cancel, expense chain + negative balance, multiple tracker filters,
employee/payroll import (no duplicates on re-import or next month), monthly payroll, adjustments, the three payroll
reports (company total = 620,976.15), dashboard alerts + insights per place, exports, audit trail, no data loss.
Payroll files: EBDA_PAY_BADR / EBDA_PAY_DAM / EBDA_PAY_HQ / EBDA_PAY_ACC (defaults = the files attached in the chat)."""
import json, re, os, urllib.request, psycopg2
from playwright.sync_api import sync_playwright
UP = '/root/.claude/uploads/45c3a104-fa98-572c-a7c6-267860b8fb8a/'
def up(prefix):
    return [UP + f for f in os.listdir(UP) if f.startswith(prefix)][0] if os.path.isdir(UP) else ''
F_BADR = os.environ.get('EBDA_PAY_BADR') or up('f701213a')
F_DAM = os.environ.get('EBDA_PAY_DAM') or up('5fdc59bb')
F_HQ = os.environ.get('EBDA_PAY_HQ') or up('9210240d')
F_ACC = os.environ.get('EBDA_PAY_ACC') or up('c9b86b4a')
BASE = 'http://localhost:8765/index.html'
fails = 0
def check(n, c, d=''):
    global fails; print(('PASS ' if c else 'FAIL ') + n + ('' if c else f' -> {d}')); fails += (not c)
def login(page, u, p):
    page.goto(BASE); page.evaluate("localStorage.clear()"); page.goto(BASE); page.wait_for_selector('input')
    ins = page.locator('input'); ins.nth(0).fill(u); ins.nth(1).fill(p)
    page.locator('button').filter(has_text=re.compile('دخول')).first.click(); page.wait_for_selector('.tabs', timeout=15000); page.wait_for_timeout(400)
def tab(page, name): page.locator('.tabs button').filter(has_text=re.compile('^' + name + '$')).first.click(); page.wait_for_timeout(500)
def tabs(page): return page.locator('.tabs button').all_inner_texts()
def rpc(req):
    r = urllib.request.urlopen(urllib.request.Request('http://localhost:8765/rest/v1/rpc/api', data=json.dumps({'req': req}).encode(), method='POST'))
    return json.loads(r.read())
db = psycopg2.connect(host='/var/tmp/pg', port=5433, user='postgres', dbname='postgres'); db.autocommit = True; cur = db.cursor()
def q(sql, *a): cur.execute(sql, a or None); return cur.fetchall()
def one(sql, *a): return q(sql, *a)[0][0]
users_before = q('select id, username, pin, role, schools from ebda.users order by id')
badr = one("select id from ebda.schools where name like '%%بدر%%'")
dam = one("select id from ebda.schools where name like '%%دمياط%%'")
comp = one("select id from ebda.schools where category='company'")
PINS = {'admin': '1234', 'acc1': '2222', 'custody1': '1111', 'sup1': '3333'}
def api(user, action, **kw):  # جلسة جديدة لكل نداء (الدخول من المتصفح أو تعديل المستخدم قد ينهى الجلسات السابقة)
    tok = rpc({'action': 'login', 'username': user, 'pin': PINS[user]})['token']
    return rpc(dict(action=action, auth={'token': tok}, **kw))
A, F, C, S = 'admin', 'acc1', 'custody1', 'sup1'
acc1_id = one("select id from ebda.users where username='acc1'")

def import_payroll(page, path, month, empty_place=None):
    tab(page, 'الرواتب')
    page.locator('.big-action', has_text='استيراد رواتب العاملين').click(); page.wait_for_timeout(300)
    page.locator('.modal input[type=file]').set_input_files(path); page.wait_for_timeout(2500)
    page.fill('[data-testid=wiz-month]', month)
    rows = page.locator('.modal .sheet-row')
    for i in range(rows.count()):
        r = rows.nth(i); sel = r.locator('select').first
        if r.locator('input[type=checkbox]').is_checked() and sel.input_value() == '':
            if empty_place: sel.select_option(empty_place)
            else: r.locator('input[type=checkbox]').uncheck()
            page.wait_for_timeout(300)
    pre = page.locator('.modal').inner_text()
    page.locator('.modal button.primary', has_text='تأكيد الاستيراد').click()
    page.wait_for_selector('.modal .imp-done', timeout=20000)
    k = page.locator('.modal .mini-kpis b').all_inner_texts()
    page.locator('.modal button.primary', has_text='تم').click(); page.wait_for_timeout(1000)
    return pre, [int(x.replace(',', '')) for x in k]

def report_html(page, title):
    box = page.locator('.big-action.report', has_text=title)
    with page.expect_download() as d:
        box.locator('button', has_text='Excel').click()
    return open(d.value.path(), encoding='utf-8').read()

with sync_playwright() as pw:
    b = pw.chromium.launch(); page = b.new_page(viewport={'width': 1360, 'height': 950}, accept_downloads=True)
    errs = []; page.on('pageerror', lambda e: errs.append(str(e))); page.on('dialog', lambda d: d.accept())

    # ================================================================ 1) شاشة الدخول وإظهار كلمة السر
    page.goto(BASE); page.evaluate("localStorage.clear()"); page.goto(BASE); page.wait_for_selector('input')
    check('login shows «إبدأ إديو للتطوير والتدريب»', 'إبدأ إديو للتطوير والتدريب' in page.locator('body').inner_text())
    pw_in = page.locator('input').nth(1); pw_in.fill('1234')
    check('password hidden by default', pw_in.get_attribute('type') == 'password')
    page.locator('.pw-eye').click()
    check('eye shows the password', pw_in.get_attribute('type') == 'text' and pw_in.input_value() == '1234')
    page.locator('.pw-eye').click()
    check('eye-off hides it again (value kept)', pw_in.get_attribute('type') == 'password' and pw_in.input_value() == '1234')
    check('password not stored in browser storage', '1234' not in page.evaluate("JSON.stringify(localStorage)"))

    # ================================================================ 12) الصلاحيات: Role + Permissions + Scope
    login(page, 'admin', '1234'); tab(page, 'الإدارة')
    page.locator('button', has_text='المستخدمون').first.click(); page.wait_for_timeout(400)
    page.locator('tr', has_text='acc1').first.locator('button').first.click(); page.wait_for_timeout(300)
    mod = page.locator('.modal').first
    mod.locator('.perm-box summary').click(); page.wait_for_timeout(200)
    perm = mod.locator('label.perm', has_text='اعتماد العهد').locator('input')
    check('user modal shows the permission checklist with role defaults', mod.locator('label.perm').count() >= 12 and perm.is_checked())
    perm.uncheck(); mod.locator('button', has_text='حفظ').first.click(); page.wait_for_timeout(1200)
    check('revoking one permission is saved as a diff (-custody.approve) without touching pin/role/scope',
          q("select perms, pin, role, schools from ebda.users where username='acc1'")[0] == ('-custody.approve',) + tuple(r for r in users_before if r[1] == 'acc1')[0][2:5],
          q("select perms from ebda.users where username='acc1'"))
    me = api(F, 'bootstrap')['me']
    check('server permissions reflect the revoke', 'custody.approve' not in me['permissions'] and 'custody.create' in me['permissions'], me.get('permissions'))
    r = api(F, 'updateUser', id=acc1_id, patch={'perms': '+manage_users'})
    check('non-admin cannot change permissions (API)', 'error' in r, r)
    check('scope enforced in API (acc1 = Badr only → Damietta payroll import refused)',
          'error' in api(F, 'importPayroll', school_id=dam, month='2026-09', rows=[{'name': 'x', 'net': '1'}]))
    check('custody officer cannot see payroll (tab + data)', 'payroll' not in json.dumps(list(api(C, 'bootstrap').keys())) or not api(C, 'bootstrap').get('payslips'))

    # ================================================================ 3/4/10/11) عهدة: الاسم من Master Data، المسئول بالاسم، مسودة → مراجعة → اعتماد
    login(page, 'acc1', '2222'); tab(page, 'العهد')
    page.locator('.big-action', has_text='إضافة عهدة').click(); page.wait_for_timeout(300)
    mod = page.locator('.modal')
    titles = mod.locator('select').nth(1).locator('option').all_inner_texts()
    check('custody name list comes from master data', 'عهدة تشغيلية' in titles and 'عهدة صيانة' in titles, titles)
    mod.locator('select').nth(1).select_option('عهدة صيانة')
    holders = mod.locator('select').nth(3).locator('option').all_inner_texts()
    check('holder chosen by name from real users (no ids shown)', any('أحمد' in h for h in holders) and not any(re.search(r'\bid[0-9a-f]{6}', h) for h in holders), holders)
    mod.locator('select').nth(3).select_option('u:custody1')
    mod.locator('input[placeholder="0"]').first.fill('10000')
    mod.locator('input[placeholder^="مثال"]').fill('صيانة المعامل v5')
    al = mod.locator('.alloc-row', has_text='مطبوعات').locator('input'); al.fill('4000')
    check('no «save & approve» button without custody.approve', mod.locator('button', has_text='حفظ واعتماد').count() == 0)
    mod.locator('button', has_text=re.compile('حفظ')).last.click(); page.wait_for_timeout(1500)
    cv = q("select id, code, title, approval, holder from ebda.custodies where purpose='صيانة المعامل v5'")
    check('custody saved as draft with its name, holder and line allocation', cv and cv[0][2] == 'عهدة صيانة' and cv[0][3] == 'draft' and cv[0][4] and
          one('select count(*) from ebda.custody_lines where custody_id=%s', cv[0][0]) == 1, cv)
    cid, ccode = cv[0][0], cv[0][1]
    check('expense on a draft custody is refused', 'error' in api(C, 'addExpense', expense={'custody_id': cid, 'line_id': 'l_b1', 'amount': 10, 'date': '2026-10-01', 'description': 'x'}))
    tab(page, 'متابعة العهد')
    card = page.locator('.acc-list .acc', has_text=ccode); card.locator('.acc-head').click(); page.wait_for_timeout(300)
    body = card.inner_text()
    check('accordion shows basics / lines / expenses / summary sections', all(s in body for s in ['البيانات الأساسية', 'البنود', 'المصروفات', 'إجمالى العهدة', 'نسبة الاستخدام']), body[:300])
    check('accordion shows the holder name, not an id', 'أحمد' in body and 'custody1' not in body.split('مسئول العهدة')[1][:40], body[:300])
    card.locator('button', has_text='إرسال للمراجعة').click(); page.wait_for_timeout(1200)
    check('draft → review', one('select approval from ebda.custodies where id=%s', cid) == 'review')
    login(page, 'admin', '1234'); tab(page, 'متابعة العهد')
    card = page.locator('.acc-list .acc', has_text=ccode); card.locator('.acc-head').click(); page.wait_for_timeout(300)
    card.locator('button', has_text=re.compile('^اعتماد$')).click(); page.wait_for_timeout(1200)
    check('admin approves → approved (with approver)', q('select approval, approved_by from ebda.custodies where id=%s', cid)[0][0] == 'approved')
    r = api(F, 'updateCustody', id=cid, patch={'holder': 'شخص آخر'})
    check('after approval non-admin cannot edit basic data', 'error' in r or one('select holder from ebda.custodies where id=%s', cid) != 'شخص آخر', r)

    # ================================================================ 26) مصروف: سلسلة الموازنة ← البند ← العهدة ← المتبقى + الرصيد السالب
    login(page, 'custody1', '1111'); tab(page, 'العهد')
    page.locator('.big-action', has_text='إضافة مصروف').click(); page.wait_for_timeout(300)
    mod = page.locator('.modal')
    opts = mod.locator('select').nth(1).locator('option').all_inner_texts()
    mod.locator('select').nth(1).select_option(label=[o for o in opts if ccode in o][0]); page.wait_for_timeout(200)
    lines = mod.locator('select').nth(2).locator('option').all_inner_texts()
    check('expense lines limited to the custody allocation', any('مطبوعات' in x for x in lines) and not any('الزى' in x for x in lines), lines)
    mod.locator('select').nth(2).select_option(index=1); mod.locator('input[placeholder="0"]').fill('4500'); page.wait_for_timeout(200)
    ch = mod.locator('.chain').inner_text()
    check('chain panel: place ← line ← custody ← holder with remaining after the operation', 'مطبوعات' in ch and ccode in ch and '4,000' in ch and '-500' in ch, ch)
    mod.locator('input[placeholder="ماذا صُرف؟"]').fill('أدوات صيانة')
    mod.locator('input[type=date]').fill('2027-03-01'); mod.locator('button.primary').click(); page.wait_for_timeout(500)
    check('future date blocked', 'المستقبل' in mod.inner_text() and one("select count(*) from ebda.expenses where description='أدوات صيانة'") == 0)
    mod.locator('input[type=date]').fill('2026-10-01')
    mod.locator('button.primary').click(); page.wait_for_timeout(1500)
    check('expense over the line allocation is recorded (with warning) → negative remaining', one("select count(*) from ebda.expenses where description='أدوات صيانة'") == 1)
    tab(page, 'متابعة العهد')
    card = page.locator('.acc-list .acc', has_text=ccode); card.locator('.acc-head').click(); page.wait_for_timeout(300)
    lt = card.inner_text()
    check('per-line status inside the custody (allocated / spent / remaining / overrun)', '4,000' in lt and '4,500' in lt and 'متجاوز' in lt, lt[:500])

    # ================================================================ 2/5) فلاتر متعددة + الرصيد حسب الفلتر
    login(page, 'admin', '1234'); tab(page, 'متابعة العهد')
    page.select_option('[data-testid=tr-title]', 'عهدة صيانة'); page.wait_for_timeout(300)
    check('filter by custody name', page.locator('.acc-list .acc').count() == 1)
    page.select_option('[data-testid=tr-holder]', 'منى'); page.wait_for_timeout(300)
    check('combined filters (name + holder) narrow to nothing when no match', page.locator('.acc-list .acc').count() == 0)
    page.locator('button', has_text='مسح الفلاتر').click(); page.wait_for_timeout(300)
    page.select_option('[data-testid=tr-holder]', 'أحمد'); page.wait_for_timeout(300)
    rem = page.locator('[data-testid=tr-remaining]').inner_text().replace(',', '')
    exp = one("""select sum(t.amount) from ebda.tranches t join ebda.custodies c on c.id=t.custody_id where c.holder='أحمد' and c.status<>'cancelled'""") - \
          one("""select coalesce(sum(e.amount),0) from ebda.expenses e join ebda.custodies c on c.id=e.custody_id where c.holder='أحمد' and c.status<>'cancelled' and coalesce(e.approval,'')<>'rejected' and coalesce(e.fin_approval,'')<>'rejected'""")
    check('remaining by holder equals the database figure', abs(float(rem) - float(exp)) < 1, (rem, exp))
    page.select_option('[data-testid=tr-approval]', 'draft'); page.wait_for_timeout(300)
    check('approval-status filter', page.locator('.acc-list .acc').count() == 0)
    page.locator('button', has_text='مسح الفلاتر').click(); page.wait_for_timeout(300)
    check('clear filters restores all', page.locator('.acc-list .acc').count() == one('select count(*) from ebda.custodies'))

    # ================================================================ 9) إلغاء العهدة (أدمن فقط، بسبب، بلا حذف)
    check('non-admin cannot cancel a custody (API)', 'error' in api(F, 'cancelCustody', id='c_d1', reason='اختبار'))
    card = page.locator('.acc-list .acc', has_text=ccode); card.locator('.acc-head').click(); page.wait_for_timeout(300)
    card.locator('button', has_text='إلغاء العهدة').click(); page.wait_for_timeout(300)
    cm = page.locator('.modal').last
    check('cancel requires a reason', cm.locator('button', has_text='تأكيد الإلغاء').is_disabled())
    cm.locator('input').fill('تم إلغاء أعمال الصيانة'); cm.locator('button', has_text='تأكيد الإلغاء').click(); page.wait_for_timeout(1500)
    cc = q('select status, cancel_reason, cancelled_by from ebda.custodies where id=%s', cid)
    check('cancelled (status ملغاة) — row and expenses kept', cc[0][0] == 'cancelled' and cc[0][1] and one('select count(*) from ebda.expenses where custody_id=%s', cid) == 1, cc)
    check('no expense on a cancelled custody', 'error' in api(C, 'addExpense', expense={'custody_id': cid, 'line_id': 'l_b1', 'amount': 1, 'date': '2026-10-01', 'description': 'x'}))

    # ================================================================ 8) حذف الموازنة (أدمن، تأكيد، حذف منطقى، استرجاع)
    r = api(A, 'addSchool', school={'name': 'جهة اختبار حذف', 'category': 'school', 'period': '2026/2027', 'active': 'نعم'})
    tsid = (r.get('item') or {}).get('id') or one("select id from ebda.schools where name='جهة اختبار حذف'")
    for n_, a_ in [('بند 1', 1000), ('بند 2', 2500)]:
        api(A, 'addLine', line={'school_id': tsid, 'section': 'تشغيل', 'name': n_, 'allocated': a_})
    check('non-admin cannot delete a budget (API)', 'error' in api(F, 'deleteBudget', school_id=badr, reason='اختبار'))
    check('budget with expenses cannot be deleted', 'error' in api(A, 'deleteBudget', school_id=badr, reason='اختبار'))
    page.reload(); page.wait_for_selector('.tabs'); tab(page, 'الموازنات')
    page.locator('select', has=page.locator(f'option[value="{tsid}"]')).first.select_option(tsid); page.wait_for_timeout(400)
    page.locator('.big-action.danger', has_text='حذف الموازنة').click(); page.wait_for_timeout(300)
    dm = page.locator('.modal').last.inner_text()
    check('delete confirmation shows place / year / total', 'جهة اختبار حذف' in dm and '2026/2027' in dm and '3,500' in dm, dm[:300])
    page.locator('.modal').last.locator('input').fill('موازنة مكررة بالخطأ')
    page.locator('.modal').last.locator('button', has_text='حذف').last.click(); page.wait_for_timeout(1500)
    check('soft delete: rows kept with deleted_at + reason', one("select count(*) from ebda.lines where school_id=%s and deleted_at<>'' and delete_reason='موازنة مكررة بالخطأ'", tsid) == 2)
    check('deleted budget hidden from bootstrap', not [l for l in api(A, 'bootstrap')['lines'] if l['school_id'] == tsid])
    api(A, 'restoreBudget', school_id=tsid)
    check('restore brings it back without duplicates', one("select count(*) from ebda.lines where school_id=%s and coalesce(deleted_at,'')=''", tsid) == 2)

    # ================================================================ 13-21) الرواتب: استيراد بلا تكرار، شهرى، مؤثرات، 3 تقارير
    emp0 = one('select count(*) from ebda.employees')
    pre, k = import_payroll(page, F_BADR, '2026-09')
    check('Badr file: totals match the file before saving', 'مطابق لإجمالى الملف' in pre and '✗' not in pre, pre[:300])
    check('Badr import: 30 employees + 30 payslips', k[:2] == [30, 30], k)
    pre, k = import_payroll(page, F_DAM, '2026-09', empty_place=dam)
    check('Damietta file (no place in title) imported after choosing the place', k[:2] == [36, 36], k)
    pre, k = import_payroll(page, F_HQ, '2026-09')
    check('HQ salaries file → company entity', k[1] == 2 and one("select count(*) from ebda.payslips where school_id=%s and month='2026-09'", comp) == 2, k)
    pre, k = import_payroll(page, F_ACC, '2026-09')
    check('accounting file: matches existing employees (no new employees)', k[0] == 0, k)
    n_emp = one('select count(*) from ebda.employees')
    check('no duplicated employees after 4 files', n_emp - emp0 == 68 and one('select count(*) from (select school_id, national_key from ebda.employees where national_key<>\'\' group by 1,2 having count(*)>1) x') == 0, n_emp - emp0)
    pre, k = import_payroll(page, F_BADR, '2026-09')
    check('re-import same month: 0 new employees, 0 new payslips, 30 updated', k == [0, 0, 30], k)
    pre, k = import_payroll(page, F_BADR, '2026-10')
    check('next month: same employees, new payslips only', k == [0, 30, 0] and one('select count(*) from ebda.employees') == n_emp, k)
    check('payroll period per place and month', one("select count(*) from ebda.payroll_periods where month='2026-09'") == 3)
    tab(page, 'الرواتب'); page.fill('[data-testid=pay-month]', '2026-09'); page.wait_for_timeout(500)
    comp_html = report_html(page, 'الرواتب المرتبطة بالشركة')
    check('company salaries report: total to transfer = 620,976.15 (same data)', '620,976.15' in comp_html, re.findall(r'[\d,]+\.\d\d', comp_html)[-5:])
    total_db = float(one("select sum(net) from ebda.payslips where month='2026-09'"))
    check('report total = database total', abs(total_db - 620976.15) < 0.005, total_db)
    page.select_option('[data-testid=pay-place]', badr); page.wait_for_timeout(400)
    mon_html = report_html(page, 'التقرير الشهرى')
    check('monthly report like the Excel (attendance / absence / leave balance / net)', 'الحضور' in mon_html and 'رصيد' in mon_html and '217,934.48' in mon_html, mon_html[:200])
    # المؤثرات: مكافأة 500 على أول موظف
    first = page.locator('.panel', has_text='التعاقد').locator('tbody tr').first
    nm = first.locator('b').first.inner_text()
    net0 = float(one("select net from ebda.payslips where emp_name=%s and month='2026-09' and school_id=%s", nm, badr))
    first.locator('button', has_text='المؤثرات').click(); page.wait_for_timeout(300)
    am = page.locator('.modal').last
    am.locator('label', has_text='مكافأة').locator('input').fill('500')
    am.locator('button.primary').click(); page.wait_for_timeout(1500)
    net1 = float(one("select net from ebda.payslips where emp_name=%s and month='2026-09' and school_id=%s", nm, badr))
    check('adjustment (bonus 500) changes the net from the same record', abs(net1 - net0 - 500) < 0.005, (net0, net1))
    acc_html = report_html(page, 'تقرير الحسابات')
    check('accounting report generated from monthly data incl. adjustments', nm in acc_html and 'مكافأة' in acc_html and '500' in acc_html, acc_html[:200])
    comp_html2 = report_html(page, 'الرواتب المرتبطة بالشركة')
    check('company report follows the adjustment (621,476.15)', '621,476.15' in comp_html2)
    # اعتماد الشهر يمنع التعديل
    page.locator('tr', has_text='بدر').locator('button', has_text='اعتماد').first.click(); page.wait_for_timeout(1200)
    check('approved payroll month is locked', 'error' in api(A, 'importPayroll', school_id=badr, month='2026-09', rows=[{'name': nm, 'net': '1'}]))
    check('company / school / place cost totals from one dataset', abs(float(one("select sum(net) from ebda.payslips where month='2026-09' and school_id=%s", comp)) - 108750) < 0.005)

    # ================================================================ 22-25) لوحة المتابعة: تنبيهات وتحليلات من البيانات الفعلية
    # حالة تجاوز حقيقية: بند بمخصص 1,000 ومصروف 1,800 معتمد
    api(A, 'addLine', line={'school_id': dam, 'section': 'تشغيل', 'name': 'بند تنبيه تجاوز', 'allocated': 1000})
    lid = one("select id from ebda.lines where name='بند تنبيه تجاوز'")
    e = api(A, 'addExpense', expense={'custody_id': 'c_d1', 'line_id': lid, 'amount': 1800, 'date': '2026-10-02', 'description': 'تنبيه'})
    eid = (e.get('item') or {}).get('id')
    if eid:
        api(A, 'updateExpense', id=eid, patch={'approval': 'approved'}); api(A, 'reviewExpense', id=eid, patch={'fin_approval': 'approved'})
    page.reload(); page.wait_for_selector('.tabs'); tab(page, 'لوحة المتابعة')
    al = page.locator('[data-testid=alerts]').inner_text()
    check('alert: budget overrun with % from real data', 'بند تنبيه تجاوز' in al and '80%' in al and 'حرج' in al, al[:400])
    check('alert: custody overrun (cancelled custody excluded)', ccode not in al, al[:400])
    page.select_option('[data-testid=dash-place]', badr); page.wait_for_timeout(400)
    al2 = page.locator('[data-testid=alerts]').inner_text()
    check('place selector updates alerts', 'بند تنبيه تجاوز' not in al2, al2[:300])
    page.locator('[data-testid=ins-payroll]').click(); page.wait_for_timeout(300)
    pn = page.locator('[data-testid=ins-pay-net]').inner_text()
    bnet = float(one("select sum(net) from ebda.payslips where month='2026-10' and school_id=%s", badr))
    check('payroll insights per place = database (latest month)', abs(float(pn.replace(',', '')) - bnet) < 0.01, (pn, bnet))
    page.select_option('[data-testid=dash-place]', 'all'); page.wait_for_timeout(400)
    page.locator('[data-testid=ins-budget]').click(); page.wait_for_timeout(200)
    check('management insights: budgets tab lists the overrun line', 'بند تنبيه تجاوز' in page.locator('[data-testid=insights]').inner_text())
    login(page, 'sup1', '3333')
    check('direct manager has no payroll tab', 'الرواتب' not in tabs(page), tabs(page))
    if page.locator('[data-testid=insights]').count():
        check('scoped dashboard: no payroll insights for direct manager', page.locator('[data-testid=ins-payroll]').count() == 0)
        check('scoped dashboard: other places\' alerts hidden', 'بند تنبيه تجاوز' not in page.locator('[data-testid=alerts]').inner_text())

    # ================================================================ 27) تتبع التعديلات
    login(page, 'admin', '1234'); tab(page, 'تتبع التعديلات')
    at = page.locator('.content').inner_text()
    for lbl in ['إلغاء عهدة', 'اعتماد عهدة', 'إرسال عهدة للمراجعة', 'حذف موازنة', 'استرجاع موازنة محذوفة', 'استيراد كشف رواتب شهرى', 'تعديل مؤثرات راتب', 'اعتماد رواتب الشهر', 'تعديل مستخدم', 'تصدير تقرير']:
        check('audit trail lists: ' + lbl, lbl in at)
    check('audit trail shows the cancel / delete reason', 'تم إلغاء أعمال الصيانة' in at and 'موازنة مكررة بالخطأ' in at)
    check('payroll report exports are audited', one("select count(*) from ebda.audit_log where action='logExport' and details::text like '%%رواتب الشركة%%'") >= 1)
    check('permission change recorded with old/new value', one("select count(*) from ebda.audit_changes where tbl='users' and new_v::text like '%%-custody.approve%%'") >= 1)

    # ================================================================ عدم فقد البيانات
    api(A, 'updateUser', id=acc1_id, patch={'perms': ''})
    after = q('select id, username, pin, role, schools from ebda.users order by id')
    check('no users recreated, no passwords/ids changed', after == users_before)
    check('no page errors', not errs, errs[:3])
    b.close()
print(f'\n{fails} failures'); raise SystemExit(1 if fails else 0)
