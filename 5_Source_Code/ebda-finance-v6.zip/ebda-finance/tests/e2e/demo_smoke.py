import re,sys
from playwright.sync_api import sync_playwright
errs=[]
with sync_playwright() as pw:
    b=pw.chromium.launch(); p=b.new_page()
    p.on('pageerror', lambda e: errs.append(str(e)))
    p.goto('http://localhost:8766/index.html'); p.evaluate("localStorage.clear()"); p.goto('http://localhost:8766/index.html'); p.wait_for_selector('input')
    ins=p.locator('input'); ins.nth(0).fill('admin'); ins.nth(1).fill('1234')
    p.locator('button').filter(has_text=re.compile('دخول')).first.click(); p.wait_for_selector('.tabs',timeout=10000)
    tabs=p.locator('.tabs button').all_inner_texts()
    for t in tabs:
        p.locator('.tabs button').filter(has_text=t).first.click(); p.wait_for_timeout(300)
    b.close()
print('tabs:',tabs); print('demo page errors:', errs); sys.exit(1 if errs else 0)
