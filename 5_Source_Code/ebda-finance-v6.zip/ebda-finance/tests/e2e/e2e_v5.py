"""Browser E2E for v6 (migration 005). Runs against tests/e2e/server.py on :8765 after `bash ../reset.sh`.
Run from the folder that holds site/. Covers: expense workflow from the UI (link + draft → submit → direct-manager decision with
mandatory reason → finance review → settlement → admin cancel), assignment (only the linked manager), dynamic reports, admin
master data + backup/restore with typed confirmation, employee import wizard (merged headers), the one-click expense & custody file
import (auto-detection, exceptions, new custodies, budget/custody updates), permissions per role, mobile layout, no console errors."""
import json, re, os, urllib.request, psycopg2, pathlib
from playwright.sync_api import sync_playwright
HERE = pathlib.Path(__file__).resolve().parent
FIX = HERE.parent / 'fixtures'
BASE = 'http://localhost:8765/index.html'
SHOTS = HERE.parent.parent / 'docs' / 'screenshots'
SHOTS.mkdir(parents=True, exist_ok=True)
fails = 0
def check(n, c, d=''):
    global fails; print(('PASS ' if c else 'FAIL ') + n + ('' if c else f' -> {d}')); fails += (not c)
def login(page, u, p):
    page.goto(BASE); page.evaluate("localStorage.clear()"); page.goto(BASE); page.wait_for_selector('input')
    ins = page.locator('input'); ins.nth(0).fill(u); ins.nth(1).fill(p)
    page.locator('button').filter(has_text=re.compile('دخول')).first.click(); page.wait_for_selector('.tabs', timeout=15000); page.wait_for_timeout(400)
def tab(page, name): page.locator('.tabs button').filter(has_text=re.compile('^' + name + '$')).first.click(); page.wait_for_timeout(700)
def tabs(page): return page.locator('.tabs button').all_inner_texts()
def rpc(req):
    r = urllib.request.urlopen(urllib.request.Request('http://localhost:8765/rest/v1/rpc/api', data=json.dumps({'req': req}).encode(), method='POST'))
    return json.loads(r.read())
db = psycopg2.connect(host='/var/tmp/pg', port=5433, user='postgres', dbname='postgres'); db.autocommit = True; cur = db.cursor()
def q(sql, *a): cur.execute(sql, a or None); return cur.fetchall()
def one(sql, *a): return q(sql, *a)[0][0]
PINS = {'admin': '1234', 'acc1': '2222', 'custody1': '1111', 'sup1': '3333', 'custody2': '5555', 'sup2': '4444'}
def api(user, action, **kw):
    tok = rpc({'action': 'login', 'username': user, 'pin': PINS[user]})['token']
    return rpc(dict(action=action, auth={'token': tok}, **kw))
badr = one("select id from ebda.schools where name like '%%بدر%%'")
dam = one("select id from ebda.schools where name like '%%دمياط%%'")
counts_before = {t: one(f'select count(*) from ebda.{t}') for t in ['users', 'schools', 'lines', 'custodies', 'expenses', 'employees']}
# المدير المباشر لمسئول عهدة بدر = sup1
api('admin', 'updateUser', id='u_c1', patch={'manager_id': 'u_s1'})

errors = []
with sync_playwright() as p:
    br = p.chromium.launch()
    ctx = br.new_context(viewport={'width': 1360, 'height': 900}, accept_downloads=True)
    page = ctx.new_page()
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('dialog', lambda d: d.accept())
    # أخطاء تحميل موارد خارجية (خطوط Google) بسبب عزل بيئة الاختبار عن الإنترنت ليست أخطاء فى النظام
    page.on('console', lambda m: m.type == 'error' and 'favicon' not in m.text and 'net::ERR_' not in m.text and errors.append(m.text))

    # ------------------------------------------------------------ 1) مسئول العهدة: مصروف برابط مستند كمسودة ← إرسال
    login(page, 'custody1', '1111')
    check('custody officer: no import button, no admin tab', 'الإدارة' not in tabs(page))
    tab(page, 'المصروفات')
    check('custody officer cannot see the expense-file import', page.locator('[data-testid=expimp-btn]').count() == 0)
    tab(page, 'العهد')
    page.locator('.big-action', has_text='إضافة مصروف').click(); page.wait_for_timeout(500)
    m = page.locator('.modal')
    sels = m.locator('select')
    # اختيار العهدة والبند (أول اختيار صالح)
    for i in range(sels.count()):
        s = sels.nth(i)
        opts = s.locator('option').all()
        vals = [o.get_attribute('value') for o in opts]
        if s.input_value() == '' and len([v for v in vals if v]) > 0:
            s.select_option([v for v in vals if v][0]); page.wait_for_timeout(200)
    m.locator('input[placeholder="0"]').first.fill('321')
    m.locator('input[placeholder="ماذا صُرف؟"]').fill('اختبار متصفح v6')
    m.locator('[data-testid=doc-link]').fill('https://drive.example.com/inv-321')
    m.locator('[data-testid=save-draft]').click(); page.wait_for_timeout(1500)
    eid = one("select id from ebda.expenses where description='اختبار متصفح v6'")
    check('draft saved with document link (stage draft)', one("select ebda.expense_stage(e) from ebda.expenses e where id=%s", eid) == 'draft'
          and one("select doc_url from ebda.expenses where id=%s", eid) == 'https://drive.example.com/inv-321')
    tab(page, 'المصروفات')
    page.locator('[data-testid=ex-q]').fill('اختبار متصفح'); page.wait_for_timeout(1200)
    page.locator('button', has_text='إرسال للاعتماد').first.click(); page.wait_for_timeout(1200)
    check('submitted from the expenses list → pending direct manager', one("select ebda.expense_stage(e) from ebda.expenses e where id=%s", eid) == 'pending_manager')
    page.screenshot(path=str(SHOTS / 'v6_custody_expenses.png'))

    # ------------------------------------------------------------ 2) مدير مباشر غير مرتبط لا يرى زر الاعتماد؛ المرتبط يعتمد بملاحظة
    r = api('sup2', 'updateExpense', id=eid, patch={'approval': 'approved', 'note': 'x'})
    check('another (not assigned) manager refused by the API', 'error' in r, r)
    login(page, 'sup1', '3333')
    tab(page, 'المصروفات')
    page.locator('[data-testid=ex-q]').fill('اختبار متصفح'); page.wait_for_timeout(1200)
    page.locator('button', has_text='مراجعة واعتماد').first.click(); page.wait_for_timeout(500)
    rej = page.locator('.modal button', has_text='رفض').first
    check('reject disabled until a reason is written', rej.is_disabled())
    page.locator('[data-testid=decide-note]').fill('مطابق للفاتورة')
    page.locator('.modal button.primary').first.click(); page.wait_for_timeout(1200)
    check('assigned manager approved with note', one("select approval || '|' || approval_note || '|' || approved_by_id from ebda.expenses where id=%s", eid) == 'approved|مطابق للفاتورة|u_s1')

    # ------------------------------------------------------------ 3) المالية: اعتماد مالى ثم تسوية
    login(page, 'acc1', '2222')
    tab(page, 'المصروفات')
    check('finance sees the expense-file import button', page.locator('[data-testid=expimp-btn]').count() == 1)
    page.locator('[data-testid=ex-q]').fill('اختبار متصفح'); page.wait_for_timeout(1200)
    page.locator('button', has_text='اعتماد مالى').first.click(); page.wait_for_timeout(1500)
    check('finance review → reviewed', one("select ebda.expense_stage(e) from ebda.expenses e where id=%s", eid) == 'reviewed')
    r = api('acc1', 'reviewExpense', id=eid, patch={'settled': 'نعم'})
    check('settlement by finance', r.get('ok') and one("select ebda.expense_stage(e) from ebda.expenses e where id=%s", eid) == 'settled', r)
    # تفاصيل المصروف: مراحل الـ Workflow
    page.locator('[data-testid=ex-q]').fill(''); page.locator('[data-testid=ex-q]').fill('اختبار متصفح'); page.wait_for_timeout(1200)
    page.locator('.exp-row:not(.head)').first.click(); page.wait_for_timeout(800)
    body = page.locator('body').inner_text()
    check('detail shows workflow steps with who', 'مطابق للفاتورة' in body and ('خالد' in body or 'مدير مباشر' in body), body[:300])

    # ------------------------------------------------------------ 4) استيراد ملف المصروفات والعهد (بضغطة واحدة) — المالية: نطاق بدر
    tab(page, 'المصروفات')
    page.locator('[data-testid=expimp-btn]').click(); page.wait_for_selector('[data-testid=expimp-file]', state='attached', timeout=10000)
    page.locator('[data-testid=expimp-file]').set_input_files(str(FIX / 'مصاريف_مدرسة_ابدأ_نموذج.xlsx'))
    page.wait_for_selector('[data-testid=expimp-counts]', timeout=20000)
    kp = page.locator('[data-testid=expimp-counts]').inner_text()
    check('finance (Badr scope): analysis shown without any column mapping', 'جاهزة للاستيراد' in kp and page.locator('.modal select:not([data-testid=expimp-sheet-school])').count() == 0, kp)
    check('Damietta sheet (outside the finance scope) not assigned to Badr — listed as an unresolved sheet, not imported',
          page.locator('[data-testid=expimp-unresolved]').count() == 1 and 'مصروفات دمياط' in page.locator('[data-testid=expimp-unresolved]').inner_text())
    page.locator('.modal .modal-close, .modal button', has_text=re.compile('^(×|✕|إغلاق)$')).first.click() if page.locator('.modal button', has_text=re.compile('^(×|✕|إغلاق)$')).count() else page.keyboard.press('Escape')
    page.wait_for_timeout(400)

    # ------------------------------------------------------------ 5) الأدمن: الاستيراد الكامل
    login(page, 'admin', '1234')
    tab(page, 'المصروفات')
    page.locator('[data-testid=expimp-btn]').click(); page.wait_for_timeout(400)
    page.locator('[data-testid=expimp-file]').set_input_files(str(FIX / 'مصاريف_مدرسة_ابدأ_نموذج.xlsx'))
    page.wait_for_selector('[data-testid=expimp-counts]', timeout=20000)
    kp = page.locator('[data-testid=expimp-counts]').inner_text()
    nums = re.findall(r'\d[\d,]*', kp)
    check('admin preview: 14 rows · 8 ready · 22,550 · 2 new / 1 existing custody · 2 duplicates · 4 to review', nums[:7] == ['14', '8', '22,550', '2', '1', '2', '4'], nums)
    check('preview lists new custodies and budget impact', page.locator('[data-testid=expimp-custodies]').count() == 1 and page.locator('[data-testid=expimp-lines]').count() == 1)
    with page.expect_download() as dl:
        page.locator('[data-testid=expimp-exceptions]').click()
    check('exceptions report downloads as Excel', dl.value.suggested_filename.endswith('.xlsx'), dl.value.suggested_filename)
    page.screenshot(path=str(SHOTS / 'v6_expense_import_preview.png'))
    before = one("select count(*) from ebda.expenses")
    page.locator('[data-testid=expimp-commit]').click()
    page.wait_for_selector('[data-testid=expimp-done]', timeout=20000)
    check('one click imported 8 expenses', one("select count(*) from ebda.expenses") - before == 8)
    check('custodies D-1 and B-7 created automatically', one("select count(*) from ebda.custodies where ext_ref in ('D-1','B-7')") == 2)
    page.screenshot(path=str(SHOTS / 'v6_expense_import_done.png'))
    page.locator('[data-testid=expimp-close]').click(); page.wait_for_timeout(1500)
    page.locator('[data-testid=ex-q]').fill('مطبعة النور'); page.wait_for_timeout(1500)
    cnt = page.locator('[data-testid=ex-count] b').first.inner_text()
    check('imported expenses searchable by supplier (2 rows)', cnt.strip() == '2', cnt)
    tab(page, 'متابعة العهد')
    check('new custody visible in the custody tracker', 'منى مسئول عهدة دمياط' in page.locator('body').inner_text())

    # ------------------------------------------------------------ 6) الإلغاء بسبب (الأدمن)
    r = api('admin', 'cancelExpense', id=eid, reason='')
    check('cancel without reason refused', 'error' in r)

    # ------------------------------------------------------------ 7) التقارير الديناميكية
    tab(page, 'التقارير')
    page.locator('[data-testid=seg-dyn]').click(); page.wait_for_timeout(1500)
    txt = page.locator('body').inner_text()
    check('dynamic reports render with summary', page.locator('[data-testid=hr-summary], [data-testid=br-summary], [data-testid=fr-summary]').count() >= 1, txt[:200])
    page.screenshot(path=str(SHOTS / 'v6_dynamic_reports.png'))

    # ------------------------------------------------------------ 8) الإدارة: النسخ الاحتياطى + الاستعادة بتأكيد الاسم
    tab(page, 'الإدارة')
    adm = page.locator('body').inner_text()
    check('admin tabs: backups, activation, settings present', page.locator('[data-testid=adm-backups]').count() + page.locator('button', has_text='النسخ الاحتياطى').count() >= 1, adm[:200])
    if page.locator('button', has_text='النسخ الاحتياطى').count(): page.locator('button', has_text='النسخ الاحتياطى').first.click(); page.wait_for_timeout(600)
    n_bk = one("select count(*) from ebda.backups")
    page.locator('[data-testid=bk-create]').click(); page.wait_for_timeout(2500)
    check('backup created from the UI (named Backup_YYYY-MM-DD_HH-MM-SS)', one("select count(*) from ebda.backups") == n_bk + 1 and
          re.match(r'^Backup_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}$', one("select name from ebda.backups order by created_at desc limit 1")))
    page.locator('[data-testid=bk-restore]').first.click(); page.wait_for_timeout(500)
    go = page.locator('[data-testid=bk-go]')
    check('restore disabled until the backup name is typed', go.is_disabled())
    page.screenshot(path=str(SHOTS / 'v6_restore_confirm.png'))
    page.keyboard.press('Escape'); page.wait_for_timeout(300)

    # ------------------------------------------------------------ 9) الجوال
    mob = br.new_context(viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True)
    mp = mob.new_page()
    mp.on('pageerror', lambda e: errors.append(str(e)))
    login(mp, 'admin', '1234')
    tab(mp, 'المصروفات')
    sw = mp.evaluate('document.documentElement.scrollWidth'); cw = mp.evaluate('document.documentElement.clientWidth')
    check('mobile: expenses screen has no horizontal page scroll', sw <= cw + 2, (sw, cw))
    mp.locator('[data-testid=expimp-btn]').click(); mp.wait_for_timeout(400)
    mp.locator('[data-testid=expimp-file]').set_input_files(str(FIX / 'مصاريف_مدرسة_ابدأ_نموذج.xlsx'))
    mp.wait_for_selector('[data-testid=expimp-counts]', timeout=20000)
    mp.screenshot(path=str(SHOTS / 'v6_mobile_import.png'))
    check('mobile: re-upload of the same file → nothing new to import (duplicates)', 'استيراد 0 مصروف' in mp.locator('[data-testid=expimp-commit]').inner_text())
    mob.close()
    br.close()

check('no browser console errors', not errors, errors[:5])
after = {t: one(f'select count(*) from ebda.{t}') for t in counts_before}
check('no data lost (counts only grew)', all(after[t] >= counts_before[t] for t in counts_before), (counts_before, after))
print(f'\n{fails} failures'); raise SystemExit(1 if fails else 0)
