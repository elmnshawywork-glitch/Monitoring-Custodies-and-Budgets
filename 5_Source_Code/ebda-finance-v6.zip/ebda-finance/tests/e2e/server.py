import json, http.server, psycopg2, os
os.chdir(os.path.join(os.path.dirname(__file__), 'site'))
conn = psycopg2.connect(host='/var/tmp/pg', port=5433, user='postgres', dbname='postgres'); conn.autocommit = True
class H(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
    def _cors(self):
        self.send_header('Access-Control-Allow-Origin', '*'); self.send_header('Access-Control-Allow-Headers', '*'); self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
    def do_OPTIONS(self): self.send_response(204); self._cors(); self.end_headers()
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        if self.path.startswith('/functions/v1/'):
            return self.fn(self.path.rsplit('/',1)[-1], body)
        cur = conn.cursor(); cur.execute('set role anon'); cur.execute('select public.api(%s::jsonb)', (json.dumps(body['req']),)); r = cur.fetchone()[0]; cur.execute('reset role')
        out = json.dumps(r).encode(); self.send_response(200); self._cors(); self.send_header('Content-Type', 'application/json'); self.end_headers(); self.wfile.write(out)
def _rpc(req):
    cur = conn.cursor(); cur.execute('set role anon'); cur.execute('select public.api(%s::jsonb)', (json.dumps(req),)); r = cur.fetchone()[0]; cur.execute('reset role'); return r
FN_LOG = []
def fn(self, name, body):
    FN_LOG.append({'fn': name, **{k: v for k, v in body.items() if k != 'dataBase64'}})
    open('fn_log.json', 'w').write(json.dumps(FN_LOG, ensure_ascii=False))
    if name == 'notify':
        out = _rpc({'action': 'notifyInfo', 'event': body['event'], 'id': body['id'], 'auth': {'token': body['token']}})
    elif body.get('action') == 'upload':
        a = _rpc({'action': 'docAuth', 'expense_id': body['expense_id'], 'mode': 'upload', 'auth': {'token': body['token']}})
        out = a if 'error' in a else _rpc({'action': 'uploadDoc', 'id': body['expense_id'], 'link': 'storage:' + a['path'] + body.get('filename', 'f'), 'filename': body.get('filename'), 'doc_type': body.get('doc_type', ''), 'auth': {'token': body['token']}})
    else:
        a = _rpc({'action': 'docAuth', 'expense_id': body['expense_id'], 'mode': 'read', 'auth': {'token': body['token']}})
        out = a if 'error' in a else {'ok': True, 'url': 'http://localhost:8765/index.html?signed=' + a['current']}
    data = json.dumps(out).encode(); self.send_response(200 if 'error' not in out else 400); self._cors(); self.send_header('Content-Type', 'application/json'); self.end_headers(); self.wfile.write(data)
H.fn = fn
http.server.ThreadingHTTPServer(('127.0.0.1', 8765), H).serve_forever()
