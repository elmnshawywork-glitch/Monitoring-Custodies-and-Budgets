import json, sys, re
from playwright.sync_api import sync_playwright
BASE='http://localhost:8765/index.html'
errs=[]; fails=0
def check(n,c,d=''):
    global fails
    print(('PASS ' if c else 'FAIL ')+n+('' if c else f' -> {d}')); fails+= (not c)
def login(page,u,p):
    page.goto(BASE); page.evaluate("localStorage.clear()"); page.goto(BASE)
    page.wait_for_selector('input')
    ins=page.locator('input'); ins.nth(0).fill(u); ins.nth(1).fill(p)
    page.locator('button').filter(has_text=re.compile('دخول')).first.click()
    page.wait_for_selector('.tabs', timeout=15000)
def tab(page,name):
    page.locator('.tabs button').filter(has_text=name).first.click(); page.wait_for_timeout(500)
with sync_playwright() as pw:
    b=pw.chromium.launch()
    page=b.new_page(viewport={'width':1280,'height':900})
    page.on('console', lambda m: m.type=='error' and errs.append(m.text))
    page.on('pageerror', lambda e: errs.append(str(e)))
    page.on('dialog', lambda d: d.accept('مستند غير واضح') if d.type=='prompt' else d.accept())
    # --- custody officer
    login(page,'custody1','1111')
    top=page.locator('.user-box').inner_text()
    check('custody header shows new role label', 'مسئول العهدة' in top, top)
    tab(page,'العهد')
    body=page.locator('.content').inner_text()
    check('custody sees CUST-001 code', 'CUST-001' in body, body[:300])
    check('custody does not see damietta custody', 'CUST-002' not in body)
    page.locator('.cust-head').first.click(); page.wait_for_timeout(300)
    check('custody sees submit-for-settlement button', page.locator('button', has_text='تقديم للتسوية').count()==1)
    check('custody has no delete-custody button', page.locator('button', has_text='حذف العهدة').count()==0)
    page.screenshot(path='shot_custody.png', full_page=True)
    # --- direct manager approves e1 via UI modal
    login(page,'sup1','3333')
    check('direct manager label', 'المدير المباشر' in page.locator('.user-box').inner_text())
    tab(page,'المصروفات')
    n_btn=page.locator('button', has_text='مراجعة واعتماد').count()
    check('sup1 sees approve button only for in-scope pending (e1 only)', n_btn==1, n_btn)
    # --- finance manager
    login(page,'acc1','2222')
    check('finance label', 'المدير المالى' in page.locator('.user-box').inner_text())
    tab(page,'المصروفات')
    txt=page.locator('.content').inner_text()
    check('expense card shows txn number', 'EXP-0000' in txt)
    check('approved expense shows awaiting financial approval chip', 'بانتظار الاعتماد المالى' in txt)
    fb=page.locator('button', has_text='اعتماد مالى')
    check('finance sees financial-approve button', fb.count()>=1, fb.count())
    fb.first.click(); page.wait_for_timeout(1500)
    txt2=page.locator('.content').inner_text()
    check('after click: chip معتمد مالياً shown', 'معتمد مالياً' in txt2)
    page.screenshot(path='shot_finance_expenses.png', full_page=True)
    tab(page,'العهد'); page.locator('.cust-head').first.click(); page.wait_for_timeout(300)
    check('finance sees settle custody button', page.locator('button', has_text='اعتماد التسوية').count()==1)
    check('finance has no delete custody button', page.locator('button', has_text='حذف العهدة').count()==0)
    tab(page,'طلبات العهد')
    t=page.locator('.content').inner_text()
    check('request status label new wording', 'المدير المباشر' in t, t[:200])
    # --- admin: edit a user without retyping pin
    login(page,'admin','1234')
    check('admin label', 'الأدمن' in page.locator('.user-box').inner_text())
    tab(page,'الإدارة')
    page.wait_for_timeout(400)
    page.locator('button', has_text='المستخدمون').first.click(); page.wait_for_timeout(500)
    row=page.locator('tr', has_text='custody1').first
    row.locator('button').first.click(); page.wait_for_timeout(400)
    modal=page.locator('.modal').first
    modal.locator('input').first.fill('أحمد (تم التعديل)')
    modal.locator('button', has_text='حفظ').first.click(); page.wait_for_timeout(1500)
    page.screenshot(path='shot_admin.png', full_page=True)
    adm=page.locator('.content').inner_text()
    check('users table shows new role names', 'المدير المالى' in adm and 'المدير المباشر' in adm, adm[:400])
    check('edited user saved without retyping pin', 'أحمد (تم التعديل)' in page.locator('.content').inner_text())
    b.close()
print('console errors:', errs[:5])
real=[e for e in errs if 'ERR_TUNNEL_CONNECTION_FAILED' not in e and 'favicon' not in e]
check('no console/page errors (ignoring blocked google fonts)', not real, real[:3])
sys.exit(1 if fails else 0)
