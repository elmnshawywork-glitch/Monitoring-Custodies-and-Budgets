import json, re, sys
from playwright.sync_api import sync_playwright
import datetime
_m = datetime.date.today().month; FM = ((_m + 3) % 12) + 1
MN = ['سبتمبر','أكتوبر','نوفمبر','ديسمبر','يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس'][FM - 1]
BASE = 'http://localhost:8765/index.html'; EDGE = 'http://localhost:8765/../site_edge/index.html'
fails = 0
def check(n, c, d=''):
    global fails; print(('PASS ' if c else 'FAIL ') + n + ('' if c else f' -> {d}')); fails += (not c)
def login(page, u, p, base=BASE):
    page.goto(base); page.evaluate("localStorage.clear()"); page.goto(base); page.wait_for_selector('input')
    ins = page.locator('input'); ins.nth(0).fill(u); ins.nth(1).fill(p)
    page.locator('button').filter(has_text=re.compile('دخول')).first.click(); page.wait_for_selector('.tabs', timeout=15000)
def tab(page, name): page.locator('.tabs button').filter(has_text=name).first.click(); page.wait_for_timeout(500)
def tabs(page): return page.locator('.tabs button').all_inner_texts()
with sync_playwright() as pw:
    b = pw.chromium.launch(); page = b.new_page(viewport={'width': 1300, 'height': 950})
    errs = []; page.on('pageerror', lambda e: errs.append(str(e)))
    page.on('dialog', lambda d: d.accept())
    # ---------------- custody officer
    login(page, 'custody1', '1111')
    sess = json.loads(page.evaluate("localStorage.getItem('ebda_session')"))
    check('session stores token, not the PIN', len(sess.get('token', '')) == 64 and 'pin' not in sess, sess.keys())
    txt = page.locator('.content').inner_text()
    check('custody dashboard: balance + action cards', 'رصيد العهدة المتاح' in txt and 'تحتاج رفع مستند' in txt and 'عُهدى' in txt, txt[:200])
    check('custody has no budget-monitoring tab', 'متابعة الموازنة' not in tabs(page), tabs(page))
    page.screenshot(path='v2_custody_dash.png', full_page=True)
    tab(page, 'العهد'); page.locator('.cust-head').first.click(); page.wait_for_timeout(300)
    qr = page.locator('.quick-row').first
    qr.locator('input[type=number]').fill('40000'); page.wait_for_timeout(1200)
    wb = page.locator('.warn-banner.over')
    check('live over-budget warning shown (no numbers for custody)', wb.count() == 1 and 'ج.م' not in wb.inner_text(), wb.count())
    qr.locator('input[placeholder="ماذا صُرف؟"]').fill('شراء كبير')
    qr.locator('button', has_text='صرف').last.click(); page.wait_for_timeout(1500)
    t = page.locator('.toast').inner_text() if page.locator('.toast').count() else ''
    check('server warning toast after saving over-budget expense', page.locator('.toast.warn').count() == 1 and 'تجاوز' in t, t)
    page.screenshot(path='v2_custody_warn.png')
    token = sess['token']
    page.locator('button', has_text='خروج').click(); page.wait_for_timeout(800)
    r = page.evaluate("""async (tok) => (await fetch('/rest/v1/rpc/api',{method:'POST',body:JSON.stringify({req:{action:'bootstrap',auth:{token:tok}}})})).json()""", token)
    check('logout invalidates the token on the server', 'error' in r, r)
    # ---------------- direct manager
    login(page, 'sup1', '3333')
    txt = page.locator('.content').inner_text()
    check('direct manager dashboard: approvals required', 'المطلوب منك' in txt and 'مصروفات بانتظار اعتمادك' in txt and '1 جهة' in txt, txt[:200])
    check('direct manager sees budget monitoring tab', 'متابعة الموازنة' in tabs(page))
    tab(page, 'متابعة الموازنة')
    mt = page.locator('.content').inner_text()
    check('monthly screen scoped to badr only', 'دمياط' not in mt and 'بدر' in mt, mt[:300])
    # ---------------- make a real deficit: approve + fin-approve the big expense through the API
    def rpc(req): return page.evaluate("async (r) => (await fetch('/rest/v1/rpc/api',{method:'POST',body:JSON.stringify({req:r})})).json()", req)
    big = [e for e in rpc({'action':'bootstrap','auth':{'username':'admin','pin':'1234'}})['expenses'] if e['amount'] == 40000][0]['id']
    rpc({'action':'updateExpense','id':big,'patch':{'approval':'approved'},'auth':{'username':'sup1','pin':'3333'}})
    rpc({'action':'reviewExpense','id':big,'patch':{'fin_approval':'approved'},'auth':{'username':'acc1','pin':'2222'}})
    # ---------------- finance
    login(page, 'acc1', '2222')
    txt = page.locator('.content').inner_text()
    check('finance dashboard action cards', 'مصروفات بانتظار الاعتماد المالى' in txt and 'عهد مقدّمة للتسوية' in txt, txt[:200])
    page.locator('.action-card', has_text='مصروفات بانتظار الاعتماد المالى').click(); page.wait_for_timeout(600)
    sel = page.locator('.content select').nth(2).input_value() if page.locator('.content select').count() >= 3 else ''
    check('dashboard card opens expenses filtered on financial approval', 'المصروفات' in page.locator('.tab.active').inner_text() and page.locator('select >> nth=3').count() >= 0 and page.locator('option[value="fin"]:checked').count() == 1)
    page.screenshot(path='v2_finance_dash.png', full_page=True)
    tab(page, 'متابعة الموازنة')
    page.locator('.filters select').nth(1).select_option(str(FM)); page.wait_for_timeout(400)
    mt = page.locator('.content').inner_text()
    check('monthly screen (current FY month) shows month columns, month diff and yearly status', ('مصروف ' + MN) in mt and 'الفرق الشهرى' in mt and 'السنة (مصروف / مخصص)' in mt and 'الإجمالى' in mt, mt[:300])
    page.locator('.check input').check(); page.wait_for_timeout(300)
    rows = page.locator('tbody tr').count(); body = page.locator('tbody').inner_text()
    check('over-only filter shows the over-budget line with its status', rows == 2 and 'مطبوعات' in body and 'تجاوز المخصص' in body, (rows, body[:200]))
    page.screenshot(path='v2_monthly.png', full_page=True)
    # ---------------- admin
    login(page, 'admin', '1234')
    txt = page.locator('.content').inner_text()
    check('admin dashboard: KPIs + charts, no audit log on the dashboard', 'إجمالى الموازنة' in txt and 'عهد مفتوحة' in txt and 'طلبات عهد معلّقة' in txt and 'آخر العمليات' not in txt and page.locator('.ch-svg').count() >= 2, txt[:300])
    page.screenshot(path='v2_admin_dash.png', full_page=True)
    # ---------------- Edge functions wiring (docs + notify)
    login(page, 'custody1', '1111', 'http://localhost:8765/site_edge/index.html')
    tab(page, 'المصروفات')
    up = page.locator('button').filter(has_text=re.compile('رفع مستند|تغيير المستند'))
    check('approved expense offers upload', up.count() >= 1, up.count())
    up.first.click(); page.wait_for_timeout(300)
    page.locator('.modal input[type=file]').set_input_files({'name':'test.pdf','mimeType':'application/pdf','buffer':b'%PDF-1.4 test'})
    page.locator('.modal button.primary').last.click(); page.wait_for_timeout(1500)
    log = json.load(open('site/fn_log.json'))
    check('upload went through docs Edge Function (not base64 into DB)', any(x['fn'] == 'docs' and x.get('action') == 'upload' for x in log), log[-1:])
    link = page.locator('a.chip.navy').first
    check('expense shows document chip', link.count() == 1)
    with page.expect_popup() as pop:
        link.click()
    np = pop.value; np.wait_for_url(re.compile('signed='), timeout=5000)
    check('document opens through signed URL', 'signed=' in np.url, np.url); np.close()
    tab(page, 'العهد'); page.locator('.cust-head').first.click(); page.wait_for_timeout(300)
    qr = page.locator('.quick-row').first
    qr.locator('input[type=number]').fill('10'); qr.locator('input[placeholder="ماذا صُرف؟"]').fill('notify test')
    qr.locator('button', has_text='صرف').last.click(); page.wait_for_timeout(1500)
    log = json.load(open('site/fn_log.json'))
    check('new expense triggers notify(expense_new)', any(x['fn'] == 'notify' and x.get('event') == 'expense_new' for x in log), [x for x in log if x['fn'] == 'notify'])
    # mobile layout smoke
    m = b.new_page(viewport={'width': 390, 'height': 844}); m.on('pageerror', lambda e: errs.append(str(e)))
    login(m, 'acc1', '2222'); m.screenshot(path='v2_mobile.png', full_page=True)
    sw = m.evaluate("document.documentElement.scrollWidth"); check('mobile: no horizontal page scroll', sw <= 392, sw)
    b.close()
check('no page errors', not errs, errs[:3])
print(f'\n{fails} failures'); sys.exit(1 if fails else 0)
