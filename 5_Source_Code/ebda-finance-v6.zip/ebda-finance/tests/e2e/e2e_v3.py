"""Browser E2E for v3 (migration 003 + new screens). Runs against tests/e2e/server.py on :8765 after `bash ../reset.sh`.
Covers: Excel import (preview/compare/confirm/no duplicates on re-import), manual budget line (with monthly plan, duplicate
blocked), custody + expense forms, month vs year logic (Sep/Oct example), dashboard per place / all, tracker filters,
reports + export logging, permissions, audit trail old/new values, no data loss."""
import json, re, sys, os, urllib.request, psycopg2
from playwright.sync_api import sync_playwright
XL = os.environ.get('EBDA_XL', '/root/.claude/uploads/45c3a104-fa98-572c-a7c6-267860b8fb8a/be934041-_______________________________________.xlsx')
BASE = 'http://localhost:8765/index.html'
fails = 0
def check(n, c, d=''):
    global fails; print(('PASS ' if c else 'FAIL ') + n + ('' if c else f' -> {d}')); fails += (not c)
def login(page, u, p):
    page.goto(BASE); page.evaluate("localStorage.clear()"); page.goto(BASE); page.wait_for_selector('input')
    ins = page.locator('input'); ins.nth(0).fill(u); ins.nth(1).fill(p)
    page.locator('button').filter(has_text=re.compile('دخول')).first.click(); page.wait_for_selector('.tabs', timeout=15000); page.wait_for_timeout(400)
def tab(page, name): page.locator('.tabs button').filter(has_text=re.compile('^' + name + '$')).first.click(); page.wait_for_timeout(500)
def tabs(page): return page.locator('.tabs button').all_inner_texts()
def rpc(req):
    r = urllib.request.urlopen(urllib.request.Request('http://localhost:8765/rest/v1/rpc/api', data=json.dumps({'req': req}).encode(), method='POST'))
    return json.loads(r.read())
def api(tok, action, **kw): return rpc(dict(action=action, auth={'token': tok}, **kw))
db = psycopg2.connect(host='/var/tmp/pg', port=5433, user='postgres', dbname='postgres'); db.autocommit = True; cur = db.cursor()
def q(sql, *a): cur.execute(sql, a or None); return cur.fetchall()
before = {t: q(f'select count(*) from ebda.{t}')[0][0] for t in ['users', 'schools', 'lines', 'custodies', 'tranches', 'expenses', 'requests']}
badr = q("select id from ebda.schools where name like '%%بدر%%'")[0][0]

with sync_playwright() as pw:
    b = pw.chromium.launch(); page = b.new_page(viewport={'width': 1360, 'height': 950}, accept_downloads=True)
    errs = []; page.on('pageerror', lambda e: errs.append(str(e))); page.on('dialog', lambda d: d.accept())

    # ================================================================ 1-3 استيراد Excel مع المعاينة والمقارنة
    login(page, 'acc1', '2222')
    tab(page, 'الموازنات')
    page.locator('.big-action', has_text='استيراد موازنة').click(); page.wait_for_timeout(300)
    page.locator('.modal input[type=file]').set_input_files(XL); page.wait_for_timeout(2500)
    m = page.locator('.modal').inner_text()
    check('import reads all sheets and auto-maps budget sheets to places', 'موازنة_بدر' in m and 'موازنة_دمياط' in m and page.locator('.sheet-row input[type=checkbox]:checked').count() == 2, m[:300])
    # المدير المالى acc1 نطاقه بدر فقط: شيت دمياط لا يجد جهته ضمن القائمة → يُلغى تفعيله
    dam_row = page.locator('.sheet-row', has_text='موازنة_دمياط')
    if dam_row.locator('select').count() and dam_row.locator('select').input_value() == '':
        dam_row.locator('input[type=checkbox]').uncheck(); page.wait_for_timeout(400)
    m = page.locator('.modal').inner_text()
    kp = {k: int(v) for v, k in re.findall(r'(\d+)\n(جديد|مبلغ مختلف|اسم مشابه|مطابق|مكرر|أخطاء)', m)}
    check('preview shows counts (new / changed / same / duplicates / errors) before saving', kp.get('جديد', 0) > 30 and 'مطابق' in kp and 'أخطاء' in kp, kp)
    check('preview compares with existing lines (current vs file amount)', 'المبلغ الحالى' in m and 'المبلغ فى الملف' in m and 'لن يُحذف' in m or 'بدون حذف' in m, m[-300:])
    n_lines = q('select count(*) from ebda.lines')[0][0]
    check('nothing saved before confirmation', n_lines == before['lines'])
    page.locator('.modal button.primary', has_text='تأكيد الاستيراد').click(); page.wait_for_timeout(2500)
    m = page.locator('.modal').inner_text()
    check('import summary shown after confirmation', 'تم الاستيراد بنجاح' in m and 'بنود جديدة' in m, m[:200])
    page.locator('.modal button.primary', has_text='تم').click(); page.wait_for_timeout(1200)
    added = q('select count(*) from ebda.lines')[0][0] - before['lines']
    check('import added lines without deleting any', added >= 30 and q("select count(*) from ebda.lines where id in ('l_b1','l_b2','l_d1')")[0][0] == 3, added)
    check('existing line kept its id + expenses (no data loss)', q("select count(*) from ebda.expenses where line_id in ('l_b1','l_b2')")[0][0] >= 3)
    check('Excel totals land in the system (Badr = 8,452,445)', round(float(q('select sum(allocated) from ebda.lines where school_id=%s', badr)[0][0])) >= 8452445, q('select sum(allocated) from ebda.lines where school_id=%s', badr))
    # إعادة استيراد نفس الملف = لا تكرار
    page.locator('.big-action', has_text='استيراد موازنة').click(); page.wait_for_timeout(300)
    page.locator('.modal input[type=file]').set_input_files(XL); page.wait_for_timeout(2500)
    dam_row = page.locator('.sheet-row', has_text='موازنة_دمياط')
    if dam_row.locator('select').count() and dam_row.locator('select').input_value() == '':
        dam_row.locator('input[type=checkbox]').uncheck(); page.wait_for_timeout(400)
    m = page.locator('.modal').inner_text()
    kp2 = {k: int(v) for v, k in re.findall(r'(\d+)\n(جديد|مبلغ مختلف|اسم مشابه|مطابق|مكرر|أخطاء)', m)}
    check('re-importing the same file finds no new lines (duplicate detection)', kp2.get('جديد', -1) == 0 and kp2.get('مطابق', 0) >= 30, kp2)
    check('confirm disabled when nothing to change', page.locator('.modal button.primary', has_text='تأكيد الاستيراد').is_disabled())
    page.locator('.modal .close').click(); page.wait_for_timeout(300)
    check('lines count unchanged after cancelled re-import', q('select count(*) from ebda.lines')[0][0] - before['lines'] == added)

    # ================================================================ 2 + 8 إضافة موازنة يدوياً بتوزيع شهرى (مثال سبتمبر/أكتوبر)
    page.locator('.big-action', has_text='إضافة موازنة يدوياً').click(); page.wait_for_timeout(300)
    mod = page.locator('.modal')
    mod.locator('input[list=sec-list]').fill('تشغيل'); mod.locator('input[placeholder="اسم البند"]').fill('مطبوعات'); page.wait_for_timeout(300)
    check('manual add blocks a duplicate line', 'موجود بالفعل' in mod.inner_text() and mod.locator('button.primary').is_disabled())
    mod.locator('input[placeholder="اسم البند"]').fill('بند اختبار شهرى'); mod.locator('input[placeholder="0"]').first.fill('200000')
    mod.locator('select').nth(1).select_option('custom'); page.wait_for_timeout(200)
    plan = mod.locator('.plan-grid input')
    for i in range(12): plan.nth(i).fill('100000' if i in (0, 1) else '0')
    mod.locator('button.primary').click(); page.wait_for_timeout(1200)
    ln = q("select id, allocated, monthly_plan from ebda.lines where name='بند اختبار شهرى'")
    check('manual line saved with its monthly plan', ln and float(ln[0][1]) == 200000 and json.loads(ln[0][2])[0] == 100000, ln)
    lid = ln[0][0]

    # مصروفات سبتمبر 80,000 وأكتوبر 120,000 (معتمدة ومعتمدة مالياً)
    C = rpc({'action': 'login', 'username': 'custody1', 'pin': '1111'})['token']
    S = rpc({'action': 'login', 'username': 'sup1', 'pin': '3333'})['token']
    F = rpc({'action': 'login', 'username': 'acc1', 'pin': '2222'})['token']
    for d, amt in [('2026-09-15', 80000), ('2026-10-01', 120000)]:
        e = api(C, 'addExpense', expense={'custody_id': 'c_b1', 'line_id': lid, 'amount': amt, 'date': d, 'description': 'اختبار ' + d})['item']['id']
        api(S, 'updateExpense', id=e, patch={'approval': 'approved'}); api(F, 'reviewExpense', id=e, patch={'fin_approval': 'approved'})

    # ================================================================ 9-11 الشهر مقابل السنة
    page.reload(); page.wait_for_selector('.tabs'); tab(page, 'متابعة الموازنة')
    flt = page.locator('.filters').first
    flt.locator('input[placeholder="بحث باسم البند"]').fill('بند اختبار شهرى'); page.wait_for_timeout(300)
    def row_text(): return page.locator('tbody tr').first.inner_text()
    flt.locator('select').nth(1).select_option('2'); page.wait_for_timeout(300)   # أكتوبر
    t = row_text()
    check('October: month alloc 100,000 / spent 120,000 / diff -20,000 / over', '100,000' in t and '120,000' in t and '-20,000' in t and 'تجاوز المخصص' in t, t)
    flt.locator('select').nth(1).select_option('1'); page.wait_for_timeout(300)   # سبتمبر
    t = row_text()
    check('September: diff +20,000 within allocation', '80,000' in t and '20,000' in t and 'داخل المخصص' in t, t)
    flt.locator('select').nth(1).select_option('all'); page.wait_for_timeout(300)
    t = row_text()
    check('Full year: alloc 200,000 = spent 200,000, diff 0, not over', '200,000' in t and 'تجاوز' not in t and 'وصل للمخصص' in t, t)
    page.locator('.check input').check(); page.wait_for_timeout(300)
    check('year "over only" filter excludes it (October overrun is not an annual overrun)', 'بند اختبار شهرى' not in page.locator('tbody').inner_text())

    # ================================================================ 12-13 لوحة المتابعة
    tab(page, 'لوحة المتابعة')
    page.select_option('[data-testid=dash-month]', '2'); page.wait_for_timeout(400)
    txt = page.locator('.content').inner_text()
    check('dashboard (all places) has KPIs + charts + places ranking', 'كل الأماكن' in txt and 'الأماكن حسب الصرف' in txt and page.locator('.ch-svg').count() >= 2, txt[:200])
    check('dashboard month mode lists the October overrun', 'بند اختبار شهرى' in page.locator('.panel', has_text='بنود تجاوزت المخصص').inner_text())
    page.select_option('[data-testid=dash-place]', badr); page.wait_for_timeout(400)
    txt2 = page.locator('.exec-title').inner_text()
    check('dashboard per place updates title and hides the places ranking', 'بدر' in txt2 and 'الأماكن حسب الصرف' not in page.locator('.content').inner_text(), txt2)
    page.select_option('[data-testid=dash-month]', 'all'); page.wait_for_timeout(300)
    check('year mode: October overrun not listed as annual overrun', 'بند اختبار شهرى' not in page.locator('.panel', has_text='بنود تجاوزت المخصص').inner_text())
    check('audit trail is not on the dashboard', 'تتبع التعديلات' not in page.locator('.content').inner_text())

    # ================================================================ 4-7 إضافة عهدة + مصروف + الربط + المتبقى
    tab(page, 'العهد')
    page.locator('.big-action', has_text='إضافة عهدة').click(); page.wait_for_timeout(300)
    mod = page.locator('.modal')
    mod.locator('select').nth(3).select_option('u:custody1'); mod.locator('input[placeholder="0"]').first.fill('5000')
    mod.locator('input[placeholder^="مثال"]').fill('رحلة ميدانية'); mod.locator('button.primary').last.click(); page.wait_for_timeout(1500)
    nc = q("select id, code, kind, purpose from ebda.custodies where purpose='رحلة ميدانية'")
    check('add custody form: one step with base amount, type and purpose', nc and q('select sum(amount) from ebda.tranches where custody_id=%s', nc[0][0])[0][0] == 5000 and nc[0][2], nc)
    cid, ccode = nc[0][0], nc[0][1]
    login(page, 'custody1', '1111'); tab(page, 'العهد')
    page.locator('.big-action', has_text='إضافة مصروف').click(); page.wait_for_timeout(300)
    mod = page.locator('.modal')
    opts = mod.locator('select').nth(1).locator('option').all_inner_texts()
    mod.locator('select').nth(1).select_option(label=[o for o in opts if ccode in o][0]); page.wait_for_timeout(200)
    mod.locator('select').nth(2).select_option(index=1); mod.locator('input[placeholder="0"]').fill('1200')
    mod.locator('input[placeholder="ماذا صُرف؟"]').fill('أتوبيس الرحلة'); mod.locator('select').nth(3).select_option('تحويل بنكى')
    mod.locator('input[type=file]').set_input_files({'name': 'فاتورة.pdf', 'mimeType': 'application/pdf', 'buffer': b'%PDF-1.4 test'})
    calc = mod.locator('.cust-calc').inner_text()
    check('expense form computes custody remaining + usage live', '5,000' in calc and '3,800' in calc and '24%' in calc, calc)
    mod.locator('button.primary').click(); page.wait_for_timeout(1800)
    ex = q("select custody_id, pay_method, doc_name, school_id from ebda.expenses where description='أتوبيس الرحلة'")
    check('expense saved, linked to custody, with payment method and attachment', ex and ex[0][0] == cid and ex[0][1] == 'تحويل بنكى' and ex[0][2] == 'فاتورة.pdf', ex)
    check('custody officer has no budget tabs / import', 'الموازنات' not in tabs(page) and 'متابعة الموازنة' not in tabs(page) and 'تتبع التعديلات' not in tabs(page), tabs(page))
    tab(page, 'متابعة العهد')
    rows = page.locator('.acc-list .acc')
    check('custody officer tracker shows only own custodies', rows.count() == q("select count(*) from ebda.custodies where \"user\"='custody1'")[0][0], rows.count())
    r = page.locator('.acc-list .acc', has_text=ccode)
    check('tracker: value / spent / remaining for the new custody', '5,000' in r.inner_text() and '1,200' in r.inner_text() and '3,800' in r.inner_text(), r.inner_text())
    r.locator('.acc-head').click(); page.wait_for_timeout(300)
    check('tracker: custody operations listed (tranche + expense + pay method)', 'أتوبيس الرحلة' in r.locator('.acc-body').inner_text() and 'دفعة عهدة' in r.locator('.acc-body').inner_text() and 'تحويل بنكى' in r.locator('.acc-body').inner_text())

    # ================================================================ 14 الفلاتر  (الأدمن)
    login(page, 'admin', '1234'); tab(page, 'متابعة العهد')
    page.select_option('[data-testid=tr-holder]', 'منى'); page.wait_for_timeout(300)
    body = page.locator('.acc-list').inner_text()
    check('tracker holder filter shows only that holder', 'منى' in body and 'أحمد' not in body, body[:200])
    page.locator('button', has_text='مسح الفلاتر').click(); page.wait_for_timeout(200)
    check('clear filters shows all custodies', page.locator('.acc-list .acc').count() == q('select count(*) from ebda.custodies')[0][0])

    # ================================================================ 15-16 التقارير والتصدير
    tab(page, 'التقارير')
    page.locator('.rep-card', has_text='تقرير الموازنة').click()
    page.locator('.panel .filters select').nth(2).select_option('month'); page.wait_for_timeout(300)
    rt = page.locator('.panel .tbl').inner_text()
    check('budget report by month with cumulative columns + annual total', 'فبراير' in rt and 'المخصص التراكمى' in rt and 'الإجمالى السنوى' in rt, rt[:200])
    with page.expect_download() as dl:
        page.locator('.panel button.primary', has_text='تصدير').click()
    check('export downloads a file', dl.value.suggested_filename.endswith('.xls'), dl.value.suggested_filename)
    page.locator('.rep-card', has_text='تقرير العهد').click(); page.wait_for_timeout(200)
    check('custody report has required columns', all(h in page.locator('.panel .tbl thead').inner_text() for h in ['رقم العهدة', 'مسئول العهدة', 'المكان', 'القيمة', 'المصروف', 'المتبقى', 'الحالة', 'تاريخ العهدة']))
    page.locator('.rep-card', has_text='تقرير المصروفات').click(); page.wait_for_timeout(200)
    check('expense report has required columns', all(h in page.locator('.panel .tbl thead').inner_text() for h in ['التاريخ', 'المكان', 'البند', 'العهدة', 'مسئول العهدة', 'القيمة', 'الوصف', 'الملاحظات']))

    # ================================================================ 18 تتبع التعديلات
    page.wait_for_timeout(500); page.reload(); page.wait_for_selector('.tabs'); tab(page, 'تتبع التعديلات')
    at = page.locator('.tbl.audit').inner_text()
    check('audit tab renamed and shows import / manual add / custody / export', 'استيراد موازنة' in at and 'إضافة بند موازنة' in at and 'إنشاء عهدة' in at and 'تصدير تقرير' in at, at[:300])
    check('audit rows show user, type and place', 'سارة المحاسب' in at and 'استيراد' in at and 'بدر' in at)
    page.locator('.filters select').nth(1).select_option('approve'); page.wait_for_timeout(300)
    at2 = page.locator('.tbl.audit').inner_text()
    check('audit type filter (approvals) with old → new values', 'اعتماد' in at2 and 'معلق' in at2 and 'معتمد' in at2, at2[:300])

    # ================================================================ 17 صلاحيات المدير المباشر
    login(page, 'sup1', '3333')
    opts = page.locator('[data-testid=dash-place] option').all_inner_texts()
    check('direct manager sees only places in scope', len(opts) == 2 and 'بدر' in opts[1], opts)
    check('direct manager has no import/budget editing tabs', 'الموازنات' not in tabs(page) and 'تتبع التعديلات' not in tabs(page))
    b.close()

# ================================================================ 19-20 عدم فقد البيانات / عدم التكرار
after = {t: q(f'select count(*) from ebda.{t}')[0][0] for t in before}
check('no rows lost in any table', all(after[t] >= before[t] for t in before), (before, after))
check('no duplicate budget lines (entity + section + name)', q('select count(*) from (select school_id, ebda.norm_txt(section), ebda.norm_txt(name) from ebda.lines group by 1,2,3 having count(*)>1) x')[0][0] == 0)
check('no page errors', not errs, errs[:3])
print(f'\n{fails} failures'); sys.exit(1 if fails else 0)
