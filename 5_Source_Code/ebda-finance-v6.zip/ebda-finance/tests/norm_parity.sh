#!/bin/bash
# يتحقق أن تطبيع النصوص فى الواجهة (normAr) مطابق تماماً لـ ebda.norm_txt فى قاعدة البيانات
set -e; cd "$(dirname "$0")"
../frontend/node_modules/.bin/esbuild ../frontend/src/lib/budget.js --bundle --format=esm --platform=node \
  --banner:js="globalThis.window=globalThis;globalThis.localStorage={getItem(){return null},setItem(){}};" --outfile=.build/budget.mjs --log-level=error
python3 - <<'PY'
import json, subprocess, psycopg2
names = ['أولاً : تكلفة التدريس', ' ثانياً : تكلفة التشغيل', 'مستهلكات معامل ', 'الزّى المدرسى', 'ـالانتقالات', 'حافز المعلمين المنتدبين من وزارة التربية والتعليم',
         'تكلفة الإدارة – شركة ابدأ إديو للتدريب والتطوير', 'Receipt 2026', 'إجمالى', 'ضرائب القيمة المضافة', 'مستهلكات ورش ومعامل']
js = json.loads(subprocess.run(['node', '-e', "import('./.build/budget.mjs').then(m=>console.log(JSON.stringify(JSON.parse(process.argv[1]).map(m.normAr))))", json.dumps(names)], capture_output=True, text=True, check=True).stdout)
c = psycopg2.connect(host='/var/tmp/pg', port=5433, user='postgres', dbname='postgres').cursor()
bad = 0
for n, j in zip(names, js):
    c.execute("select ebda.norm_txt(%s)", (n,)); s = c.fetchone()[0]
    if s != j: bad += 1; print('DIFF', repr(n), repr(s), repr(j))
print(('PASS' if not bad else 'FAIL') + f' normalisation parity ({len(names)} samples)')
raise SystemExit(1 if bad else 0)
PY
