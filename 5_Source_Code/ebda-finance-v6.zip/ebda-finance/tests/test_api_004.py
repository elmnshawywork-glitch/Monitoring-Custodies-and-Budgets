"""Tests for migration 004: flexible permissions (role + perms + scope), custody approval / cancel / line allocation,
logical expense checks, budget soft delete + restore, payroll import (no duplicate employees), adjustments, approval lock."""
import json, subprocess, sys, psycopg2, pathlib
HERE = pathlib.Path(__file__).parent
PSQL = ['psql', '-h', '/var/tmp/pg', '-p', '5433', '-U', 'postgres', '-q', '-v', 'ON_ERROR_STOP=1']
conn = psycopg2.connect(host='/var/tmp/pg', port=5433, user='postgres', dbname='postgres'); conn.autocommit = True
cur = conn.cursor()
fails = 0
def check(n, c, d=''):
    global fails; print(('PASS ' if c else 'FAIL ') + n + ('' if c else f' -> {d}')); fails += (not c)
def sql(q, *a):
    cur.execute("reset role"); cur.execute(q, a or None); return cur.fetchall() if cur.description else None
def raw(req):
    cur.execute("set role anon"); cur.execute("select public.api(%s::jsonb)", (json.dumps(req),)); r = cur.fetchone()[0]; cur.execute("reset role"); return r
def login(u, p): return raw({'action': 'login', 'username': u, 'pin': p})['token']
def api(tok, action, **kw): return raw(dict(action=action, auth={'token': tok}, **kw))
ok = lambda r: isinstance(r, dict) and r.get('ok') is True
err = lambda r: isinstance(r, dict) and 'error' in r

TABLES = ['users', 'schools', 'lines', 'custodies', 'tranches', 'expenses', 'requests', 'employees', 'payslips', 'audit_log']
NEWCOLS = ['title', 'approval', 'approved_by', 'approved_at', 'submitted_by', 'cancel_reason', 'cancelled_by', 'cancelled_at', 'holder_emp_id',
           'deleted_at', 'deleted_by', 'delete_reason', 'staff_group', 'assignment', 'work_type', 'insurance_status', 'national_key',
           'job', 'month_days', 'work_days', 'attend_days', 'rest_days', 'absent_days', 'permissions', 'deduct_days', 'direct_ded', 'leave_opening',
           'leave_used', 'leave_balance', 'task_pct', 'quality_pct', 'avg_pct', 'net_import', 'adjustments', 'source_file', 'updated_at']
import os
if os.environ.get('EBDA_ALSO_005'):  # أعمدة 005 الجديدة (إضافية فقط) لا تدخل فى مقارنة الصفوف
    NEWCOLS = list(NEWCOLS) + ['manager_id', 'dept', 'user_id', 'requester_id', 'active', 'created_by_id', 'approved_by_id', 'approval_note', 'submitted_at',
        'returned_by', 'returned_at', 'return_reason', 'fin_by_id', 'settled_by', 'settled_by_id', 'cancelled_at', 'cancelled_by', 'cancel_reason',
        'manager_user_id', 'birth_place', 'secondment_status', 'serial_no', 'supplier', 'doc_no', 'import_batch', 'import_row', 'ext_ref', 'last_seen']
def snapshot():
    strip = ' '.join(f"- '{c}'" for c in NEWCOLS)
    out = {}
    for t in TABLES:
        out[t] = sql(f"select md5(coalesce(string_agg(md5((to_jsonb(x) {strip})::text), ',' order by x.id), '')), count(*) from ebda.{t} x")[0]
    return out
# بيانات قائمة قبل 004: موظف + قسيمة بالطريقة القديمة
badr = sql("select id from ebda.schools where name like '%%بدر%%'")[0][0]
dam = sql("select id from ebda.schools where name like '%%دمياط%%'")[0][0]
sql("insert into ebda.employees(id,school_id,category,name,national_id,base_salary,active,archived) values('emp_old',%s,'contract','موظف قديم','29707070106936',9000,'نعم','لا')", badr)
sql("insert into ebda.payslips(id,employee_id,emp_name,school_id,month,base,net) values('ps_old','emp_old','موظف قديم',%s,'2026-08',9000,9000)", badr)
before = snapshot()
mig = HERE.parent / 'supabase' / 'migrations' / '004_permissions_custody_payroll.sql'
for _ in range(2): subprocess.run(PSQL + ['-f', str(mig)], check=True, capture_output=True)
import os
if os.environ.get('EBDA_ALSO_005'):  # نفس الاختبارات بعد تطبيق 005 فوق 004 (التوافق للخلف)
    for _ in range(2): subprocess.run(PSQL + ['-f', str(mig.parent / '005_workflow_backup_performance.sql')], check=True, capture_output=True)
check('004 on existing data (twice) keeps every existing row unchanged', snapshot() == before, [t for t in TABLES if snapshot()[t] != before[t]])
check('existing custodies stay approved (no workflow break)', sql("select count(*) from ebda.custodies where approval<>'approved'")[0][0] == 0)
check('schema_version = ' + ('5' if os.environ.get('EBDA_ALSO_005') else '4'), sql("select value from ebda.config where key='schema_version'")[0][0] == ('5' if os.environ.get('EBDA_ALSO_005') else '4'))
check('national key back-filled for existing employees', sql("select national_key from ebda.employees where id='emp_old'")[0][0] == '29707070106936')

A = login('admin', '1234'); F = login('acc1', '2222'); S = login('sup1', '3333'); C = login('custody1', '1111')

# ---------------------------------------------------------------- Role + Permissions + Scope
b = api(F, 'bootstrap')
check('finance default permissions = previous behaviour', set(b['me']['permissions']) >= {'budget.edit', 'custody.create', 'custody.approve', 'payroll.import'} and 'expense.approve' not in b['me']['permissions'], b['me']['permissions'])
check('custody officer default: record expenses only', api(C, 'bootstrap')['me']['permissions'] == ['expense.record'])
r = api(A, 'updateUser', id='u_s1', patch={'perms': '+custody.create,-request.approve'})
S = login('sup1', '3333')
ps = api(S, 'bootstrap')['me']['permissions']
check('grant (+) and revoke (-) per user', 'custody.create' in ps and 'request.approve' not in ps and 'expense.approve' in ps, ps)
r = api(S, 'decideRequest', id='r1', decision='approve')
check('revoked permission is enforced by the API', err(r), r)
r = api(S, 'addCustody', custody={'school_id': dam, 'holder': 'x', 'amount': 1})
check('granted permission still limited by scope (other school rejected)', err(r) and 'نطاق' in r['error'], r)
r = api(S, 'addCustody', custody={'school_id': badr, 'holder': 'تجربة مدير', 'amount': 500})
check('granted user without approve permission creates a DRAFT custody', ok(r) and r['item']['approval'] == 'draft', r)
sdraft = r['item']['id']
api(A, 'updateUser', id='u_s1', patch={'perms': ''})

# ---------------------------------------------------------------- custody workflow: draft → review → approved
r = api(F, 'addCustody', custody={'school_id': badr, 'title': 'عهدة صيانة', 'kind': 'تشغيلية', 'holder': 'أحمد', 'user': 'custody1', 'amount': 10000, 'approval': 'draft',
                                  'lines': [{'line_id': 'l_b1', 'amount': 6000}, {'line_id': 'l_b2', 'amount': 4000}]})
check('custody saved as draft with name + line allocations', ok(r) and r['item']['approval'] == 'draft' and r['item']['title'] == 'عهدة صيانة' and len(r['custody_lines']) == 2, r)
cid = r['item']['id']
r = api(C, 'addExpense', expense={'custody_id': cid, 'line_id': 'l_b1', 'amount': 100, 'date': '2026-10-01', 'description': 'x'})
check('no spending from a non-approved custody', err(r) and 'لم تُعتمد' in r['error'], r)
check('submit draft → review', ok(api(F, 'submitCustody', id=cid)) and sql("select approval from ebda.custodies where id=%s", cid)[0][0] == 'review')
r = api(S, 'approveCustody', id=cid)
check('direct manager cannot approve custody', err(r), r)
r = api(F, 'approveCustody', id=cid)
check('finance approves custody', ok(r) and sql("select approval, approved_by from ebda.custodies where id=%s", cid)[0] == ('approved', 'سارة المحاسب'), r)
r = api(F, 'updateCustody', id=cid, patch={'holder': 'شخص آخر'})
check('after approval finance cannot edit basic data', err(r) and 'للأدمن' in r['error'], r)
check('admin can still edit basic data', ok(api(A, 'updateCustody', id=cid, patch={'holder': 'أحمد'})))
r = api(C, 'addExpense', expense={'custody_id': cid, 'line_id': 'l_d1', 'amount': 100, 'date': '2026-10-01', 'description': 'x'})
check('expense line must belong to custody allocations', err(r), r)
r = api(C, 'addExpense', expense={'custody_id': cid, 'line_id': 'l_b1', 'amount': 100, 'date': '2030-01-01', 'description': 'x'})
check('future-dated expense rejected', err(r) and 'المستقبل' in r['error'], r)
r = api(C, 'addExpense', expense={'custody_id': cid, 'line_id': 'l_b1', 'amount': 12000, 'date': '2026-10-02', 'description': 'أكبر من العهدة'})
check('overspending is allowed (negative remaining is information, not an error)', ok(r), r)
check('custody remaining can be negative', sql("select (select sum(amount) from ebda.tranches where custody_id=%s) - (select sum(amount) from ebda.expenses where custody_id=%s)", cid, cid)[0][0] == -2000)
r = api(F, 'setCustodyLines', custody_id=cid, lines=[{'line_id': 'l_b2', 'amount': 4000}])
check('finance cannot change allocations after approval', err(r), r)
r = api(A, 'setCustodyLines', custody_id=cid, lines=[{'line_id': 'l_b2', 'amount': 4000}])
check('cannot remove an allocated line that has expenses', err(r) and 'مصروفات' in r['error'], r)
check('admin updates allocation amounts', ok(api(A, 'setCustodyLines', custody_id=cid, lines=[{'line_id': 'l_b1', 'amount': 8000}, {'line_id': 'l_b2', 'amount': 2000}])))

# ---------------------------------------------------------------- cancel (admin only, reason, no delete)
r = api(F, 'cancelCustody', id=cid, reason='خطأ')
check('finance cannot cancel custody', err(r) and 'للأدمن' in r['error'], r)
r = api(A, 'cancelCustody', id=cid, reason='')
check('cancel requires a reason', err(r), r)
r = api(A, 'cancelCustody', id=cid, reason='تم الصرف خارج النظام')
check('admin cancels an APPROVED custody', ok(r) and sql("select status, cancel_reason, cancelled_by from ebda.custodies where id=%s", cid)[0] == ('cancelled', 'تم الصرف خارج النظام', 'المدير العام'), r)
check('cancelled custody keeps its history (row, tranches, expenses)', sql("select count(*) from ebda.expenses where custody_id=%s", cid)[0][0] == 1 and sql("select count(*) from ebda.tranches where custody_id=%s", cid)[0][0] == 1)
r = api(C, 'addExpense', expense={'custody_id': cid, 'line_id': 'l_b1', 'amount': 10, 'date': '2026-10-02', 'description': 'x'})
check('no expenses on a cancelled custody', err(r) and 'ملغاة' in r['error'], r)
au = [a for a in api(A, 'bootstrap')['audit'] if a['action'] == 'cancelCustody' and 'تم الصرف خارج النظام' in (a['details'] or '')]
check('cancellation + reason in the audit trail', len(au) == 1)

# ---------------------------------------------------------------- custody names (master data)
r = api(F, 'saveCustodyName', item={'name': 'عهدة أنشطة'})
check('only admin manages custody names', err(r))
r = api(A, 'saveCustodyName', item={'name': 'عهدة أنشطة', 'sections': 'تشغيل'})
check('admin adds a custody name', ok(r))
check('duplicate name rejected', err(api(A, 'saveCustodyName', item={'name': 'عهده انشطه'})))
check('deactivate a name', ok(api(A, 'saveCustodyName', item={'id': r['id'], 'name': 'عهدة أنشطة', 'active': 'لا'})))
check('names in bootstrap for all roles', any(n['name'] == 'عهدة صيانة' for n in api(C, 'bootstrap')['custody_names']))

# ---------------------------------------------------------------- budget soft delete
r = api(F, 'deleteBudget', school_id=badr, reason='اختبار')
check('only admin deletes a budget', err(r) and 'للأدمن' in r['error'], r)
r = api(A, 'deleteBudget', school_id=badr, reason='اختبار')
check('budget with linked expenses cannot be deleted', err(r) and 'مصروف' in r['error'], r)
comp = sql("select id from ebda.schools where category='company'")[0][0]
api(A, 'addLine', line={'school_id': comp, 'section': 'إدارى', 'name': 'بند للحذف', 'allocated': 5000})
api(A, 'addLine', line={'school_id': comp, 'section': 'إدارى', 'name': 'بند آخر', 'allocated': 3000})
n_comp = sql("select count(*) from ebda.lines where school_id=%s", comp)[0][0]
r = api(A, 'deleteBudget', school_id=comp, reason='موازنة خاطئة')
check('admin soft-deletes a budget without expenses', ok(r) and r['count'] == n_comp, r)
check('rows are kept (soft delete)', sql("select count(*) from ebda.lines where school_id=%s and deleted_at<>''", comp)[0][0] == n_comp)
bb = api(A, 'bootstrap')
check('deleted budget hidden from everyone and listed for admin restore', not any(l['school_id'] == comp for l in bb['lines']) and any(d['school_id'] == comp for d in bb['deletedBudgets']))
check('re-adding a line with the same name after delete is allowed', ok(api(A, 'addLine', line={'school_id': comp, 'section': 'إدارى', 'name': 'بند للحذف', 'allocated': 7000})))
r = api(A, 'restoreBudget', school_id=comp)
check('restore skips lines that would duplicate active ones', ok(r) and r['count'] == n_comp - 1 and sql("select count(*) from ebda.lines where school_id=%s and name='بند للحذف' and deleted_at=''", comp)[0][0] == 1, r)
check('deleteBudget recorded with reason', any(a['action'] == 'deleteBudget' and 'موازنة خاطئة' in (a['details'] or '') for a in api(A, 'bootstrap')['audit']))

# ---------------------------------------------------------------- payroll import: one employee per person, one payslip per month
rows = [
    {'name': 'مصطفي عاطف عبدالغفار', 'national_id': '29707070106936', 'staff_group': 'private', 'job': 'م.تنفيذي', 'salary': '20000', 'ded_total': '0', 'net': '20000', 'absent_days': '1', 'month_days': '30', 'leave_opening': '21', 'leave_used': '1', 'leave_balance': '20', 'bank': 'الاهلي المصري', 'account_no': '0955001737027000010'},
    {'name': 'امير سامي بليلة', 'national_id': '30212200101091', 'staff_group': 'private', 'job': 'أخصائي', 'salary': '10000', 'ded_total': '6333.33', 'net': '3666.67', 'deduct_days': '1', 'month_days': '30'},
    {'name': 'وائل عبد الملك عزيز', 'national_id': '28608091304477', 'staff_group': 'gov', 'job': 'م.أكاديمي', 'salary': '10000', 'net': '10000', 'task_pct': '0.98'},
    {'name': 'نجوى محمد صالح', 'national_id': '27812110100945', 'staff_group': 'cleaning', 'job': 'عامل نظافة', 'salary': '6800', 'net': '6800', 'attend_days': '30'},
]
r = api(S, 'importPayroll', school_id=badr, month='2026-09', rows=rows)
check('direct manager cannot import payroll', err(r), r)
r = api(F, 'importPayroll', school_id=dam, month='2026-09', rows=rows)
check('payroll import respects scope', err(r), r)
r = api(F, 'importPayroll', school_id=badr, month='2026-09', rows=rows + [{'name': 'خطأ', 'salary': 'abc'}])
check('invalid number rejects the whole import (no partial write)', err(r) and sql("select count(*) from ebda.payslips where month='2026-09'")[0][0] == 0, r)
r = api(F, 'importPayroll', school_id=badr, month='2026-09', file_name='سبتمبر.xlsx', rows=rows)
check('import Sep: existing employee matched by national ID, 3 new', ok(r) and r['employees_added'] == 3 and r['payslips_added'] == 4, r)
check('existing employee was not duplicated', sql("select count(*) from ebda.employees where national_key='29707070106936'")[0][0] == 1)
r = api(F, 'importPayroll', school_id=badr, month='2026-09', rows=rows)
check('re-import same month: no new employees or payslips (updated)', ok(r) and r['employees_added'] == 0 and r['payslips_added'] == 0 and r['payslips_updated'] == 4, r)
rows2 = [dict(x, net=str(float(x['net']) + 100)) for x in rows]
rows2[2] = dict(rows2[2], national_id='', name='وائل  عبد الملك عزيز')
r = api(F, 'importPayroll', school_id=badr, month='2026-10', rows=rows2)
check('October: same people reused (matched by name when ID missing), new month payslips', ok(r) and r['employees_added'] == 0 and r['payslips_added'] == 4, r)
check('one employee row per person after 2 months', sql("select count(*) from ebda.employees where school_id=%s", badr)[0][0] == 4)
pid = sql("select p.id from ebda.payslips p join ebda.employees e on e.id=p.employee_id where e.national_key='30212200101091' and p.month='2026-09'")[0][0]
r = api(F, 'adjustPayslip', id=pid, adjustments={'bonus': 500, 'advance': 1000})
check('adjustments: net = imported net + earnings − deductions', ok(r) and abs(float(r['net']) - (3666.67 + 500 - 1000)) < 0.01, r)
check('unknown component rejected', err(api(F, 'adjustPayslip', id=pid, adjustments={'hack': 5})))
r = api(F, 'importPayroll', school_id=badr, month='2026-09', rows=rows)
check('re-import keeps adjustments and recomputes net', abs(float(sql("select net from ebda.payslips where id=%s", pid)[0][0]) - 3166.67) < 0.01)
check('approve payroll period', ok(api(F, 'approvePayroll', school_id=badr, month='2026-09')))
check('approved period is locked for import', err(api(F, 'importPayroll', school_id=badr, month='2026-09', rows=rows)))
check('approved period is locked for adjustments', err(api(F, 'adjustPayslip', id=pid, adjustments={'bonus': 1})))
check('only admin reopens', err(api(F, 'reopenPayroll', school_id=badr, month='2026-09')) and ok(api(A, 'reopenPayroll', school_id=badr, month='2026-09')))
check('custom salary component (no hard-coding)', ok(api(A, 'savePayrollComponent', item={'code': 'transport', 'name': 'بدل انتقال', 'kind': 'earning'})))
r = api(F, 'adjustPayslip', id=pid, adjustments={'transport': 250})
check('new component used immediately', ok(r) and abs(float(r['net']) - 3916.67) < 0.01, r)
bf = api(F, 'bootstrap')
check('payroll data in bootstrap (periods, components, payslips with attendance)', len(bf['payroll_periods']) == 2 and any(c['code'] == 'transport' for c in bf['payroll_components'])
      and any(p['absent_days'] == 1 and p['leave_balance'] == 20 for p in bf['payslips']))
check('custody officer gets no payroll data', 'payslips' not in api(C, 'bootstrap'))
ch = [c for c in api(A, 'bootstrap')['audit_changes'] if c['tbl'] == 'payslips' and c['op'] == 'update']
check('payroll edits tracked with old/new values', any('net' in (c['new_v'] or {}) for c in ch))
check('payroll actions in the audit trail', {'importPayroll', 'adjustPayslip', 'approvePayroll'} <= {a['action'] for a in api(A, 'bootstrap')['audit']})

print(f'\n{fails} failures'); sys.exit(1 if fails else 0)
