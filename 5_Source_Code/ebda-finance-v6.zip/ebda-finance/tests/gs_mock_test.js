const fs=require('fs'), vm=require('vm');
function mkSheet(name){const s={name,data:[],hidden:[],prot:[],rules:[],
  getLastRow(){let n=this.data.length;while(n>0&&(this.data[n-1]||[]).every(v=>v===''||v==null))n--;return n;},
  getRange(r,c,nr=1,nc=1){const sh=this;const R={
    setValues(v){for(let i=0;i<v.length;i++){sh.data[r-1+i]=sh.data[r-1+i]||[];for(let j=0;j<v[i].length;j++)sh.data[r-1+i][c-1+j]=v[i][j];}return R;},
    getValues(){const o=[];for(let i=0;i<nr;i++){const row=[];for(let j=0;j<nc;j++){const v=(sh.data[r-1+i]||[])[c-1+j];row.push(v==null?'':v);}o.push(row);}return o;},
    getColumn(){return c;},
    protect(){const p={d:'',setDescription(x){this.d=x;return p;},getDescription(){return this.d;},setRange(){return p;},setWarningOnly(){return p;}};sh.prot.push(p);return p;}};
    ['setFontWeight','setBackground','setFontColor','setWrap','setVerticalAlignment','setNumberFormat'].forEach(m=>R[m]=()=>R);return R;},
  setFrozenRows(){},setRightToLeft(){},hideColumns(c){this.hidden.push(c);},
  getProtections(){return this.prot;},getConditionalFormatRules(){return this.rules;},setConditionalFormatRules(r){this.rules=r;},
  appendRow(v){this.data.push(v);} };return s;}
function mkSS(){const sheets={};return{sheets,getSheetByName:n=>sheets[n]||null,insertSheet:n=>(sheets[n]=mkSheet(n))};}
const ssB=mkSS(), ssC=mkSS(); ssB.insertSheet('موازنة دمياط').appendRow(['user tab untouched']);
let exportData=JSON.parse(fs.readFileSync('export1.json','utf8'));
const builder=()=>{const b={whenTextContains(){return b},setBackground(){return b},setFontColor(){return b},setRanges(){return b},build(){return{getRanges:()=>[{getColumn:()=>-1}]}}};return b;};
const ctx={SpreadsheetApp:{openById:id=>id.startsWith('1LZ')?ssB:ssC,ProtectionType:{RANGE:'R'},newConditionalFormatRule:builder,getUi:()=>({})},
  LockService:{getScriptLock:()=>({tryLock:()=>true,releaseLock(){}})},
  UrlFetchApp:{fetch:()=>({getContentText:()=>JSON.stringify(exportData),getResponseCode:()=>200})},ScriptApp:{},console};
vm.createContext(ctx); vm.runInContext(fs.readFileSync('../apps_script/EBDA_Sheets_Sync.gs','utf8'),ctx);
const assert=(n,c,d='')=>{console.log((c?'PASS ':'FAIL ')+n+(c?'':' -> '+d)); if(!c) process.exitCode=1;};
ctx.syncNow();
const B=ssB.sheets['⟳ متابعة الموازنات'], E=ssC.sheets['⟳ المصروفات'], C=ssC.sheets['⟳ متابعة العهد'];
const nB=B.getLastRow(), nE=E.getLastRow();
assert('budget rows = lines + header', nB===exportData.budget.length+1, nB);
assert('expenses rows', nE===exportData.expenses.length+1, nE);
// user adds a note column to the right of row 2 of expenses
const w=E.data[0].length; E.data[1][w]='ملاحظة يدوية';
const firstKey=E.data[1][w-1];
ctx.syncNow();
assert('re-sync creates no duplicates', E.getLastRow()===nE && B.getLastRow()===nB, E.getLastRow());
assert('user note column preserved on same record', E.data[1][w]==='ملاحظة يدوية' && E.data[1][w-1]===firstKey);
// a record deleted in DB + a new one added
const removed=exportData.expenses.shift();
exportData.expenses.push(Object.assign({},removed,{key:'NEW1',txn_no:'EXP-99999'}));
ctx.syncNow();
assert('new record appended', E.getLastRow()===nE+1);
const delRow=E.data.find(r=>r[w-1]===removed.key);
assert('deleted record kept & marked', delRow && delRow[0]==='محذوف من النظام', delRow&&delRow[0]);
assert('user tabs untouched', ssB.sheets['موازنة دمياط'].data[0][0]==='user tab untouched');
assert('sync log written', ssB.sheets['⟳ سجل المزامنة'].getLastRow()===4);
const row=B.data.find(r=>r[4]==='مطبوعات' && String(r[0]).includes('بدر'));
const src=exportData.budget.find(b=>b.key===row[row.length-1]);
assert('budget row values match DB (Sep spent, total, remaining, pending)', row[7]===Number(src.months[0]) && row[19]===Number(src.spent) && row[20]===Number(src.annual)-Number(src.spent) && row[23]===Number(src.pending), JSON.stringify(row));
console.log('custody sample:', JSON.stringify(C.data[1]));
