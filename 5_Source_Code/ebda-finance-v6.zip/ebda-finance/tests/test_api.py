"""API permission & workflow tests against local Postgres after migration 001.
Runs as role anon (like the browser) through public.api()."""
import json, sys, psycopg2

conn = psycopg2.connect(host='/var/tmp/pg', port=5433, user='postgres', dbname='postgres')
conn.autocommit = True
cur = conn.cursor()
cur.execute("set role anon")  # same privileges as the public web client
PINS = {'admin': '1234', 'custody1': '1111', 'custody2': '5555', 'acc1': '2222', 'sup1': '3333', 'sup2': '4444', 'olduser': '9999'}
fails = 0


def api(who, action, **kw):
    req = dict(action=action, **kw)
    if who:
        req['auth'] = {'username': who, 'pin': PINS[who]}
    cur.execute("select public.api(%s::jsonb)", (json.dumps(req),))
    return cur.fetchone()[0]


def check(name, cond, detail=''):
    global fails
    print(('PASS ' if cond else 'FAIL ') + name + ('' if cond else f'  -> {detail}'))
    if not cond: fails += 1


def ok(r): return isinstance(r, dict) and r.get('ok') is True
def err(r): return isinstance(r, dict) and 'error' in r


# ---------- login & security
r = api(None, 'login', username='custody1', pin='1111'); check('legacy plaintext pin still logs in after hashing', ok(r) and r['user']['role'] == 'custody' and r['user']['role_key'] == 'custody_officer', r)
check('login returns arabic role label', r['user'].get('role_label') == 'مسئول العهدة', r)
check('wrong pin rejected', err(api(None, 'login', username='custody1', pin='0000')))
check('inactive user cannot login', err(api(None, 'login', username='olduser', pin='9999')))
check('inactive user cannot call api', err(api('olduser', 'bootstrap')))
check('default/unknown token rejected for dumpAll', err(api(None, 'dumpAll', token='CHANGE_ME_TO_A_SECRET')))
d = api(None, 'dumpAll', token='s3cret-token-xyz')
check('dumpAll ok with secret token', ok(d), d)
check('dumpAll has no pins', all('pin' not in u for u in d['users']))
check('dumpAll strips inline base64 docs', all(not str(e.get('doc_url', '')).startswith('data:') for e in d['expenses']))
b = api('admin', 'bootstrap')
check('admin bootstrap users without pins', ok(b) and b['users'] and all('pin' not in u for u in b['users']), b.get('error'))
check('admin sees audit', 'audit' in b)

# ---------- scope: bootstrap visibility
bc = api('custody1', 'bootstrap')
check('custody sees only own custody', [c['code'] for c in bc['custodies']] == ['CUST-001'], [c['code'] for c in bc['custodies']])
check('custody sees only own expenses', {e['id'] for e in bc['expenses']} == {'e1', 'e2', 'e3'}, {e['id'] for e in bc['expenses']})
check('custody sees line names without amounts', all('allocated' not in l for l in bc['lines']))
check('custody gets no users / salaries / audit', not any(k in bc for k in ('users', 'salaries', 'audit')))
bs = api('sup1', 'bootstrap')
check('direct manager (badr) does not see damietta expenses', 'e5' not in {e['id'] for e in bs['expenses']})
check('direct manager sees only badr requests', {r['id'] for r in bs['requests']} == {'r1'}, {r['id'] for r in bs['requests']})
check('direct manager role_key', bs['me']['role_key'] == 'direct_manager')
ba = api('acc1', 'bootstrap')
check('finance manager sees budgets amounts', all('allocated' in l for l in ba['lines']))
check('finance manager without manage_users gets no pins/perms list', all('pin' not in u for u in ba.get('users', [])))

# ---------- direct manager scope enforcement (the old hole)
check('sup1 cannot approve damietta expense (out of scope)', err(api('sup1', 'updateExpense', id='e5', patch={'approval': 'approved'})))
check('sup1 cannot decide damietta request', err(api('sup1', 'decideRequest', id='r2', decision='approve')))
check('custody cannot approve own expense', err(api('custody1', 'updateExpense', id='e1', patch={'approval': 'approved'})))
r = api('sup1', 'updateExpense', id='e1', patch={'approval': 'approved', 'amount': 999999})
check('sup1 approves badr expense', ok(r), r)
cur.execute("reset role"); cur.execute("select amount, approval, approved_by, approved_at<>'' from ebda.expenses where id='e1'"); row = cur.fetchone(); cur.execute("set role anon")
check('approval cannot smuggle amount change', row[0] == 1000 and row[1] == 'approved' and row[3], row)
check('cannot re-decide already approved expense', err(api('sup1', 'updateExpense', id='e1', patch={'approval': 'rejected'})))

# ---------- expenses by custody officer
check('custody cannot add expense to other custody', err(api('custody1', 'addExpense', expense={'custody_id': 'c_d1', 'amount': 10, 'line_id': 'l_d1', 'date': '2026-09-08'})))
check('custody cannot use line from other school', err(api('custody1', 'addExpense', expense={'custody_id': 'c_b1', 'amount': 10, 'line_id': 'l_d1', 'date': '2026-09-08'})))
check('custody cannot add zero amount', err(api('custody1', 'addExpense', expense={'custody_id': 'c_b1', 'amount': 0, 'line_id': 'l_b1', 'date': '2026-09-08'})))
r = api('custody1', 'addExpense', expense={'custody_id': 'c_b1', 'amount': 1500, 'line_id': 'l_b1', 'date': '2026-09-15', 'description': 'ورق', 'school_id': 'HACK'})
check('custody adds expense; school forced from custody; txn_no assigned', ok(r) and r['item']['school_id'] != 'HACK' and r['item']['txn_no'].startswith('EXP-'), r)
newe = r['item']['id']
check('custody can edit own pending', ok(api('custody1', 'updateExpense', id=newe, patch={'amount': 1600})))
check('custody cannot edit approved expense', err(api('custody1', 'updateExpense', id='e2', patch={'amount': 1})))
check('custody cannot delete approved expense', err(api('custody1', 'deleteExpense', id='e2')))
check('custody cannot add budget line', err(api('custody1', 'addLine', line={'school_id': 'x', 'name': 'x'})))
check('custody cannot financially review', err(api('custody1', 'reviewExpense', id='e2', patch={'fin_approval': 'approved'})))

# ---------- financial approval & budget impact
check('finance cannot fin-approve before direct manager approval', err(api('acc1', 'reviewExpense', id=newe, patch={'fin_approval': 'approved'})))
r = api('acc1', 'reviewExpense', id='e2', patch={'fin_approval': 'approved'})
check('finance approves e2 financially', ok(r), r)
r = api('acc1', 'reviewExpense', id='e2', patch={'review_status': 'مستوفى', 'settled': 'نعم'})
check('finance settles e2', ok(r), r)
r = api('acc1', 'reviewExpense', id='e1', patch={'settled': 'نعم', 'review_status': 'مستوفى'})
check('legacy settle path also sets fin approval', ok(r), r)
cur.execute("reset role"); cur.execute("select fin_approval, settled_at<>'' from ebda.expenses where id='e1'"); row = cur.fetchone(); cur.execute("set role anon")
check('e1 fin_approval=approved after settle', row == ('approved', True), row)
check('finance out-of-scope (damietta) cannot review', err(api('acc1', 'reviewExpense', id='e5', patch={'fin_approval': 'approved'})))

# ---------- custody lifecycle
check('custody officer can submit for settlement', ok(api('custody1', 'updateCustody', id='c_b1', patch={'status': 'pending_settlement'})))
check('custody officer cannot change other fields', err(api('custody1', 'updateCustody', id='c_b1', patch={'status': 'pending_settlement', 'label': 'x'})))
r = api('acc1', 'updateCustody', id='c_b1', patch={'status': 'settled'})
check('cannot settle custody with unsettled expenses', err(r), r)
api('sup1', 'updateExpense', id=newe, patch={'approval': 'rejected', 'note': 'مرفوض للاختبار'})  # v6: سبب الرفض إلزامى
r = api('acc1', 'updateCustody', id='c_b1', patch={'status': 'settled'})
check('settle custody once all expenses settled/rejected', ok(r), r)
check('no new expenses on settled custody', err(api('custody1', 'addExpense', expense={'custody_id': 'c_b1', 'amount': 5, 'line_id': 'l_b1', 'date': '2026-10-01'})))
check('no tranche on settled custody', err(api('acc1', 'addTranche', tranche={'custody_id': 'c_b1', 'amount': 5, 'date': '2026-10-01'})))
check('finance cannot delete custody', err(api('acc1', 'deleteCustody', id='c_b1')))
check('admin cannot delete custody with approved expenses', err(api('admin', 'deleteCustody', id='c_b1')))

# ---------- requests workflow → new custody after settlement
check('custody cannot request for other school', err(api('custody1', 'addRequest', request={'school_id': 'nope', 'items': []})))
check('finance cannot transfer before DM approval', err(api('acc1', 'transferRequest', id='r1', decision='approve')))
check('sup1 approves r1', ok(api('sup1', 'decideRequest', id='r1', decision='approve')))
check('sup1 cannot decide twice', err(api('sup1', 'decideRequest', id='r1', decision='approve')))
r = api('acc1', 'transferRequest', id='r1', decision='approve')
check('finance transfers r1 -> NEW custody since old one settled', ok(r) and r['custody_code'] == 'CUST-003', r)
bc = api('custody1', 'bootstrap')
codes = sorted(c['code'] for c in bc['custodies'])
check('custody1 now sees old + new custody', codes == ['CUST-001', 'CUST-003'], codes)
nc = [c for c in bc['custodies'] if c['code'] == 'CUST-003'][0]
check('new custody balance = request total', float(nc['received']) == 4000, nc)
st = [x for x in bc['requests'] if x['id'] == 'r1'][0]['stage']
check('request stage transferred', st == 'transferred', st)

# ---------- users management
check('finance cannot add users without perm', err(api('acc1', 'addUser', user={'username': 'z', 'pin': '1234', 'role': 'custody'})))
r = api('admin', 'addUser', user={'username': 'fin2', 'pin': '7777', 'name': 'مدير مالى', 'role': 'finance_manager', 'schools': '*'})
check('admin adds user with NEW role code -> stored as legacy', ok(r) and r['item']['role'] == 'accountant' and r['item']['role_key'] == 'finance_manager', r)
check('new user must reset password', r['item'].get('must_reset') == 'نعم', r)
uid = r['item']['id']
check('updateUser with empty pin keeps old pin', ok(api('admin', 'updateUser', id=uid, patch={'name': 'م. مالى', 'pin': ''})))
PINS['fin2'] = '7777'
check('fin2 still logs in', ok(api(None, 'login', username='fin2', pin='7777')))
check('cannot delete last admin', err(api('admin', 'deleteUser', id=api('admin', 'bootstrap')['me']['id'])))
check('admin grants manage_users to finance', ok(api('admin', 'updateUser', id=uid, patch={'perms': 'manage_users'})))
check('finance w/ perm cannot create admin', err(api('fin2', 'addUser', user={'username': 'evil', 'pin': '1234', 'role': 'admin'})))
check('finance w/ perm can create custody officer', ok(api('fin2', 'addUser', user={'username': 'c9', 'pin': '1234', 'role': 'custody_officer', 'schools': ''})))
check('unknown role rejected', err(api('admin', 'addUser', user={'username': 'q', 'pin': '1234', 'role': 'boss'})))

# ---------- lines / import guards
check('finance can add budget line in scope', ok(api('acc1', 'addLine', line={'school_id': bc['schools'][0]['id'], 'name': 'بند جديد', 'allocated': 1000})))
check('cannot delete line that has expenses', err(api('admin', 'deleteLine', id='l_b1')))
check('cannot replace budget of school with expenses', err(api('admin', 'importBudget', school_id=bc['schools'][0]['id'], lines=[])))

# ---------- audit log
cur.execute("reset role")
cur.execute("select count(*) from ebda.audit_log where action in ('login','loginFailed')"); check('login & failed logins audited', cur.fetchone()[0] >= 3)
cur.execute("select details from ebda.audit_log where action='updateUser' order by ts desc limit 1"); det = cur.fetchone()[0]
check('audit details never contain pins', '7777' not in det and '"pin"' not in det, det[:200])
cur.execute("set role anon")

# ---------- sheets export
sx = api(None, 'syncExport', token='s3cret-token-xyz')
check('syncExport ok', ok(sx), sx if not ok(sx) else '')
bl = [x for x in sx['budget'] if x['line'] == 'مطبوعات' and 'بدر' in x['entity']][0]
check('budget export counts only fin-approved (e1 1000 + e2 2000 in Sep)', float(bl['months'][0]) == 3000 and float(bl['spent']) == 3000, bl)
bz = [x for x in sx['budget'] if x['line'] == 'الزى المدرسى'][0]
check('legacy settled + central counted (3000 Oct + 5000 Sep)', float(bz['months'][1]) == 3000 and float(bz['months'][0]) == 5000, bz)
check('export expenses have txn_no', all(e['txn_no'] for e in sx['expenses']))
print(f'\n{fails} failures')
sys.exit(1 if fails else 0)
