#!/bin/bash
# تشغيل اختبار حمل واحد مع المراقبة: run_load.sh <name> <stages>
cd /home/claude/perf
for i in 1 2 3 4 5 6 7 8 9 10; do
  curl -s -o /dev/null -X POST localhost:3000/rpc/api -H 'Content-Type: application/json' -d '{"req":{"action":"ping"}}' && break
  pgrep -x postgrest >/dev/null || (setsid nohup bin/postgrest /home/claude/app/repo/ebda-finance/tests/perf/postgrest.conf > pgrst.log 2>&1 &)
  sleep 1
done
python3 /home/claude/app/repo/ebda-finance/tests/perf/monitor.py runs/$1_mon.csv & echo $! > runs/mon.pid
bin/k6 run --quiet --compatibility-mode=base --no-color --no-usage-report -e STAGES="$2" --summary-export runs/$1.json /home/claude/app/repo/ebda-finance/tests/perf/load_test.js > runs/$1.txt 2>&1
kill $(cat runs/mon.pid)
