import csv,json,sys,re
for name in sys.argv[1:]:
    t=open(name+'.txt').read()
    def g(k):
        m=re.search(r'^\s*'+re.escape(k)+r'\.*: (.*)$',t,re.M); return m.group(1).strip() if m else '-'
    print('=====',name)
    for k in ['http_reqs','http_req_failed','api_errors','vus_max','iterations','checks']: print(' ',k,g(k))
    m=re.search(r'^\s*http_req_duration\.*: (.*)$',t,re.M); print('  duration',m.group(1) if m else '-')
    for l in re.findall(r'\{ name:(\w+) \}\.*: (avg=\S+).*?(med=\S+).*?(p\(95\)=\S+).*?(max=\S+)',t): print('   ',l)
    r=list(csv.DictReader(open(name+'_mon.csv'))); busy=[x for x in r if float(x['cpu_idle'])<60] or r
    av=lambda k: round(sum(float(x[k]) for x in busy)/len(busy),1); mx=lambda k: max(float(x[k]) for x in r)
    print('  cpu busy avg %', round(100-av('cpu_idle'),1), 'mem max MB', mx('mem_used_mb'), 'pg_conn max', mx('pg_conn_total'), 'pg active avg', av('pg_active'),
          'pgrst rss max', mx('pgrst_rss_mb'), 'k6 rss max', mx('k6_rss_mb'), 'net MB/s avg', av('net_lo_mb'), 'tps avg', av('tps_commit'), 'samples', len(r))
