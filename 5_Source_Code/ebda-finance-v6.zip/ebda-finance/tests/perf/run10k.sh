#!/bin/bash
# 10,000 مستخدم افتراضى: نتائج متدفقة إلى CSV (تبقى حتى لو توقف k6) + حارس ذاكرة يوقف k6 بلطف (SIGINT ← يكتب الملخص)
cd /home/claude/perf
D=/sys/fs/cgroup/memory/process_api/01a11022-51d1-7333-888c-7cc6a72e8bec/claude-code-bash
( while true; do u=$(awk '/^total_rss /{r=$2}/^total_shmem /{s=$2}END{print int((r+s)/1048576)}' $D/memory.stat); if [ "$u" -gt 5700 ]; then echo "$(date +%s) rss+shmem ${u}MB — SIGINT k6" >> runs/guard10k.log; pkill -INT -x k6; sleep 30; fi; sleep 2; done ) & echo $! > runs/guard10k.pid
python3 /home/claude/app/repo/ebda-finance/tests/perf/monitor.py runs/r10000b_mon.csv & echo $! > runs/mon.pid
bin/k6 run --quiet --compatibility-mode=base --no-color --no-usage-report -e STAGES="240s:10000,240s:10000,30s:0" --out csv=runs/r10000b_points.csv.gz --summary-export runs/r10000b.json /home/claude/app/repo/ebda-finance/tests/perf/load_test.js > runs/r10000b.txt 2>&1
kill $(cat runs/mon.pid) $(cat runs/guard10k.pid); echo done > runs/r10000b.done
