"""مراقبة الموارد أثناء اختبار الحمل (كل 5 ثوان): CPU · RAM · اتصالات قاعدة البيانات · ذاكرة PostgREST/k6/Postgres · الشبكة (lo)."""
import time, sys, subprocess, psycopg2, os
out = open(sys.argv[1], 'w')
out.write('ts,cpu_user,cpu_sys,cpu_idle,cpu_iowait,mem_used_mb,pg_conn_total,pg_active,pg_rss_mb,pgrst_rss_mb,k6_rss_mb,net_lo_mb,tps_commit\n')
def cpu():
    a = list(map(int, open('/proc/stat').readline().split()[1:8])); return a
def rss(name):
    tot = 0
    for p in os.listdir('/proc'):
        if not p.isdigit(): continue
        try:
            comm = open(f'/proc/{p}/comm').read().strip()
            if comm.startswith(name):
                for l in open(f'/proc/{p}/status'):
                    if l.startswith('VmRSS:'): tot += int(l.split()[1])
        except Exception: pass
    return tot / 1024
def net():
    for l in open('/proc/net/dev'):
        if l.strip().startswith('lo:'): return int(l.split(':')[1].split()[0])
    return 0
c = psycopg2.connect(host='/var/tmp/pg', port=5433, user='postgres', dbname='postgres'); c.autocommit = True; cur = c.cursor()
prev = cpu(); pn = net(); pt = None
while True:
    time.sleep(5)
    now = cpu(); d = [b - a for a, b in zip(prev, now)]; tot = sum(d) or 1; prev = now
    mem = [l for l in open('/proc/meminfo')]
    mt = int(mem[0].split()[1]); ma = int([l for l in mem if l.startswith('MemAvailable')][0].split()[1])
    cur.execute("select count(*), count(*) filter (where state='active') from pg_stat_activity where datname='ebda_perf'"); conn = cur.fetchone()
    cur.execute("select xact_commit from pg_stat_database where datname='ebda_perf'"); tc = cur.fetchone()[0]
    tps = 0 if pt is None else (tc - pt) / 5; pt = tc
    nn = net(); nmb = (nn - pn) / 1048576 / 5; pn = nn
    out.write(f"{int(time.time())},{100*d[0]/tot:.1f},{100*d[2]/tot:.1f},{100*d[3]/tot:.1f},{100*d[4]/tot:.1f},{(mt-ma)/1024:.0f},{conn[0]},{conn[1]},{rss('postgres'):.0f},{rss('postgrest'):.0f},{rss('k6'):.0f},{nmb:.2f},{tps:.0f}\n")
    out.flush()
