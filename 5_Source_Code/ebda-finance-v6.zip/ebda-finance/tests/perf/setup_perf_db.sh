#!/bin/bash
# قاعدة بيانات اختبار أداء منفصلة (ebda_perf): نفس الـ schema + Migrations 001 → 005 + بيانات ضخمة مولّدة
set -e
cd "$(dirname "$0")"
P="psql -h ${PGHOST:-/var/tmp/pg} -p ${PGPORT:-5433} -U postgres -q -v ON_ERROR_STOP=1"
$P -d postgres -c "drop database if exists ebda_perf" -c "create database ebda_perf"
$P -d ebda_perf -c "create schema if not exists extensions" -c "create extension if not exists pgcrypto schema extensions" -c "create extension if not exists pg_stat_statements" >/dev/null
$P -d ebda_perf -f ../../supabase/supabase_setup.sql >/dev/null
for m in ../../supabase/migrations/00{1,2,3,4,5}_*.sql; do $P -d ebda_perf -f $m 2>&1 | grep -v NOTICE || true; done
time $P -d ebda_perf -f gen_big_data.sql
$P -d ebda_perf -Atc "select 'expenses', count(*) from ebda.expenses union all select 'custodies', count(*) from ebda.custodies union all select 'users', count(*) from ebda.users union all select 'lines', count(*) from ebda.lines union all select 'payslips', count(*) from ebda.payslips"
