import json, time, psycopg2, sys
c=psycopg2.connect(host='/var/tmp/pg',port=5433,user='postgres',dbname='ebda_perf'); c.autocommit=True; cur=c.cursor()
cur.execute("set pg_stat_statements.track='all'"); cur.execute("select pg_stat_statements_reset()")
def call(req):
    cur.execute("select public.api(%s::jsonb)::text",(json.dumps(req),)); return cur.fetchone()[0]
u=sys.argv[1]; act=sys.argv[2] if len(sys.argv)>2 else 'bootstrap'
t=json.loads(call({'action':'login','username':u,'pin':'1234'}))['token']
t0=time.time(); s=call({'action':act,'auth':{'token':t}, **(json.loads(sys.argv[3]) if len(sys.argv)>3 else {})}); print('total', round(time.time()-t0,2),'s', len(s))
cur.execute("select round(total_exec_time::numeric,1), calls, left(regexp_replace(query,'\\s+',' ','g'),150) from pg_stat_statements order by total_exec_time desc limit 12")
for r in cur.fetchall(): print(r)
