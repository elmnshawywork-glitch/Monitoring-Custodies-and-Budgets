-- بيانات اختبار أداء ضخمة (قاعدة بيانات اختبار منفصلة فقط — ليست Production)
-- 60 جهة · 6,000 بند · 9,810 مستخدم · 12,000 عهدة · 250,000 مصروف · 8,000 موظف · 96,000 قسيمة · 200,000 سجل تدقيق
set search_path = ebda, public, extensions;
select setseed(0.42);
set session_replication_role = replica;  -- بدون Triggers أثناء التوليد (تتبع التعديلات يُولَّد منفصلاً أدناه)

-- كلمة سر واحدة (1234) مشفرة مرة واحدة لكل المستخدمين (bcrypt)
create temp table h as select ebda.pin_hash('1234') as pin;

insert into ebda.schools(id,name,type,period,students,active,category)
select 'sc'||g, case when g<=50 then 'مدرسة اختبار '||g when g<=55 then 'شركة اختبار '||g else 'مركز تدريب '||g end, '', '2026/2027', 500, 'نعم',
       case when g<=50 then 'school' when g<=55 then 'company' else 'training_general' end
from generate_series(1,60) g;

insert into ebda.lines(id,school_id,section,name,allocated,note,monthly_plan,active)
select 'ln'||s||'_'||k, 'sc'||s, 'قسم '||((k-1)/10+1), 'بند '||k, (10000 + (random()*490000))::int, '', '', 'نعم'
from generate_series(1,60) s, generate_series(1,100) k;

insert into ebda.users(id,username,pin,name,role,schools,active,email,must_reset,perms,manager_id)
select 'adm'||g, 'admin'||g, (select pin from h), 'أدمن '||g, 'manager', '*', 'نعم', '', 'لا', '', '' from generate_series(1,10) g;
insert into ebda.users(id,username,pin,name,role,schools,active,email,must_reset,perms,manager_id)
select 'fin'||g, 'fin'||g, (select pin from h), 'مدير مالى '||g, 'accountant',
       (select string_agg('sc'||((g*7+j) % 60 + 1), ',') from generate_series(0,4) j), 'نعم', '', 'لا', '', '' from generate_series(1,300) g;
insert into ebda.users(id,username,pin,name,role,schools,active,email,must_reset,perms,manager_id)
select 'mgr'||g, 'mgr'||g, (select pin from h), 'مدير مباشر '||g, 'supervisor', 'sc'||(g % 60 + 1), 'نعم', '', 'لا', '', '' from generate_series(1,1500) g;
insert into ebda.users(id,username,pin,name,role,schools,active,email,must_reset,perms,manager_id)
select 'cus'||g, 'cus'||g, (select pin from h), 'مسئول عهدة '||g, 'custody', 'sc'||(g % 60 + 1), 'نعم', '', 'لا', '',
       'mgr'||((g % 60 + 1) + 60 * (g % 25))   -- مدير مباشر من نفس المكان
from generate_series(1,8000) g;

insert into ebda.custodies(id,label,holder,school_id,note,"user",code,status,opened_at,kind,purpose,title,approval,approved_by,approved_at)
select 'cu'||g, 'عهدة '||g, 'مسئول عهدة '||((g-1) % 8000 + 1), 'sc'||(((g-1) % 8000 + 1) % 60 + 1), '', 'cus'||((g-1) % 8000 + 1),
       'CUST-'||lpad(g::text,5,'0'),
       case when g % 10 = 0 then 'settled' when g % 17 = 0 then 'pending_settlement' else 'open' end,
       (date '2026-09-01' + ((g % 30))::int)::text, 'عهدة تشغيلية', 'اختبار', 'عهدة تشغيلية', 'approved', 'admin', now()::text
from generate_series(1,12000) g;

update ebda.custodies c set user_id = c."user" where coalesce(c.user_id,'')='';

insert into ebda.tranches(id,custody_id,date,amount,note)
select 'tr'||g||'_'||k, 'cu'||g, (date '2026-09-01' + (g % 30))::text, (5000 + random()*45000)::int, 'دفعة'
from generate_series(1,12000) g, generate_series(1,2) k;

insert into ebda.custody_lines(id,custody_id,line_id,amount,note)
select 'cl'||g||'_'||k, 'cu'||g, 'ln'||(((g-1) % 8000 + 1) % 60 + 1)||'_'||((g*3+k*7) % 100 + 1), (2000 + random()*20000)::int, ''
from generate_series(1,12000) g, generate_series(1,2) k
on conflict do nothing;

-- 250,000 مصروف على 13 شهراً (سبتمبر 2025 → أكتوبر 2026) — القديم مسوّى غالباً، والحديث بحالات الدورة المختلفة
insert into ebda.expenses(id,date,school_id,custody_id,line_id,spend_item,description,amount,approval,approved_by,approved_at,doc_url,doc_name,
  review_status,review_note,settled,ref,note,created_by,created_at,txn_no,fin_approval,fin_by,fin_at,settled_at,doc_is_link,created_by_id,pay_method)
select 'ex'||e, d::text, c.school_id, c.id, cl.line_id, '', 'مصروف اختبار '||e, (50 + random()*4950)::int,
  case when old then (case when r < .02 then 'rejected' else 'approved' end)
       when r < .10 then 'pending' when r < .13 then 'returned' when r < .14 then 'rejected' else 'approved' end,
  'مدير', d::text,
  case when r < .7 then 'https://drive.example.com/'||e else '' end, case when r < .7 then 'فاتورة' else '' end,
  '', '', case when old and r >= .03 then 'نعم' when not old and r >= .40 then 'نعم' else '' end, '', '', 'مسئول', d::text, 'EXP-'||lpad(e::text,7,'0'),
  case when old then 'approved' when r < .25 then '' else 'approved' end, 'مالى', d::text,
  case when (old and r >= .03) or (not old and r >= .40) then d::text else '' end,
  case when r < .7 then 'نعم' else 'لا' end, c.user_id, 'نقدى'
from (select e, random() r, d, d < date '2026-08-07' as old, ((e-1) % 12000 + 1) as cn
      from (select e, date '2025-09-01' + (random()*400)::int as d from generate_series(1,250000) e) q) x
join ebda.custodies c on c.id = 'cu'||x.cn
join lateral (select line_id from ebda.custody_lines where custody_id = c.id order by line_id limit 1) cl on true;

insert into ebda.employees(id,school_id,category,name,national_id,national_key,base_salary,active,archived,job,phone)
select 'em'||g, 'sc'||(g % 60 + 1), case when g % 5 = 0 then 'gov' else 'contract' end, 'موظف '||g, (29000000000000 + g)::text, (29000000000000 + g)::text,
       (4000 + random()*20000)::int, 'نعم', 'لا', 'معلم', '010'||g
from generate_series(1,8000) g;
insert into ebda.payslips(id,employee_id,emp_name,school_id,month,base,net,net_import,adjustments,staff_group)
select 'ps'||g||'_'||m, 'em'||g, 'موظف '||g, 'sc'||(g % 60 + 1), '2026-'||lpad(m::text,2,'0'), 8000, 7500, 7500, '{}'::jsonb, 'private'
from generate_series(1,8000) g, generate_series(1,12) m;

insert into ebda.audit_log(id,ts,actor,actor_role,action,entity,details,txid)
select 'al'||g, (now() - (g || ' seconds')::interval)::text, 'مستخدم '||(g % 500), 'مسئول العهدة', 'addExpense', 'ex'||g,
       '{"expense":{"amount":100,"description":"اختبار"}}', 1000000 + g
from generate_series(1,200000) g;
insert into ebda.audit_changes(actor_id,tbl,row_id,op,school_id,old_v,new_v,txid)
select 'cus'||(g % 8000 + 1), 'expenses', 'ex'||g, 'update', 'sc'||(g % 60 + 1), '{"approval":"pending"}', '{"approval":"approved"}', 1000000 + g
from generate_series(1,200000) g;

set session_replication_role = origin;
analyze;
select ebda.rebuild_line_agg();
