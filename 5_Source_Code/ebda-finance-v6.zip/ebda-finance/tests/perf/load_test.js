// اختبار حمل واقعى (k6) على PostgREST + PostgreSQL بنفس دالة الـ API المستخدمة فى Supabase.
// توزيع المستخدمين: 82% مسئولو عهد · 15% مديرون مباشرون · 3% مديرون ماليون · 0.1% أدمن
// كل مستخدم افتراضى: يسجّل الدخول مرة ← يحمّل لوحته (bootstrap) ← بحث/فلترة/تقارير/تسجيل مصروف مع «وقت تفكير» واقعى.
// التشغيل: k6 run -e BASE=http://127.0.0.1:3000 -e STAGES=... load_test.js
import http from "k6/http";
import { check, sleep } from "k6";
import { Counter, Trend } from "k6/metrics";

const BASE = __ENV.BASE || "http://127.0.0.1:3000";
const URL = BASE + "/rpc/api";
const HDR = { headers: { "Content-Type": "application/json" }, timeout: "60s" };
const apiErrors = new Counter("api_errors");
const loginTime = new Trend("t_login", true);

function parseStages(s) {
  // "60s:500,120s:500,60s:2000" → [{duration, target}]
  return s.split(",").map((x) => {
    const [d, t] = x.split(":");
    return { duration: d, target: Number(t) };
  });
}

export const options = {
  discardResponseBodies: true,
  scenarios: {
    users: {
      executor: "ramping-vus",
      startVUs: 0,
      stages: parseStages(__ENV.STAGES || "30s:100,60s:100"),
      gracefulRampDown: "30s",
      gracefulStop: "30s",
    },
  },
  thresholds: {
    http_req_failed: ["rate<0.05"],
    "http_req_duration{name:login}": ["p(95)<600000"],
    "http_req_duration{name:bootstrap_custody}": ["p(95)<600000"],
    "http_req_duration{name:search_mine}": ["p(95)<600000"],
    "http_req_duration{name:add_expense}": ["p(95)<600000"],
    "http_req_duration{name:submit_doc_link}": ["p(95)<600000"],
    "http_req_duration{name:bootstrap_manager}": ["p(95)<600000"],
    "http_req_duration{name:my_queue}": ["p(95)<600000"],
    "http_req_duration{name:approve}": ["p(95)<600000"],
    "http_req_duration{name:filter_school}": ["p(95)<600000"],
    "http_req_duration{name:report_holder}": ["p(95)<600000"],
    "http_req_duration{name:bootstrap_finance}": ["p(95)<600000"],
    "http_req_duration{name:fin_queue}": ["p(95)<600000"],
    "http_req_duration{name:fin_approve}": ["p(95)<600000"],
    "http_req_duration{name:report_budget}": ["p(95)<600000"],
    "http_req_duration{name:report_financial}": ["p(95)<600000"],
    "http_req_duration{name:bootstrap_admin}": ["p(95)<600000"],
    "http_req_duration{name:report_financial_admin}": ["p(95)<600000"],
  },
  summaryTrendStats: ["avg", "min", "med", "p(90)", "p(95)", "p(99)", "max"],
};

function roleOf(vu) {
  const r = vu % 1000;
  if (r === 0) return ["admin", "admin" + ((vu / 1000) % 10 | 0 || 1)];
  if (r <= 30) return ["fin", "fin" + (((vu / 1000) | 0) * 30 + r)];
  if (r <= 180) return ["mgr", "mgr" + ((((vu / 1000) | 0) * 150 + r) % 1500 || 1500)];
  return ["cus", "cus" + ((((vu / 1000) | 0) * 820 + r) % 8000 || 8000)];
}

function call(name, req, keepBody) {
  const p = Object.assign({ tags: { name } }, HDR);
  if (keepBody) p.responseType = "text";
  const res = http.post(URL, JSON.stringify({ req }), p);
  const ok = check(res, { [name + " 200"]: (r) => r.status === 200 });
  if (keepBody && res.status === 200) {
    let j = null;
    try {
      j = JSON.parse(res.body);
    } catch (e) {}
    if (!j || j.error) {
      apiErrors.add(1, { name });
      return null;
    }
    return j;
  }
  return ok ? {} : null;
}

let token = null;
let iter = 0;

export default function () {
  const [role, user] = roleOf(__VU);
  if (!token) {
    const t0 = Date.now();
    const r = call("login", { action: "login", username: user, pin: "1234" }, true);
    loginTime.add(Date.now() - t0);
    if (!r || !r.token) {
      sleep(5);
      return;
    }
    token = r.token;
  }
  const A = (action, extra) => Object.assign({ action, auth: { token } }, extra || {});
  iter++;
  const n = Number(user.replace(/\D/g, "")) || 1;

  if (role === "cus") {
    if (iter % 5 === 1) call("bootstrap_custody", A("bootstrap"));
    call("search_mine", A("searchExpenses", { filters: { mine: "1" }, page_size: 50 }));
    if (Math.random() < 0.3) {
      // تسجيل مصروف على عهدته وعلى بند موزع عليها (نفس معادلة توليد البيانات)
      const line = "ln" + ((n % 60) + 1) + "_" + (((n * 3 + 7) % 100) + 1);
      const r = call("add_expense", A("addExpense", { expense: { custody_id: "cu" + n, line_id: line, amount: 50 + Math.floor(Math.random() * 500), date: "2026-10-05", description: "اختبار حمل" } }), true);
      if (r && r.item && Math.random() < 0.5) call("submit_doc_link", A("uploadDoc", { id: r.item.id, link: "https://drive.example.com/load/" + r.item.id, filename: "فاتورة" }));
    }
    sleep(5 + Math.random() * 10);
  } else if (role === "mgr") {
    if (iter % 4 === 1) call("bootstrap_manager", A("bootstrap"));
    const q = call("my_queue", A("searchExpenses", { filters: { my_queue: "1" }, page_size: 20 }), true);
    if (q && q.rows && q.rows.length && Math.random() < 0.3) call("approve", A("updateExpense", { id: q.rows[0].id, patch: { approval: "approved", note: "اعتماد اختبار حمل" } }));
    call("filter_school", A("searchExpenses", { filters: { from: "2026-09-15", stages: ["pending_manager"] }, page_size: 50 }));
    if (Math.random() < 0.3) call("report_holder", A("report", { kind: "custodyHolder", filters: {} }));
    sleep(5 + Math.random() * 10);
  } else if (role === "fin") {
    if (iter % 4 === 1) call("bootstrap_finance", A("bootstrap"));
    const q = call("fin_queue", A("searchExpenses", { filters: { stages: ["pending_finance"] }, page_size: 20 }), true);
    if (q && q.rows && q.rows.length && Math.random() < 0.3) call("fin_approve", A("reviewExpense", { id: q.rows[0].id, patch: { fin_approval: "approved" } }));
    call(Math.random() < 0.5 ? "report_budget" : "report_financial", A("report", { kind: Math.random() < 0.5 ? "budget" : "financial", filters: {} }));
    sleep(8 + Math.random() * 12);
  } else {
    if (iter % 3 === 1) call("bootstrap_admin", A("bootstrap"));
    call("report_financial_admin", A("report", { kind: "financial", filters: {} }));
    sleep(20 + Math.random() * 20);
  }
}
