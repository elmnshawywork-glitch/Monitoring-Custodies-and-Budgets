"""قياس زمن وحجم كل استدعاء API مباشرة على قاعدة بيانات الأداء (بدون شبكة)."""
import json, time, psycopg2, sys, os
db = os.environ.get('PERF_DB', 'ebda_perf')
c = psycopg2.connect(host='/var/tmp/pg', port=5433, user='postgres', dbname=db); c.autocommit = True; cur = c.cursor()
def call(req):
    t = time.perf_counter(); cur.execute("select public.api(%s::jsonb)::text", (json.dumps(req),)); s = cur.fetchone()[0]; return (time.perf_counter() - t) * 1000, s
def tok(u):
    ms, s = call({'action': 'login', 'username': u, 'pin': '1234'}); return json.loads(s)['token'], ms
rows = []
for u in ['admin1', 'fin1', 'mgr1', 'cus1']:
    t, lm = tok(u)
    rows.append((u, 'login', lm, 0))
    for name, req in [('bootstrap', {'action': 'bootstrap'}),
                      ('searchExpenses p1', {'action': 'searchExpenses', 'filters': {}, 'page_size': 50}),
                      ('search filtered', {'action': 'searchExpenses', 'filters': {'school_id': 'sc5', 'stages': ['pending_manager'], 'from': '2026-09-10'}, 'page_size': 50}),
                      ('my_queue', {'action': 'searchExpenses', 'filters': {'my_queue': '1'}, 'page_size': 50}),
                      ('report budget', {'action': 'report', 'kind': 'budget', 'filters': {}}),
                      ('report holder', {'action': 'report', 'kind': 'custodyHolder', 'filters': {}}),
                      ('report financial', {'action': 'report', 'kind': 'financial', 'filters': {}})]:
        req = dict(req, auth={'token': t})
        ms, s = call(req)
        err = json.loads(s).get('error') if len(s) < 500 else None
        rows.append((u, name, ms, len(s.encode()), err))
for r in rows:
    print('%-7s %-18s %9.1f ms %12s bytes %s' % (r[0], r[1], r[2], r[3], r[4] if len(r) > 4 and r[4] else ''))
