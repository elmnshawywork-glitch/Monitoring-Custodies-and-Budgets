"""Tests for migration 005: full expense workflow (draft → direct manager → finance → settlement, return-for-edit, cancel,
un-approve), direct-manager assignment, separation of duties, ownership by user id, disabled lines/places, master data,
backup / restore (admin only, safety backup first, audit never lost), permission matrix enforced in the API.
Run: bash reset.sh 004 && python3 test_api_005.py"""
import json, subprocess, psycopg2, pathlib, os
HERE = pathlib.Path(__file__).parent
PSQL = ['psql', '-h', os.environ.get('PGHOST', '/var/tmp/pg'), '-p', os.environ.get('PGPORT', '5433'), '-U', 'postgres', '-q', '-v', 'ON_ERROR_STOP=1']
conn = psycopg2.connect(host=os.environ.get('PGHOST', '/var/tmp/pg'), port=int(os.environ.get('PGPORT', '5433')), user='postgres', dbname='postgres'); conn.autocommit = True
cur = conn.cursor()
fails = 0
def check(n, c, d=''):
    global fails; print(('PASS ' if c else 'FAIL ') + n + ('' if c else f' -> {d}')); fails += (not c)
def sql(q, *a):
    cur.execute("reset role"); cur.execute(q, a or None); return cur.fetchall() if cur.description else None
def one(q, *a): return sql(q, *a)[0][0]
def raw(req):
    cur.execute("set role anon"); cur.execute("select public.api(%s::jsonb)", (json.dumps(req),)); r = cur.fetchone()[0]; cur.execute("reset role"); return r
PINS = {'admin': '1234', 'custody1': '1111', 'custody2': '5555', 'acc1': '2222', 'sup1': '3333', 'sup2': '4444'}
def login(u, p=None): return raw({'action': 'login', 'username': u, 'pin': p or PINS[u]})
def api(who, action, **kw):
    t = login(who)['token']
    return raw(dict(action=action, auth={'token': t}, **kw))
ok = lambda r: isinstance(r, dict) and r.get('ok') is True
err = lambda r: isinstance(r, dict) and 'error' in r
badr = one("select id from ebda.schools where name like '%%بدر%%'")
dam = one("select id from ebda.schools where name like '%%دمياط%%'")

# ================================================================ 0) 005 على بيانات قائمة (مرتين): لا يتغير أى صف موجود
TABLES = ['users', 'schools', 'lines', 'custodies', 'tranches', 'expenses', 'requests', 'employees', 'payslips', 'audit_log', 'custody_names']
NEW = ['manager_id', 'dept', 'user_id', 'requester_id', 'active', 'created_by_id', 'approved_by_id', 'approval_note', 'submitted_at', 'returned_by',
       'returned_at', 'return_reason', 'fin_by_id', 'settled_by', 'settled_by_id', 'cancelled_at', 'cancelled_by', 'cancel_reason',
       'manager_user_id', 'birth_place', 'secondment_status', 'serial_no', 'supplier', 'doc_no', 'import_batch', 'import_row', 'ext_ref']
def snapshot():
    strip = ' '.join(f"- '{c}'" for c in NEW)
    return {t: sql(f"select md5(coalesce(string_agg(md5((to_jsonb(x) {strip} - 'pin')::text), ',' order by x.id), '')), count(*) from ebda.{t} x")[0] for t in TABLES}
pins_before = sql("select id, pin from ebda.users order by id")
before = snapshot()
mig = HERE.parent / 'supabase' / 'migrations' / '005_workflow_backup_performance.sql'
for _ in range(2): subprocess.run(PSQL + ['-f', str(mig)], check=True, capture_output=True)
after = snapshot()
check('005 on existing data (twice) keeps every existing row unchanged', before == after, [t for t in TABLES if before[t] != after[t]])
check('passwords untouched', sql("select id, pin from ebda.users order by id") == pins_before)
check('schema_version = 5', one("select value from ebda.config where key='schema_version'") == '5')
check('custody owner ids back-filled from usernames', sql("select id, user_id from ebda.custodies order by id") == [('c_b1', 'u_c1'), ('c_d1', 'u_c2')])
try:
    cur.execute("set role anon"); cur.execute("select count(*) from ebda.backups"); denied = False
except Exception as e:
    denied = 'permission denied' in str(e)
cur.execute("reset role")
check('ebda.backups not readable by the public (anon) role', denied)

# ================================================================ 1) الملكية بالمعرّف: تغيير اسم الدخول لا يفقد العهدة
r = api('admin', 'updateUser', id='u_c1', patch={'username': 'ahmed.m'})
check('admin renames custody1 → ahmed.m', ok(r), r)
check('custody follows the user (username cascaded, id unchanged)', sql("select \"user\", user_id from ebda.custodies where id='c_b1'") == [('ahmed.m', 'u_c1')])
PINS['ahmed.m'] = '1111'
b = api('ahmed.m', 'bootstrap')
check('renamed user still sees and owns his custody', any(c['id'] == 'c_b1' for c in b['custodies']))
check('old username cannot log in', err(login('custody1')))
api('admin', 'updateUser', id='u_c1', patch={'username': 'custody1'})
check('rename back keeps ownership', one("select \"user\" from ebda.custodies where id='c_b1'") == 'custody1')

# ================================================================ 2) التكليف: مدير مباشر لكل مسئول عهدة
r = api('admin', 'addUser', user={'username': 'sup3', 'pin': '7777', 'name': 'محمد على', 'role': 'supervisor', 'schools': badr})
sup3 = r['item']['id']; PINS['sup3'] = '7777'
sql("update ebda.users set must_reset='لا' where id=%s", sup3)
check('manager must exist', err(api('admin', 'updateUser', id='u_c1', patch={'manager_id': 'nope'})))
check('user cannot be his own manager', err(api('admin', 'updateUser', id='u_c1', patch={'manager_id': 'u_c1'})))
check('assign custody1 → manager «محمد على» (sup3)', ok(api('admin', 'updateUser', id='u_c1', patch={'manager_id': sup3})))
check('non-admin cannot assign managers', err(api('acc1', 'updateUser', id='u_c1', patch={'manager_id': 'u_s1'})))
b3 = api('sup3', 'bootstrap')
check('manager sees his team', [t['username'] for t in b3['team']] == ['custody1'], b3.get('team'))
check('custody carries the owner\'s manager id', [c['manager_id'] for c in b3['custodies'] if c['id'] == 'c_b1'] == [sup3])

# ================================================================ 3) دورة المصروف: مسودة ← إرسال ← المدير المباشر ← المالى ← التسوية
r = api('custody1', 'addExpense', expense={'custody_id': 'c_b1', 'line_id': 'l_b1', 'amount': 500, 'date': '2026-10-01', 'description': 'مسودة', 'draft': '1'})
check('save as draft', ok(r) and r['item']['approval'] == 'draft', r)
d1 = r['item']['id']
check('draft not counted in budget', not one("select ebda.counts_in_budget(e) from ebda.expenses e where id=%s", d1))
check('cannot approve a draft', err(api('sup3', 'updateExpense', id=d1, patch={'approval': 'approved'})))
check('owner can edit the draft', ok(api('custody1', 'updateExpense', id=d1, patch={'amount': 600})))
check('only owner (or admin) submits', err(api('sup3', 'submitExpense', id=d1)))
r = api('custody1', 'submitExpense', id=d1)
check('submit → pending direct manager', ok(r) and one("select approval from ebda.expenses where id=%s", d1) == 'pending' and one("select submitted_at from ebda.expenses where id=%s", d1) != '', r)
check('bad document link refused', err(api('custody1', 'addExpense', expense={'custody_id': 'c_b1', 'line_id': 'l_b1', 'amount': 10, 'date': '2026-10-01', 'description': 'x', 'doc_link': 'ftp://x'})))
r = api('custody1', 'addExpense', expense={'custody_id': 'c_b1', 'line_id': 'l_b1', 'amount': 1200, 'date': '2026-10-02', 'description': 'فاتورة طباعة',
                                           'doc_link': 'https://drive.google.com/file/d/abc/view', 'doc_type': 'فاتورة'})
w1 = r['item']['id']
check('expense with document link (opens directly)', ok(r) and r['item']['doc_url'].startswith('https://') and one("select doc_is_link from ebda.expenses where id=%s", w1) == 'نعم', r)
check('created_by_id recorded', one("select created_by_id from ebda.expenses where id=%s", w1) == 'u_c1')
# التكليف يُطبَّق فعلياً
check('in-scope manager who is NOT the assigned one cannot approve', err(api('sup1', 'updateExpense', id=w1, patch={'approval': 'approved'})))
check('finance manager cannot do the direct-manager approval', err(api('acc1', 'updateExpense', id=w1, patch={'approval': 'approved'})))
check('custody officer cannot approve', err(api('custody1', 'updateExpense', id=w1, patch={'approval': 'approved'})))
check('reject / return need a reason', err(api('sup3', 'updateExpense', id=w1, patch={'approval': 'returned'})))
r = api('sup3', 'updateExpense', id=w1, patch={'approval': 'returned', 'note': 'أرفق الفاتورة الأصلية'})
check('assigned manager returns for edit', ok(r) and sql("select approval, return_reason, returned_by from ebda.expenses where id=%s", w1)[0] == ('returned', 'أرفق الفاتورة الأصلية', 'محمد على'), r)
check('owner edits the returned expense', ok(api('custody1', 'updateExpense', id=w1, patch={'description': 'فاتورة طباعة (أصل)'})))
check('owner re-submits', ok(api('custody1', 'submitExpense', id=w1)) and one("select approval from ebda.expenses where id=%s", w1) == 'pending')
r = api('sup3', 'updateExpense', id=w1, patch={'approval': 'approved', 'note': 'تمام'})
check('assigned manager approves', ok(r) and sql("select approved_by, approved_by_id, approval_note from ebda.expenses where id=%s", w1)[0] == ('محمد على', sup3, 'تمام'), r)
check('decision is final for the manager (no second decision)', err(api('sup3', 'updateExpense', id=w1, patch={'approval': 'rejected', 'note': 'x'})))
check('approved expense waits for finance (stage)', one("select ebda.expense_stage(e) from ebda.expenses e where id=%s", w1) == 'pending_finance')
check('direct manager cannot do the financial review', err(api('sup3', 'reviewExpense', id=w1, patch={'fin_approval': 'approved'})))
r = api('acc1', 'reviewExpense', id=w1, patch={'fin_approval': 'returned', 'fin_note': 'المبلغ لا يطابق الفاتورة'})
check('finance returns for edit (reason required)', ok(r) and one("select ebda.expense_stage(e) from ebda.expenses e where id=%s", w1) == 'fin_returned', r)
check('owner changes the amount → needs a new manager approval', ok(api('custody1', 'updateExpense', id=w1, patch={'amount': 1150}))
      and one("select approval from ebda.expenses where id=%s", w1) == 'returned')
api('custody1', 'submitExpense', id=w1); api('sup3', 'updateExpense', id=w1, patch={'approval': 'approved', 'note': 'ok'})
check('back at financial review', one("select ebda.expense_stage(e) from ebda.expenses e where id=%s", w1) == 'pending_finance')
r = api('acc1', 'reviewExpense', id=w1, patch={'fin_approval': 'approved'})
check('finance approves (reviewed)', ok(r) and one("select ebda.expense_stage(e) from ebda.expenses e where id=%s", w1) == 'reviewed', r)
sql("update ebda.config set value='yes' where key='require_doc_to_settle'")
api('sup3', 'updateExpense', id=d1, patch={'approval': 'approved', 'note': 'ok'})
check('settling without a document is blocked when required', err(api('acc1', 'reviewExpense', id=d1, patch={'fin_approval': 'approved', 'settled': 'نعم'})))
r = api('acc1', 'reviewExpense', id=w1, patch={'settled': 'نعم', 'review_status': 'مستوفى'})
check('finance marks «تمت التسوية» (who + when)', ok(r) and sql("select settled, settled_by, settled_by_id<>'' , settled_at<>'' from ebda.expenses where id=%s", w1)[0] == ('نعم', 'سارة المحاسب', True, True), r)
sql("update ebda.config set value='no' where key='require_doc_to_settle'")
check('stage = settled', one("select ebda.expense_stage(e) from ebda.expenses e where id=%s", w1) == 'settled')
h = api('acc1', 'expenseHistory', id=w1)
acts = [x['action'] for x in h['items']]
check('workflow history (every step with actor + time)', ok(h) and acts.count('updateExpense') >= 3 and 'reviewExpense' in acts and 'submitExpense' in acts and all(x['ts'] and x['actor'] for x in h['items']), acts)
check('history not visible outside scope', err(api('custody2', 'expenseHistory', id=w1)))

# ================================================================ 4) الفصل بين المهام
sql("insert into ebda.custodies(id,label,holder,school_id,\"user\",code,status,approval) values('c_fin','عهدة سارة','سارة',%s,'acc1','CUST-900','open','approved')", badr)
sql("insert into ebda.tranches(id,custody_id,date,amount) values('t_fin','c_fin','2026-09-01',5000)")
api('admin', 'updateUser', id='u_a1', patch={'perms': '+expense.record'})
r = api('acc1', 'addExpense', expense={'custody_id': 'c_fin', 'line_id': 'l_b1', 'amount': 300, 'date': '2026-10-01', 'description': 'مصروف المدير المالى'})
fe = r['item']['id']
check('finance manager who holds a custody records his own expense', ok(r), r)
api('sup1', 'updateExpense', id=fe, patch={'approval': 'approved', 'note': 'ok'})
check('…the direct manager approves it', one("select approval from ebda.expenses where id=%s", fe) == 'approved')
check('finance manager cannot financially review his own expense', err(api('acc1', 'reviewExpense', id=fe, patch={'fin_approval': 'approved'})))
check('admin can (top authority)', ok(api('admin', 'reviewExpense', id=fe, patch={'fin_approval': 'approved'})))
api('admin', 'updateUser', id='u_s1', patch={'perms': '+expense.record'})
sql("update ebda.custodies set \"user\"='sup1' where id='c_fin'")
r = api('sup1', 'addExpense', expense={'custody_id': 'c_fin', 'line_id': 'l_b1', 'amount': 50, 'date': '2026-10-01', 'description': 'مدير مباشر ومسئول عهدة'})
check('manager who also holds a custody records an expense', ok(r), r)
check('…but cannot approve his own expense', err(api('sup1', 'updateExpense', id=r['item']['id'], patch={'approval': 'approved'})))
sql("update ebda.custodies set \"user\"='acc1' where id='c_fin'"); api('admin', 'updateUser', id='u_s1', patch={'perms': ''}); api('admin', 'updateUser', id='u_a1', patch={'perms': ''})

# ================================================================ 5) الإلغاء وإلغاء الاعتماد (الأدمن)
spent0 = float([c for c in api('admin', 'bootstrap')['custodies'] if c['id'] == 'c_b1'][0]['spent'])
check('only admin cancels an expense', err(api('acc1', 'cancelExpense', id=w1, reason='خطأ')))
check('cancel needs a reason', err(api('admin', 'cancelExpense', id=w1)))
check('admin cancels even after settlement', ok(api('admin', 'cancelExpense', id=w1, reason='تكرار فاتورة')))
check('cancelled expense kept (no delete) with reason', sql("select cancel_reason, cancelled_by from ebda.expenses where id=%s", w1)[0] == ('تكرار فاتورة', 'المدير العام'))
check('cancelled = out of budget and out of custody balance', not one("select ebda.counts_in_budget(e) from ebda.expenses e where id=%s", w1)
      and abs(float([c for c in api('admin', 'bootstrap')['custodies'] if c['id'] == 'c_b1'][0]['spent']) - (spent0 - 1150)) < 0.01)
check('no action on a cancelled expense', err(api('acc1', 'reviewExpense', id=w1, patch={'settled': ''})) and err(api('custody1', 'uploadDoc', id=w1, link='https://x.y')))
check('admin cannot hard-delete a settled expense (must cancel)', err(api('admin', 'deleteExpense', id='e3')))
check('admin un-approves (back to the direct manager)', ok(api('admin', 'unapproveExpense', id='e2', reason='مراجعة البند')) and
      sql("select approval, fin_approval from ebda.expenses where id='e2'")[0] == ('pending', ''))

# ================================================================ 6) المستندات المرفوعة لا تُرسَل مع تحميل الصفحة
sql("update ebda.expenses set doc_url='data:application/pdf;base64,AAAA', doc_is_link='لا', doc_name='f.pdf' where id='e1'")
b = api('acc1', 'bootstrap')
check('bootstrap does not ship file contents', not any(str(e.get('doc_url', '')).startswith('data:') for e in b['expenses']) and
      [e['doc_url'] for e in b['expenses'] if e['id'] == 'e1'] == ['inline:'])
check('getDoc opens it for an allowed user', api('acc1', 'getDoc', id='e1').get('url', '').startswith('data:'))
check('getDoc refused out of scope', err(api('custody2', 'getDoc', id='e1')))

# ================================================================ 7) تعطيل البنود والجهات (لا حذف للتاريخ)
check('only admin disables a line', err(api('acc1', 'setLineActive', id='l_b2', active='لا')))
check('admin disables «الزى المدرسى»', ok(api('admin', 'setLineActive', id='l_b2', active='لا')))
check('disabled line refuses new expenses', err(api('custody1', 'addExpense', expense={'custody_id': 'c_b1', 'line_id': 'l_b2', 'amount': 10, 'date': '2026-10-01', 'description': 'x'})))
check('disabled line still visible with its old expenses', any(l['id'] == 'l_b2' and l['active'] == 'لا' for l in api('admin', 'bootstrap')['lines'])
      and one("select count(*) from ebda.expenses where line_id='l_b2'") >= 2)
api('admin', 'setLineActive', id='l_b2', active='نعم')
check('disable a place (admin)', ok(api('admin', 'updateSchool', id=dam, patch={'active': 'لا'})))
b = api('admin', 'bootstrap')
check('disabled place kept for history (flagged inactive)', any(s['id'] == dam and s['active'] == 'لا' for s in b['schools']) and any(e['school_id'] == dam for e in b['expenses']))
api('admin', 'updateSchool', id=dam, patch={'active': 'نعم'})
check('user with custodies cannot be hard-deleted', err(api('admin', 'deleteUser', id='u_c2')))

# ================================================================ 8) Master Data: أنواع العهد وأنواع الموازنات
b = api('admin', 'bootstrap')
check('custody kinds + entity types served as master data', len(b['custody_kinds']) >= 5 and any(t['code'] == 'school' for t in b['entity_types']))
check('only admin edits custody kinds', err(api('acc1', 'saveCustodyKind', item={'name': 'جديد'})))
r = api('admin', 'saveCustodyKind', item={'name': 'عهدة صيانة دورية'})
check('add custody kind', ok(r))
check('duplicate kind refused', err(api('admin', 'saveCustodyKind', item={'name': 'عهده صيانه دوريه'})))
sql("update ebda.custodies set kind='عهدة صيانة دورية' where id='c_d1'")
check('rename kind updates existing custodies', ok(api('admin', 'saveCustodyKind', item={'id': r['id'], 'name': 'صيانة دورية'})) and one("select kind from ebda.custodies where id='c_d1'") == 'صيانة دورية')
check('disable kind', ok(api('admin', 'saveCustodyKind', item={'id': r['id'], 'name': 'صيانة دورية', 'active': 'لا'})))
check('add budget/entity type', ok(api('admin', 'saveEntityType', item={'label': 'مركز تدريب إقليمى'})))
check('only admin edits entity types', err(api('acc1', 'saveEntityType', item={'label': 'x'})))

# ================================================================ 9) النسخ الاحتياطى والاستعادة
check('non-admin cannot back up', err(api('acc1', 'createBackup')) and err(api('sup1', 'createBackup')) and err(api('custody1', 'createBackup')))
r = api('admin', 'createBackup', note='قبل التجربة')
bk = r['backup']
check('backup named with date + time', ok(r) and bk['name'].startswith('Backup_20') and len(bk['name']) >= len('Backup_2026-10-06_10-30'), bk.get('name'))
cnt = {t: one(f"select count(*) from ebda.{t}") for t in ['users', 'schools', 'lines', 'custodies', 'tranches', 'expenses', 'requests', 'employees', 'payslips', 'audit_log', 'config']}
check('backup includes every table (users, places, budgets, custodies, expenses, payroll, employees, audit…)',
      all(bk['counts'].get(t) == cnt[t] or t == 'audit_log' for t in cnt) and bk['counts']['audit_log'] >= 1, (bk['counts'], cnt))
check('backup listed for admin only', any(x['id'] == bk['id'] for x in api('admin', 'bootstrap')['backups']) and 'backups' not in api('acc1', 'bootstrap'))
dl = api('admin', 'downloadBackup', id=bk['id'])
check('admin can download the backup file', ok(dl) and 'expenses' in dl['data'] and '_meta' in dl['data'])
check('non-admin cannot download', err(api('acc1', 'downloadBackup', id=bk['id'])))
# تغييرات بعد النسخة
api('custody1', 'addExpense', expense={'custody_id': 'c_b1', 'line_id': 'l_b1', 'amount': 77, 'date': '2026-10-03', 'description': 'بعد النسخة'})
sql("update ebda.lines set allocated=1 where id='l_b1'")
audit_before = one("select count(*) from ebda.audit_log")
exp_sum = one("select sum(amount) from ebda.expenses where description<>'بعد النسخة'")
check('restore requires typing the backup name', err(api('admin', 'restoreBackup', id=bk['id'], confirm='x')))
check('non-admin cannot restore', err(api('acc1', 'restoreBackup', id=bk['id'], confirm=bk['name'])))
r = api('admin', 'restoreBackup', id=bk['id'], confirm=bk['name'])
check('restore ok + automatic safety backup first', ok(r) and r['safety_backup']['name'].startswith('SafetyBackup_'), r)
check('data back to the backup state', one("select count(*) from ebda.expenses where description='بعد النسخة'") == 0 and float(one("select allocated from ebda.lines where id='l_b1'")) == 37950
      and one("select sum(amount) from ebda.expenses") == exp_sum)
check('counts equal the backup', all(one(f"select count(*) from ebda.{t}") == bk['counts'][t] for t in ['users', 'schools', 'lines', 'custodies', 'expenses', 'employees', 'payslips']))
check('audit trail never lost by a restore (merged)', one("select count(*) from ebda.audit_log") >= audit_before)
check('schema version unchanged by restore', one("select value from ebda.config where key='schema_version'") == '5')
check('logins still work after restore', ok(login('acc1')) and ok(login('admin')))
sb = r['safety_backup']['id']
r2 = api('admin', 'restoreBackup', id=sb, confirm=r['safety_backup']['name'])
check('the safety backup can undo the restore', ok(r2) and one("select count(*) from ebda.expenses where description='بعد النسخة'") == 1)
api('admin', 'restoreBackup', id=bk['id'], confirm=bk['name'])

# ================================================================ 9b) البحث والتقارير على الخادم (داخل النطاق)
r = api('admin', 'searchExpenses', filters={}, page_size=2, page=1)
check('server-side search: total + page + sum', ok(r) and r['total'] == one("select count(*) from ebda.expenses") and len(r['rows']) == 2, r.get('total'))
r2 = api('admin', 'searchExpenses', filters={}, page_size=2, page=2)
check('pagination returns the next page', ok(r2) and not set(x['id'] for x in r['rows']) & set(x['id'] for x in r2['rows']))
check('custody officer search sees only his custodies', all(x['holder_id'] == 'u_c1' for x in api('custody1', 'searchExpenses', filters={}, page_size=500)['rows']))
check('out-of-scope place returns nothing', api('sup1', 'searchExpenses', filters={'school_id': dam})['total'] == 0)
r = api('admin', 'searchExpenses', filters={'stages': ['pending_manager'], 'school_id': badr})
check('multi-filter (stage + place)', ok(r) and all(x['stage'] == 'pending_manager' and x['school_id'] == badr for x in r['rows']) and r['total'] >= 1)
q3 = api('sup3', 'searchExpenses', filters={'my_queue': '1'})
assigned_other = [r[0] for r in sql("select id from ebda.users where manager_id<>'' and manager_id<>%s", sup3)]
check('direct manager queue = pending of his team (+ unassigned in his scope), never another manager\'s team',
      ok(q3) and q3['total'] >= 1 and any(x['holder_id'] == 'u_c1' for x in q3['rows'])
      and all(x['stage'] == 'pending_manager' and x['holder_id'] not in assigned_other for x in q3['rows']), q3.get('rows'))
check('unassigned in-scope manager has empty queue for custody1', all(x['holder_id'] != 'u_c1' for x in api('sup1', 'searchExpenses', filters={'my_queue': '1'})['rows']))
r = api('admin', 'report', kind='custodyHolder', filters={'holder_id': 'u_c1', 'school_id': badr})
rec = float(one("select sum(amount) from ebda.tranches where custody_id='c_b1'"))
spn = float(one("select coalesce(sum(amount),0) from ebda.expenses e where custody_id='c_b1' and ebda.active_on_custody(e)"))
check('custody-holder report summary = database (received / spent / remaining)', ok(r) and abs(r['summary']['received'] - rec) < .01 and abs(r['summary']['spent'] - spn) < .01
      and abs(r['summary']['remaining'] - (rec - spn)) < .01, r.get('summary'))
check('custody officer cannot report on another holder', api('custody1', 'report', kind='custodyHolder', filters={'holder_id': 'u_c2'})['summary']['count'] == 0)
r = api('admin', 'report', kind='budget', filters={'school_id': badr})
lm = api('admin', 'bootstrap')['line_months']
check('budget report spent = server line_months (same rule as the dashboard)', ok(r) and all(abs(x['spent'] - sum(lm.get(x['line_id'], [0] * 12))) < .01 for x in r['rows']))
check('budget report states', all(x['state'] in ('within', 'near', 'reached', 'over', 'none') for x in r['rows']))
r = api('admin', 'report', kind='financial', filters={})
check('comprehensive financial report', ok(r) and all(k in r['summary'] for k in ['budget_total', 'custody_total', 'expenses_total', 'pending_manager', 'pending_finance',
      'settled', 'unsettled', 'budget_remaining', 'over_lines', 'overdue_custodies']))
check('direct manager line_months limited to scope', set(api('sup1', 'bootstrap').get('line_months', {}).keys()) <= set(one("select coalesce(array_agg(id),'{}') from ebda.lines where school_id=%s", badr)))

# ================================================================ 9c) استيراد العاملين الآمن
emp0 = one("select count(*) from ebda.employees")
ROWS = [{'name': 'محمد أحمد السيد', 'national_id': '29001011201234', 'job': 'رياضيات', 'phone': '0100'},
        {'name': 'منى عبد الله', 'national_id': '٢٩٥٠٢٠٢١٢٠١٢٣٥', 'job': 'عربى'},
        {'name': 'محمد أحمد السيد', 'national_id': '29001011201234'},
        {'name': '', 'national_id': '123'},
        {'name': 'بدون رقم قومى', 'job': 'إدارى'}]
check('custody officer / direct manager cannot import employees', err(api('custody1', 'importEmployeesSafe', school_id=badr, rows=ROWS)) and err(api('sup1', 'importEmployeesSafe', school_id=badr, rows=ROWS)))
check('out-of-scope place refused', err(api('acc1', 'importEmployeesSafe', school_id=dam, rows=ROWS)))
r = api('acc1', 'importEmployeesSafe', school_id=badr, category='contract', rows=ROWS, mode='preview')
check('preview: new / duplicate / error detected, nothing saved', ok(r) and r['counts']['new'] == 3 and r['counts']['duplicate'] == 1 and r['counts']['error'] == 1
      and one("select count(*) from ebda.employees") == emp0, r.get('counts'))
check('preview flags missing data (warnings)', r['counts']['warnings'] >= 2 and any('الرقم القومى غير موجود' in x['reasons'] for x in r['rows']))
r = api('acc1', 'importEmployeesSafe', school_id=badr, category='contract', rows=ROWS, mode='commit')
check('commit adds only new valid rows', ok(r) and one("select count(*) from ebda.employees") == emp0 + 3)
check('Arabic-digit national ID normalised', one("select count(*) from ebda.employees where national_key='29502021201235'") == 1)
ROWS[0]['job'] = 'رياضيات (أول)'; ROWS[0]['phone'] = ''
r = api('acc1', 'importEmployeesSafe', school_id=badr, category='contract', rows=ROWS, mode='commit')
check('re-import: no new employees, changed one updated, others unchanged', r['counts']['new'] == 0 and r['counts']['updated'] == 1 and r['counts']['same'] == 2
      and one("select count(*) from ebda.employees") == emp0 + 3, r.get('counts'))
check('update keeps fields not in the file (empty never overwrites)', sql("select job, phone from ebda.employees where national_key='29001011201234'")[0] == ('رياضيات (أول)', '0100'))
eid = one("select id from ebda.employees where national_key='29001011201234'")
api('admin', 'importEmployeesSafe', school_id=dam, category='gov', rows=[{'name': 'محمد أحمد السيد', 'national_id': '29001011201234', 'secondment_status': 'ندب'}], mode='commit')
check('same person in another place = same employee id (moved, not duplicated)', one("select id from ebda.employees where national_key='29001011201234'") == eid
      and one("select count(*) from ebda.employees where national_key='29001011201234'") == 1 and one("select school_id from ebda.employees where id=%s", eid) == dam)
check('manual add with an existing national ID refused', err(api('admin', 'addEmployee', emp={'school_id': badr, 'name': 'نسخة', 'national_id': '29001011201234'})))
check('employee change history in the audit trail', one("select count(*) from ebda.audit_changes where tbl='employees' and row_id=%s and op='update'", eid) >= 2)

# ================================================================ 9d) جدول التجميع (agg_line_month) = إعادة الحساب من المصروفات دائماً
recalc = sql("""select line_id, coalesce(school_id,''), ebda.exp_fy(date), ebda.fy_month(date), sum(amount) from ebda.expenses x
               where ebda.counts_in_budget(x) and coalesce(line_id,'')<>'' and ebda.exp_fy(date) is not null group by 1,2,3,4 order by 1,2,3,4""")
stored = sql("select line_id, school_id, fy, m, amount from ebda.agg_line_month where amount <> 0 order by 1,2,3,4")
check('maintained budget aggregate equals a full recalculation after all workflow actions', [tuple(map(str, r)) for r in recalc] == [tuple(map(str, r)) for r in stored], (recalc[:3], stored[:3]))

# ================================================================ 10) مصفوفة الصلاحيات (من الـ API مباشرة — ليس إخفاء أزرار فقط)
def fresh_expense():
    return api('custody1', 'addExpense', expense={'custody_id': 'c_b1', 'line_id': 'l_b1', 'amount': 5, 'date': '2026-10-01', 'description': 'مصفوفة'})['item']['id']
M = {}
def cell(op, role, allowed): M.setdefault(op, {})[role] = allowed
for role in ['custody1', 'sup3', 'acc1', 'admin']:
    e = fresh_expense()
    cell('إضافة مصروف', role, ok(api(role, 'addExpense', expense={'custody_id': 'c_b1', 'line_id': 'l_b1', 'amount': 1, 'date': '2026-10-01', 'description': 'm'})))
    cell('رفع/رابط مستند', role, ok(api(role, 'uploadDoc', id=e, link='https://example.com/d.pdf')))
    cell('اعتماد مباشر', role, ok(api(role, 'updateExpense', id=e, patch={'approval': 'approved', 'note': 'm'})))
    if role != 'sup3': api('sup3', 'updateExpense', id=e, patch={'approval': 'approved', 'note': 'm'})
    cell('مراجعة مالية', role, ok(api(role, 'reviewExpense', id=e, patch={'fin_approval': 'approved'})))
    if role not in ('acc1', 'admin'): api('acc1', 'reviewExpense', id=e, patch={'fin_approval': 'approved'})
    cell('تسوية', role, ok(api(role, 'reviewExpense', id=e, patch={'settled': 'نعم'})))
    cell('إلغاء', role, ok(api(role, 'cancelExpense', id=e, reason='مصفوفة')))
    cell('حذف موازنة', role, ok(api(role, 'deleteBudget', school_id='nope', reason='x')) or 'المكان غير موجود' in str(api(role, 'deleteBudget', school_id='nope', reason='x')))
    cell('إدارة المستخدمين', role, ok(api(role, 'updateUser', id='u_x', patch={'name': 'معطل'})))
    cell('نسخ احتياطى', role, ok(api(role, 'backupInfo', id=bk['id'])))
EXPECT = {'إضافة مصروف': [1, 0, 0, 1], 'رفع/رابط مستند': [1, 0, 1, 1], 'اعتماد مباشر': [0, 1, 0, 1], 'مراجعة مالية': [0, 0, 1, 1],
          'تسوية': [0, 0, 1, 1], 'إلغاء': [0, 0, 0, 1], 'حذف موازنة': [0, 0, 0, 1], 'إدارة المستخدمين': [0, 0, 0, 1], 'نسخ احتياطى': [0, 0, 0, 1]}
print('\n%-18s %-10s %-10s %-10s %-6s' % ('العملية', 'مسئول عهدة', 'مدير مباشر', 'مدير مالى', 'Admin'))
for op, exp in EXPECT.items():
    got = [M[op][r] for r in ['custody1', 'sup3', 'acc1', 'admin']]
    print('%-18s %-10s %-10s %-10s %-6s' % (op, *['نعم' if g else 'لا' for g in got]))
    check('matrix: ' + op, got == [bool(x) for x in exp], got)

print(f'\n{fails} failures'); raise SystemExit(1 if fails else 0)
