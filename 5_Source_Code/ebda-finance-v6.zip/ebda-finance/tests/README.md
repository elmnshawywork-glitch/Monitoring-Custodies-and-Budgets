# الاختبارات

المتطلبات: PostgreSQL 16 محلى، وPython 3 مع `psycopg2` و`playwright`، وNode 20+، وتشغيل `npm install` داخل `frontend/` (لـ esbuild).
الإعداد الافتراضى: socket `/var/tmp/pg` ومنفذ `5433`. لتغييرهما استخدم `PGHOST` / `PGPORT` مع `reset.sh`، وعدّل الاتصال فى ملفات Python.

```bash
bash tests/reset.sh && python3 tests/test_api.py        # 76 — صلاحيات المرحلة 1
bash tests/reset.sh && python3 tests/test_api_002.py    # 32 — جلسات/تنبيهات/إشعارات/مستندات
bash tests/reset.sh 002 && python3 tests/test_api_003.py # 40 — 003 على بيانات قائمة: استيراد آمن، منع التكرار، تتبع القديم/الجديد
bash tests/reset.sh 003 && python3 tests/test_api_004.py # 65 — 004: الصلاحيات، دورة العهدة، حذف الموازنة، الرواتب
bash tests/reset.sh 004 && python3 tests/test_api_005.py # 118 — 005: دورة المصروف، المدير المباشر، الفصل بين المهام، الإلغاء، النسخ والاستعادة، البحث والتقارير، استيراد العاملين، مصفوفة الصلاحيات
bash tests/reset.sh && python3 tests/test_api_005_import.py   # 63 — استيراد ملف المصروفات والعهد (بقارئ الواجهة نفسه على tests/fixtures/مصاريف_مدرسة_ابدأ_نموذج.xlsx)
bash tests/reset.sh && (cd tests/import && python3 real_file_check.py "<مصاريف مدرسة ابدأ.xlsx>" "<ملف الموازنات.xlsx>")  # تجربة الملف الحقيقى
bash tests/reset.sh 003 && EBDA_ALSO_005=1 python3 tests/test_api_004.py   # اختبارات 004 بعد تطبيق 005 فوقها (التوافق للخلف)
bash tests/norm_parity.sh                               # تطابق تطبيع النص العربى بين الواجهة وقاعدة البيانات
(cd tests && node gs_mock_test.js)                      # مزامنة الشيت (محاكاة SpreadsheetApp)

# الخادم الوهمى (يحاكى Supabase REST + Edge Functions على :8765) — يخدم مجلد site/
#   site/      = index.html + bundle.js + styles.css + logo.png + vendor/ + config.js (SUPABASE_URL=http://localhost:8765)
#   site_edge/ = نفس الملفات مع EDGE_FUNCTIONS:true، ورابط رمزى site/site_edge -> ../site_edge
cd tests/e2e && python3 server.py &   # ملفات e2e تُشغَّل من المجلد الذى يحتوى site/
bash ../reset.sh && bash ../run_edge_test.sh            # 10 — الدالتان notify و docs
bash ../reset.sh && python3 e2e.py                      # 19 — متصفح: المرحلة 1
bash ../reset.sh && python3 e2e_v2.py                   # 21 — متصفح: المرحلتان 2 و3
bash ../reset.sh && EBDA_XL=<ملف موازنات Excel> python3 e2e_v3.py   # 43 — متصفح: المرحلة 4 (البنود العشرون)
bash ../reset.sh && python3 e2e_v5.py                   # 29 — متصفح: الإصدار 6 (دورة المصروف، الاستيراد بضغطة، التقارير، النسخ، الجوال)
bash ../reset.sh && EBDA_PAY_BADR=<ملف بدر> EBDA_PAY_DAM=<ملف دمياط> EBDA_PAY_HQ=<جدول مرتبات الشركة> EBDA_PAY_ACC=<ملف الحسابات> python3 e2e_v4.py   # 81 — متصفح: المرحلة 5
```
> `e2e_v2.py` يختار شهر السنة المالية الحالى تلقائيًا، لأن المصروفات تُسجَّل بتاريخ اليوم.

## اختبار الحمل (قاعدة بيانات منفصلة ebda_perf — ليست Production)
```bash
bash tests/perf/setup_perf_db.sh                         # 250 ألف مصروف، 12 ألف عهدة، ~10 آلاف مستخدم
bash tests/perf/run_load.sh r1000 "60s:1000,120s:1000,20s:0"
bash tests/perf/run10k.sh                                 # 10,000 مستخدم افتراضى
python3 tests/perf/summ.py r1000
```
النتائج والقراءة: `docs/PERFORMANCE_v6.md`.
