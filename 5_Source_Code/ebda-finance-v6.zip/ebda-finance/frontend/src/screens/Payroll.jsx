// الرواتب الشهرية (Payroll): استيراد احترافى · فترة لكل مكان وشهر · المؤثرات · الاعتماد · 3 تقارير من نفس البيانات
import { probe } from "../lib/api";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { fmt, yes } from "../lib/utils";
import { CAT_LABEL } from "../lib/model";
import { can } from "../lib/perms";
import { Modal, Field } from "../components/ui";
import { Salaries } from "./Salaries";
import { GROUPS, FIELDS, readPayrollWorkbook, sectionRows, fileTotalOf, matchEmployees, guessPlace, mapHeaders } from "../lib/payrollImport";
import { slipsOf, totals, groupOf, GROUP_ORDER, monthLabel, empOf, adjSummary, monthlyReport, accountingReport, companyReport, outputHTML } from "../lib/payroll";

export function PayrollHub(props) {
  const [view, setView] = useState("payroll");
  return (
    <div className="stack">
      <div className="seg">
        <button className={view === "payroll" ? "on" : ""} onClick={() => setView("payroll")}>
          الرواتب الشهرية
        </button>
        <button className={view === "old" ? "on" : ""} onClick={() => setView("old")}>
          بيانات العاملين والرواتب السابقة
        </button>
      </div>
      {view === "payroll" ? <PayrollScreen {...props} /> : <Salaries {...props} />}
    </div>
  );
}

const thisMonth = () => new Date().toISOString().slice(0, 7);

function PayrollScreen({ data: data0, act, showToast, setModal }) {
  // مع كثرة القسائم يرسل الخادم آخر شهور فقط؛ الشهر الأقدم يُطلب عند اختياره (payrollMonth)
  const win = data0.payslips_window || {};
  const months = useMemo(() => {
    const s = new Set(
      (data0.payslips || [])
        .map((p) => p.month)
        .concat((data0.payroll_periods || []).map((p) => p.month))
        .filter((m) => /^\d{4}-\d{2}$/.test(m)),
    );
    return Array.from(s).sort().reverse();
  }, [data0]);
  const [month, setMonth] = useState(months[0] || thisMonth());
  const [extra, setExtra] = useState({});
  useEffect(() => {
    if (!win.windowed || !win.from || !month || month >= win.from || extra[month]) return;
    probe("payrollMonth", { month })
      .then((r) => setExtra((x) => Object.assign({}, x, { [month]: r.payslips || [] })))
      .catch((e) => showToast(e.message, "err"));
  }, [month, win.windowed]);
  const data = useMemo(
    () => (extra[month] ? Object.assign({}, data0, { payslips: (data0.payslips || []).filter((p) => p.month !== month).concat(extra[month]) }) : data0),
    [data0, extra, month],
  );
  const placesWith = data.schools.filter((s) => (data.payslips || []).some((p) => String(p.school_id) === String(s.id) && p.month === month));
  const [place, setPlace] = useState("all");
  const [wizard, setWizard] = useState(false);
  const [adjust, setAdjust] = useState(null);
  const [q, setQ] = useState("");
  const comps = data.payroll_components || [];
  const slips = slipsOf(data, place, month).filter((p) => !q || String(p.emp_name).indexOf(q) >= 0);
  const T = totals(slips, comps);
  const period = place !== "all" ? (data.payroll_periods || []).find((p) => String(p.school_id) === place && p.month === month) : null;
  const periodsOfMonth = (data.payroll_periods || []).filter((p) => p.month === month);
  const run = async (a, p, msg) => {
    try {
      await act(a, p);
      showToast(msg);
    } catch (e) {}
  };
  const prev = (() => {
    const i = months.indexOf(month);
    return i >= 0 && months[i + 1] ? totals(slipsOf(data, place, months[i + 1]), comps) : null;
  })();

  return (
    <div className="stack">
      <div className="exec-bar">
        <div className="exec-title">
          <h2>الرواتب الشهرية — {monthLabel(month)}</h2>
          <span>
            {place === "all" ? placesWith.length + " مكان" : (data.schools.find((s) => String(s.id) === place) || {}).name}
            {period ? " · " + (period.status === "approved" ? "معتمدة بواسطة " + period.approved_by : "مسودة — مستوردة من " + (period.file_name || "ملف")) : ""}
          </span>
        </div>
        <div className="filters">
          <div className="qf">
            <span>الشهر</span>
            <input type="month" value={month} onChange={(e) => setMonth(e.target.value)} data-testid="pay-month" />
          </div>
          <div className="qf">
            <span>المكان</span>
            <select value={place} onChange={(e) => setPlace(e.target.value)} data-testid="pay-place">
              <option value="all">كل الأماكن</option>
              {data.schools.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
          <div className="qf">
            <span>بحث</span>
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="اسم الموظف" />
          </div>
        </div>
      </div>

      <div className="big-actions">
        {can(data, "payroll.import") && (
          <button className="big-action" onClick={() => setWizard(true)}>
            <span className="ba-ico">⤓</span>
            <b>استيراد رواتب العاملين</b>
            <small>من ملف Excel الشهرى — معاينة وتحقق قبل الحفظ</small>
          </button>
        )}
        {can(data, "payroll.import") && setModal && (
          <button className="big-action" onClick={() => setModal({ type: "importEmployees", payload: {} })} data-testid="emp-import-btn">
            <span className="ba-ico">👥</span>
            <b>استيراد بيانات العاملين</b>
            <small>كشف المتعاقدين / الحكوميين والمنتدبين — بدون تكرار</small>
          </button>
        )}
        <ReportButton title="التقرير الشهرى" sub="الحضور والغيابات والرواتب والأرصدة" disabled={place === "all"} hint="اختر مكاناً" make={() => monthlyReport(data, place, month)} name={"التقرير الشهرى " + month} />
        <ReportButton title="تقرير الحسابات" sub="مؤثرات الرواتب — تلقائى" disabled={!slips.length} make={() => accountingReport(data, month, place === "all" ? null : [place])} name={"تقرير الحسابات " + month} />
        <ReportButton title="الرواتب المرتبطة بالشركة" sub="جدول المرتبات + المطلوب تحويله" disabled={!(data.payslips || []).some((p) => p.month === month)} make={() => companyReport(data, month).html} name={"رواتب الشركة " + month} />
      </div>

      <div className="kpi-grid">
        <div className="kpi2">
          <span>إجمالى العاملين</span>
          <b>{T.n}</b>
          <small>{prev ? (T.n - prev.n >= 0 ? "+" : "") + (T.n - prev.n) + " عن الشهر السابق" : ""}</small>
        </div>
        <div className="kpi2">
          <span>الرواتب والحوافز الأساسية</span>
          <b>{fmt(Math.round(T.base))}</b>
        </div>
        <div className="kpi2">
          <span>إجمالى الخصومات</span>
          <b>{fmt(Math.round(T.ded + T.adjDed))}</b>
          <small>غياب {T.absent} يوم · أذونات {T.perms}</small>
        </div>
        <div className="kpi2">
          <span>الحوافز والإضافات</span>
          <b>{fmt(Math.round(T.gov + T.earn + T.allow))}</b>
          <small>حوافز حكوميين {fmt(Math.round(T.gov))}</small>
        </div>
        <div className="kpi2 pos">
          <span>إجمالى صافى الرواتب</span>
          <b>{fmt(Math.round(T.net))}</b>
          <small>{prev && prev.net ? (T.net >= prev.net ? "▲ " : "▼ ") + Math.round(Math.abs((T.net - prev.net) / prev.net) * 100) + "% عن الشهر السابق" : ""}</small>
        </div>
      </div>

      {periodsOfMonth.length > 0 && (
        <div className="panel">
          <h3 className="panel-title">حالة رواتب {monthLabel(month)}</h3>
          <div className="table-wrap">
            <table className="tbl">
              <thead>
                <tr>
                  <th>المكان</th>
                  <th>العاملون</th>
                  <th>صافى الرواتب</th>
                  <th>الملف</th>
                  <th>الحالة</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {periodsOfMonth.map((p) => {
                  const sl = slipsOf(data, p.school_id, month);
                  const t = totals(sl, comps);
                  return (
                    <tr key={p.id}>
                      <td>{(data.schools.find((s) => String(s.id) === String(p.school_id)) || {}).name}</td>
                      <td className="num">{t.n}</td>
                      <td className="num">{fmt(t.net)}</td>
                      <td style={{ fontSize: 12 }}>
                        {p.file_name}
                        <span className="cust-sub">
                          {p.imported_by} · {String(p.imported_at || "").slice(0, 16)}
                        </span>
                      </td>
                      <td>
                        <span className={"chip " + (p.status === "approved" ? "green" : "amber")}>{p.status === "approved" ? "معتمدة" : "مسودة"}</span>
                      </td>
                      <td>
                        {p.status !== "approved" && can(data, "payroll.approve") && (
                          <button className="btn primary sm" onClick={() => run("approvePayroll", { school_id: p.school_id, month }, "تم اعتماد رواتب الشهر")}>
                            اعتماد
                          </button>
                        )}
                        {p.status === "approved" && data.me.role === "manager" && (
                          <button className="btn ghost sm" onClick={() => run("reopenPayroll", { school_id: p.school_id, month }, "تمت إعادة فتح الرواتب")}>
                            إعادة فتح
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {GROUP_ORDER.map((g) => {
        const rows = slips.filter((p) => groupOf(p) === g);
        if (!rows.length) return null;
        const t = totals(rows, comps);
        return (
          <div className="panel" key={g}>
            <h3 className="panel-title">
              {GROUPS[g]} <small>· {rows.length} · صافى {fmt(t.net)}</small>
            </h3>
            <div className="table-wrap">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>الاسم</th>
                    {place === "all" && <th>المكان</th>}
                    <th>{g === "gov" ? "الحافز الأساسى" : "الراتب"}</th>
                    <th>الغياب / الأذونات</th>
                    {g === "private" && <th>رصيد الإجازات</th>}
                    <th>الخصومات</th>
                    <th>المؤثرات</th>
                    <th>الصافى</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((p) => {
                    const locked = (data.payroll_periods || []).some((x) => String(x.school_id) === String(p.school_id) && x.month === p.month && x.status === "approved");
                    const adj = Object.keys(p.adjustments || {}).length;
                    return (
                      <tr key={p.id}>
                        <td>
                          <b>{p.emp_name}</b>
                          <span className="cust-sub">{p.job}</span>
                        </td>
                        {place === "all" && <td style={{ fontSize: 12 }}>{(data.schools.find((s) => String(s.id) === String(p.school_id)) || {}).name}</td>}
                        <td className="num">{fmt(p.base)}</td>
                        <td className="num">
                          {Number(p.absent_days || 0)} / {Number(p.permissions || 0)}
                        </td>
                        {g === "private" && (
                          <td className="num">
                            {Number(p.leave_balance || 0)}
                            <span className="cust-sub">من {Number(p.leave_opening || 0)}</span>
                          </td>
                        )}
                        <td className="num">{fmt(p.ded_total)}</td>
                        <td style={{ fontSize: 12 }}>{adj ? adjSummary({ adjustments: p.adjustments }, comps) : "—"}</td>
                        <td className="num" style={{ fontWeight: 800 }}>
                          {fmt(p.net)}
                          {Math.abs(Number(p.net || 0) - Number(p.net_import || 0)) > 0.005 && <span className="cust-sub">قبل المؤثرات {fmt(p.net_import)}</span>}
                        </td>
                        <td>
                          {can(data, "payroll.import") && !locked && (
                            <button className="btn ghost sm" onClick={() => setAdjust(p)}>
                              المؤثرات
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        );
      })}
      {!slips.length && <div className="empty">لا توجد رواتب مستوردة لـ {monthLabel(month)}{place !== "all" ? " فى هذا المكان" : ""} — استخدم «استيراد رواتب العاملين».</div>}
      {wizard && (
        <PayrollImportWizard
          data={data}
          act={act}
          defaultMonth={month}
          close={() => setWizard(false)}
          onDone={(m, msg) => (setWizard(false), setMonth(m), showToast(msg))}
        />
      )}
      {adjust && <AdjustModal data={data} p={adjust} act={act} showToast={showToast} close={() => setAdjust(null)} />}
    </div>
  );
}

function ReportButton({ title, sub, make, name, disabled, hint }) {
  return (
    <div className={"big-action report " + (disabled ? "off" : "")}>
      <span className="ba-ico">📄</span>
      <b>{title}</b>
      <small>{disabled && hint ? hint : sub}</small>
      <span className="rep-btns">
        <button className="btn ghost sm" disabled={disabled} onClick={() => outputHTML("print", name, make())}>
          طباعة / PDF
        </button>
        <button className="btn ghost sm" disabled={disabled} onClick={() => outputHTML("excel", name, make())}>
          Excel
        </button>
      </span>
    </div>
  );
}

// ============================================================================ المؤثرات على الراتب
function AdjustModal({ data, p, act, showToast, close }) {
  const comps = (data.payroll_components || []).filter((c) => yes(c.active));
  const [vals, setVals] = useState(() => Object.assign({}, p.adjustments || {}));
  const [note, setNote] = useState(p.note || "");
  const [busy, setBusy] = useState(false);
  const delta = comps.reduce((a, c) => a + (c.kind === "earning" ? 1 : -1) * (Number(vals[c.code]) || 0), 0);
  const e = empOf(data, p);
  return (
    <Modal title={"المؤثرات على راتب: " + p.emp_name} close={close} wide>
      <div className="kv" style={{ marginBottom: 10 }}>
        <div>
          <span>الوظيفة</span>
          <b>{p.job || e.job}</b>
        </div>
        <div>
          <span>الراتب / الحافز</span>
          <b>{fmt(p.base)}</b>
        </div>
        <div>
          <span>خصومات الحضور</span>
          <b>{fmt(p.ded_total)}</b>
        </div>
        <div>
          <span>الصافى من التقرير الشهرى</span>
          <b>{fmt(p.net_import)}</b>
        </div>
      </div>
      <div className="plan-grid" style={{ gridTemplateColumns: "repeat(3,minmax(0,1fr))" }}>
        {comps.map((c) => (
          <label key={c.code}>
            <span>
              {c.name} {c.kind === "earning" ? "(+)" : "(−)"}
            </span>
            <input inputMode="decimal" value={vals[c.code] || ""} onChange={(ev) => setVals(Object.assign({}, vals, { [c.code]: ev.target.value }))} />
          </label>
        ))}
      </div>
      <Field label="ملاحظات">
        <input value={note} onChange={(ev) => setNote(ev.target.value)} />
      </Field>
      <div className="cust-calc" style={{ gridTemplateColumns: "repeat(3,minmax(0,1fr))" }}>
        <div>
          <span>الصافى قبل المؤثرات</span>
          <b>{fmt(p.net_import)}</b>
        </div>
        <div>
          <span>صافى المؤثرات</span>
          <b className={delta < 0 ? "red" : "green"}>{fmt(delta)}</b>
        </div>
        <div>
          <span>الصافى النهائى</span>
          <b>{fmt(Number(p.net_import || 0) + delta)}</b>
        </div>
      </div>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <span className="spacer" />
        <button
          className="btn primary"
          disabled={busy}
          onClick={async () => {
            setBusy(true);
            try {
              const adj = {};
              Object.entries(vals).forEach(([k, v]) => Number(v) > 0 && (adj[k] = Number(v)));
              await act("adjustPayslip", { id: p.id, adjustments: adj, note });
              showToast("تم حفظ المؤثرات");
              close();
            } catch (err) {
              setBusy(false);
            }
          }}
        >
          حفظ
        </button>
      </div>
    </Modal>
  );
}

// ============================================================================ معالج استيراد الرواتب
function PayrollImportWizard({ data, act, defaultMonth, close, onDone }) {
  const [step, setStep] = useState(1);
  const [sheets, setSheets] = useState([]);
  const [fileName, setFileName] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [month, setMonth] = useState(defaultMonth);
  const [showMap, setShowMap] = useState(null);
  const [result, setResult] = useState(null);
  const fileRef = useRef();
  const extra = useMemo(() => {
    try {
      return JSON.parse(data.payroll_map || "{}") || {};
    } catch (e) {
      return {};
    }
  }, [data]);

  const read = async (f) => {
    if (!f) return;
    setErr("");
    setBusy(true);
    try {
      const raw = await readPayrollWorkbook(f, extra);
      const list = raw
        .filter((s) => s.sections.length)
        .map((s) => {
          const g = guessPlace(data.schools, s);
          return Object.assign(s, { include: true, school_id: g ? String(g.id) : "" });
        });
      if (!list.length) {
        setErr("لم يتم العثور على جداول رواتب — يجب أن يحتوى الملف عمود «إسم الموظف» أو «إسم العامل».");
        setBusy(false);
        return;
      }
      const m = list.map((s) => s.month).find((x) => x && list.some((y) => y.sections.some((sec) => sec.map.net != null)));
      if (m) setMonth(m);
      setSheets(list);
      setFileName(f.name);
      setStep(2);
    } catch (e) {
      setErr(e.message || "تعذّر قراءة الملف");
    }
    setBusy(false);
  };
  const upd = (i, patch) => setSheets(sheets.map((s, j) => (j === i ? Object.assign({}, s, patch) : s)));
  const updSec = (i, k, patch) => upd(i, { sections: sheets[i].sections.map((x, j) => (j === k ? Object.assign({}, x, patch) : x)) });

  const prepared = sheets.map((s) =>
    Object.assign({}, s, {
      secs: s.sections.map((sec) => {
        const rows = matchEmployees(data, s.school_id, sectionRows(sec), month);
        const sum = rows.reduce((a, r) => a + Number(r.net || 0), 0);
        return { sec, rows, sum, fileTotal: fileTotalOf(sec) };
      }),
    }),
  );
  const active = prepared.filter((s) => s.include);
  const allRows = active.flatMap((s) => s.secs.flatMap((x) => x.rows));
  const errors = allRows.filter((r) => r._errors.length);
  const dups = allRows.filter((r) => r._dup);
  const unmapped = active.filter((s) => !s.school_id);
  const locked = active.filter((s) => (data.payroll_periods || []).some((p) => String(p.school_id) === s.school_id && p.month === month && p.status === "approved"));
  const cnt = {
    newEmp: allRows.filter((r) => r._emp === "new" && !r._dup).length,
    oldEmp: allRows.filter((r) => r._emp === "existing" && !r._dup).length,
    newSlip: allRows.filter((r) => r._slip === "new" && !r._dup).length,
    updSlip: allRows.filter((r) => r._slip === "update" && !r._dup).length,
    warn: allRows.filter((r) => r._warnings.length).length,
  };

  const confirm = async () => {
    if (unmapped.length) return setErr("اختر المكان لكل شيت.");
    if (errors.length) return setErr("صحّح الأخطاء فى الملف أولاً (" + errors.length + " سطر).");
    if (locked.length) return setErr("رواتب " + monthLabel(month) + " معتمدة لبعض الأماكن — يجب إعادة فتحها أولاً.");
    setBusy(true);
    setErr("");
    let sum = { employees_added: 0, payslips_added: 0, payslips_updated: 0 };
    try {
      // الإعداد المخصص للأعمدة يُحفظ ليُستخدم فى المرات القادمة
      const custom = {};
      active.forEach((s) =>
        s.sections.forEach((sec) => {
          const auto = mapHeaders(sec.headers, extra);
          Object.keys(sec.map).forEach((k) => {
            if (sec.map[k] != null && auto[k] !== sec.map[k]) (custom[k] = custom[k] || []).push(sec.headers[sec.map[k]]);
          });
        }),
      );
      if (Object.keys(custom).length) {
        const merged = Object.assign({}, extra);
        Object.keys(custom).forEach((k) => (merged[k] = Array.from(new Set((merged[k] || []).concat(custom[k])))));
        await act("savePayrollMap", { map: JSON.stringify(merged) });
      }
      const bySchool = {};
      active.forEach((s) => s.secs.forEach((x) => x.rows.filter((r) => !r._dup).forEach((r) => (bySchool[s.school_id] = bySchool[s.school_id] || []).push(r))));
      for (const sid of Object.keys(bySchool)) {
        const rows = bySchool[sid].map((r) => {
          const o = {};
          Object.keys(r).forEach((k) => k[0] !== "_" && k !== "excelRow" && (o[k] = r[k]));
          return o;
        });
        const res = await act("importPayroll", { school_id: sid, month, file_name: fileName, rows });
        Object.keys(sum).forEach((k) => (sum[k] += Number(res[k] || 0)));
      }
      setResult(sum);
      setStep(3);
    } catch (e) {
      setErr(e.message || "تعذّر الاستيراد");
    }
    setBusy(false);
  };

  return (
    <Modal title="استيراد رواتب العاملين" close={close} xl>
      <div className="wizard-steps">
        {["اختيار الملف", "المعاينة والتحقق", "النتيجة"].map((t, i) => (
          <span key={i} className={"wstep " + (step === i + 1 ? "on" : step > i + 1 ? "done" : "")}>
            <b>{i + 1}</b> {t}
          </span>
        ))}
      </div>
      {err && <div className="warn-banner over">{err}</div>}
      {step === 1 && (
        <>
          <p className="hint">
            يقرأ النظام تقرير الحضور والرواتب الشهرى (أقسام التعاقد الخاص · الانتداب الحكومى · النظافة · الأمن) أو جدول مرتبات العاملين بالشركة،
            ويتعرّف على المكان والشهر والأعمدة تلقائياً. <b>لا يُنشأ الموظف مرة أخرى كل شهر</b> — يتم التعرف عليه بالرقم القومى ثم بالاسم،
            ويُحدَّث سطر الشهر إن كان مستورداً من قبل.
          </p>
          <div className="file-drop" onClick={() => fileRef.current && fileRef.current.click()}>
            <div style={{ fontSize: 28 }}>📊</div>
            <b>{busy ? "جارٍ القراءة…" : "اختر ملف الرواتب (.xlsx)"}</b>
            <span>اضغط هنا لاختيار الملف</span>
            <input ref={fileRef} type="file" hidden accept=".xlsx,.xls" onChange={(e) => read(e.target.files[0])} />
          </div>
        </>
      )}
      {step === 2 && (
        <>
          <div className="filters" style={{ marginBottom: 10 }}>
            <div className="qf">
              <span>شهر الرواتب</span>
              <input type="month" value={month} onChange={(e) => setMonth(e.target.value)} data-testid="wiz-month" />
            </div>
            <span className="hint" style={{ alignSelf: "center" }}>
              📎 {fileName}
            </span>
          </div>
          {prepared.map((s, i) => (
            <div key={s.name} className={"sheet-row " + (s.include ? "" : "off")} style={{ gridTemplateColumns: "200px 1fr", marginBottom: 8 }}>
              <label className="check">
                <input type="checkbox" checked={s.include} onChange={(e) => upd(i, { include: e.target.checked })} /> <b>{s.name}</b>
              </label>
              <select value={s.school_id} onChange={(e) => upd(i, { school_id: e.target.value })}>
                <option value="">— اختر المكان —</option>
                {data.schools.map((x) => (
                  <option key={x.id} value={x.id}>
                    {CAT_LABEL[x.category || "school"] + " · " + x.name}
                  </option>
                ))}
              </select>
              {s.include && (
                <div className="sec-list">
                  {s.secs.map((x, k) => {
                    const ok = x.fileTotal == null || Math.abs(x.fileTotal - x.sum) < 1;
                    return (
                      <div key={k} className="sec-row">
                        <select value={x.sec.group} onChange={(e) => updSec(i, k, { group: e.target.value })}>
                          {Object.keys(GROUPS).map((g) => (
                            <option key={g} value={g}>
                              {GROUPS[g]}
                            </option>
                          ))}
                        </select>
                        <span>{x.rows.length} سطر</span>
                        <span>صافى {fmt(x.sum)}</span>
                        {x.rows.every((r) => r.employee_only) ? (
                          <span className="chip navy">بيانات العاملين فقط</span>
                        ) : x.fileTotal != null ? (
                          <span className={"chip " + (ok ? "green" : "red")}>{ok ? "✓ مطابق لإجمالى الملف " + fmt(x.fileTotal) : "✗ إجمالى الملف " + fmt(x.fileTotal)}</span>
                        ) : (
                          <span className="chip gray">لا يوجد إجمالى للمقارنة</span>
                        )}
                        <button className="btn ghost sm" onClick={() => setShowMap(showMap === i + ":" + k ? null : i + ":" + k)}>
                          ربط الأعمدة
                        </button>
                        {showMap === i + ":" + k && (
                          <div className="map-grid">
                            {FIELDS.map(([key, label]) => (
                              <label key={key}>
                                <span>{label}</span>
                                <select
                                  value={x.sec.map[key] == null ? "" : x.sec.map[key]}
                                  onChange={(e) => updSec(i, k, { map: Object.assign({}, x.sec.map, { [key]: e.target.value === "" ? null : Number(e.target.value) }) })}
                                >
                                  <option value="">— غير موجود —</option>
                                  {x.sec.headers.map((h, hi) =>
                                    h ? (
                                      <option key={hi} value={hi}>
                                        {h}
                                      </option>
                                    ) : null,
                                  )}
                                </select>
                              </label>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
          <div className="imp-kpis" style={{ gridTemplateColumns: "repeat(6,minmax(0,1fr))" }}>
            <div className="imp-kpi teal">
              <b>{cnt.newEmp}</b>
              <span>موظف جديد</span>
            </div>
            <div className="imp-kpi green">
              <b>{cnt.oldEmp}</b>
              <span>موظف موجود (لن يتكرر)</span>
            </div>
            <div className="imp-kpi navy">
              <b>{cnt.newSlip}</b>
              <span>سطر شهر جديد</span>
            </div>
            <div className="imp-kpi amber">
              <b>{cnt.updSlip}</b>
              <span>تحديث سطر الشهر</span>
            </div>
            <div className="imp-kpi gray">
              <b>{dups.length}</b>
              <span>مكرر فى الملف</span>
            </div>
            <div className="imp-kpi red">
              <b>{errors.length}</b>
              <span>أخطاء</span>
            </div>
          </div>
          <div className="table-wrap" style={{ maxHeight: 320, overflow: "auto" }}>
            <table className="tbl imp-tbl">
              <thead>
                <tr>
                  <th>الموظف</th>
                  <th>القسم</th>
                  <th>الموظف فى النظام</th>
                  <th>الراتب</th>
                  <th>الخصومات</th>
                  <th>الصافى</th>
                  <th>ملاحظات التحقق</th>
                </tr>
              </thead>
              <tbody>
                {active.flatMap((s) =>
                  s.secs.flatMap((x) =>
                    x.rows.map((r, ri) => (
                      <tr key={s.name + x.sec.headerRow + ri} className={r._errors.length ? "def" : ""}>
                        <td>
                          {r.name}
                          <span className="cust-sub">
                            سطر {r.excelRow}
                            {r.national_id ? " · " + r.national_id : ""}
                          </span>
                        </td>
                        <td style={{ fontSize: 12 }}>{GROUPS[r.staff_group]}</td>
                        <td>
                          <span className={"chip " + (r._dup ? "gray" : r._emp === "new" ? "teal" : "green")}>{r._dup ? "مكرر" : r._emp === "new" ? "جديد" : "موجود"}</span>
                          {r._slip === "update" && <span className="chip amber" style={{ marginInlineStart: 4 }}>تحديث الشهر</span>}
                        </td>
                        <td className="num">{r.salary ? fmt(r.salary) : "—"}</td>
                        <td className="num">{r.ded_total ? fmt(r.ded_total) : "—"}</td>
                        <td className="num">{r.employee_only ? "—" : fmt(r.net)}</td>
                        <td style={{ fontSize: 12 }} className={r._errors.length ? "red" : ""}>
                          {r._errors.concat(r._warnings).join(" · ") || "✓"}
                        </td>
                      </tr>
                    )),
                  ),
                )}
              </tbody>
            </table>
          </div>
          <div className="modal-actions">
            <button className="btn ghost" onClick={() => setStep(1)}>
              رجوع
            </button>
            <span className="spacer" />
            <span className="imp-sum">
              {cnt.warn ? cnt.warn + " تحذير للمراجعة (لا يمنع الاستيراد) · " : ""}الشهر: {monthLabel(month)}
            </span>
            <button className="btn primary" disabled={busy || !active.length || !!errors.length || !!unmapped.length} onClick={confirm}>
              {busy ? "جارٍ الاستيراد…" : "تأكيد الاستيراد"}
            </button>
          </div>
        </>
      )}
      {step === 3 && result && (
        <>
          <div className="imp-done">
            <div style={{ fontSize: 34 }}>✅</div>
            <h3>تم استيراد رواتب {monthLabel(month)}</h3>
          </div>
          <div className="mini-kpis">
            <div>
              <span>موظفون جدد</span>
              <b className="teal">{result.employees_added}</b>
            </div>
            <div>
              <span>سطور شهر جديدة</span>
              <b>{result.payslips_added}</b>
            </div>
            <div>
              <span>سطور حُدّثت</span>
              <b className="amber">{result.payslips_updated}</b>
            </div>
          </div>
          <p className="hint">الرواتب «مسودة» حتى يعتمدها المدير المالى. كل العمليات مسجّلة فى «تتبع التعديلات».</p>
          <div className="modal-actions">
            <span className="spacer" />
            <button className="btn primary" onClick={() => onDone(month, "تم استيراد الرواتب")}>
              تم
            </button>
          </div>
        </>
      )}
    </Modal>
  );
}
