import { AdminCustodyNames, AdminPayComponents } from "./AdminMasters";
import { AdminCustodyKinds, AdminEntityTypes, AdminActivation, AdminWorkflowSettings, AdminBackups } from "./AdminV6";
import React, { useState } from "react";
import { exportAs, fmt, yes } from "../lib/utils";
import { CAT_LABEL, ROLE_LABEL } from "../lib/model";
import { Catalog } from "../components/ui";

export function AuditLog({ data }) {
  let l = {
      addExpense: "تسجيل صرف",
      addCentral: "شراء مركزى",
      updateExpense: "تعديل/اعتماد مصروف",
      reviewExpense: "مراجعة مستند",
      deleteExpense: "حذف مصروف",
      uploadDoc: "رفع مستند",
      addTranche: "إضافة عهدة/دفعة",
      addCustody: "إنشاء عهدة",
      updateCustody: "تعديل عهدة",
      deleteCustody: "حذف عهدة",
      addSchool: "إضافة جهة",
      updateSchool: "تعديل جهة",
      deleteSchool: "حذف جهة",
      addLine: "إضافة بند",
      updateLine: "تعديل بند",
      deleteLine: "حذف بند",
      importBudget: "استيراد موازنة",
      addUser: "إضافة مستخدم",
      updateUser: "تعديل مستخدم",
      deleteUser: "حذف مستخدم",
      resetPin: "تصفير كلمة سر",
      setPassword: "تغيير كلمة سر",
      addSalary: "إضافة راتب",
      updateSalary: "تعديل راتب",
      deleteSalary: "حذف راتب",
      importSalaries: "استيراد رواتب",
      addTempBudget: "موازنة مؤقتة",
      deleteTempBudget: "حذف موازنة مؤقتة",
      addRequest: "طلب عهدة",
      updateRequestItem: "تعديل بند طلب",
      deleteRequestItem: "حذف بند طلب",
      decideRequest: "قرار على طلب",
      transferRequest: "تحويل طلب",
      addEmployee: "إضافة موظف",
      updateEmployee: "تعديل موظف",
      archiveEmployee: "أرشفة موظف",
      restoreEmployee: "استرجاع موظف",
      deleteEmployee: "حذف موظف نهائى",
      importEmployees: "استيراد عاملين",
      addPayslip: "إضافة راتب شهرى",
      updatePayslip: "تعديل راتب شهرى",
      deletePayslip: "حذف راتب شهرى",
      addPayslipsBatch: "توليد كشف رواتب",
    },
    e = data.audit || [],
    [n, i] = useState("all"),
    [u, s] = useState("all"),
    [o, d] = useState(""),
    [c, p] = useState(""),
    m = Array.from(new Set(e.map((f) => f.actor).filter(Boolean))),
    r = Array.from(new Set(e.map((f) => f.action).filter(Boolean))),
    v = e.filter(
      (f) =>
        (n === "all" || f.action === n) &&
        (u === "all" || f.actor === u) &&
        (!o || (f.ts || "").slice(0, 10) >= o) &&
        (!c || (f.ts || "").slice(0, 10) <= c),
    ),
    [S, N] = useState("excel"),
    b = () => {
      let f = ["التوقيت", "المستخدم", "الدور", "الإجراء", "التفاصيل"],
        h = v.map((y) => [
          String(y.ts || "")
            .replace("T", " ")
            .slice(0, 16),
          y.actor,
          ROLE_LABEL[y.actor_role] || y.actor_role,
          l[y.action] || y.action,
          y.details,
        ]);
      exportAs(S, "سجل تتبّع التعديلات", f, h, `عدد العمليات: ${v.length}`);
    };
  return (
    <div className="stack">
      <div
        className="panel"
        style={{
          padding: 12,
        }}
      >
        <div
          style={{
            display: "flex",
            gap: 8,
            flexWrap: "wrap",
            alignItems: "end",
          }}
        >
          <div
            className="qf"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 4,
            }}
          >
            <span
              style={{
                fontSize: 11,
                color: "var(--ink-soft)",
              }}
            >
              المستخدم
            </span>
            <select value={u} onChange={(f) => s(f.target.value)}>
              <option value="all">الكل</option>
              {m.map((f) => (
                <option key={f} value={f}>
                  {f}
                </option>
              ))}
            </select>
          </div>
          <div
            className="qf"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 4,
            }}
          >
            <span
              style={{
                fontSize: 11,
                color: "var(--ink-soft)",
              }}
            >
              الإجراء
            </span>
            <select value={n} onChange={(f) => i(f.target.value)}>
              <option value="all">الكل</option>
              {r.map((f) => (
                <option key={f} value={f}>
                  {l[f] || f}
                </option>
              ))}
            </select>
          </div>
          <div
            className="qf"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 4,
            }}
          >
            <span
              style={{
                fontSize: 11,
                color: "var(--ink-soft)",
              }}
            >
              من
            </span>
            <input
              type="date"
              value={o}
              onChange={(f) => d(f.target.value)}
              style={{
                padding: "8px 10px",
                border: "1px solid var(--line)",
                borderRadius: 8,
              }}
            />
          </div>
          <div
            className="qf"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 4,
            }}
          >
            <span
              style={{
                fontSize: 11,
                color: "var(--ink-soft)",
              }}
            >
              إلى
            </span>
            <input
              type="date"
              value={c}
              onChange={(f) => p(f.target.value)}
              style={{
                padding: "8px 10px",
                border: "1px solid var(--line)",
                borderRadius: 8,
              }}
            />
          </div>
          <div
            className="qf"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 4,
            }}
          >
            <span
              style={{
                fontSize: 11,
                color: "var(--ink-soft)",
              }}
            >
              صيغة
            </span>
            <select value={S} onChange={(f) => N(f.target.value)}>
              <option value="excel">Excel</option>
              <option value="word">Word</option>
              <option value="pdf">PDF</option>
              <option value="csv">CSV</option>
            </select>
          </div>
          <button className="btn ghost sm" onClick={b}>
            تصدير
          </button>
          <div
            style={{
              fontSize: 13,
              color: "var(--navy)",
              fontWeight: 700,
              marginInlineStart: "auto",
            }}
          >
            {"عدد العمليات: "}
            {v.length}
          </div>
        </div>
      </div>
      <div className="panel">
        <h3 className="panel-title">سجل تتبّع التعديلات</h3>
        <div className="table-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>التوقيت</th>
                <th>المستخدم</th>
                <th>الدور</th>
                <th>الإجراء</th>
                <th>التفاصيل</th>
              </tr>
            </thead>
            <tbody>
              {v.map((f) => (
                <tr key={f.id}>
                  <td
                    style={{
                      whiteSpace: "nowrap",
                      color: "var(--ink-soft)",
                      fontSize: 12,
                    }}
                  >
                    {String(f.ts || "")
                      .replace("T", " ")
                      .slice(0, 16)}
                  </td>
                  <td
                    style={{
                      fontWeight: 600,
                    }}
                  >
                    {f.actor}
                  </td>
                  <td
                    style={{
                      fontSize: 12,
                    }}
                  >
                    {ROLE_LABEL[f.actor_role] || f.actor_role}
                  </td>
                  <td>
                    <span className="chip navy">{l[f.action] || f.action}</span>
                  </td>
                  <td
                    style={{
                      fontSize: 11,
                      color: "var(--ink-soft)",
                      direction: "ltr",
                      textAlign: "left",
                    }}
                  >
                    {f.details}
                  </td>
                </tr>
              ))}
              {v.length === 0 && (
                <tr>
                  <td colSpan="5">
                    <div className="empty">لا توجد عمليات مطابقة.</div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function Admin({ data, act, probe, showToast, setModal }) {
  let [u, s] = useState("schools"),
    [o, d] = useState(null),
    [c, p] = useState(!1),
    m = async () => {
      (p(!0), d(null));
      try {
        let v = await probe("ping", {});
        d(
          v && v.demo
            ? {
                ok: !0,
                demo: !0,
              }
            : {
                ok: !0,
                remote: !0,
                r: v,
              },
        );
      } catch (v) {
        d({
          ok: !1,
          msg: v.message,
        });
      }
      p(!1);
    },
    r = [
      ["schools", "المدارس والبنود"],
      ["custodyItems", "بنود ومسئولو العهد"],
      ["users", "المستخدمون والصلاحيات"],
    ].concat(
      data.me.role === "manager"
        ? [
            ["custodyNames", "أسماء العهد"],
            ["custodyKinds", "أنواع العهد"],
            ["entityTypes", "أنواع الموازنات"],
            ["activation", "تعطيل الجهات والبنود"],
            ["payComponents", "عناصر الراتب"],
            ["wfSettings", "إعدادات الدورة"],
            ["backups", "النسخ الاحتياطى"],
          ]
        : [],
    );
  return (
    <div className="stack">
      <div className="panel">
        <div className="toolbar">
          <h3
            className="panel-title"
            style={{
              margin: 0,
            }}
          >
            الاتصال بجوجل شيت
          </h3>
          <button className="btn ghost sm" onClick={m} disabled={c}>
            {c ? "جارٍ الفحص…" : "اختبار الاتصال"}
          </button>
        </div>
        <div
          style={{
            fontSize: 13,
            color: "var(--ink-soft)",
            marginTop: 8,
          }}
        >
          {o == null && <span>اضغط «اختبار الاتصال» للتأكد من الربط مع جوجل شيت.</span>}
          {o && o.ok && o.demo && (
            <span
              style={{
                color: "var(--amber)",
              }}
            >
              ⚠ وضع تجريبى — التطبيق غير مربوط بجوجل شيت. البيانات تُحفظ على متصفحك فقط. ضع رابط Apps Script فى
              config.js لتفعيل الحفظ المشترك.
            </span>
          )}
          {o && o.ok && o.remote && (
            <span
              style={{
                color: "var(--green)",
              }}
            >
              {"✅ متصل بنجاح — عدد المستخدمين: "}
              {o.r.users}
              {" · المدارس: "}
              {o.r.schools}. الحفظ يتم على جوجل شيت.
            </span>
          )}
          {o && !o.ok && (
            <span
              style={{
                color: "var(--red)",
              }}
            >
              {"✗ فشل الاتصال: "}
              {o.msg}
              {" — تأكد أن رابط Apps Script صحيح (ينتهى بـ /exec) وأن النشر بصلاحية Anyone وأعِد النشر بإصدار جديد."}
            </span>
          )}
        </div>
      </div>
      <div
        className="tabs"
        style={{
          position: "static",
          borderRadius: 12,
          border: "1px solid var(--line)",
        }}
      >
        {r.map(([v, S]) => (
          <button key={v} className={"tab " + (u === v ? "active" : "")} onClick={() => s(v)}>
            {S}
          </button>
        ))}
      </div>
      {u === "schools" && <AdminSchools data={data} act={act} setModal={setModal} />}
      {u === "custodyItems" && <AdminCustodyItems data={data} act={act} />}
      {u === "users" && <AdminUsers data={data} act={act} setModal={setModal} />}
      {u === "custodyNames" && <AdminCustodyNames data={data} act={act} showToast={showToast} />}
      {u === "payComponents" && <AdminPayComponents data={data} act={act} showToast={showToast} />}
      {u === "custodyKinds" && <AdminCustodyKinds data={data} act={act} showToast={showToast} />}
      {u === "entityTypes" && <AdminEntityTypes data={data} act={act} showToast={showToast} />}
      {u === "activation" && <AdminActivation data={data} act={act} showToast={showToast} />}
      {u === "wfSettings" && <AdminWorkflowSettings data={data} act={act} showToast={showToast} />}
      {u === "backups" && <AdminBackups data={data} act={act} showToast={showToast} />}
    </div>
  );
}

export function AdminSchools({ data, act, setModal }) {
  let [n, i] = useState(data.schools[0] ? data.schools[0].id : ""),
    u = data.lines.filter((s) => String(s.school_id) === String(n));
  return (
    <div className="stack">
      <div className="panel">
        <div className="toolbar">
          <h3
            className="panel-title"
            style={{
              margin: 0,
            }}
          >
            الجهات / الوحدات
          </h3>
          <button
            className="btn primary sm"
            onClick={() =>
              setModal({
                type: "school",
              })
            }
          >
            + جهة
          </button>
        </div>
        <div
          className="chips-list"
          style={{
            marginTop: 12,
          }}
        >
          {data.schools.map((s) => (
            <span key={s.id} className="cat-chip">
              {s.name}{" "}
              <span
                className="chip navy"
                style={{
                  marginInlineStart: 4,
                }}
              >
                {CAT_LABEL[s.category || "school"]}
              </span>
              <button
                className="icon-btn"
                style={{
                  width: 24,
                  height: 24,
                }}
                onClick={() =>
                  setModal({
                    type: "school",
                    payload: s,
                  })
                }
              >
                ✎
              </button>
            </span>
          ))}
        </div>
      </div>
      <div className="panel">
        <div className="toolbar">
          <div
            style={{
              display: "flex",
              gap: 8,
              alignItems: "center",
            }}
          >
            <span
              style={{
                fontWeight: 700,
                color: "var(--navy)",
              }}
            >
              بنود موازنة:
            </span>
            <select value={n} onChange={(s) => i(s.target.value)}>
              {data.schools.map((s) => (
                <option key={s.id} value={s.id}>
                  {CAT_LABEL[s.category || "school"]}
                  {" · "}
                  {s.name}
                </option>
              ))}
            </select>
          </div>
          <button
            className="btn primary sm"
            onClick={() =>
              setModal({
                type: "line",
                payload: {
                  school_id: n,
                },
              })
            }
          >
            + بند
          </button>
        </div>
        <div
          className="table-wrap"
          style={{
            marginTop: 12,
          }}
        >
          <table className="tbl">
            <thead>
              <tr>
                <th>القسم</th>
                <th>البند</th>
                <th>الموازنة</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {u.map((s) => (
                <tr key={s.id}>
                  <td>{s.section}</td>
                  <td>{s.name}</td>
                  <td className="num">{fmt(s.allocated)}</td>
                  <td
                    style={{
                      display: "flex",
                      gap: 6,
                    }}
                  >
                    <button
                      className="icon-btn"
                      onClick={() =>
                        setModal({
                          type: "line",
                          payload: s,
                        })
                      }
                    >
                      ✎
                    </button>
                    <button
                      className="icon-btn"
                      onClick={() =>
                        act("deleteLine", {
                          id: s.id,
                        })
                      }
                    >
                      ×
                    </button>
                  </td>
                </tr>
              ))}
              {u.length === 0 && (
                <tr>
                  <td colSpan="4">
                    <div className="empty">لا توجد بنود.</div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function AdminCustodyItems({ data, act }) {
  return (
    <div className="admin-grid">
      <Catalog
        title="بنود صرف العهدة"
        items={data.spendItems}
        cols={["name"]}
        labels={["اسم البند"]}
        onAdd={(e) =>
          act("addSpendItem", {
            item: {
              name: e.name,
            },
          })
        }
        onDel={(e) =>
          act("deleteSpendItem", {
            id: e,
          })
        }
      />
      <Catalog
        title="مسئولو العهد"
        items={data.holders}
        cols={["name", "title"]}
        labels={["الاسم", "الوظيفة"]}
        onAdd={(e) =>
          act("addHolder", {
            item: {
              name: e.name,
              title: e.title,
            },
          })
        }
        onDel={(e) =>
          act("deleteHolder", {
            id: e,
          })
        }
      />
    </div>
  );
}

export function AdminUsers({ data, act, setModal }) {
  return (
    <div className="panel">
      <div className="toolbar">
        <h3
          className="panel-title"
          style={{
            margin: 0,
          }}
        >
          المستخدمون
        </h3>
        <button
          className="btn primary sm"
          onClick={() =>
            setModal({
              type: "user",
            })
          }
        >
          + مستخدم
        </button>
      </div>
      <div
        className="table-wrap"
        style={{
          marginTop: 12,
        }}
      >
        <table className="tbl">
          <thead>
            <tr>
              <th>الاسم</th>
              <th>المستخدم</th>
              <th>الدور</th>
              <th>المدارس</th>
              <th>المدير المباشر</th>
              <th>الحالة</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {(data.users || []).map((n) => {
              let i =
                n.schools === "*"
                  ? "كل المدارس"
                  : String(n.schools)
                      .split(",")
                      .map((u) => {
                        let s = data.schools.find((o) => String(o.id) === String(u.trim()));
                        return s ? s.name : u;
                      })
                      .join("، ");
              return (
                <tr key={n.id}>
                  <td
                    style={{
                      fontWeight: 600,
                    }}
                  >
                    {n.name}
                  </td>
                  <td>{n.username}</td>
                  <td>
                    <span
                      className={
                        "chip " +
                        (n.role === "manager"
                          ? "navy"
                          : n.role === "supervisor"
                            ? "amber"
                            : n.role === "custody"
                              ? "gray"
                              : "green")
                      }
                    >
                      {ROLE_LABEL[n.role] || n.role}
                    </span>
                  </td>
                  <td
                    style={{
                      fontSize: 12,
                    }}
                  >
                    {i}
                  </td>
                  <td style={{ fontSize: 12 }}>
                    {n.manager_id ? ((data.users || []).find((x) => x.id === n.manager_id) || {}).name || "—" : n.role === "custody" ? <span className="muted">حسب النطاق</span> : "—"}
                    {n.dept ? <span className="cust-sub">{n.dept}</span> : null}
                  </td>
                  <td>
                    {yes(n.active) ? "مفعّل" : "موقوف"}
                    {n.must_reset === "نعم" || n.must_reset === !0 ? " · بانتظار تعيين كلمة السر" : ""}
                  </td>
                  <td
                    style={{
                      display: "flex",
                      gap: 6,
                    }}
                  >
                    <button
                      className="icon-btn"
                      title="تعديل"
                      onClick={() =>
                        setModal({
                          type: "user",
                          payload: n,
                        })
                      }
                    >
                      ✎
                    </button>
                    <button
                      className="icon-btn"
                      title="تصفير كلمة السر"
                      onClick={() => {
                        (typeof window == "undefined" ||
                          window.confirm(
                            "تصفير كلمة سر «" + n.name + "»؟ سيُطلب منه تعيين كلمة سر جديدة عند الدخول.",
                          )) &&
                          act("resetPin", {
                            id: n.id,
                          });
                      }}
                    >
                      🔑
                    </button>
                    <button
                      className="icon-btn"
                      title="حذف"
                      onClick={() =>
                        act("deleteUser", {
                          id: n.id,
                        })
                      }
                    >
                      ×
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
