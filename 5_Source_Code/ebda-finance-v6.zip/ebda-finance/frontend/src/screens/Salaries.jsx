import React, { useEffect, useState } from "react";
import { exportAs, fmt, yes } from "../lib/utils";
import { CAT_LABEL, DEDUCTION_RATES, EMP_CATEGORIES, salaryLabel } from "../lib/model";
import { Kpi } from "../components/ui";

export function Salaries({ data, canEdit, act, showToast, setModal }) {
  let [u, s] = useState("employees"),
    [o, d] = useState(data.schools[0] ? data.schools[0].id : ""),
    [c, p] = useState("all"),
    [m, r] = useState(""),
    [v, S] = useState(""),
    N = data.employees || [],
    b = N.filter((_) => !yes(_.archived)),
    f = N.filter((_) => yes(_.archived)),
    h = b.filter((_) => String(_.school_id) === String(o)),
    y = h.filter(
      (_) =>
        (c === "all" || (_.category || "contract") === c) &&
        (!m || (_.name || "").includes(m) || (_.job || "").includes(m) || (_.national_id || "").includes(m)),
    ),
    x = ((_) => ({
      n: _.length,
      contract: _.filter((A) => (A.category || "contract") !== "gov").length,
      gov: _.filter((A) => A.category === "gov").length,
      total: _.reduce((A, z) => A + Number(z.base_salary || 0), 0),
    }))(h),
    C = [
      ["employees", "العاملون"],
      ["payroll", "الرواتب الشهرية"],
      ["report", "تقرير موظف"],
    ];
  return (
    canEdit && C.push(["archive", "الأرشيف (" + f.length + ")"]),
    (
      <div className="stack">
        <div className="toolbar">
          <h3 className="section-h">
            {"الرواتب والحوافز "}
            {!canEdit && (
              <span
                style={{
                  fontSize: 12,
                  color: "var(--ink-soft)",
                  fontWeight: 400,
                }}
              >
                (عرض فقط)
              </span>
            )}
          </h3>
          <select value={o} onChange={(_) => d(_.target.value)}>
            {data.schools.map((_) => (
              <option key={_.id} value={_.id}>
                {CAT_LABEL[_.category || "school"]}
                {" · "}
                {_.name}
              </option>
            ))}
          </select>
        </div>
        <div
          className="tabs"
          style={{
            position: "static",
            borderRadius: 10,
            border: "1px solid var(--line)",
          }}
        >
          {C.map(([_, A]) => (
            <button key={_} className={"tab " + (u === _ ? "active" : "")} onClick={() => s(_)}>
              {A}
            </button>
          ))}
        </div>
        {u === "employees" && (
          <>
            <div className="kpi-row">
              <Kpi label="عدد العاملين" v={x.n} u="" tone="navy" />
              <Kpi label="متعاقدون" v={x.contract} u="" tone="teal" />
              <Kpi label="حكوميون / منتدبون" v={x.gov} u="" tone="amber" />
              <Kpi label="إجمالى الأساسى الشهرى" v={fmt(x.total)} u="ج.م" tone="green" />
            </div>
            <div className="panel">
              <div
                className="toolbar"
                style={{
                  marginBottom: 12,
                }}
              >
                <div
                  style={{
                    display: "flex",
                    gap: 8,
                    flexWrap: "wrap",
                  }}
                >
                  <select value={c} onChange={(_) => p(_.target.value)}>
                    <option value="all">كل التصنيفات</option>
                    <option value="contract">متعاقد</option>
                    <option value="gov">حكومى/منتدب</option>
                  </select>
                  <input
                    value={m}
                    onChange={(_) => r(_.target.value)}
                    placeholder="بحث بالاسم/المسمى/الرقم القومى"
                    style={{
                      padding: "8px 10px",
                      border: "1px solid var(--line)",
                      borderRadius: 8,
                      minWidth: 200,
                    }}
                  />
                </div>
                {canEdit && (
                  <div
                    style={{
                      display: "flex",
                      gap: 8,
                    }}
                  >
                    <button
                      className="btn ghost sm"
                      onClick={() =>
                        setModal({
                          type: "importEmployees",
                          payload: {
                            school_id: o,
                          },
                        })
                      }
                    >
                      استيراد عاملين
                    </button>
                    <button
                      className="btn primary sm"
                      onClick={() =>
                        setModal({
                          type: "employee",
                          payload: {
                            school_id: o,
                          },
                        })
                      }
                    >
                      + موظف
                    </button>
                  </div>
                )}
              </div>
              <div className="table-wrap">
                <table className="tbl">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>الاسم</th>
                      <th>التصنيف</th>
                      <th>المسمى</th>
                      <th>المؤهل</th>
                      <th>الهاتف</th>
                      <th>الأساسى</th>
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    {y.map((_, A) => (
                      <tr key={_.id}>
                        <td
                          style={{
                            color: "var(--ink-soft)",
                          }}
                        >
                          {A + 1}
                        </td>
                        <td
                          style={{
                            fontWeight: 600,
                          }}
                        >
                          {_.name}
                        </td>
                        <td>
                          <span className={"chip " + (_.category === "gov" ? "amber" : "teal")}>
                            {EMP_CATEGORIES[_.category || "contract"]}
                          </span>
                        </td>
                        <td>{_.job}</td>
                        <td
                          style={{
                            fontSize: 12,
                          }}
                        >
                          {_.qualification}
                        </td>
                        <td
                          style={{
                            direction: "ltr",
                            textAlign: "right",
                            fontSize: 12,
                          }}
                        >
                          {_.phone}
                        </td>
                        <td className="num teal">{fmt(_.base_salary)}</td>
                        <td
                          style={{
                            display: "flex",
                            gap: 6,
                          }}
                        >
                          <button
                            className="icon-btn"
                            title="تقرير"
                            onClick={() => {
                              (S(_.id), s("report"));
                            }}
                          >
                            📄
                          </button>
                          {canEdit && (
                            <button
                              className="icon-btn"
                              title="تعديل"
                              onClick={() =>
                                setModal({
                                  type: "employee",
                                  payload: _,
                                })
                              }
                            >
                              ✎
                            </button>
                          )}
                          {canEdit && (
                            <button
                              className="icon-btn"
                              title="أرشفة"
                              onClick={() => {
                                (typeof window == "undefined" ||
                                  window.confirm("أرشفة «" + _.name + "»؟ يمكن استرجاعه لاحقاً من الأرشيف.")) &&
                                  act("archiveEmployee", {
                                    id: _.id,
                                  });
                              }}
                            >
                              🗄
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                    {y.length === 0 && (
                      <tr>
                        <td colSpan="8">
                          <div className="empty">لا يوجد عاملون مطابقون.</div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
        {u === "payroll" && (
          <PayrollMonth data={data} sid={o} canEdit={canEdit} act={act} showToast={showToast} setModal={setModal} />
        )}
        {u === "report" && <EmployeeLedger data={data} sid={o} repEmp={v} setRepEmp={S} />}
        {u === "archive" && canEdit && (
          <div className="panel">
            <h3 className="panel-title">الأرشيف — العاملون المحذوفون</h3>
            <div className="table-wrap">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>الاسم</th>
                    <th>التصنيف</th>
                    <th>المسمى</th>
                    <th>الجهة</th>
                    <th>تاريخ الأرشفة</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {f.map((_) => (
                    <tr key={_.id}>
                      <td
                        style={{
                          fontWeight: 600,
                        }}
                      >
                        {_.name}
                      </td>
                      <td>{EMP_CATEGORIES[_.category || "contract"]}</td>
                      <td>{_.job}</td>
                      <td
                        style={{
                          fontSize: 12,
                        }}
                      >
                        {(data.schools.find((A) => String(A.id) === String(_.school_id)) || {}).name || "—"}
                      </td>
                      <td
                        style={{
                          fontSize: 12,
                          color: "var(--ink-soft)",
                        }}
                      >
                        {String(_.archived_at || "").slice(0, 10)}
                      </td>
                      <td
                        style={{
                          display: "flex",
                          gap: 6,
                        }}
                      >
                        <button
                          className="btn ghost sm"
                          onClick={() =>
                            act("restoreEmployee", {
                              id: _.id,
                            })
                          }
                        >
                          استرجاع
                        </button>
                        <button
                          className="btn danger-ghost sm"
                          onClick={() => {
                            (typeof window == "undefined" ||
                              window.confirm("حذف «" + _.name + "» نهائياً؟ لا يمكن التراجع.")) &&
                              act("deleteEmployee", {
                                id: _.id,
                              });
                          }}
                        >
                          حذف نهائى
                        </button>
                      </td>
                    </tr>
                  ))}
                  {f.length === 0 && (
                    <tr>
                      <td colSpan="6">
                        <div className="empty">الأرشيف فارغ.</div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    )
  );
}

export function PayrollMonth({ data, sid, canEdit, act, showToast, setModal }) {
  let [s, o] = useState(new Date().toISOString().slice(0, 7)),
    d = (data.employees || []).filter((N) => String(N.school_id) === String(sid) && !yes(N.archived)),
    c = (data.payslips || []).filter((N) => String(N.school_id) === String(sid) && N.month === s),
    p = (N) => {
      let b = (data.employees || []).find((f) => String(f.id) === String(N));
      return b ? b.name : "—";
    },
    m = c.reduce(
      (N, b) => ({
        gross: N.gross + Number(b.gross || 0),
        ded: N.ded + Number(b.ded_total || 0),
        net: N.net + Number(b.net || 0),
      }),
      {
        gross: 0,
        ded: 0,
        net: 0,
      },
    ),
    r = new Set(c.map((N) => String(N.employee_id)));
  return (
    <div className="stack">
      <div
        className="panel"
        style={{
          padding: 12,
        }}
      >
        <div
          style={{
            display: "flex",
            gap: 8,
            flexWrap: "wrap",
            alignItems: "end",
          }}
        >
          <div
            className="qf"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 4,
            }}
          >
            <span
              style={{
                fontSize: 11,
                color: "var(--ink-soft)",
              }}
            >
              الشهر
            </span>
            <input
              type="month"
              value={s}
              onChange={(N) => o(N.target.value)}
              style={{
                padding: "8px 10px",
                border: "1px solid var(--line)",
                borderRadius: 8,
              }}
            />
          </div>
          {canEdit && (
            <button
              className="btn primary sm"
              onClick={async () => {
                let N = d
                  .filter((b) => !r.has(String(b.id)))
                  .map((b) => {
                    let f = Number(b.base_salary || 0),
                      h = Math.round(f * DEDUCTION_RATES.medical * 100) / 100,
                      y = Math.round(f * DEDUCTION_RATES.social * 100) / 100,
                      g = Math.round(f * DEDUCTION_RATES.tax * 100) / 100,
                      x = h + y + g,
                      C = f;
                    return {
                      employee_id: b.id,
                      emp_name: b.name,
                      school_id: sid,
                      month: s,
                      base: f,
                      incentive: 0,
                      allowances: 0,
                      gross: C,
                      ded_medical: h,
                      ded_social: y,
                      ded_tax: g,
                      ded_other: 0,
                      ded_total: x,
                      net: C - x,
                      note: "",
                    };
                  });
                if (!N.length) {
                  showToast("لا يوجد عاملون جدد لهذا الشهر", "err");
                  return;
                }
                try {
                  let b = await act("addPayslipsBatch", {
                    rows: N,
                  });
                  showToast("تم توليد " + ((b && b.count) || N.length) + " كشف راتب");
                } catch (b) {}
              }}
            >
              توليد كشف الشهر تلقائياً
            </button>
          )}
          {canEdit && (
            <button
              className="btn ghost sm"
              onClick={() =>
                setModal({
                  type: "payslip",
                  payload: {
                    school_id: sid,
                    month: s,
                    employees: d,
                  },
                })
              }
            >
              + راتب فردى
            </button>
          )}
          <button
            className="btn ghost sm"
            onClick={() => {
              let N = [
                  "الموظف",
                  "الأساسى",
                  "بدلات",
                  "حوافز",
                  "الإجمالى",
                  "تأمين طبى",
                  "تأمين اجتماعى",
                  "ضريبة",
                  "خصم آخر",
                  "إجمالى الخصم",
                  "الصافى",
                ],
                b = c.map((f) => [
                  p(f.employee_id),
                  f.base,
                  f.allowances,
                  f.incentive,
                  f.gross,
                  f.ded_medical,
                  f.ded_social,
                  f.ded_tax,
                  f.ded_other,
                  f.ded_total,
                  f.net,
                ]);
              (b.push(["الإجمالى", "", "", "", m.gross, "", "", "", "", m.ded, m.net]),
                exportAs(
                  "excel",
                  "كشف رواتب " + s,
                  N,
                  b,
                  "الجهة: " + ((data.schools.find((f) => String(f.id) === String(sid)) || {}).name || ""),
                ));
            }}
            disabled={!c.length}
          >
            تصدير الكشف Excel
          </button>
        </div>
        <div
          style={{
            fontSize: 12.5,
            color: "var(--ink-soft)",
            marginTop: 8,
          }}
        >
          «توليد كشف الشهر» ينشئ رواتب لكل العاملين غير المُدرجين بالشهر، بخصومات تلقائية (طبى 8% · اجتماعى 8% · ضريبة
          10%) قابلة للتعديل بعد ذلك.
        </div>
      </div>
      <div className="panel">
        <div className="mini-kpis">
          <div>
            <span>عدد الكشوف</span>
            <b>{c.length}</b>
          </div>
          <div>
            <span>إجمالى المستحق</span>
            <b className="teal">{fmt(m.gross)}</b>
          </div>
          <div>
            <span>إجمالى الخصومات</span>
            <b className="red">{fmt(m.ded)}</b>
          </div>
          <div>
            <span>صافى المدفوع</span>
            <b className="green">{fmt(m.net)}</b>
          </div>
        </div>
        <div className="table-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>الموظف</th>
                <th>الأساسى</th>
                <th>بدلات</th>
                <th>حوافز</th>
                <th>الإجمالى</th>
                <th>طبى</th>
                <th>اجتماعى</th>
                <th>ضريبة</th>
                <th>آخر</th>
                <th>الخصم</th>
                <th>الصافى</th>
                {canEdit && <th />}
              </tr>
            </thead>
            <tbody>
              {c.map((N) => (
                <tr key={N.id}>
                  <td
                    style={{
                      fontWeight: 600,
                    }}
                  >
                    {p(N.employee_id)}
                  </td>
                  <td className="num">{fmt(N.base)}</td>
                  <td className="num">{fmt(N.allowances)}</td>
                  <td className="num">{fmt(N.incentive)}</td>
                  <td className="num">{fmt(N.gross)}</td>
                  <td className="num red">{fmt(N.ded_medical)}</td>
                  <td className="num red">{fmt(N.ded_social)}</td>
                  <td className="num red">{fmt(N.ded_tax)}</td>
                  <td className="num red">{fmt(N.ded_other)}</td>
                  <td className="num red">{fmt(N.ded_total)}</td>
                  <td className="num green">
                    <b>{fmt(N.net)}</b>
                  </td>
                  {canEdit && (
                    <td
                      style={{
                        display: "flex",
                        gap: 6,
                      }}
                    >
                      <button
                        className="icon-btn"
                        onClick={() =>
                          setModal({
                            type: "payslip",
                            payload: {
                              edit: N,
                              school_id: sid,
                              month: s,
                              employees: d,
                            },
                          })
                        }
                      >
                        ✎
                      </button>
                      <button
                        className="icon-btn"
                        onClick={() =>
                          act("deletePayslip", {
                            id: N.id,
                          })
                        }
                      >
                        ×
                      </button>
                    </td>
                  )}
                </tr>
              ))}
              {c.length === 0 && (
                <tr>
                  <td colSpan={canEdit ? 12 : 11}>
                    <div className="empty">لا كشوف لهذا الشهر — استخدم «توليد كشف الشهر».</div>
                  </td>
                </tr>
              )}
              {c.length > 0 && (
                <tr className="tot">
                  <td>الإجمالى</td>
                  <td />
                  <td />
                  <td />
                  <td className="num">{fmt(m.gross)}</td>
                  <td colSpan="4" />
                  <td className="num red">{fmt(m.ded)}</td>
                  <td className="num green">{fmt(m.net)}</td>
                  {canEdit && <td />}
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function EmployeeLedger({ data, sid, repEmp, setRepEmp }) {
  let i = (data.employees || []).filter((r) => String(r.school_id) === String(sid)),
    [u, s] = useState(repEmp || (i[0] ? i[0].id : ""));
  useEffect(() => {
    repEmp && s(repEmp);
  }, [repEmp]);
  let o = (data.employees || []).find((r) => String(r.id) === String(u)),
    d = (data.payslips || [])
      .filter((r) => String(r.employee_id) === String(u))
      .slice()
      .sort((r, v) => (r.month < v.month ? -1 : 1)),
    c = d.reduce(
      (r, v) => ({
        gross: r.gross + Number(v.gross || 0),
        ded: r.ded + Number(v.ded_total || 0),
        net: r.net + Number(v.net || 0),
      }),
      {
        gross: 0,
        ded: 0,
        net: 0,
      },
    ),
    p = (r) => {
      if (!o) return;
      let v = ["الشهر", "الأساسى", "بدلات", "حوافز", "الإجمالى", "طبى", "اجتماعى", "ضريبة", "آخر", "الخصم", "الصافى"],
        S = d.map((N) => [
          N.month,
          N.base,
          N.allowances,
          N.incentive,
          N.gross,
          N.ded_medical,
          N.ded_social,
          N.ded_tax,
          N.ded_other,
          N.ded_total,
          N.net,
        ]);
      (S.push(["الإجمالى", "", "", "", c.gross, "", "", "", "", c.ded, c.net]),
        exportAs(
          r,
          "تقرير راتب - " + o.name,
          v,
          S,
          o.job +
            " · " +
            EMP_CATEGORIES[o.category || "contract"] +
            " · " +
            salaryLabel(o.category) +
            ": " +
            fmt(o.base_salary),
        ));
    },
    m = ({ l, v }) => (
      <div
        style={{
          fontSize: 13,
        }}
      >
        <span
          style={{
            color: "var(--ink-soft)",
          }}
        >
          {l}
          {": "}
        </span>
        <b
          style={{
            color: "var(--navy)",
          }}
        >
          {v || "—"}
        </b>
      </div>
    );
  return (
    <div className="stack">
      <div
        className="panel"
        style={{
          padding: 12,
        }}
      >
        <div
          style={{
            display: "flex",
            gap: 8,
            flexWrap: "wrap",
            alignItems: "end",
          }}
        >
          <div
            className="qf"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 4,
              flex: 1,
              minWidth: 220,
            }}
          >
            <span
              style={{
                fontSize: 11,
                color: "var(--ink-soft)",
              }}
            >
              الموظف
            </span>
            <select value={u} onChange={(r) => s(r.target.value)}>
              <option value="">— اختر —</option>
              {i.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                  {" — "}
                  {r.job}
                </option>
              ))}
            </select>
          </div>
          <button className="btn ghost sm" onClick={() => p("excel")} disabled={!o}>
            Excel
          </button>
          <button className="btn ghost sm" onClick={() => p("pdf")} disabled={!o}>
            PDF
          </button>
        </div>
      </div>
      {o ? (
        <>
          <div className="panel">
            <h3 className="panel-title">
              {o.name}{" "}
              <span
                className={"chip " + (o.category === "gov" ? "amber" : "teal")}
                style={{
                  marginInlineStart: 6,
                }}
              >
                {EMP_CATEGORIES[o.category || "contract"]}
              </span>
            </h3>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))",
                gap: 10,
              }}
            >
              {React.createElement(m, {
                l: "المسمى",
                v: o.job,
              })}
              {React.createElement(m, {
                l: "النوع",
                v: o.job_type,
              })}
              {React.createElement(m, {
                l: "المؤهل",
                v: o.qualification,
              })}
              {React.createElement(m, {
                l: "سنة التخرج",
                v: o.grad_year,
              })}
              {React.createElement(m, {
                l: "الرقم القومى",
                v: o.national_id,
              })}
              {React.createElement(m, {
                l: "الهاتف",
                v: o.phone,
              })}
              {React.createElement(m, {
                l: "الإيميل",
                v: o.email,
              })}
              {React.createElement(m, {
                l: "البنك",
                v: o.bank,
              })}
              {React.createElement(m, {
                l: "رقم الحساب",
                v: o.account_no,
              })}
              {React.createElement(m, {
                l: "الرقم التأمينى",
                v: o.insurance_no,
              })}
              {React.createElement(m, {
                l: "نظام التعاقد",
                v: o.contract_type,
              })}
              {React.createElement(m, {
                l: salaryLabel(o.category),
                v: fmt(o.base_salary) + " ج.م",
              })}
              {React.createElement(m, {
                l: "تاريخ التعيين",
                v: o.hire_date,
              })}
              {React.createElement(m, {
                l: "بداية العمل مع ابدأ",
                v: o.ebda_start,
              })}
              {React.createElement(m, {
                l: "ملاحظات",
                v: o.note,
              })}
            </div>
          </div>
          <div className="panel">
            <div className="mini-kpis">
              <div>
                <span>عدد الأشهر</span>
                <b>{d.length}</b>
              </div>
              <div>
                <span>إجمالى المستحق</span>
                <b className="teal">{fmt(c.gross)}</b>
              </div>
              <div>
                <span>إجمالى الخصومات</span>
                <b className="red">{fmt(c.ded)}</b>
              </div>
              <div>
                <span>إجمالى الصافى</span>
                <b className="green">{fmt(c.net)}</b>
              </div>
            </div>
            <div className="table-wrap">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>الشهر</th>
                    <th>الأساسى</th>
                    <th>بدلات</th>
                    <th>حوافز</th>
                    <th>الإجمالى</th>
                    <th>طبى</th>
                    <th>اجتماعى</th>
                    <th>ضريبة</th>
                    <th>آخر</th>
                    <th>الخصم</th>
                    <th>الصافى</th>
                  </tr>
                </thead>
                <tbody>
                  {d.map((r) => (
                    <tr key={r.id}>
                      <td
                        style={{
                          fontWeight: 600,
                        }}
                      >
                        {r.month}
                      </td>
                      <td className="num">{fmt(r.base)}</td>
                      <td className="num">{fmt(r.allowances)}</td>
                      <td className="num">{fmt(r.incentive)}</td>
                      <td className="num">{fmt(r.gross)}</td>
                      <td className="num red">{fmt(r.ded_medical)}</td>
                      <td className="num red">{fmt(r.ded_social)}</td>
                      <td className="num red">{fmt(r.ded_tax)}</td>
                      <td className="num red">{fmt(r.ded_other)}</td>
                      <td className="num red">{fmt(r.ded_total)}</td>
                      <td className="num green">
                        <b>{fmt(r.net)}</b>
                      </td>
                    </tr>
                  ))}
                  {d.length === 0 && (
                    <tr>
                      <td colSpan="11">
                        <div className="empty">لا توجد رواتب مسجّلة لهذا الموظف بعد.</div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        <div className="empty">اختر موظفاً لعرض تقريره.</div>
      )}
    </div>
  );
}
