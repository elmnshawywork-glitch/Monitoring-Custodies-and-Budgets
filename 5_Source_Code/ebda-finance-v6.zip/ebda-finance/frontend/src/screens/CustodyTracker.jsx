import { WindowNote } from "../components/ui";
// متابعة العهد — عرض Master-Detail (Accordion):
//  فلاتر متعددة تعمل معاً · موقف مالى (موجب / صفر / سالب) حسب الفلاتر وعلى مستوى المسئول/المكان/النوع/الفترة
//  وكل عهدة تُفتح لعرض: البيانات الأساسية · البنود (مخصص/مصروف/متبقى/حالة) · المصروفات · الملخص · الإجراءات حسب الصلاحية
import React, { useMemo, useState } from "react";
import { fmt, exportAs, yes, today, reportHTML } from "../lib/utils";
import { CAT_LABEL, lineName } from "../lib/model";
import { custodyInfo, custodyLines, CUSTODY_STATES, APPROVAL_STATES } from "../lib/custody";
import { can } from "../lib/perms";
import { Meter } from "../components/charts";
import { ApprovalChip, DocLink, Modal, Field } from "../components/ui";

const SETTLE = {
  all: "الكل",
  unsettled: "بها مصروفات غير مُسوّاة",
  pending: "بانتظار تسوية العهدة",
  settled: "تمت تسويتها / مغلقة",
};
const APPROVAL_F = { all: "الكل", draft: "مسودة", review: "قيد المراجعة", approved: "معتمدة", cancelled: "ملغاة" };
const GROUP = { custody: "العهدة", holder: "مسئول العهدة", place: "المكان", kind: "نوع العهدة", month: "شهر العهدة" };

export function CustodyTracker({ data, setModal, act, showToast }) {
  const all = useMemo(() => data.custodies.map((c) => custodyInfo(data, c)), [data]);
  const init = { place: "all", holder: "all", title: "all", kind: "all", line: "all", state: "all", from: "", to: "", settle: "all", approval: "all" };
  const [f, setF] = useState(init);
  const set = (k, v) => setF(Object.assign({}, f, { [k]: v }));
  const [group, setGroup] = useState("custody");
  const [open, setOpen] = useState(null);
  const [cancelFor, setCancelFor] = useState(null);

  const holders = Array.from(new Set(all.map((x) => x.holderName).filter(Boolean))).sort();
  const titles = Array.from(new Set(all.map((x) => x.title).filter(Boolean))).sort();
  const kinds = Array.from(new Set(all.map((x) => x.kind).filter(Boolean))).sort();
  const linesHere = data.lines.filter((l) => f.place === "all" || String(l.school_id) === f.place);
  const inRange = (d) => (!f.from || String(d || "") >= f.from) && (!f.to || String(d || "").slice(0, 10) <= f.to);
  const periodActive = !!(f.from || f.to || f.line !== "all");

  const rows = all
    .filter((x) => f.place === "all" || String(x.c.school_id) === f.place)
    .filter((x) => f.holder === "all" || x.holderName === f.holder)
    .filter((x) => f.title === "all" || x.title === f.title)
    .filter((x) => f.kind === "all" || x.kind === f.kind)
    .filter((x) => f.state === "all" || x.state === f.state)
    .filter((x) => f.approval === "all" || x.approval === f.approval)
    .filter(
      (x) =>
        f.settle === "all" ||
        (f.settle === "unsettled" && x.unsettled > 0) ||
        (f.settle === "pending" && x.c.status === "pending_settlement") ||
        (f.settle === "settled" && (x.c.status === "settled" || x.c.status === "closed")),
    )
    .map((x) => {
      const ops = x.expenses.filter((e) => inRange(e.date) && (f.line === "all" || String(e.line_id) === f.line));
      const opsSpent = ops.filter((e) => e.approval !== "rejected" && e.fin_approval !== "rejected").reduce((a, e) => a + Number(e.amount || 0), 0);
      return { ...x, ops, opsSpent };
    })
    .filter((x) => !periodActive || x.ops.length > 0 || (f.line === "all" && inRange(x.c.opened_at)))
    .sort((a, b) => String(b.c.opened_at || b.c.code || "").localeCompare(String(a.c.opened_at || a.c.code || "")));
  const T = rows.reduce((a, x) => ({ r: a.r + x.received, s: a.s + x.spent, p: a.p + x.opsSpent }), { r: 0, s: 0, p: 0 });
  const remain = T.r - T.s;
  const filtersOn = Object.keys(init).some((k) => f[k] !== init[k]);

  // تجميع الموقف المالى
  const groups = useMemo(() => {
    if (group === "custody") return null;
    const key = (x) =>
      group === "holder" ? x.holderName : group === "place" ? (x.school ? x.school.name : "—") : group === "kind" ? x.kind || "—" : String(x.c.opened_at || "").slice(0, 7) || "—";
    const g = {};
    rows.forEach((x) => {
      const k = key(x);
      const o = (g[k] = g[k] || { k, n: 0, r: 0, s: 0, open: 0, overdue: 0 });
      o.n++;
      o.r += x.received;
      o.s += x.spent;
      if (["open", "notes", "overdue", "pending_settlement"].indexOf(x.state) >= 0) o.open++;
      if (x.state === "overdue") o.overdue++;
    });
    return Object.values(g).sort((a, b) => b.r - b.s - (a.r - a.s));
  }, [rows, group]);

  const doExport = (fmtOut) => {
    const head = ["رقم العهدة", "اسم العهدة", "نوع العهدة", "مسئول العهدة", "المكان", "التاريخ", "القيمة", "المصروف", "المتبقى", "الاستخدام", "الاعتماد", "الحالة"];
    const body = rows.map((x) => [x.c.code || "", x.title, x.kind, x.holderName, x.school ? x.school.name : "", String(x.c.opened_at || "").slice(0, 10), fmt(x.received), fmt(x.spent), fmt(x.remaining), Math.round(x.usage * 100) + "%", x.approvalInfo.label, x.stateInfo.label]);
    body.push(["الإجمالى", rows.length + " عهدة", "", "", "", "", fmt(T.r), fmt(T.s), fmt(remain), T.r ? Math.round((T.s / T.r) * 100) + "%" : "", "", ""]);
    exportAs(fmtOut, "تقرير متابعة العهد", head, body, filterNote());
  };
  const filterNote = () =>
    [
      f.place !== "all" && "المكان: " + ((data.schools.find((s) => String(s.id) === f.place) || {}).name || ""),
      f.holder !== "all" && "المسئول: " + f.holder,
      f.title !== "all" && "اسم العهدة: " + f.title,
      f.from && "من " + f.from,
      f.to && "إلى " + f.to,
      f.line !== "all" && "البند: " + lineName(data, f.line),
    ]
      .filter(Boolean)
      .join(" · ");

  const run = async (action, payload, msg) => {
    try {
      await act(action, payload);
      showToast(msg);
    } catch (e) {}
  };
  const printCustody = (x) => {
    const cl = custodyLines(data, x.c);
    const html =
      reportHTML(
        "عهدة " + (x.c.code || "") + " — " + x.title,
        ["البند", "المخصص", "المصروف", "المتبقى", "الحالة"],
        cl.map((l) => [l.line.name, fmt(l.alloc), fmt(l.spent), fmt(l.remaining), l.state.label]),
        "المسئول: " + x.holderName + " · المكان: " + (x.school ? x.school.name : "") + " · القيمة " + fmt(x.received) + " · المصروف " + fmt(x.spent) + " · المتبقى " + fmt(x.remaining),
      ) + reportHTML("مصروفات العهدة", ["التاريخ", "البيان", "البند", "القيمة"], x.expenses.map((e) => [e.date, e.description, lineName(data, e.line_id) || "", fmt(e.amount)]));
    const w = window.open("", "_blank");
    if (!w) return alert("اسمح بالنوافذ المنبثقة للطباعة");
    w.document.write(html + "<script>setTimeout(function(){window.print();},350);</script>");
    w.document.close();
  };

  return (
    <div className="stack">
      <WindowNote data={data} />
      <div className="toolbar">
        <h3 className="section-h">متابعة العهد</h3>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {can(data, "custody.create") && (
            <button className="btn primary sm" onClick={() => setModal({ type: "custody" })}>
              + إضافة عهدة
            </button>
          )}
          {can(data, "expense.record") && (
            <button className="btn teal sm" onClick={() => setModal({ type: "newExpense" })}>
              + إضافة مصروف
            </button>
          )}
        </div>
      </div>

      <div className="panel" style={{ padding: 12 }}>
        <div className="filters">
          <F label="المكان / المدرسة">
            <select value={f.place} onChange={(e) => setF(Object.assign({}, f, { place: e.target.value, line: "all" }))}>
              <option value="all">الكل</option>
              {data.schools.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </F>
          <F label="مسئول العهدة">
            <select value={f.holder} onChange={(e) => set("holder", e.target.value)} data-testid="tr-holder">
              <option value="all">الكل</option>
              {holders.map((h) => (
                <option key={h}>{h}</option>
              ))}
            </select>
          </F>
          <F label="اسم العهدة">
            <select value={f.title} onChange={(e) => set("title", e.target.value)} data-testid="tr-title">
              <option value="all">الكل</option>
              {titles.map((h) => (
                <option key={h}>{h}</option>
              ))}
            </select>
          </F>
          <F label="نوع العهدة">
            <select value={f.kind} onChange={(e) => set("kind", e.target.value)}>
              <option value="all">الكل</option>
              {kinds.map((k) => (
                <option key={k}>{k}</option>
              ))}
            </select>
          </F>
          <F label="البند">
            <select value={f.line} onChange={(e) => set("line", e.target.value)}>
              <option value="all">الكل</option>
              {linesHere.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                  {f.place === "all" ? " · " + ((data.schools.find((s) => String(s.id) === String(l.school_id)) || {}).name || "") : ""}
                </option>
              ))}
            </select>
          </F>
          <F label="حالة العهدة">
            <select value={f.state} onChange={(e) => set("state", e.target.value)}>
              <option value="all">الكل</option>
              {Object.keys(CUSTODY_STATES).map((k) => (
                <option key={k} value={k}>
                  {CUSTODY_STATES[k].label}
                </option>
              ))}
            </select>
          </F>
          <F label="حالة الاعتماد">
            <select value={f.approval} onChange={(e) => set("approval", e.target.value)} data-testid="tr-approval">
              {Object.keys(APPROVAL_F).map((k) => (
                <option key={k} value={k}>
                  {APPROVAL_F[k]}
                </option>
              ))}
            </select>
          </F>
          <F label="حالة التسوية">
            <select value={f.settle} onChange={(e) => set("settle", e.target.value)}>
              {Object.keys(SETTLE).map((k) => (
                <option key={k} value={k}>
                  {SETTLE[k]}
                </option>
              ))}
            </select>
          </F>
          <F label="من تاريخ">
            <input type="date" value={f.from} onChange={(e) => set("from", e.target.value)} />
          </F>
          <F label="إلى تاريخ">
            <input type="date" value={f.to} onChange={(e) => set("to", e.target.value)} />
          </F>
          <button className="btn ghost sm" disabled={!filtersOn} onClick={() => setF(init)}>
            مسح الفلاتر
          </button>
        </div>
      </div>

      <div className={"position " + (remain < -0.005 ? "neg" : remain > 0.005 ? "pos" : "zero")}>
        <div className="pos-title">
          الموقف المالى {f.holder !== "all" ? "لـ " + f.holder : filtersOn ? "حسب الفلاتر" : "لكل العهد"}
          <small>{rows.length} عهدة</small>
        </div>
        <div>
          <span>إجمالى العهد المسلّمة</span>
          <b>{fmt(T.r)}</b>
        </div>
        <div>
          <span>إجمالى المصروفات</span>
          <b>{fmt(T.s)}</b>
        </div>
        <div>
          <span>المتبقى</span>
          <b data-testid="tr-remaining">{fmt(remain)}</b>
          <em>{remain < -0.005 ? "تجاوز: المصروف أكبر من العهد" : remain > 0.005 ? "رصيد قائم مع المسئول" : "مُستنفد بالكامل"}</em>
        </div>
        {periodActive && (
          <div>
            <span>مصروف الفترة / البند المختار</span>
            <b>{fmt(T.p)}</b>
          </div>
        )}
      </div>

      <div className="toolbar">
        <div className="seg">
          {Object.keys(GROUP).map((k) => (
            <button key={k} className={group === k ? "on" : ""} onClick={() => setGroup(k)}>
              حسب {GROUP[k]}
            </button>
          ))}
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <button className="btn ghost sm" onClick={() => doExport("excel")}>
            Excel
          </button>
          <button className="btn ghost sm" onClick={() => doExport("pdf")}>
            PDF
          </button>
        </div>
      </div>

      {groups ? (
        <div className="table-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>{GROUP[group]}</th>
                <th>عدد العهد</th>
                <th>مفتوحة</th>
                <th>العهد المسلّمة</th>
                <th>المصروف</th>
                <th>المتبقى</th>
                <th>الحالة</th>
              </tr>
            </thead>
            <tbody>
              {groups.map((g) => (
                <tr key={g.k} className={g.r - g.s < -0.005 ? "def" : ""}>
                  <td style={{ fontWeight: 700 }}>{g.k}</td>
                  <td className="num">{g.n}</td>
                  <td className="num">
                    {g.open}
                    {g.overdue ? <span className="cust-sub red">{g.overdue} متأخرة</span> : null}
                  </td>
                  <td className="num">{fmt(g.r)}</td>
                  <td className="num">{fmt(g.s)}</td>
                  <td className={"num " + (g.r - g.s < -0.005 ? "red" : "green")}>{fmt(g.r - g.s)}</td>
                  <td>
                    <span className={"chip " + (g.r - g.s < -0.005 ? "red" : Math.abs(g.r - g.s) <= 0.005 ? "amber" : "green")}>
                      {g.r - g.s < -0.005 ? "تجاوز" : Math.abs(g.r - g.s) <= 0.005 ? "مستنفد" : "رصيد قائم"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="acc-list">
          {rows.map((x) => (
            <CustodyCard
              key={x.c.id}
              data={data}
              x={x}
              open={open === x.c.id}
              toggle={() => setOpen(open === x.c.id ? null : x.c.id)}
              ops={periodActive ? x.ops : x.expenses}
              setModal={setModal}
              run={run}
              onCancel={() => setCancelFor(x)}
              onPrint={() => printCustody(x)}
            />
          ))}
          {!rows.length && <div className="empty">لا توجد عهد مطابقة للفلاتر.</div>}
        </div>
      )}
      {cancelFor && <CancelModal x={cancelFor} close={() => setCancelFor(null)} run={run} />}
    </div>
  );
}

function CustodyCard({ data, x, open, toggle, ops, setModal, run, onCancel, onPrint }) {
  const me = data.me;
  const isAdmin = me.role === "manager";
  const owner = String(x.c.user || "") === String(me.username);
  const cl = open ? custodyLines(data, x.c) : [];
  const tr = open ? (data.tranches || []).filter((t) => String(t.custody_id) === String(x.c.id)) : [];
  const st = x.c.status || "open";
  const live = st !== "cancelled" && st !== "closed";
  const acts = [];
  if (live && can(data, "custody.create") && (x.approval !== "approved" || isAdmin))
    acts.push(["تعديل", "ghost", () => setModal({ type: "custody", payload: x.c })]);
  if (x.approval === "draft" && can(data, "custody.create")) acts.push(["إرسال للمراجعة", "ghost", () => run("submitCustody", { id: x.c.id }, "تم الإرسال للمراجعة")]);
  if (live && x.approval !== "approved" && x.approval !== "cancelled" && can(data, "custody.approve"))
    acts.push(["اعتماد", "primary", () => run("approveCustody", { id: x.c.id }, "تم اعتماد العهدة")]);
  if (st === "open" && x.approval === "approved" && can(data, "expense.record") && (owner || isAdmin))
    acts.push(["إضافة مصروف", "teal", () => setModal({ type: "newExpense", payload: { custody_id: x.c.id } })]);
  if (st === "open" && x.approval === "approved" && can(data, "custody.create")) acts.push(["إضافة دفعة", "ghost", () => setModal({ type: "tranche", payload: x.c })]);
  if (st === "open" && x.approval === "approved" && (owner || can(data, "custody.create")))
    acts.push(["تقديم للتسوية", "ghost", () => run("updateCustody", { id: x.c.id, patch: { status: "pending_settlement" } }, "تم تقديم العهدة للتسوية")]);
  if (st === "pending_settlement" && can(data, "custody.approve"))
    acts.push(["اعتماد التسوية", "primary", () => run("updateCustody", { id: x.c.id, patch: { status: "settled" } }, "تمت تسوية العهدة")]);
  if (st === "settled" && can(data, "custody.approve")) acts.push(["إغلاق", "ghost", () => run("updateCustody", { id: x.c.id, patch: { status: "closed" } }, "تم إغلاق العهدة")]);
  if (st !== "cancelled" && isAdmin) acts.push(["إلغاء العهدة", "danger-ghost", onCancel]);
  acts.push(["طباعة / تقرير", "ghost", onPrint]);

  return (
    <div className={"acc " + (open ? "open " : "") + (x.remaining < -0.005 ? "neg" : "")}>
      <button className="acc-head" onClick={toggle} aria-expanded={open}>
        <span className="caret">{open ? "▾" : "◂"}</span>
        <span className="acc-code">{x.c.code || "—"}</span>
        <span className="acc-main">
          <b>{x.title || x.c.label}</b>
          <small>
            {x.school ? x.school.name : "—"} · {x.kind}
          </small>
        </span>
        <span className="acc-holder">{x.holderName}</span>
        <span className="acc-num">
          <small>القيمة</small>
          {fmt(x.received)}
        </span>
        <span className="acc-num">
          <small>المصروف</small>
          {fmt(x.spent)}
        </span>
        <span className={"acc-num " + (x.remaining < -0.005 ? "red" : "green")}>
          <small>المتبقى</small>
          {fmt(x.remaining)}
        </span>
        <span className="acc-chips">
          <span className={"chip " + x.approvalInfo.tone}>{x.approvalInfo.label}</span>
          {x.approval !== "cancelled" && <span className={"chip " + x.stateInfo.tone}>{x.stateInfo.label}</span>}
        </span>
      </button>
      {open && (
        <div className="acc-body">
          <section>
            <h4>البيانات الأساسية</h4>
            <div className="kv">
              <div>
                <span>اسم العهدة</span>
                <b>{x.title || "—"}</b>
              </div>
              <div>
                <span>نوع العهدة</span>
                <b>{x.kind || "—"}</b>
              </div>
              <div>
                <span>المكان</span>
                <b>{x.school ? CAT_LABEL[x.school.category || "school"] + " · " + x.school.name : "—"}</b>
              </div>
              <div>
                <span>مسئول العهدة</span>
                <b>{x.holderName}</b>
              </div>
              <div>
                <span>التاريخ</span>
                <b>{String(x.c.opened_at || "").slice(0, 10)}</b>
              </div>
              <div>
                <span>القيمة</span>
                <b>{fmt(x.received)}</b>
              </div>
              <div>
                <span>الحالة</span>
                <b>{x.stateInfo.label}</b>
              </div>
              <div>
                <span>الاعتماد</span>
                <b>
                  {x.approvalInfo.label}
                  {x.c.approved_by ? " — " + x.c.approved_by : ""}
                </b>
              </div>
              {x.c.purpose && (
                <div className="wide">
                  <span>الغرض</span>
                  <b>{x.c.purpose}</b>
                </div>
              )}
              {st === "cancelled" && (
                <div className="wide red">
                  <span>سبب الإلغاء</span>
                  <b>
                    {x.c.cancel_reason} — {x.c.cancelled_by} · {String(x.c.cancelled_at || "").slice(0, 16)}
                  </b>
                </div>
              )}
            </div>
          </section>
          <section>
            <h4>البنود</h4>
            {cl.length ? (
              <table className="tbl inner">
                <thead>
                  <tr>
                    <th>البند</th>
                    <th>المخصص</th>
                    <th>المصروف</th>
                    <th>المتبقى</th>
                    <th>الاستخدام</th>
                    <th>الحالة</th>
                  </tr>
                </thead>
                <tbody>
                  {cl.map((l) => (
                    <tr key={l.line.id}>
                      <td>
                        {l.line.name}
                        <span className="cust-sub">{l.line.section}</span>
                      </td>
                      <td className="num">{l.alloc ? fmt(l.alloc) : "—"}</td>
                      <td className="num">{fmt(l.spent)}</td>
                      <td className={"num " + (l.remaining < -0.005 ? "red" : "")}>{l.alloc ? fmt(l.remaining) : "—"}</td>
                      <td>
                        <div className="pct">
                          <Meter pct={l.usage} />
                          <span>{Math.round(l.usage * 100)}%</span>
                        </div>
                      </td>
                      <td>
                        <span className={"chip " + l.state.tone}>{l.state.label}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="muted">لم تُوزَّع العهدة على بنود ولا توجد مصروفات بعد.</div>
            )}
          </section>
          <section>
            <h4>المصروفات</h4>
            <table className="tbl inner">
              <thead>
                <tr>
                  <th>التاريخ</th>
                  <th>البيان</th>
                  <th>البند</th>
                  <th>القيمة</th>
                  <th>طريقة الدفع</th>
                  <th>الحالة</th>
                  <th>المرفق</th>
                </tr>
              </thead>
              <tbody>
                {tr.map((t) => (
                  <tr key={t.id} className="in">
                    <td className="num">{t.date}</td>
                    <td>دفعة عهدة {t.note ? "— " + t.note : ""}</td>
                    <td>—</td>
                    <td className="num green">+{fmt(t.amount)}</td>
                    <td>—</td>
                    <td>
                      <span className="chip green">مستلمة</span>
                    </td>
                    <td />
                  </tr>
                ))}
                {ops
                  .slice()
                  .sort((a, b) => String(a.date).localeCompare(String(b.date)))
                  .map((e) => (
                    <tr key={e.id}>
                      <td className="num">{e.date}</td>
                      <td>
                        {e.txn_no ? e.txn_no + " · " : ""}
                        {e.description}
                        {e.review_note ? <span className="cust-sub red">ملاحظة: {e.review_note}</span> : null}
                      </td>
                      <td>{lineName(data, e.line_id) || "—"}</td>
                      <td className="num">−{fmt(e.amount)}</td>
                      <td>{e.pay_method || "—"}</td>
                      <td>
                        <ApprovalChip s={e.approval} sett={yes(e.settled)} fin={e.fin_approval} />
                      </td>
                      <td>{e.doc_url ? <DocLink expense={e} className="chip navy">📎 عرض</DocLink> : <span className="muted">—</span>}</td>
                    </tr>
                  ))}
                {!tr.length && !ops.length && (
                  <tr>
                    <td colSpan={7} className="empty">
                      لا توجد عمليات.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </section>
          <section className="acc-sum">
            <div>
              <span>إجمالى العهدة</span>
              <b>{fmt(x.received)}</b>
            </div>
            <div>
              <span>إجمالى المصروف</span>
              <b>{fmt(x.spent)}</b>
            </div>
            <div>
              <span>المتبقى</span>
              <b className={x.remaining < -0.005 ? "red" : "green"}>{fmt(x.remaining)}</b>
              {x.remaining < -0.005 && <em>تجاوز بقيمة {fmt(-x.remaining)}</em>}
            </div>
            <div>
              <span>نسبة الاستخدام</span>
              <b>{Math.round(x.usage * 100)}%</b>
            </div>
            <div>
              <span>بانتظار الاعتماد / غير مُسوّى</span>
              <b>
                {x.pending} / {x.unsettled}
              </b>
            </div>
          </section>
          <div className="acc-actions">
            {acts.map(([t, tone, fn]) => (
              <button key={t} className={"btn sm " + tone} onClick={fn}>
                {t}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function CancelModal({ x, close, run }) {
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  return (
    <Modal title="إلغاء العهدة" close={close}>
      <div className="warn-banner over">
        هل أنت متأكد من إلغاء العهدة {x.c.code} — {x.title} ({x.holderName})؟ لن تُحذف العهدة؛ ستتحول حالتها إلى «ملغاة» مع الاحتفاظ بكل
        تاريخها، ولن يُسمح بتسجيل مصروفات عليها.
      </div>
      <Field label="سبب الإلغاء (إلزامى)">
        <input value={reason} onChange={(e) => setReason(e.target.value)} autoFocus />
      </Field>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          تراجع
        </button>
        <span className="spacer" />
        <button
          className="btn danger-ghost"
          disabled={busy || reason.trim().length < 3}
          onClick={async () => {
            setBusy(true);
            await run("cancelCustody", { id: x.c.id, reason: reason.trim() }, "تم إلغاء العهدة");
            close();
          }}
        >
          تأكيد الإلغاء
        </button>
      </div>
    </Modal>
  );
}

function F({ label, children }) {
  return (
    <div className="qf">
      <span>{label}</span>
      {children}
    </div>
  );
}
