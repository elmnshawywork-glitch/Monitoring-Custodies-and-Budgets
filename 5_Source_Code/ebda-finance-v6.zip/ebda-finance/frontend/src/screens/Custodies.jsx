import React, { useEffect, useRef, useState } from "react";
import { probe } from "../lib/api";
import { fmt, today, yes } from "../lib/utils";
import { DOC_TYPES, custIssued, lineName, unitCat, useCalc } from "../lib/model";
import { ApprovalChip } from "../components/ui";

export function Custodies({ data, isMgr, canRecord, canManageCustody, act, showToast, setModal }) {
  let o = useCalc(data),
    [d, c] = useState(null),
    p = (v) => data.custodies.filter((S) => v.indexOf(unitCat(data, S.school_id)) >= 0),
    m = [
      {
        key: "school",
        label: "عهد وموازنات المدارس",
        subs: [
          {
            cat: "school",
          },
        ],
      },
      {
        key: "company",
        label: "عهدة الشركة الداخلية",
        subs: [
          {
            cat: "company",
          },
        ],
      },
      {
        key: "training",
        label: "عهد التدريب",
        subs: [
          {
            cat: "training_general",
            label: "عام",
          },
          {
            cat: "training_vocational",
            label: "مهنى",
          },
          {
            cat: "training_project",
            label: "مشروعات",
          },
          {
            cat: "training_program",
            label: "برامج",
          },
          {
            cat: "training_course",
            label: "دورات",
          },
        ],
      },
    ],
    r = {
      data: data,
      calc: o,
      isMgr: isMgr,
      canRecord: canRecord,
      canManageCustody: canManageCustody,
      act: act,
      showToast: showToast,
      setModal: setModal,
      open: d,
      setOpen: c,
    };
  return (
    <div className="stack">
      <div className="toolbar">
        <h3 className="section-h">العهد المالية</h3>
      </div>
      {(canManageCustody || canRecord) && (
        <div className="big-actions">
          {canManageCustody && (
            <button className="big-action" onClick={() => setModal({ type: "custody" })}>
              <span className="ba-ico">＋</span>
              <b>إضافة عهدة</b>
              <small>المكان · النوع · المسئول · القيمة · الغرض</small>
            </button>
          )}
          {canRecord && (
            <button className="big-action" onClick={() => setModal({ type: "newExpense" })}>
              <span className="ba-ico">🧾</span>
              <b>إضافة مصروف</b>
              <small>على عهدة مفتوحة مع المرفق — حساب الرصيد تلقائى</small>
            </button>
          )}
        </div>
      )}
      {data.custodies.length === 0 && <div className="empty">لا توجد عهد.</div>}
      {m.map((v) => {
        let S = p(v.subs.map((N) => N.cat));
        return S.length === 0 ? null : (
          <div key={v.key} className="cust-group">
            <div className="cust-group-h">
              {v.label} <span className="cust-group-n">{S.length}</span>
            </div>
            {v.subs.map((N) => {
              let b = p([N.cat]);
              return b.length === 0 ? null : (
                <div key={N.cat}>
                  {N.label && (
                    <div className="cust-sub-h">
                      {"تدريب "}
                      {N.label}
                    </div>
                  )}
                  {b.map((f) => (
                    <CustodyBlock key={f.id} c={f} {...r} />
                  ))}
                </div>
              );
            })}
          </div>
        );
      })}
    </div>
  );
}

export function CustodyBlock({
  c: t,
  data,
  calc,
  isMgr,
  canRecord,
  canManageCustody,
  act,
  showToast,
  setModal,
  open,
  setOpen,
}) {
  let m = custIssued(data, t),
    r = calc.spentByCustody[t.id] || 0,
    v = calc.pendingByCustody[t.id] || 0,
    S = m - r,
    N = open === t.id,
    b = m ? Math.min(100, (r / m) * 100) : 0,
    f = data.schools.find((g) => String(g.id) === String(t.school_id)),
    h = [];
  ((data.tranches || [])
    .filter((g) => String(g.custody_id) === String(t.id))
    .forEach((g) =>
      h.push({
        date: g.date,
        kind: "in",
        item: "عهدة مستلمة" + (g.note ? " — " + g.note : ""),
        amount: Number(g.amount || 0),
      }),
    ),
    (data.expenses || [])
      .filter((g) => String(g.custody_id) === String(t.id) && g.approval !== "rejected")
      .forEach((g) =>
        h.push({
          date: g.date,
          kind: "out",
          item: lineName(data, g.line_id) || g.spend_item || "صرف",
          desc: g.description,
          amount: Number(g.amount || 0),
          approval: g.approval,
          settled: yes(g.settled),
        }),
      ),
    h.sort((g, x) => (g.date < x.date ? -1 : g.date > x.date ? 1 : g.kind === "in" ? -1 : 1)));
  let y = 0;
  return (
    h.forEach((g) => {
      ((y += g.kind === "in" ? g.amount : -g.amount), (g.balance = y));
    }),
    (
      <div className="cust-block">
        <div className="cust-head" onClick={() => setOpen(N ? null : t.id)}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
            }}
          >
            <span className="cust-toggle">{N ? "−" : "+"}</span>
            <div>
              <b>{t.label}</b>
              {t.code && (
                <span
                  className="chip gray"
                  style={{
                    marginInlineStart: 6,
                  }}
                >
                  {t.code}
                </span>
              )}
              {(() => {
                let ST = t.status || "open",
                  CM = {
                    open: ["مفتوحة", "green"],
                    pending_settlement: ["فى انتظار التسوية", "amber"],
                    settled: ["تمت التسوية", "navy"],
                    closed: ["مغلقة", "gray"],
                  },
                  [TX, CL] = CM[ST] || CM.open;
                ST === "open" && r > 0 && ((TX = "بها مصروفات"), (CL = "teal"));
                return (
                  <span
                    className={"chip " + CL}
                    style={{
                      marginInlineStart: 6,
                    }}
                  >
                    {TX}
                  </span>
                );
              })()}
              <span className="cust-sub">
                {t.holder}
                {f ? " · " + f.name : ""}
              </span>
            </div>
          </div>
          <div className="cust-bal">
            <span className="n">{fmt(S)}</span>
            <span className="u">ج.م متبقّى</span>
          </div>
        </div>
        {N && (
          <div className="cust-body">
            <div className="mini-kpis">
              <div>
                <span>المستلمة</span>
                <b>{fmt(m)}</b>
              </div>
              <div>
                <span>المصروف</span>
                <b className="teal">{fmt(r)}</b>
              </div>
              <div>
                <span>المتبقى</span>
                <b className={S >= 0 ? "green" : "red"}>{fmt(S)}</b>
              </div>
              <div>
                <span>قيد الاعتماد</span>
                <b className="amber">{fmt(v)}</b>
              </div>
            </div>
            <div
              className="bar"
              style={{
                height: 11,
                marginBottom: 12,
              }}
            >
              <div
                className="bar-fill"
                style={{
                  width: b + "%",
                  background: b > 90 ? "var(--red)" : "var(--navy)",
                }}
              />
            </div>
            {S <= 0 && <div className="warn-banner">انتهت العهدة — أضف عهدة جديدة لمواصلة الصرف.</div>}
            {canRecord && (t.status || "open") === "open" && (
              <QuickAdd data={data} custody={t} act={act} showToast={showToast} />
            )}
            {(t.status || "open") !== "open" && (
              <div className="warn-banner">
                العهدة ليست مفتوحة — لا يمكن تسجيل مصروفات جديدة عليها. بعد التسوية اطلب عهدة جديدة.
              </div>
            )}
            <div
              style={{
                display: "flex",
                gap: 8,
                flexWrap: "wrap",
                margin: "10px 0",
              }}
            >
              {data.me &&
                data.me.role === "custody" &&
                String(t.user || "") === String(data.me.username) &&
                (t.status || "open") === "open" && (
                  <button
                    className="btn primary sm"
                    onClick={() => {
                      (typeof window == "undefined" ||
                        window.confirm("تقديم العهدة للتسوية؟ لن تستطيع إضافة مصروفات بعدها")) &&
                        act("updateCustody", {
                          id: t.id,
                          patch: {
                            status: "pending_settlement",
                          },
                        })
                          .then(() => showToast("تم تقديم العهدة للتسوية"))
                          .catch(() => {});
                    }}
                  >
                    تقديم للتسوية
                  </button>
                )}
              {canManageCustody && ["open", "pending_settlement"].indexOf(t.status || "open") >= 0 && (
                <button
                  className="btn teal sm"
                  onClick={() => {
                    (typeof window == "undefined" || window.confirm("اعتماد تسوية العهدة؟")) &&
                      act("updateCustody", {
                        id: t.id,
                        patch: {
                          status: "settled",
                        },
                      })
                        .then(() => showToast("تمت تسوية العهدة"))
                        .catch(() => {});
                  }}
                >
                  اعتماد التسوية
                </button>
              )}
              {canManageCustody && (t.status || "open") === "settled" && (
                <button
                  className="btn ghost sm"
                  onClick={() =>
                    act("updateCustody", {
                      id: t.id,
                      patch: {
                        status: "closed",
                      },
                    })
                      .then(() => showToast("تم إغلاق العهدة"))
                      .catch(() => {})
                  }
                >
                  إغلاق العهدة
                </button>
              )}
              {canManageCustody && ["settled", "closed", "pending_settlement"].indexOf(t.status || "open") >= 0 && (
                <button
                  className="btn ghost sm"
                  onClick={() =>
                    act("updateCustody", {
                      id: t.id,
                      patch: {
                        status: "open",
                      },
                    })
                      .then(() => showToast("أُعيد فتح العهدة"))
                      .catch(() => {})
                  }
                >
                  إعادة فتح
                </button>
              )}
              {canManageCustody && (t.status || "open") === "open" && (
                <button
                  className="btn teal sm"
                  onClick={() =>
                    setModal({
                      type: "tranche",
                      payload: t,
                    })
                  }
                >
                  + إضافة عهدة
                </button>
              )}
              {canManageCustody && (
                <button
                  className="btn ghost sm"
                  onClick={() =>
                    setModal({
                      type: "custody",
                      payload: t,
                    })
                  }
                >
                  تعديل
                </button>
              )}
              {isMgr && (
                <button
                  className="btn danger-ghost sm"
                  onClick={() => {
                    (typeof window == "undefined" ||
                      window.confirm("حذف هذه العهدة وكل حركاتها ومستنداتها نهائياً؟")) &&
                      act("deleteCustody", {
                        id: t.id,
                      });
                  }}
                >
                  حذف العهدة
                </button>
              )}
            </div>
            <div className="table-wrap">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>التاريخ</th>
                    <th>البند / الحركة</th>
                    <th>البيان</th>
                    <th>وارد</th>
                    <th>منصرف</th>
                    <th>الرصيد</th>
                    <th>الحالة</th>
                  </tr>
                </thead>
                <tbody>
                  {h.map((g, x) => (
                    <tr key={x} className={g.kind === "in" ? "in" : ""}>
                      <td
                        style={{
                          whiteSpace: "nowrap",
                          color: "var(--ink-soft)",
                        }}
                      >
                        {g.date}
                      </td>
                      <td
                        style={{
                          fontWeight: 600,
                        }}
                      >
                        {g.item}
                      </td>
                      <td
                        style={{
                          color: "var(--ink-soft)",
                          fontSize: 12,
                        }}
                      >
                        {g.desc || "—"}
                      </td>
                      <td className="num green">{g.kind === "in" ? fmt(g.amount) : "—"}</td>
                      <td className="num red">{g.kind === "out" ? fmt(g.amount) : "—"}</td>
                      <td className={"num " + (g.balance < 0 ? "red" : "")}>
                        <b>{fmt(g.balance)}</b>
                      </td>
                      <td>
                        {g.kind === "out" ? (
                          <ApprovalChip s={g.approval} sett={g.settled} />
                        ) : (
                          <span className="chip green">إيداع</span>
                        )}
                      </td>
                    </tr>
                  ))}
                  {h.length === 0 && (
                    <tr>
                      <td colSpan="7">
                        <div className="empty">لا توجد حركات.</div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    )
  );
}

export function QuickAdd({ data, custody, act, showToast }) {
  let u = unitCat(data, custody.school_id) !== "school" && data.me.role !== "custody",
    s = data.lines.filter((z) => String(z.school_id) === String(custody.school_id)),
    [o, d] = useState(s[0] ? s[0].id : u ? "__new__" : ""),
    [c, p] = useState(""),
    [m, r] = useState(""),
    [v, S] = useState(today()),
    [N, b] = useState(""),
    [f, h] = useState(!1),
    [y, g] = useState(null),
    [x, C] = useState(DOC_TYPES[0]),
    _ = useRef(),
    [warn, setWarn] = useState("");
  // تنبيه فورى إذا كان المبلغ يتجاوز المتبقى من البند (الخادم يقرر؛ مسئول العهدة لا يرى أرقام الموازنة)
  useEffect(() => {
    setWarn("");
    if (!o || o === "__new__" || !(Number(m) > 0)) return;
    const t = setTimeout(() => {
      probe("lineStatus", { line_id: o, amount: Number(m) })
        .then((r) => setWarn(r && r.over ? r.message || "تنبيه: هذا المصروف يتجاوز المتبقى من البند" : ""))
        .catch(() => {});
    }, 450);
    return () => clearTimeout(t);
  }, [o, m]);
  if (s.length === 0 && !u)
    return (
      <div className="warn-banner">لا توجد بنود موازنة لهذه المدرسة — أبلغ المدير المالى لإضافتها قبل تسجيل الصرف.</div>
    );
  let A = async () => {
    if (!m) return;
    let z = o;
    h(!0);
    try {
      if (z === "__new__") {
        if (!c.trim()) {
          h(!1);
          return;
        }
        let $ = await act("addLine", {
          line: {
            school_id: custody.school_id,
            section: "بنود داخلية",
            name: c.trim(),
            allocated: 0,
          },
        });
        if (((z = $ && $.item && $.item.id), !z)) {
          h(!1);
          return;
        }
      }
      let E = {
          date: v,
          school_id: custody.school_id,
          custody_id: custody.id,
          line_id: z,
          spend_item: "",
          description: N.trim(),
          amount: Number(m) || 0,
          doc_url: "",
          doc_name: "",
          ref: "",
          note: "",
        },
        j = await act("addExpense", {
          expense: E,
        }),
        q = j && j.item && j.item.id;
      if (y && q) {
        let $ = new FileReader();
        await new Promise((ft) => {
          (($.onload = ft), $.readAsDataURL(y));
        });
        let I = $.result,
          J = String(I).split(",")[1];
        await act("uploadDoc", {
          id: q,
          filename: y.name,
          mimeType: y.type,
          dataBase64: J,
          dataUrl: I,
          doc_type: x,
        });
      }
      (r(""),
        b(""),
        p(""),
        g(null),
        showToast(y ? "تم تسجيل الصرف ورفع المستند" : "تم تسجيل الصرف — بانتظار الاعتماد"));
    } catch (E) {}
    h(!1);
  };
  return (
    <>
      {warn && <div className="warn-banner over">⚠ {warn}</div>}
      <div className="quick-row">
        <div className="qf">
          <span>بند الموازنة</span>
          <select value={o} onChange={(z) => d(z.target.value)}>
            {s.map((z) => (
              <option key={z.id} value={z.id}>
                {z.section ? z.section + " — " : ""}
                {z.name}
              </option>
            ))}
            {u && <option value="__new__">➕ بند جديد…</option>}
          </select>
        </div>
        {o === "__new__" && (
          <div
            className="qf"
            style={{
              minWidth: 150,
            }}
          >
            <span>اسم البند الجديد</span>
            <input value={c} onChange={(z) => p(z.target.value)} placeholder="بند يُضاف للموازنة الداخلية" />
          </div>
        )}
        <div className="qf">
          <span>المبلغ</span>
          <input
            type="number"
            step="any"
            value={m}
            onChange={(z) => r(z.target.value)}
            onKeyDown={(z) => z.key === "Enter" && A()}
            style={{
              width: 100,
            }}
          />
        </div>
        <div className="qf">
          <span>التاريخ</span>
          <input type="date" value={v} onChange={(z) => S(z.target.value)} />
        </div>
        <div
          className="qf"
          style={{
            flex: 1,
            minWidth: 150,
          }}
        >
          <span>البيان</span>
          <input
            value={N}
            onChange={(z) => b(z.target.value)}
            onKeyDown={(z) => z.key === "Enter" && A()}
            placeholder="ماذا صُرف؟"
          />
        </div>
        <div className="qf">
          <span>مستند</span>
          <div
            style={{
              display: "flex",
              gap: 4,
              alignItems: "center",
            }}
          >
            <button className="btn ghost sm" onClick={() => _.current && _.current.click()} title="إرفاق مستند الصرف">
              📎{y ? " ✓" : ""}
            </button>
            <input
              ref={_}
              type="file"
              hidden={!0}
              accept="image/*,application/pdf"
              onChange={(z) => g(z.target.files[0])}
            />
          </div>
        </div>
        {y && (
          <div className="qf">
            <span>النوع</span>
            <select value={x} onChange={(z) => C(z.target.value)}>
              {DOC_TYPES.map((z) => (
                <option key={z} value={z}>
                  {z}
                </option>
              ))}
            </select>
          </div>
        )}
        <button className="btn primary sm" disabled={f} onClick={A}>
          {f ? "…" : "+ صرف"}
        </button>
      </div>
    </>
  );
}
