// التقارير الديناميكية (v6): اختر فلتراً واحداً أو أكثر ← النتائج المطابقة فقط.
// مع الخادم: الحساب والفلترة داخل قاعدة البيانات (action «report» / «searchExpenses») ولا تُنقل إلا النتائج.
import React, { useEffect, useMemo, useState } from "react";
import { fmt, exportAs } from "../lib/utils";
import { CAT_LABEL, FY_MONTHS } from "../lib/model";
import { REMOTE, probe } from "../lib/api";
import { CUSTODY_STATES } from "../lib/custody";
import { STAGES } from "../lib/expense";
import { REPORTS } from "../lib/reportsCore";
import { localSearch } from "../lib/expenseSearch";
import { kindsOf } from "../modals/EntryModals";

const BUDGET_STATE = {
  within: ["داخل الموازنة", "green"],
  near: ["قريب من الاستنفاد", "amber"],
  reached: ["مستنفد", "amber"],
  over: ["متجاوز", "red"],
  none: ["لا توجد موازنة", "gray"],
};
const Q = ({ label, children }) => (
  <div className="qf">
    <span>{label}</span>
    {children}
  </div>
);
const signed = (v) => (v < -0.005 ? "neg" : v > 0.005 ? "pos" : "zero");

function useReport(kind, filters, data, showToast) {
  const [res, setRes] = useState(null);
  const [busy, setBusy] = useState(false);
  const key = JSON.stringify(filters);
  useEffect(() => {
    let live = true;
    (async () => {
      setBusy(true);
      try {
        let r;
        if (kind === "expenses") r = REMOTE ? await probe("report", { kind: "expenses", filters, page_size: 5000 }) : localSearch(data, filters, 1, 5000);
        else r = REMOTE ? await probe("report", { kind, filters }) : REPORTS[kind](data, filters);
        if (live) setRes(r);
      } catch (e) {
        if (live && showToast) showToast(e.message, "err");
      }
      if (live) setBusy(false);
    })();
    return () => (live = false);
  }, [kind, key, data]);
  return [res, busy];
}

export function DynamicReports({ data, showToast }) {
  const [rep, setRep] = useState("holder");
  return (
    <div className="stack">
      <div className="rep-cards">
        {[
          ["holder", "حالة مسئول العهدة", "ملخص المسئول + عهده: الإجمالى · المصروف · المتبقى · المفتوحة · المسواة · المتأخرة"],
          ["budget", "حالة الموازنات", "المكان · السنة · النوع · البند · المخصص · المصروف · المتبقى · النسبة · الحالة"],
          ["expenses", "تقرير المصروفات المتقدم", "مراحل الاعتماد والمراجعة والتسوية والمستند لكل مصروف"],
          ["financial", "التقرير المالى الشامل", "الموازنات + العهد + المصروفات + التسويات"],
        ].map(([k, t, d]) => (
          <button key={k} className={"rep-card " + (rep === k ? "on" : "")} onClick={() => setRep(k)} data-testid={"dr-" + k}>
            <b>{t}</b>
            <small>{d}</small>
          </button>
        ))}
      </div>
      {rep === "holder" && <HolderReport data={data} showToast={showToast} />}
      {rep === "budget" && <BudgetStateReport data={data} showToast={showToast} />}
      {rep === "expenses" && <ExpenseProReport data={data} showToast={showToast} />}
      {rep === "financial" && <FinancialSummary data={data} showToast={showToast} />}
    </div>
  );
}

function Toolbar({ busy, onExport, children }) {
  const [f, setF] = useState("excel");
  return (
    <div className="filters dr-filters">
      {children}
      <span className="spacer" />
      {busy && <span className="muted">جارٍ الحساب…</span>}
      <select value={f} onChange={(e) => setF(e.target.value)}>
        <option value="excel">Excel</option>
        <option value="pdf">PDF</option>
        <option value="csv">CSV</option>
      </select>
      <button className="btn primary sm" onClick={() => onExport(f)}>
        تصدير
      </button>
    </div>
  );
}

const noteOf = (data, f, labels) =>
  Object.entries(f)
    .filter(([k, v]) => v && labels[k])
    .map(([k, v]) => labels[k] + ": " + v)
    .join(" · ") || "بدون فلاتر";

// ---------------------------------------------------------------- (1) حالة مسئول العهدة
function HolderReport({ data, showToast }) {
  const init = { holder: "", school_id: "", title: "", kind: "", line_id: "", from: "", to: "", state: "", settle: "" };
  const [f, setF] = useState(init);
  const set = (k, v) => setF(Object.assign({}, f, { [k]: v }));
  const filters = useMemo(() => Object.fromEntries(Object.entries(f).filter(([, v]) => v)), [f]);
  const [res, busy] = useReport("custodyHolder", filters, data, showToast);
  const holders = Array.from(new Set((data.custodies || []).map((c) => c.holder || c.label).filter(Boolean))).sort();
  const s = (res && res.summary) || {};
  const rows = (res && res.rows) || [];
  const lines = (data.lines || []).filter((l) => !f.school_id || String(l.school_id) === String(f.school_id));
  const exp = (fmtOut) =>
    exportAs(
      fmtOut,
      "تقرير حالة مسئول العهدة",
      ["رقم العهدة", "اسم العهدة", "النوع", "المكان", "المسئول", "القيمة", "المصروف", "المتبقى", "الحالة", "قيد المراجعة", "غير مسواة"],
      rows.map((r) => [r.code, r.title, r.kind, r.school, r.holder, r.received, r.spent, r.remaining, (CUSTODY_STATES[r.state] || {}).label || r.state, r.under_review, r.unsettled]),
      noteOf(data, f, { holder: "المسئول", from: "من", to: "إلى", kind: "النوع", title: "اسم العهدة" }),
    );
  return (
    <div className="stack">
      <div className="panel">
        <Toolbar busy={busy} onExport={exp}>
          <Q label="مسئول العهدة">
            <select value={f.holder} onChange={(e) => set("holder", e.target.value)} data-testid="hr-holder">
              <option value="">الكل</option>
              {holders.map((h) => (
                <option key={h}>{h}</option>
              ))}
            </select>
          </Q>
          <Q label="المكان">
            <select value={f.school_id} onChange={(e) => setF(Object.assign({}, f, { school_id: e.target.value, line_id: "" }))} data-testid="hr-place">
              <option value="">الكل</option>
              {data.schools.map((x) => (
                <option key={x.id} value={x.id}>
                  {x.name}
                </option>
              ))}
            </select>
          </Q>
          <Q label="اسم العهدة">
            <select value={f.title} onChange={(e) => set("title", e.target.value)}>
              <option value="">الكل</option>
              {(data.custody_names || []).map((n) => (
                <option key={n.id}>{n.name}</option>
              ))}
            </select>
          </Q>
          <Q label="نوع العهدة">
            <select value={f.kind} onChange={(e) => set("kind", e.target.value)} data-testid="hr-kind">
              <option value="">الكل</option>
              {Array.from(new Set(kindsOf(data).concat((data.custodies || []).map((c) => c.kind).filter(Boolean)))).map((k) => (
                <option key={k}>{k}</option>
              ))}
            </select>
          </Q>
          <Q label="البند">
            <select value={f.line_id} onChange={(e) => set("line_id", e.target.value)}>
              <option value="">الكل</option>
              {lines.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                </option>
              ))}
            </select>
          </Q>
          <Q label="من تاريخ">
            <input type="date" value={f.from} onChange={(e) => set("from", e.target.value)} data-testid="hr-from" />
          </Q>
          <Q label="إلى تاريخ">
            <input type="date" value={f.to} onChange={(e) => set("to", e.target.value)} data-testid="hr-to" />
          </Q>
          <Q label="حالة العهدة">
            <select value={f.state} onChange={(e) => set("state", e.target.value)}>
              <option value="">الكل</option>
              {Object.entries(CUSTODY_STATES).map(([k, v]) => (
                <option key={k} value={k}>
                  {v.label}
                </option>
              ))}
            </select>
          </Q>
          <Q label="حالة التسوية">
            <select value={f.settle} onChange={(e) => set("settle", e.target.value)}>
              <option value="">الكل</option>
              <option value="settled">مسواة / مغلقة</option>
              <option value="unsettled">غير مسواة</option>
            </select>
          </Q>
          <button className="btn ghost sm" onClick={() => setF(init)}>
            مسح الفلاتر
          </button>
        </Toolbar>
      </div>
      <div className="panel" data-testid="hr-summary">
        <h3 className="panel-title">
          مسئول العهدة: {f.holder || (s.holders && s.holders.length === 1 ? s.holders[0] : (s.holders || []).length + " مسئول")}
        </h3>
        <div className="sum-grid">
          <Sum label="إجمالى العهد" v={s.received} />
          <Sum label="إجمالى المصروف" v={s.spent} />
          <Sum label={s.remaining < -0.005 ? "المتبقى (تجاوز)" : "المتبقى"} v={s.remaining} tone={signed(s.remaining)} testid="hr-remaining" />
          {(f.from || f.to || f.line_id) && <Sum label="المصروف ضمن الفلتر" v={s.filtered_spent} />}
          <Sum label="العهد المفتوحة" n={s.open} />
          <Sum label="العهد المسواة" n={s.settled} />
          <Sum label="العهد المتأخرة" n={s.overdue} tone={s.overdue ? "neg" : ""} />
          <Sum label="المصروفات قيد المراجعة" n={s.under_review} />
          <Sum label="المصروفات غير المسواة" n={s.unsettled} />
        </div>
        {s.remaining < -0.005 && <div className="warn-banner over">⚠ يوجد تجاوز: المصروف أكبر من إجمالى العهد بـ {fmt(-s.remaining)} ج.م</div>}
      </div>
      <div className="panel">
        <ReportTable
          head={["رقم العهدة", "اسم العهدة", "النوع", "المكان", "المسئول", "القيمة", "المصروف", "المتبقى", "الحالة", "قيد المراجعة", "غير مسواة"]}
          rows={rows.map((r) => [
            r.code,
            r.title || "—",
            r.kind || "—",
            r.school,
            r.holder,
            fmt(r.received),
            fmt(r.spent),
            <b className={"num " + (r.remaining < -0.005 ? "red" : "")}>{fmt(r.remaining)}</b>,
            <span className={"chip " + ((CUSTODY_STATES[r.state] || {}).tone || "gray")}>{(CUSTODY_STATES[r.state] || {}).label || r.state}</span>,
            r.under_review,
            r.unsettled,
          ])}
        />
      </div>
    </div>
  );
}

function Sum({ label, v, n, tone, testid }) {
  return (
    <div className={"sum " + (tone || "")} data-testid={testid}>
      <span>{label}</span>
      <b className="num">{n != null ? n : fmt(Math.round((v || 0) * 100) / 100)}</b>
    </div>
  );
}

function ReportTable({ head, rows, empty }) {
  if (!rows.length) return <div className="empty">{empty || "لا توجد نتائج مطابقة للفلاتر."}</div>;
  return (
    <div className="table-wrap">
      <table className="tbl" data-testid="dr-table">
        <thead>
          <tr>
            {head.map((h) => (
              <th key={h}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              {r.map((c, j) => (
                <td key={j}>{c}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ---------------------------------------------------------------- (2) حالة الموازنات
function BudgetStateReport({ data, showToast }) {
  const periods = Array.from(new Set(data.schools.map((s) => s.period).filter(Boolean))).sort().reverse();
  const init = { school_id: "", period: periods[0] || "", category: "", month: "", line_id: "", state: "" };
  const [f, setF] = useState(init);
  const set = (k, v) => setF(Object.assign({}, f, { [k]: v }));
  const filters = useMemo(() => Object.fromEntries(Object.entries(f).filter(([, v]) => v)), [f]);
  const [res, busy] = useReport("budget", filters, data, showToast);
  const s = (res && res.summary) || {};
  const rows = (res && res.rows) || [];
  const cats = Array.from(new Set(data.schools.map((x) => x.category || "school")));
  const head = ["المكان", "السنة", "نوع الموازنة", "القسم", "البند", f.month ? "مخصص الشهر" : "المخصص", f.month ? "مصروف الشهر" : "المصروف", "المتبقى", "نسبة الاستخدام", "حالة البند"];
  const exp = (o) =>
    exportAs(
      o,
      "تقرير حالة الموازنات",
      head,
      rows.map((r) => [r.school, r.period, CAT_LABEL[r.category] || r.category, r.section, r.line, r.alloc, r.spent, r.remaining, Math.round(r.pct * 100) + "%", BUDGET_STATE[r.state][0]]),
      (f.month ? "شهر " + FY_MONTHS[f.month - 1] : "السنة كاملة") + (f.period ? " · " + f.period : ""),
    );
  return (
    <div className="stack">
      <div className="panel">
        <Toolbar busy={busy} onExport={exp}>
          <Q label="المكان">
            <select value={f.school_id} onChange={(e) => setF(Object.assign({}, f, { school_id: e.target.value, line_id: "" }))} data-testid="br-place">
              <option value="">الكل</option>
              {data.schools.map((x) => (
                <option key={x.id} value={x.id}>
                  {x.name}
                </option>
              ))}
            </select>
          </Q>
          <Q label="السنة المالية">
            <select value={f.period} onChange={(e) => set("period", e.target.value)}>
              <option value="">كل السنوات</option>
              {periods.map((p) => (
                <option key={p}>{p}</option>
              ))}
            </select>
          </Q>
          <Q label="نوع الموازنة">
            <select value={f.category} onChange={(e) => set("category", e.target.value)}>
              <option value="">الكل</option>
              {cats.map((c) => (
                <option key={c} value={c}>
                  {CAT_LABEL[c] || c}
                </option>
              ))}
            </select>
          </Q>
          <Q label="الفترة">
            <select value={f.month} onChange={(e) => set("month", e.target.value)} data-testid="br-month">
              <option value="">السنة كاملة</option>
              {FY_MONTHS.map((m, i) => (
                <option key={m} value={i + 1}>
                  {m}
                </option>
              ))}
            </select>
          </Q>
          <Q label="البند">
            <select value={f.line_id} onChange={(e) => set("line_id", e.target.value)}>
              <option value="">الكل</option>
              {(data.lines || [])
                .filter((l) => !f.school_id || String(l.school_id) === String(f.school_id))
                .map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.name}
                  </option>
                ))}
            </select>
          </Q>
          <Q label="حالة البند">
            <select value={f.state} onChange={(e) => set("state", e.target.value)} data-testid="br-state">
              <option value="">الكل</option>
              {Object.entries(BUDGET_STATE).map(([k, v]) => (
                <option key={k} value={k}>
                  {v[0]}
                </option>
              ))}
            </select>
          </Q>
        </Toolbar>
      </div>
      <div className="panel" data-testid="br-summary">
        <div className="sum-grid">
          <Sum label="عدد البنود" n={s.lines} />
          <Sum label={f.month ? "مخصص الشهر" : "المخصص"} v={s.alloc} />
          <Sum label={f.month ? "مصروف الشهر" : "المصروف"} v={s.spent} />
          <Sum label="المتبقى" v={s.remaining} tone={signed(s.remaining)} />
          <Sum label="متجاوز" n={s.over} tone={s.over ? "neg" : ""} />
          <Sum label="مستنفد" n={s.reached} />
          <Sum label="قريب من الاستنفاد" n={s.near} />
          <Sum label="داخل الموازنة" n={s.within} />
        </div>
      </div>
      <div className="panel">
        <ReportTable
          head={head}
          rows={rows.map((r) => [
            r.school,
            r.period,
            CAT_LABEL[r.category] || r.category,
            r.section,
            <span>
              {r.line}
              {String(r.active || "نعم").indexOf("نعم") < 0 && <span className="chip gray">معطّل</span>}
            </span>,
            fmt(r.alloc),
            fmt(r.spent),
            <b className={"num " + (r.remaining < -0.5 ? "red" : "")}>{fmt(r.remaining)}</b>,
            Math.round(r.pct * 100) + "%",
            <span className={"chip " + BUDGET_STATE[r.state][1]}>{BUDGET_STATE[r.state][0]}</span>,
          ])}
        />
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- (3) المصروفات المتقدم
const APPROVAL_TXT = { pending: "بانتظار", approved: "معتمد", rejected: "مرفوض", returned: "معاد للتعديل", draft: "مسودة" };
const FIN_TXT = { "": "—", approved: "تمت المراجعة", rejected: "مرفوض", returned: "معاد للتعديل" };
function ExpenseProReport({ data, showToast }) {
  const init = { school_id: "", holder: "", custody_id: "", line_id: "", manager_id: "", stage: "", from: "", to: "", spend_item: "" };
  const [f, setF] = useState(init);
  const set = (k, v) => setF(Object.assign({}, f, { [k]: v }));
  const filters = useMemo(() => {
    const o = Object.fromEntries(Object.entries(f).filter(([k, v]) => v && k !== "stage"));
    if (f.stage) o.stages = [f.stage];
    return o;
  }, [f]);
  const [res, busy] = useReport("expenses", filters, data, showToast);
  const rows = (res && res.rows) || [];
  const custs = (data.custodies || []).filter((c) => !f.school_id || String(c.school_id) === String(f.school_id));
  const head = ["رقم المصروف", "التاريخ", "المكان", "العهدة", "مسئول العهدة", "البند", "القيمة", "اعتماد المدير المباشر", "مراجعة المدير المالى", "التسوية", "المستند"];
  const docTxt = (r) => (r.doc_url ? (String(r.doc_url).indexOf("http") === 0 ? r.doc_url : "مرفوع بالنظام") : "لا يوجد");
  const exp = (o) =>
    exportAs(
      o,
      "تقرير المصروفات",
      head.concat(["الحالة"]),
      rows.map((r) => [
        r.txn_no,
        r.date,
        r.school,
        r.custody_code,
        r.holder,
        r.line,
        r.amount,
        (APPROVAL_TXT[r.approval] || r.approval) + (r.approved_by ? " — " + r.approved_by : ""),
        (FIN_TXT[r.fin_approval || ""] || r.fin_approval) + (r.fin_by ? " — " + r.fin_by : ""),
        String(r.settled || "").indexOf("نعم") >= 0 ? "تمت" + (r.settled_by ? " — " + r.settled_by : "") : "لم تتم",
        docTxt(r),
        (STAGES[r.stage] || {}).label || r.stage,
      ]),
      "عدد " + (res ? res.total : 0) + " · الإجمالى " + fmt(res ? res.sum : 0),
    );
  return (
    <div className="stack">
      <div className="panel">
        <Toolbar busy={busy} onExport={exp}>
          <Q label="المكان">
            <select value={f.school_id} onChange={(e) => setF(Object.assign({}, f, { school_id: e.target.value, custody_id: "", line_id: "" }))}>
              <option value="">الكل</option>
              {data.schools.map((x) => (
                <option key={x.id} value={x.id}>
                  {x.name}
                </option>
              ))}
            </select>
          </Q>
          <Q label="مسئول العهدة">
            <select value={f.holder} onChange={(e) => set("holder", e.target.value)}>
              <option value="">الكل</option>
              {Array.from(new Set(custs.map((c) => c.holder || c.label).filter(Boolean))).map((h) => (
                <option key={h}>{h}</option>
              ))}
            </select>
          </Q>
          <Q label="العهدة">
            <select value={f.custody_id} onChange={(e) => set("custody_id", e.target.value)}>
              <option value="">الكل</option>
              {custs.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.code} · {c.title || c.label}
                </option>
              ))}
            </select>
          </Q>
          <Q label="البند">
            <select value={f.line_id} onChange={(e) => set("line_id", e.target.value)}>
              <option value="">الكل</option>
              {(data.lines || [])
                .filter((l) => !f.school_id || String(l.school_id) === String(f.school_id))
                .map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.name}
                  </option>
                ))}
            </select>
          </Q>
          <Q label="المدير المباشر">
            <select value={f.manager_id} onChange={(e) => set("manager_id", e.target.value)}>
              <option value="">الكل</option>
              {(data.managers || []).map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </Q>
          <Q label="حالة المصروف">
            <select value={f.stage} onChange={(e) => set("stage", e.target.value)} data-testid="er-stage">
              <option value="">الكل</option>
              {Object.entries(STAGES).map(([k, v]) => (
                <option key={k} value={k}>
                  {v.short || v.label}
                </option>
              ))}
            </select>
          </Q>
          <Q label="نوع المصروف">
            <select value={f.spend_item} onChange={(e) => set("spend_item", e.target.value)}>
              <option value="">الكل</option>
              {(data.spendItems || []).map((x) => (
                <option key={x.id}>{x.name}</option>
              ))}
            </select>
          </Q>
          <Q label="من">
            <input type="date" value={f.from} onChange={(e) => set("from", e.target.value)} />
          </Q>
          <Q label="إلى">
            <input type="date" value={f.to} onChange={(e) => set("to", e.target.value)} />
          </Q>
        </Toolbar>
        <div className="exp-count">
          عدد المصروفات: <b>{res ? res.total : "…"}</b> · الإجمالى (بدون الملغى والمرفوض): <b>{res ? fmt(res.sum) : "…"}</b> ج.م
        </div>
      </div>
      <div className="panel">
        <ReportTable
          head={head}
          rows={rows.map((r) => [
            <b>{r.txn_no}</b>,
            r.date,
            r.school,
            r.custody_code,
            r.holder || "—",
            r.line || r.spend_item || "—",
            fmt(r.amount),
            (APPROVAL_TXT[r.approval] || r.approval || "—") + (r.approved_by ? " · " + r.approved_by : ""),
            (FIN_TXT[r.fin_approval || ""] || r.fin_approval) + (r.fin_by ? " · " + r.fin_by : ""),
            String(r.settled || "").indexOf("نعم") >= 0 ? "تمت" : "لم تتم",
            r.doc_url ? <span className="chip navy">يوجد</span> : <span className="chip amber">لا يوجد</span>,
          ])}
        />
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- (4) التقرير المالى الشامل
function FinancialSummary({ data, showToast }) {
  const periods = Array.from(new Set(data.schools.map((s) => s.period).filter(Boolean))).sort().reverse();
  const [f, setF] = useState({ school_id: "", period: periods[0] || "", from: "", to: "" });
  const set = (k, v) => setF(Object.assign({}, f, { [k]: v }));
  const filters = useMemo(() => Object.fromEntries(Object.entries(f).filter(([, v]) => v)), [f]);
  const [res, busy] = useReport("financial", filters, data, showToast);
  const s = (res && res.summary) || {};
  const g = (x) => x || { n: 0, amount: 0 };
  const items = [
    ["إجمالى الموازنات", s.budget_total],
    ["المصروف المحتسب على الموازنات", s.budget_spent],
    ["إجمالى المتبقى من الموازنات", s.budget_remaining],
    ["إجمالى العهد", s.custody_total],
    ["المصروف من العهد", s.custody_spent],
    ["المتبقى من العهد", s.custody_remaining],
    ["إجمالى المصروفات", s.expenses_total],
    ["المصروفات قيد الاعتماد (المدير المباشر)", g(s.pending_manager).amount, g(s.pending_manager).n],
    ["المصروفات قيد المراجعة (المدير المالى)", g(s.pending_finance).amount, g(s.pending_finance).n],
    ["المصروفات المسواة", g(s.settled).amount, g(s.settled).n],
    ["المصروفات غير المسواة", g(s.unsettled).amount, g(s.unsettled).n],
    ["مسودات / معادة للتعديل", g(s.returned).amount, g(s.returned).n],
    ["المصروفات الملغاة", g(s.cancelled).amount, g(s.cancelled).n],
  ];
  const exp = (o) =>
    exportAs(
      o,
      "التقرير المالى الشامل",
      ["البند", "القيمة", "العدد"],
      items
        .map((x) => [x[0], Math.round((x[1] || 0) * 100) / 100, x[2] == null ? "" : x[2]])
        .concat([["البنود المتجاوزة", s.over_lines, ""], ["العهد المتأخرة", s.overdue_custodies, ""]]),
      (f.period || "كل السنوات") + (f.from || f.to ? " · " + (f.from || "…") + " ← " + (f.to || "…") : ""),
    );
  return (
    <div className="stack">
      <div className="panel">
        <Toolbar busy={busy} onExport={exp}>
          <Q label="المكان">
            <select value={f.school_id} onChange={(e) => set("school_id", e.target.value)} data-testid="fr-place">
              <option value="">الكل</option>
              {data.schools.map((x) => (
                <option key={x.id} value={x.id}>
                  {x.name}
                </option>
              ))}
            </select>
          </Q>
          <Q label="السنة المالية">
            <select value={f.period} onChange={(e) => set("period", e.target.value)}>
              <option value="">كل السنوات</option>
              {periods.map((p) => (
                <option key={p}>{p}</option>
              ))}
            </select>
          </Q>
          <Q label="مصروفات من">
            <input type="date" value={f.from} onChange={(e) => set("from", e.target.value)} />
          </Q>
          <Q label="إلى">
            <input type="date" value={f.to} onChange={(e) => set("to", e.target.value)} />
          </Q>
        </Toolbar>
      </div>
      <div className="panel" data-testid="fr-summary">
        <div className="sum-grid">
          {items.map(([l, v, n]) => (
            <div key={l} className={"sum " + (l.indexOf("المتبقى") >= 0 ? signed(v || 0) : "")}>
              <span>{l}</span>
              <b className="num">{fmt(Math.round((v || 0) * 100) / 100)}</b>
              {n != null && <small>{n} مصروف</small>}
            </div>
          ))}
          <div className={"sum " + (s.over_lines ? "neg" : "")}>
            <span>البنود المتجاوزة</span>
            <b className="num">{s.over_lines || 0}</b>
          </div>
          <div className={"sum " + (s.overdue_custodies ? "neg" : "")}>
            <span>العهد المتأخرة</span>
            <b className="num">{s.overdue_custodies || 0}</b>
          </div>
        </div>
      </div>
      <div className="dash-grid">
        <div className="panel">
          <h3 className="panel-title">البنود المتجاوزة</h3>
          <ReportTable
            head={["المكان", "البند", "المخصص", "المصروف", "التجاوز"]}
            rows={((res && res.over_lines) || []).map((x) => [x.school, x.line, fmt(x.alloc), fmt(x.spent), <b className="red num">{fmt(x.over)}</b>])}
            empty="✔ لا توجد بنود متجاوزة."
          />
        </div>
        <div className="panel">
          <h3 className="panel-title">العهد المتأخرة</h3>
          <ReportTable
            head={["العهدة", "المسئول", "منذ (يوم)", "المتبقى"]}
            rows={((res && res.overdue_custodies) || []).map((x) => [x.code, x.holder, x.age, fmt(x.remaining)])}
            empty="✔ لا توجد عهد متأخرة."
          />
        </div>
      </div>
    </div>
  );
}
