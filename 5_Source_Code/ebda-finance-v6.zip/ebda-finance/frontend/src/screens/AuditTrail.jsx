// تتبع التعديلات (Audit Trail): من قام بماذا، ومتى، وعلى أى عنصر، وفى أى مكان، مع القيمة القديمة والجديدة.
// المصدر: audit_log (الطلب نفسه) + audit_changes (التغييرات الفعلية على الجداول، مربوطة برقم المعاملة txid).
import React, { useMemo, useState } from "react";
import { fmt, exportAs } from "../lib/utils";
import { ROLE_LABEL } from "../lib/model";

const ACTION = {
  addExpense: "تسجيل مصروف",
  addCentral: "شراء مركزى",
  updateExpense: "تعديل مصروف",
  reviewExpense: "مراجعة/اعتماد مالى لمصروف",
  deleteExpense: "حذف مصروف",
  uploadDoc: "رفع مستند",
  addTranche: "إضافة دفعة لعهدة",
  addCustody: "إنشاء عهدة",
  updateCustody: "تعديل عهدة",
  deleteCustody: "حذف عهدة",
  addSchool: "إضافة جهة",
  updateSchool: "تعديل جهة",
  deleteSchool: "حذف جهة",
  addLine: "إضافة بند موازنة",
  updateLine: "تعديل بند موازنة",
  deleteLine: "حذف بند موازنة",
  importBudget: "استيراد موازنة",
  addRequest: "طلب عهدة",
  decideRequest: "قرار المدير المباشر على طلب",
  transferRequest: "اعتماد مالى وتحويل طلب",
  updateRequestItem: "تعديل بند طلب",
  addUser: "إضافة مستخدم",
  updateUser: "تعديل مستخدم",
  deleteUser: "حذف مستخدم",
  resetPin: "تصفير كلمة سر",
  setPassword: "تغيير كلمة السر",
  addSalary: "إضافة راتب",
  updateSalary: "تعديل راتب",
  deleteSalary: "حذف راتب",
  importSalaries: "استيراد رواتب",
  addEmployee: "إضافة موظف",
  updateEmployee: "تعديل موظف",
  archiveEmployee: "أرشفة موظف",
  importEmployees: "استيراد موظفين",
  addPayslip: "إضافة راتب شهرى",
  addTempBudget: "موازنة مؤقتة",
  emailReport: "إرسال تقرير بالبريد",
  logExport: "تصدير تقرير",
  login: "تسجيل دخول",
  loginFailed: "محاولة دخول فاشلة",
  saveCustodyName: "حفظ اسم عهدة",
  submitCustody: "إرسال عهدة للمراجعة",
  approveCustody: "اعتماد عهدة",
  cancelCustody: "إلغاء عهدة",
  setCustodyLines: "توزيع العهدة على البنود",
  deleteBudget: "حذف موازنة",
  restoreBudget: "استرجاع موازنة محذوفة",
  importPayroll: "استيراد كشف رواتب شهرى",
  adjustPayslip: "تعديل مؤثرات راتب",
  approvePayroll: "اعتماد رواتب الشهر",
  reopenPayroll: "إعادة فتح رواتب الشهر",
  savePayrollComponent: "حفظ عنصر راتب",
  savePayrollMap: "حفظ ربط أعمدة الرواتب",
  submitExpense: "إرسال مصروف للاعتماد",
  cancelExpense: "إلغاء مصروف",
  unapproveExpense: "إلغاء اعتماد مصروف",
  saveCustodyKind: "حفظ نوع عهدة",
  saveEntityType: "حفظ نوع موازنة/جهة",
  setLineActive: "تعطيل/تفعيل بند",
  setSetting: "تعديل إعداد",
  createBackup: "إنشاء نسخة احتياطية",
  downloadBackup: "تنزيل نسخة احتياطية",
  restoreBackup: "استعادة نسخة احتياطية",
  linkEmployee: "ربط موظف",
  importEmployeesSafe: "استيراد العاملين (معاينة/تأكيد)",
};
const TYPES = {
  add: ["إضافة", "teal"],
  edit: ["تعديل", "amber"],
  del: ["حذف", "red"],
  import: ["استيراد", "navy"],
  export: ["تصدير", "gray"],
  approve: ["اعتماد", "green"],
  reject: ["رفض", "red"],
  settle: ["تسوية", "green"],
  doc: ["مستند", "navy"],
  security: ["أمان", "gray"],
  login: ["دخول", "gray"],
  cancel: ["إلغاء", "red"],
  restore: ["استرجاع", "teal"],
  ret: ["إعادة للتعديل", "amber"],
  backup: ["نسخ احتياطى", "navy"],
};
const TBL = {
  lines: "بند موازنة",
  expenses: "مصروف",
  custodies: "عهدة",
  tranches: "دفعة عهدة",
  schools: "جهة",
  users: "مستخدم",
  requests: "طلب عهدة",
  temp_budgets: "موازنة مؤقتة",
  custody_lines: "توزيع عهدة",
  custody_names: "اسم عهدة",
  payslips: "راتب شهرى",
  employees: "موظف",
  payroll_periods: "فترة رواتب",
  payroll_components: "عنصر راتب",
  custody_kinds: "نوع عهدة",
  entity_types: "نوع موازنة",
};
const FIELD = {
  allocated: "المخصص",
  amount: "المبلغ",
  name: "الاسم",
  section: "القسم",
  note: "ملاحظات",
  monthly_plan: "التوزيع الشهرى",
  approval: "اعتماد المدير المباشر",
  approved_by: "اعتمده",
  fin_approval: "الاعتماد المالى",
  fin_by: "اعتمده مالياً",
  fin_note: "ملاحظة مالية",
  settled: "التسوية",
  review_status: "مراجعة المستند",
  review_note: "ملاحظة المراجعة",
  status: "الحالة",
  date: "التاريخ",
  description: "الوصف",
  line_id: "البند",
  doc_url: "المستند",
  doc_name: "اسم المستند",
  doc_type: "نوع المستند",
  pay_method: "طريقة الدفع",
  holder: "مسئول العهدة",
  user: "المستخدم المسئول",
  label: "المسمى",
  kind: "نوع العهدة",
  purpose: "الغرض",
  role: "الدور",
  schools: "النطاق",
  active: "نشط",
  pin: "كلمة السر",
  username: "اسم المستخدم",
  email: "البريد",
  perms: "صلاحيات إضافية",
  period: "السنة المالية",
  category: "النوع",
  spend_item: "نوع المصروف",
  total: "الإجمالى",
  title: "اسم العهدة",
  holder_emp_id: "مسئول العهدة (موظف)",
  cancel_reason: "سبب الإلغاء",
  cancelled_by: "ألغاها",
  deleted_at: "تاريخ الحذف",
  deleted_by: "حذفها",
  delete_reason: "سبب الحذف",
  net: "الصافى",
  base: "الأساسى",
  adjustments: "المؤثرات",
  absent_days: "أيام الغياب",
  insurance_status: "التأمينات",
  national_key: "الرقم القومى",
  staff_group: "الفئة",
  sections: "الأقسام",
  approval_note: "ملاحظة المدير المباشر",
  return_reason: "سبب الإعادة",
  returned_by: "أعاده",
  settled_by: "سوّاه",
  submitted_at: "أُرسل للاعتماد",
  manager_id: "المدير المباشر",
  dept: "القسم",
  user_id: "مالك العهدة",
};
const VAL = { returned: "معاد للتعديل", cancelled: "ملغاة", draft: "مسودة", review: "قيد المراجعة", approved: "معتمد", rejected: "مرفوض", pending: "معلق", open: "مفتوحة", pending_settlement: "تحت التسوية", settled: "تمت التسوية", closed: "مغلقة", pending_supervisor: "بانتظار المدير المباشر", pending_accountant: "بانتظار المدير المالى", transferred: "تم التحويل" };
const SKIP = new Set(["approved_by_id", "fin_by_id", "settled_by_id", "created_by_id", "returned_at", "cancelled_at", "submitted_by", "source_file", "id", "created_at", "created_by", "updated_at", "updated_by", "txn_no", "code", "req_no", "approved_at", "fin_at", "settled_at", "decided_at", "opened_at", "doc_is_link"]);

function parse(t) {
  try {
    return typeof t === "string" ? JSON.parse(t) : t || {};
  } catch (e) {
    return {};
  }
}
function opType(a, d) {
  const act = a.action,
    p = d.patch || {};
  if (act === "login") return "login";
  if (act === "cancelCustody" || act === "cancelExpense") return "cancel";
  if (act === "createBackup" || act === "downloadBackup") return "backup";
  if (act === "restoreBackup") return "restore";
  if (act === "unapproveExpense") return "edit";
  if (act === "submitExpense") return "edit";
  if (act === "updateExpense" && p.approval === "returned") return "ret";
  if (act === "reviewExpense" && p.fin_approval === "returned") return "ret";
  if (act === "restoreBudget") return "restore";
  if (act === "approveCustody" || act === "approvePayroll") return "approve";
  if (act === "reopenPayroll") return "edit";
  if (act === "loginFailed") return "security";
  if (act === "logExport" || act === "emailReport") return "export";
  if (act === "importEmployeesSafe" && (d.mode || "preview") !== "commit") return "edit";
  if (/^import/.test(act)) return "import";
  if (act === "uploadDoc") return "doc";
  if (/^(delete|archive)/.test(act)) return "del";
  if (act === "setPassword" || act === "resetPin") return "security";
  if (act === "updateExpense" && p.approval) return p.approval === "rejected" ? "reject" : "approve";
  if (act === "reviewExpense") return p.fin_approval === "rejected" ? "reject" : yesish(p.settled) ? "settle" : p.fin_approval ? "approve" : "edit";
  if (act === "decideRequest" || act === "transferRequest") return d.decision === "approve" ? "approve" : "reject";
  if (act === "updateCustody" && (p.status === "settled" || p.status === "closed")) return "settle";
  if (/^add/.test(act)) return "add";
  return "edit";
}
let COMP_NAMES = {}; // أسماء عناصر الراتب (Master Data) لعرض المؤثرات بالاسم
const yesish = (v) => String(v || "").indexOf("نعم") >= 0;
const show = (k, v) => {
  if (v == null || v === "") return "—";
  if (k === "monthly_plan") return "توزيع مخصص";
  if (k === "adjustments" && typeof v === "object") {
    const e = Object.entries(v || {});
    return e.length ? e.map(([c, x]) => (COMP_NAMES[c] || c) + " " + fmt(x)).join(" · ") : "لا يوجد";
  }
  if (typeof v === "number") return fmt(v);
  if (VAL[v]) return VAL[v];
  const s = typeof v === "object" ? JSON.stringify(v) : String(v);
  return s.length > 60 ? s.slice(0, 60) + "…" : s;
};

export function AuditTrail({ data }) {
  const schoolName = (id) => (data.schools.find((s) => String(s.id) === String(id)) || {}).name || "";
  COMP_NAMES = Object.fromEntries((data.payroll_components || []).map((c) => [c.code, c.name]));
  const lookup = (tbl, id) => {
    const src = { expenses: data.expenses, custodies: data.custodies, lines: data.lines, payslips: data.payslips, employees: data.employees, users: data.users, schools: data.schools, payroll_periods: data.payroll_periods, payroll_components: data.payroll_components, custody_names: data.custody_names }[tbl];
    const r = (src || []).find((x) => String(x.id) === String(id));
    return r ? r.txn_no || r.code || r.emp_name || r.name || r.username || r.description || r.month || "" : "";
  };
  const rows = useMemo(() => {
    const byTx = {};
    (data.audit_changes || []).forEach((c) => (byTx[c.txid] = byTx[c.txid] || []).push(c));
    return (data.audit || []).map((a) => {
      const d = parse(a.details);
      const ch = (a.txid != null && byTx[a.txid]) || [];
      const type = opType(a, d);
      // العنصر
      let item = "";
      const first = ch[0];
      const rec = first ? Object.assign({}, first.old_v || {}, first.new_v || {}) : {};
      if (first) {
        const ident = rec.txn_no || rec.code || rec.req_no || rec.name || rec.emp_name || rec.username || rec.label || lookup(first.tbl, first.row_id) || (rec.amount != null ? fmt(rec.amount) + " ج.م" : "") || first.row_id;
        item = (TBL[first.tbl] || first.tbl) + (ident ? " «" + ident + "»" : "") + (ch.length > 1 ? " +" + (ch.length - 1) : "");
      } else if (a.action === "logExport") item = d.report ? "«" + d.report + "» · " + String(d.format || "").toUpperCase() : "";
      else if (d.line) item = "بند «" + (d.line.name || "") + "»";
      else if (d.custody) item = "عهدة «" + (d.custody.holder || d.custody.label || "") + "»";
      else if (d.expense) item = "مصروف «" + (d.expense.description || "") + "»";
      else if (d.user) item = "مستخدم «" + (d.user.username || "") + "»";
      else if (a.entity) item = a.entity;
      // المكان
      const sid =
        (ch.find((c) => c.school_id) || {}).school_id ||
        (d.line && d.line.school_id) ||
        (d.custody && d.custody.school_id) ||
        (d.expense && d.expense.school_id) ||
        d.school_id ||
        (d.lines && d.lines[0] && d.lines[0].school_id) ||
        "";
      // القديم / الجديد (أول تعديل ذو معنى)
      let oldV = "",
        newV = "";
      const upd = ch.find((c) => c.op === "update");
      if (upd) {
        const k = Object.keys(upd.new_v || {}).find((x) => !SKIP.has(x)) || Object.keys(upd.new_v || {})[0];
        if (k) {
          oldV = (FIELD[k] || k) + ": " + show(k, (upd.old_v || {})[k]);
          newV = (FIELD[k] || k) + ": " + show(k, (upd.new_v || {})[k]);
        }
      } else if (ch.find((c) => c.op === "insert")) {
        const ins = ch.find((c) => c.op === "insert").new_v || {};
        newV = ins.allocated != null ? "المخصص: " + fmt(ins.allocated) : ins.amount != null ? "المبلغ: " + fmt(ins.amount) : "سجل جديد";
      } else if (ch.find((c) => c.op === "delete")) {
        const del = ch.find((c) => c.op === "delete").old_v || {};
        oldV = del.allocated != null ? "المخصص: " + fmt(del.allocated) : del.amount != null ? "المبلغ: " + fmt(del.amount) : "تم الحذف";
      } else if (d.patch) {
        const k = Object.keys(d.patch).find((x) => !SKIP.has(x));
        if (k) newV = (FIELD[k] || k) + ": " + show(k, d.patch[k]);
        if (d.before && k) oldV = (FIELD[k] || k) + ": " + show(k, d.before[k]);
      }
      if (a.action === "importBudget" && ch.length) {
        const ins = ch.filter((c) => c.op === "insert").length,
          up = ch.filter((c) => c.op === "update").length;
        newV = "أُضيف " + ins + " بند · عُدّل " + up;
        oldV = up ? "انظر التفاصيل (" + up + " تعديل)" : "";
      }
      if (a.action === "importPayroll") {
        const ins = ch.filter((c) => c.op === "insert" && c.tbl === "payslips").length,
          up = ch.filter((c) => c.op === "update" && c.tbl === "payslips").length,
          ne = ch.filter((c) => c.op === "insert" && c.tbl === "employees").length;
        item = "رواتب شهر " + (d.month || "") + " · " + ((d.rows || []).length || "") + " صف";
        newV = ch.length ? "رواتب جديدة " + ins + " · محدثة " + up + " · موظفون جدد " + ne : "";
        oldV = "";
      }
      if (a.action === "deleteBudget" || a.action === "restoreBudget") {
        const n = ch.filter((c) => c.tbl === "lines").length;
        const tot = ch.filter((c) => c.tbl === "lines").reduce((x, c) => x + Number(((c.new_v || c.old_v) || {}).allocated || 0), 0);
        item = "موازنة " + (d.period ? "السنة " + d.period + " · " : "") + n + " بند" + (tot ? " · " + fmt(tot) + " ج.م" : "");
      }
      if (d.reason) newV = (newV ? newV + " · " : "") + "السبب: " + d.reason;
      const schools = Array.from(new Set(ch.map((c) => c.school_id).filter(Boolean)));
      return { a, d, ch, type, item, place: schools.length > 1 ? schools.map(schoolName).join(" · ") : schoolName(sid), oldV, newV, failed: !ch.length && /^(add|update|delete|import|review|transfer|decide)/.test(a.action) };
    });
  }, [data]);

  const [user, setUser] = useState("all");
  const [type, setType] = useState("all");
  const [place, setPlace] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [q, setQ] = useState("");
  const [logins, setLogins] = useState(false);
  const [open, setOpen] = useState(null);
  const [fmtOut, setFmtOut] = useState("excel");
  const users = Array.from(new Set(rows.map((r) => r.a.actor).filter(Boolean))).sort();
  const places = Array.from(new Set(rows.map((r) => r.place).filter(Boolean))).sort();
  const shown = rows.filter(
    (r) =>
      (logins || (r.type !== "login" && r.a.action !== "loginFailed")) &&
      (user === "all" || r.a.actor === user) &&
      (type === "all" || r.type === type) &&
      (place === "all" || r.place === place) &&
      (!from || String(r.a.ts) >= from) &&
      (!to || String(r.a.ts).slice(0, 10) <= to) &&
      (!q || (r.item + " " + (ACTION[r.a.action] || r.a.action) + " " + r.oldV + " " + r.newV).indexOf(q) >= 0),
  );
  const doExport = () =>
    exportAs(
      fmtOut,
      "تتبع التعديلات",
      ["التاريخ والوقت", "المستخدم", "الدور", "نوع العملية", "العملية", "العنصر", "المكان", "القيمة القديمة", "القيمة الجديدة"],
      shown.map((r) => [ts(r.a.ts), r.a.actor, ROLE_LABEL[r.a.actor_role] || r.a.actor_role, TYPES[r.type][0], ACTION[r.a.action] || r.a.action, r.item, r.place, r.oldV, r.newV]),
    );

  return (
    <div className="stack">
      <div className="toolbar">
        <h3 className="section-h">تتبع التعديلات</h3>
        <span className="hint" style={{ margin: 0 }}>
          آخر {rows.length} عملية · كل إضافة وتعديل وحذف واستيراد وتصدير واعتماد مع القيمة القديمة والجديدة
        </span>
      </div>
      <div className="panel" style={{ padding: 12 }}>
        <div className="filters">
          <div className="qf">
            <span>المستخدم</span>
            <select value={user} onChange={(e) => setUser(e.target.value)}>
              <option value="all">الكل</option>
              {users.map((u) => (
                <option key={u}>{u}</option>
              ))}
            </select>
          </div>
          <div className="qf">
            <span>نوع العملية</span>
            <select value={type} onChange={(e) => setType(e.target.value)}>
              <option value="all">الكل</option>
              {Object.keys(TYPES).map((k) => (
                <option key={k} value={k}>
                  {TYPES[k][0]}
                </option>
              ))}
            </select>
          </div>
          <div className="qf">
            <span>المكان</span>
            <select value={place} onChange={(e) => setPlace(e.target.value)}>
              <option value="all">الكل</option>
              {places.map((p) => (
                <option key={p}>{p}</option>
              ))}
            </select>
          </div>
          <div className="qf">
            <span>من تاريخ</span>
            <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </div>
          <div className="qf">
            <span>إلى تاريخ</span>
            <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          </div>
          <div className="qf">
            <span>بحث</span>
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بند، رقم عملية، قيمة…" />
          </div>
          <label className="check">
            <input type="checkbox" checked={logins} onChange={(e) => setLogins(e.target.checked)} /> إظهار تسجيلات الدخول
          </label>
          <div className="spacer" />
          <select value={fmtOut} onChange={(e) => setFmtOut(e.target.value)}>
            <option value="excel">Excel</option>
            <option value="pdf">PDF</option>
            <option value="csv">CSV</option>
          </select>
          <button className="btn ghost sm" onClick={doExport}>
            تصدير
          </button>
        </div>
      </div>
      <div className="table-wrap">
        <table className="tbl audit">
          <thead>
            <tr>
              <th>التاريخ والوقت</th>
              <th>المستخدم</th>
              <th>نوع العملية</th>
              <th>العملية</th>
              <th>العنصر</th>
              <th>المكان</th>
              <th>القيمة القديمة</th>
              <th>القيمة الجديدة</th>
            </tr>
          </thead>
          <tbody>
            {shown.map((r) => (
              <React.Fragment key={r.a.id}>
                <tr className={r.ch.length ? "click" : ""} onClick={() => r.ch.length && setOpen(open === r.a.id ? null : r.a.id)}>
                  <td className="num" style={{ whiteSpace: "nowrap" }}>
                    {ts(r.a.ts)}
                  </td>
                  <td>
                    {r.a.actor}
                    <span className="cust-sub">{ROLE_LABEL[r.a.actor_role] || r.a.actor_role}</span>
                  </td>
                  <td>
                    <span className={"chip " + TYPES[r.type][1]}>{TYPES[r.type][0]}</span>
                  </td>
                  <td>
                    {ACTION[r.a.action] || r.a.action}
                    {r.failed && <span className="cust-sub">لم تُنفَّذ (مرفوضة أو بلا تغيير)</span>}
                  </td>
                  <td>
                    {r.item || "—"}
                    {r.ch.length > 1 && <span className="cust-sub">اضغط لعرض كل التغييرات ({r.ch.length})</span>}
                  </td>
                  <td style={{ fontSize: 12.5 }}>{r.place || "—"}</td>
                  <td className="old-v">{r.oldV || "—"}</td>
                  <td className="new-v">{r.newV || "—"}</td>
                </tr>
                {open === r.a.id && (
                  <tr className="ops-row">
                    <td colSpan={8}>
                      <ChangeList changes={r.ch} schoolName={schoolName} />
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
        {!shown.length && <div className="empty">لا توجد عمليات مطابقة.</div>}
      </div>
    </div>
  );
}

function ChangeList({ changes, schoolName }) {
  return (
    <table className="tbl inner">
      <thead>
        <tr>
          <th>العنصر</th>
          <th>العملية</th>
          <th>الحقل</th>
          <th>القيمة القديمة</th>
          <th>القيمة الجديدة</th>
        </tr>
      </thead>
      <tbody>
        {changes.flatMap((c) => {
          const rec = Object.assign({}, c.old_v || {}, c.new_v || {});
          const ident = (TBL[c.tbl] || c.tbl) + " «" + (rec.txn_no || rec.code || rec.name || rec.emp_name || rec.username || rec.label || lookup(c.tbl, c.row_id) || c.row_id) + "»" + (c.school_id ? " · " + schoolName(c.school_id) : "");
          const op = c.op === "insert" ? "إضافة" : c.op === "delete" ? "حذف" : "تعديل";
          const keys = Object.keys(c.op === "update" ? c.new_v || {} : c.new_v || c.old_v || {}).filter((k) => !SKIP.has(k) && k !== "school_id" && k !== "custody_id");
          return keys.map((k, i) => (
            <tr key={c.id + k}>
              <td>{i === 0 ? ident : ""}</td>
              <td>{i === 0 ? op : ""}</td>
              <td>{FIELD[k] || k}</td>
              <td className="old-v">{c.op === "insert" ? "—" : show(k, (c.old_v || {})[k])}</td>
              <td className="new-v">{c.op === "delete" ? "—" : show(k, (c.new_v || {})[k])}</td>
            </tr>
          ));
        })}
      </tbody>
    </table>
  );
}

function ts(v) {
  const s = String(v || "");
  return s.replace("T", " ").slice(0, 16);
}
