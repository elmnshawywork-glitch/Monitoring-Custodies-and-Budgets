import React from "react";
import { fmt, yes } from "../lib/utils";
import { custIssued, unitCat, useCalc } from "../lib/model";
import { Kpi } from "../components/ui";

export function PettyBar({ data }) {
  let l = 0,
    e = 0;
  ((data.tranches || []).forEach((i) => (l += Number(i.amount || 0))),
    (data.expenses || []).forEach((i) => {
      i.approval !== "rejected" && i.custody_id && (e += Number(i.amount || 0));
    }));
  let n = l - e;
  return (
    <div className="petty-bar">
      <div className="pb-item">
        <span>إجمالى العهد المستلمة</span>
        <b>
          {fmt(l)} <i>ج.م</i>
        </b>
      </div>
      <div className="pb-sep" />
      <div className="pb-item">
        <span>المصروف</span>
        <b className="amber">
          {fmt(e)} <i>ج.م</i>
        </b>
      </div>
      <div className="pb-sep" />
      <div className="pb-item">
        <span>المتبقى · Petty Cash</span>
        <b className={n >= 0 ? "green" : "red"}>
          {fmt(n)} <i>ج.م</i>
        </b>
      </div>
    </div>
  );
}

export function Dashboard({ data, onGo }) {
  let e = useCalc(data);
  if (data.me.role === "custody" || data.me.role === "supervisor")
    return <OfficerHome data={data} calc={e} onGo={onGo} />;
  let n = (c) => {
      let p = data.lines
          .filter((r) => String(r.school_id) === String(c))
          .reduce((r, v) => r + Number(v.allocated || 0), 0),
        m = e.spentBySchool[c] || 0;
      return {
        allocated: p,
        spent: m,
        remaining: p - m,
      };
    },
    i = data.schools.reduce((c, p) => c + n(p.id).allocated, 0),
    u = data.schools.reduce((c, p) => c + n(p.id).spent, 0),
    s = data.expenses.filter((c) => c.approval === "pending").length,
    o = data.expenses.filter((c) => c.approval === "approved" && !yes(c.settled)).length,
    d = data.custodies.reduce((c, p) => c + (custIssued(data, p) - (e.spentByCustody[p.id] || 0)), 0);
  return (
    <div className="stack">
      <div className="kpi-row">
        <Kpi label="إجمالى الموازنات" v={fmt(i)} u="ج.م" tone="navy" />
        <Kpi label="إجمالى المصروف" v={fmt(u)} u="ج.م" tone="teal" />
        <Kpi label="المتبقى" v={fmt(i - u)} u="ج.م" tone="green" />
        <Kpi label="رصيد العهد المتاح" v={fmt(d)} u="ج.م" tone="amber" />
      </div>
      <div className="kpi-row">
        <div
          className="kpi red"
          style={{
            cursor: "pointer",
          }}
          onClick={() => onGo("approvals")}
        >
          <div className="kpi-label">بنود بانتظار الاعتماد</div>
          <div className="kpi-value">{s}</div>
        </div>
        <div
          className="kpi teal"
          style={{
            cursor: "pointer",
          }}
          onClick={() => onGo("approvals")}
        >
          <div className="kpi-label">مصروفات لم تُسوَّ</div>
          <div className="kpi-value">{o}</div>
        </div>
      </div>
      <PettyByType data={data} calc={e} onGo={onGo} />
      <div className="panel">
        <h3 className="panel-title">حالة الموازنات</h3>
        <div className="table-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>المدرسة / الجهة</th>
                <th>الموازنة</th>
                <th>المصروف</th>
                <th>المتبقى</th>
                <th>التنفيذ</th>
              </tr>
            </thead>
            <tbody>
              {data.schools.map((c) => {
                let p = n(c.id),
                  m = p.allocated ? Math.round((p.spent / p.allocated) * 100) : 0;
                return (
                  <tr key={c.id}>
                    <td
                      style={{
                        fontWeight: 600,
                      }}
                    >
                      {c.name}
                    </td>
                    <td className="num">{fmt(p.allocated)}</td>
                    <td className="num teal">{fmt(p.spent)}</td>
                    <td className="num green">{fmt(p.remaining)}</td>
                    <td
                      style={{
                        minWidth: 120,
                      }}
                    >
                      <div className="bar">
                        <div
                          className="bar-fill"
                          style={{
                            width: m + "%",
                            background: m > 90 ? "var(--red)" : "var(--teal)",
                          }}
                        />
                      </div>
                      <span
                        style={{
                          fontSize: 11,
                          color: "var(--ink-soft)",
                        }}
                      >
                        {m}%
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function PettyByType({ data, calc, onGo }) {
  let n = [
      ["school", "المدارس", "navy"],
      ["company", "الشركة الداخلية", "teal"],
      ["training_general", "تدريب عام", "green"],
      ["training_vocational", "تدريب مهنى", "amber"],
    ],
    i = {};
  data.custodies.forEach((s) => {
    let o = unitCat(data, s.school_id),
      d = custIssued(data, s) - (calc.spentByCustody[s.id] || 0);
    (((i[o] = i[o] || {
      rem: 0,
      n: 0,
    }).rem += d),
      (i[o].n += 1));
  });
  let u = n.filter(([s]) => i[s]);
  return u.length === 0 ? null : (
    <div className="panel">
      <h3 className="panel-title">النقدية المتاحة بالعهد حسب النوع · Petty Cash</h3>
      <div
        className="kpi-row"
        style={{
          cursor: "pointer",
        }}
        onClick={() => onGo("custodies")}
      >
        {u.map(([s, o, d]) => (
          <div key={s} className={"kpi " + d}>
            <div className="kpi-label">
              {o}{" "}
              <span
                style={{
                  opacity: 0.7,
                }}
              >
                ({i[s].n}
                {" عهدة)"}
              </span>
            </div>
            <div className="kpi-value">
              {fmt(i[s].rem)} <span className="kpi-unit">ج.م</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function OfficerHome({ data, calc, onGo }) {
  let n = data.custodies.map((s) => {
      let o = custIssued(data, s),
        d = calc.spentByCustody[s.id] || 0;
      return {
        c: s,
        issued: o,
        spent: d,
        rem: o - d,
      };
    }),
    i = n.reduce(
      (s, o) => ({
        issued: s.issued + o.issued,
        spent: s.spent + o.spent,
      }),
      {
        issued: 0,
        spent: 0,
      },
    ),
    u = data.expenses.filter((s) => s.approval === "pending").length;
  return (
    <div className="stack">
      <div className="kpi-row">
        <Kpi label="عدد العهد" v={n.length} u="" tone="navy" />
        <Kpi label="إجمالى العهد المستلمة" v={fmt(i.issued)} u="ج.م" tone="teal" />
        <Kpi label="المصروف" v={fmt(i.spent)} u="ج.م" tone="amber" />
        <Kpi label="المتبقى" v={fmt(i.issued - i.spent)} u="ج.م" tone="green" />
      </div>
      <div className="kpi-row">
        <div
          className="kpi red"
          style={{
            cursor: "pointer",
          }}
          onClick={() => onGo("approvals")}
        >
          <div className="kpi-label">بنود بانتظار الاعتماد</div>
          <div className="kpi-value">{u}</div>
        </div>
        <div
          className="kpi teal"
          style={{
            cursor: "pointer",
          }}
          onClick={() => onGo("custodies")}
        >
          <div className="kpi-label">العهد المالية</div>
          <div
            className="kpi-value"
            style={{
              fontSize: 15,
            }}
          >
            افتح تبويب العهد ‹
          </div>
        </div>
      </div>
      <div className="panel">
        <h3 className="panel-title">العهد</h3>
        {n.length === 0 ? (
          <div className="empty">لا توجد عهد.</div>
        ) : (
          <div className="table-wrap">
            <table className="tbl">
              <thead>
                <tr>
                  <th>العهدة</th>
                  <th>المستلمة</th>
                  <th>المصروف</th>
                  <th>المتبقى</th>
                  <th>الاستهلاك</th>
                </tr>
              </thead>
              <tbody>
                {n.map((s) => {
                  let o = s.issued ? Math.min(100, Math.round((s.spent / s.issued) * 100)) : 0;
                  return (
                    <tr
                      key={s.c.id}
                      style={{
                        cursor: "pointer",
                      }}
                      onClick={() => onGo("custodies")}
                    >
                      <td
                        style={{
                          fontWeight: 600,
                        }}
                      >
                        {s.c.label}
                      </td>
                      <td className="num">{fmt(s.issued)}</td>
                      <td className="num amber">{fmt(s.spent)}</td>
                      <td className={"num " + (s.rem >= 0 ? "green" : "red")}>{fmt(s.rem)}</td>
                      <td
                        style={{
                          minWidth: 110,
                        }}
                      >
                        <div className="bar">
                          <div
                            className="bar-fill"
                            style={{
                              width: o + "%",
                              background: o > 90 ? "var(--red)" : "var(--navy)",
                            }}
                          />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
