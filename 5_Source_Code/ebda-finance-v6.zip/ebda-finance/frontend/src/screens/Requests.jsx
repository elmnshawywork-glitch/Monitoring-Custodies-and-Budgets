import React from "react";
import { fmt } from "../lib/utils";
import { useCalc } from "../lib/model";

export function Requests({ data, role, act, showToast, setModal }) {
  let u = useCalc(data),
    s = role === "manager",
    o = role === "custody",
    d = role === "supervisor" || s,
    c = role === "accountant" || s,
    p = (N) => {
      let b = (data.lines || []).find((f) => String(f.id) === String(N));
      return b ? b.name : "—";
    },
    m = (N) => {
      let b = (data.lines || []).find((f) => String(f.id) === String(N));
      return !b || b.allocated === void 0 ? null : Number(b.allocated || 0) - (u.spentByLine[b.id] || 0);
    },
    r = {
      pending_supervisor: ["بانتظار المدير المباشر", "amber"],
      pending_accountant: ["معتمد من المدير المباشر · بانتظار الاعتماد المالى", "navy"],
      transferred: ["معتمد مالياً · تم التحويل للعهدة", "green"],
      spent: ["تم الصرف من العهدة", "teal"],
      settled: ["تمت التسوية", "green"],
      rejected: ["مرفوض", "red"],
    },
    v = (data.requests || []).slice().reverse(),
    S = (N, b, f) =>
      act(N, b)
        .then(() => showToast(f))
        .catch(() => {});
  return (
    <div className="stack">
      <div className="toolbar">
        <h3 className="section-h">طلبات العهد</h3>
        {(o || s) && (
          <button
            className="btn primary"
            onClick={() =>
              setModal({
                type: "request",
              })
            }
          >
            + طلب عهدة
          </button>
        )}
      </div>
      {v.length === 0 && <div className="empty">لا توجد طلبات.</div>}
      {v.map((N) => {
        let [b, f] = r[N.stage || N.status] || r[N.status] || ["—", "gray"],
          h = d && N.status === "pending_supervisor",
          y = c && N.status === "pending_accountant",
          g = N.items || [],
          x = (data.schools.find((C) => String(C.id) === String(N.school_id)) || {}).name;
        return (
          <div key={N.id} className="panel">
            <div
              className="toolbar"
              style={{
                marginBottom: 10,
              }}
            >
              <div>
                <b
                  style={{
                    fontFamily: "Cairo",
                    color: "var(--navy)",
                  }}
                >
                  {N.req_no ? N.req_no + " · " : ""}
                  {N.requester_name}
                </b>{" "}
                <span className="cust-sub">
                  {x}
                  {N.created_at ? " · " + String(N.created_at).slice(0, 10) : ""}
                </span>
              </div>
              <div
                style={{
                  display: "flex",
                  gap: 8,
                  alignItems: "center",
                }}
              >
                <span className={"chip " + f}>{b}</span>
                <b>
                  {fmt(N.total)}
                  {" ج.م"}
                </b>
              </div>
            </div>
            <div className="table-wrap">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>البند المطلوب</th>
                    <th>البند الرئيسى</th>
                    <th>المبلغ</th>
                    {d && <th>المتاح بالبند</th>}
                    <th>ملاحظات</th>
                    {h && <th />}
                  </tr>
                </thead>
                <tbody>
                  {g.map((C) => {
                    let _ = m(C.line_id),
                      A = _ == null ? null : Number(C.amount || 0) <= _;
                    return (
                      <tr key={C.id} className={C.decision === "rejected" ? "def" : ""}>
                        <td
                          style={{
                            fontWeight: 600,
                          }}
                        >
                          {C.name}
                        </td>
                        <td>{p(C.line_id)}</td>
                        <td className="num">{fmt(C.amount)}</td>
                        {d && (
                          <td>
                            {_ == null ? (
                              "—"
                            ) : (
                              <span className={"chip " + (A ? "green" : "red")}>
                                {A ? "كافٍ" : "غير كافٍ"}
                                {" · "}
                                {fmt(_)}
                              </span>
                            )}
                          </td>
                        )}
                        <td
                          style={{
                            fontSize: 12,
                            color: "var(--ink-soft)",
                          }}
                        >
                          {C.sup_note || "—"}
                        </td>
                        {h && (
                          <td
                            style={{
                              display: "flex",
                              gap: 6,
                            }}
                          >
                            <button
                              className="icon-btn"
                              title="تعديل"
                              onClick={() =>
                                setModal({
                                  type: "reqitem",
                                  payload: {
                                    it: C,
                                    school_id: N.school_id,
                                  },
                                })
                              }
                            >
                              ✎
                            </button>
                            <button
                              className="icon-btn"
                              title="حذف"
                              onClick={() =>
                                act("deleteRequestItem", {
                                  id: C.id,
                                })
                              }
                            >
                              ×
                            </button>
                          </td>
                        )}
                      </tr>
                    );
                  })}
                  {g.length === 0 && (
                    <tr>
                      <td colSpan="6">
                        <div className="empty">لا بنود.</div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            {N.reason && (
              <div style={{ fontSize: 12.5, color: "var(--navy)", marginTop: 8, fontWeight: 600 }}>
                {"سبب الطلب: "}
                {N.reason}
              </div>
            )}
            {N.note && (
              <div
                style={{
                  fontSize: 12,
                  color: "var(--ink-soft)",
                  marginTop: 8,
                }}
              >
                {"ملاحظة: "}
                {N.note}
              </div>
            )}
            <div
              style={{
                display: "flex",
                gap: 8,
                marginTop: 12,
                flexWrap: "wrap",
              }}
            >
              {h && (
                <button
                  className="btn primary sm"
                  onClick={() =>
                    S(
                      "decideRequest",
                      {
                        id: N.id,
                        decision: "approve",
                      },
                      "تم الاعتماد وإرساله للمحاسب",
                    )
                  }
                >
                  اعتماد وإرسال للمحاسب
                </button>
              )}
              {h && (
                <button
                  className="btn danger-ghost sm"
                  onClick={() =>
                    S(
                      "decideRequest",
                      {
                        id: N.id,
                        decision: "reject",
                      },
                      "تم الرفض",
                    )
                  }
                >
                  رفض
                </button>
              )}
              {y && (
                <button
                  className="btn teal sm"
                  onClick={() =>
                    S(
                      "transferRequest",
                      {
                        id: N.id,
                        decision: "approve",
                      },
                      "تم تحويل العهدة للموظف",
                    )
                  }
                >
                  موافقة وتحويل للموظف
                </button>
              )}
              {y && (
                <button
                  className="btn danger-ghost sm"
                  onClick={() =>
                    S(
                      "transferRequest",
                      {
                        id: N.id,
                        decision: "reject",
                      },
                      "تم الرفض",
                    )
                  }
                >
                  رفض
                </button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
