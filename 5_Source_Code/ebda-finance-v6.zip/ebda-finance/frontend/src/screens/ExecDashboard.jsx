// لوحة المتابعة التنفيذية: قائمة المكان أعلى الصفحة تُحدّث كل المؤشرات والرسوم.
// الحسابات من lib/budget.js (شهر = مخصص الشهر مقابل مصروفه · كل الشهور = السنوى مقابل السنوى).
import React, { useMemo, useState } from "react";
import { fmt } from "../lib/utils";
import { CAT_LABEL, countsInBudget, activeOnCustody } from "../lib/model";
import { budgetModel, periodFigures, monthlySeries, groupFigures, FY_MONTHS, currentFyMonth, pctOf } from "../lib/budget";
import { custodyInfo, CUSTODY_STATES } from "../lib/custody";
import { PlanActualBars, MonthlyChart, CumulativeChart, BarList, StatusBar, Meter } from "../components/charts";
import { buildInsights } from "../lib/insights";
import { monthLabel } from "../lib/payroll";
import { can } from "../lib/perms";

export function ExecDashboard({ data, onGo }) {
  const periods = useMemo(
    () => Array.from(new Set(data.schools.map((s) => s.period).filter(Boolean))).sort().reverse(),
    [data],
  );
  const [place, setPlace] = useState("all");
  const [period, setPeriod] = useState(periods[0] || "all");
  const [month, setMonth] = useState("all");
  const m = month === "all" ? null : Number(month);

  const schoolIds = place === "all" ? null : new Set([place]);
  const model = useMemo(() => budgetModel(data, { schoolIds, period }), [data, place, period]);
  const fig = periodFigures(model.lines, m);
  const series = monthlySeries(model.lines);
  const bySection = groupFigures(model.lines, (r) => r.line.section || "عام", (r) => r.line.section || "عام", m).sort((a, b) => b.alloc - a.alloc);
  const byPlace = groupFigures(model.lines, (r) => r.entity.id, (r) => r.entity.name, m).sort((a, b) => b.spent - a.spent);
  const topLines = model.lines
    .map((r) => ({ r, f: periodFigures([r], m) }))
    .filter((x) => x.f.spent > 0)
    .sort((a, b) => b.f.spent - a.f.spent)
    .slice(0, 8);
  const overLines = model.lines
    .map((r) => ({ r, f: periodFigures([r], m) }))
    .filter((x) => x.f.status.key === "over")
    .sort((a, b) => a.f.diff - b.f.diff);

  // العهد ضمن المكان المختار
  const ents = new Set(model.entities.map((s) => String(s.id)));
  const custs = data.custodies.filter((c) => (place === "all" ? ents.has(String(c.school_id)) || !c.school_id : String(c.school_id) === place)).map((c) => custodyInfo(data, c));
  const cTotals = custs.reduce((a, x) => ({ received: a.received + x.received, spent: a.spent + x.spent }), { received: 0, spent: 0 });
  const stCount = (k) => custs.filter((x) => x.state === k).length;
  const openish = custs.filter((x) => ["open", "notes", "overdue", "pending_settlement"].indexOf(x.state) >= 0);

  // المصروفات حسب النوع (المعتمدة فى الفترة)
  const inPeriod = (e) => {
    if (!ents.has(String(e.school_id))) return false;
    if (!m) return true;
    const mm = /^(\d{4})-(\d{2})/.exec(String(e.date || ""));
    return mm && ((Number(mm[2]) + 3) % 12) + 1 === m;
  };
  const byType = {};
  if (data.agg && data.agg.spend_types)
    // مجمّعة على الخادم من كل المصروفات المحتسبة
    data.agg.spend_types
      .filter((x) => ents.has(String(x.school_id)) && (!m || x.m === m))
      .forEach((x) => (byType[x.item] = (byType[x.item] || 0) + Number(x.amount || 0)));
  else
    data.expenses.filter((e) => countsInBudget(e) && inPeriod(e)).forEach((e) => {
      const k = e.spend_item || (e.custody_id ? "مصروف عهدة (غير مصنّف)" : "شراء مركزى");
      byType[k] = (byType[k] || 0) + Number(e.amount || 0);
    });
  const typeItems = Object.entries(byType)
    .map(([label, value]) => ({ label, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 8);
  const pendingAmt =
    data.agg && data.agg.school_pending
      ? Object.entries(data.agg.school_pending)
          .filter(([k]) => ents.has(String(k)))
          .reduce((a, [, v]) => a + Number(v || 0), 0)
      : data.expenses
          .filter((e) => ents.has(String(e.school_id)) && activeOnCustody(e) && !countsInBudget(e))
          .reduce((a, e) => a + Number(e.amount || 0), 0);

  const ent = place === "all" ? null : data.schools.find((s) => String(s.id) === place);
  const periodLabel = m ? "شهر " + FY_MONTHS[m - 1] : "السنة كاملة";
  const cats = Array.from(new Set(data.schools.map((s) => s.category || "school")));
  const ins = useMemo(() => buildInsights(data, model, { month: m, place: place === "all" ? null : place }), [data, model, m, place]);

  return (
    <div className="stack exec">
      <div className="exec-bar">
        <div className="exec-title">
          <h2>{ent ? ent.name : "كل الأماكن"}</h2>
          <span>
            {ent ? CAT_LABEL[ent.category || "school"] + " · " : model.entities.length + " جهة · "}
            {period !== "all" ? "السنة المالية " + period : "كل السنوات"} · {periodLabel}
          </span>
        </div>
        <div className="filters">
          <label className="qf">
            <span>المكان</span>
            <select value={place} onChange={(e) => setPlace(e.target.value)} data-testid="dash-place">
              <option value="all">كل الأماكن</option>
              {cats.map((c) => (
                <optgroup key={c} label={CAT_LABEL[c] || c}>
                  {data.schools
                    .filter((s) => (s.category || "school") === c)
                    .map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                </optgroup>
              ))}
            </select>
          </label>
          <label className="qf">
            <span>السنة المالية</span>
            <select value={period} onChange={(e) => setPeriod(e.target.value)}>
              <option value="all">كل السنوات</option>
              {periods.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </label>
          <label className="qf">
            <span>الفترة</span>
            <select value={month} onChange={(e) => setMonth(e.target.value)} data-testid="dash-month">
              <option value="all">السنة كاملة</option>
              {FY_MONTHS.map((x, i) => (
                <option key={x} value={i + 1}>
                  {x}
                  {i + 1 === currentFyMonth() ? " (الحالى)" : ""}
                </option>
              ))}
            </select>
          </label>
        </div>
      </div>

      <div className="kpi-grid">
        <div className="kpi2">
          <span>{m ? "مخصص " + FY_MONTHS[m - 1] : "إجمالى الموازنة"}</span>
          <b>{fmt(Math.round(fig.alloc))}</b>
          <small>ج.م</small>
        </div>
        <div className="kpi2">
          <span>{m ? "مصروف " + FY_MONTHS[m - 1] : "إجمالى المصروف"}</span>
          <b>{fmt(Math.round(fig.spent))}</b>
          <small>{pendingAmt > 0 ? "+ " + fmt(pendingAmt) + " قيد الاعتماد (غير محتسب)" : "المعتمد فقط"}</small>
        </div>
        <div className={"kpi2 " + (fig.diff < -0.5 ? "neg" : "pos")}>
          <span>{fig.diff < -0.5 ? "التجاوز" : "المتبقى"}</span>
          <b>{fmt(Math.round(Math.abs(fig.diff)))}</b>
          <small>{m ? "الفرق الشهرى = المخصص − المصروف" : "الفرق السنوى = المخصص السنوى − المصروف السنوى"}</small>
        </div>
        <div className="kpi2">
          <span>نسبة الصرف</span>
          <b>{Math.round(fig.pct * 100)}%</b>
          <Meter pct={fig.pct} />
          <small className={"st-" + fig.status.tone}>{fig.status.label}</small>
        </div>
        <div className="kpi2 click" onClick={() => onGo && onGo("tracker")}>
          <span>العهد المفتوحة</span>
          <b>{openish.length}</b>
          <small>
            الرصيد {fmt(cTotals.received - cTotals.spent)} ج.م{stCount("overdue") ? " · " + stCount("overdue") + " متأخرة" : ""}
          </small>
        </div>
      </div>

      <AlertsPanel alerts={ins.alerts} />
      <div className="dash-grid">
        <div className="panel span2">
          <h3 className="panel-title">
            المصروف الشهرى مقابل المخصص الشهرى <small>· السنة المالية (سبتمبر ← أغسطس)</small>
          </h3>
          <MonthlyChart labels={FY_MONTHS} plan={series.plan} spent={series.spent} selected={m} />
        </div>
        <div className="panel">
          <h3 className="panel-title">الاتجاه التراكمى للصرف</h3>
          <CumulativeChart labels={FY_MONTHS} plan={series.plan} spent={series.spent} upTo={lastMonthWithData(series.spent)} />
          <div className="note-line">
            {(() => {
              const k = lastMonthWithData(series.spent);
              if (!k) return "لا يوجد مصروف معتمد بعد.";
              const p = series.plan.slice(0, k).reduce((a, x) => a + x, 0),
                s = series.spent.slice(0, k).reduce((a, x) => a + x, 0);
              return "حتى نهاية " + FY_MONTHS[k - 1] + ": صُرف " + fmt(s) + " من مخصص " + fmt(p) + " (" + Math.round(pctOf(s, p) * 100) + "%)";
            })()}
          </div>
        </div>

        <div className="panel span2">
          <h3 className="panel-title">
            الموازنة مقابل المصروف حسب الأقسام <small>· {periodLabel}</small>
          </h3>
          <PlanActualBars items={bySection.map((g) => ({ label: g.label, plan: g.alloc, actual: g.spent }))} />
          <LegendPA />
        </div>
        <div className="panel">
          <h3 className="panel-title">
            أعلى البنود صرفاً <small>· {periodLabel}</small>
          </h3>
          <BarList
            items={topLines.map((x) => ({ label: x.r.line.name, value: x.f.spent, sub: place === "all" ? x.r.entity.name : x.r.line.section }))}
            empty="لا يوجد مصروف معتمد فى هذه الفترة."
          />
        </div>

        {place === "all" && (
          <div className="panel span2">
            <h3 className="panel-title">
              الأماكن حسب الصرف <small>· اضغط على المكان لعرض لوحته</small>
            </h3>
            <PlanActualBars
              items={byPlace.map((g) => ({ label: g.label, plan: g.alloc, actual: g.spent, id: g.key }))}
              onPick={(x) => setPlace(String(x.id))}
            />
            <LegendPA />
          </div>
        )}

        <div className="panel">
          <h3 className="panel-title">حالة العهد</h3>
          <div className="mini-kpis tight" style={{ marginTop: 0 }}>
            <div>
              <span>إجمالى العهد</span>
              <b>{fmt(cTotals.received)}</b>
            </div>
            <div>
              <span>المصروف منها</span>
              <b className="teal">{fmt(cTotals.spent)}</b>
            </div>
            <div>
              <span>الرصيد</span>
              <b className={cTotals.received - cTotals.spent < 0 ? "red" : "green"}>{fmt(cTotals.received - cTotals.spent)}</b>
            </div>
          </div>
          <StatusBar
            segments={Object.keys(CUSTODY_STATES).map((k) => ({
              label: CUSTODY_STATES[k].label,
              color: CUSTODY_STATES[k].color,
              value: stCount(k),
              amount: custs.filter((x) => x.state === k).reduce((a, x) => a + x.remaining, 0),
            }))}
          />
        </div>

        <div className={"panel " + (place === "all" ? "" : "span2")} data-panel="types">
          <h3 className="panel-title">
            المصروفات حسب النوع <small>· {periodLabel}</small>
          </h3>
          <BarList items={typeItems} color="#1e7e9c" empty="لا توجد مصروفات معتمدة فى هذه الفترة." />
        </div>

        <div className={"panel " + (place === "all" ? "span2" : "span3")}>
          <h3 className="panel-title">
            بنود تجاوزت المخصص <small>· {periodLabel}</small>
          </h3>
          {overLines.length ? (
            <div className="table-wrap">
              <table className="tbl">
                <thead>
                  <tr>
                    {place === "all" && <th>المكان</th>}
                    <th>البند</th>
                    <th>{m ? "المخصص الشهرى" : "المخصص السنوى"}</th>
                    <th>{m ? "المصروف الشهرى" : "المصروف السنوى"}</th>
                    <th>التجاوز</th>
                    <th>النسبة</th>
                  </tr>
                </thead>
                <tbody>
                  {overLines.slice(0, 10).map(({ r, f }) => (
                    <tr key={r.line.id} className="def">
                      {place === "all" && <td>{r.entity.name}</td>}
                      <td style={{ fontWeight: 600 }}>
                        {r.line.name}
                        <span className="cust-sub">{r.line.section}</span>
                      </td>
                      <td className="num">{fmt(f.alloc)}</td>
                      <td className="num">{fmt(f.spent)}</td>
                      <td className="num red">{fmt(-f.diff)}</td>
                      <td className="num">{Math.round(f.pct * 100)}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="empty" style={{ padding: 10 }}>
              ✔ لا توجد بنود تجاوزت مخصصها {m ? "فى هذا الشهر" : "على مستوى السنة"}.
            </div>
          )}
        </div>
      </div>
      <InsightsPanel ins={ins} data={data} place={place} />
    </div>
  );
}

const SEV = {
  critical: { label: "حرج", cls: "sev-critical" },
  serious: { label: "مهم", cls: "sev-serious" },
  warning: { label: "تنبيه", cls: "sev-warning" },
};

function AlertsPanel({ alerts }) {
  const [all, setAll] = useState(false);
  const counts = { critical: 0, serious: 0, warning: 0 };
  alerts.forEach((a) => counts[a.sev]++);
  const shown = all ? alerts : alerts.slice(0, 8);
  return (
    <div className="panel alerts-panel" data-testid="alerts">
      <h3 className="panel-title">
        تنبيهات ذكية{" "}
        <small>
          · {alerts.length ? Object.keys(counts).filter((k) => counts[k]).map((k) => counts[k] + " " + SEV[k].label).join(" · ") : "لا توجد حالات تستدعى الانتباه"}
        </small>
      </h3>
      {alerts.length ? (
        <ul className="alert-list">
          {shown.map((a, i) => (
            <li key={i} className={SEV[a.sev].cls} data-sev={a.sev}>
              <span className="sev-chip">{SEV[a.sev].label}</span>
              <b>{a.kind}</b>
              <span>{a.text}</span>
            </li>
          ))}
        </ul>
      ) : (
        <div className="empty" style={{ padding: 8 }}>
          ✔ لا توجد تنبيهات للمكان والفترة المختارة.
        </div>
      )}
      {alerts.length > 8 && (
        <button className="btn ghost sm" onClick={() => setAll(!all)}>
          {all ? "عرض أقل" : "عرض كل التنبيهات (" + alerts.length + ")"}
        </button>
      )}
    </div>
  );
}

function InsightsPanel({ ins, data, place }) {
  const tabs = [
    ["budget", "الموازنات"],
    ["custody", "العهد"],
    ["expenses", "المصروفات"],
  ];
  if (can(data, "payroll.view")) tabs.push(["payroll", "الرواتب"]);
  const [tab, setTab] = useState("budget");
  const nameOf = (id) => (data.schools.find((s) => String(s.id) === String(id)) || {}).name || "—";
  const b = ins.budget,
    c = ins.custody,
    e = ins.expenses,
    p = ins.payroll;
  const cur = FY_MONTHS[b.curM - 1],
    prev = b.prevM ? FY_MONTHS[b.prevM - 1] : null;
  return (
    <div className="panel insights" data-testid="insights">
      <h3 className="panel-title">
        تحليلات للإدارة <small>· محسوبة من البيانات الفعلية للمكان المختار</small>
      </h3>
      <div className="seg" style={{ marginBottom: 10 }}>
        {tabs.map(([k, l]) => (
          <button key={k} className={tab === k ? "on" : ""} onClick={() => setTab(k)} data-testid={"ins-" + k}>
            {l}
          </button>
        ))}
      </div>

      {tab === "budget" && (
        <div className="ins-grid">
          <div>
            <h4>أكثر الأماكن استهلاكاً للموازنة (السنوى)</h4>
            <BarList items={b.places.slice(0, 8).map((x) => ({ label: x.s.name, value: Math.round(x.f.pct * 100), sub: fmt(x.f.spent) + " من " + fmt(x.f.alloc) }))} valueFmt={(v) => v + "%"} />
          </div>
          <div>
            <h4>بنود متجاوزة ({b.over.length})</h4>
            <BarList items={b.over.slice(0, 8).map((x) => ({ label: x.r.line.name, value: Math.round(-x.f.diff), sub: x.r.entity.name + " · " + Math.round(x.f.pct * 100) + "%" }))} color="#d03b3b" empty="لا توجد بنود متجاوزة." />
          </div>
          <div>
            <h4>بنود منخفضة الاستخدام</h4>
            <BarList
              items={b.underused.map((x) => ({ label: x.r.line.name, value: Math.round(x.f.alloc - x.f.spent), sub: x.r.entity.name + " · مستخدم " + Math.round(x.f.pct * 100) + "%" }))}
              color="#3a9b6a"
              empty="لا توجد بنود منخفضة الاستخدام."
            />
            <small className="muted">مستخدم أقل من 30% من المتوقع حتى الآن (مضى {Math.round(b.elapsed * 100)}% من السنة).</small>
          </div>
          <div>
            <h4>اقتراحات إعادة توزيع</h4>
            {b.realloc.length ? (
              <ul className="ins-list">
                {b.realloc.slice(0, 5).map((t, i) => (
                  <li key={i}>{t}</li>
                ))}
              </ul>
            ) : (
              <div className="muted">لا توجد اقتراحات حالياً.</div>
            )}
            <div className="ins-kv" style={{ marginTop: 8 }}>
              <span>مصروف {cur}</span>
              <b className="num">{fmt(Math.round(b.thisMonthSpent))}</b>
              {prev && (
                <>
                  <span>مصروف {prev}</span>
                  <b className="num">{fmt(Math.round(b.prevMonthSpent))}</b>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {tab === "custody" && (
        <div className="ins-grid">
          <div>
            <h4>أكثر المسئولين رصيداً مفتوحاً</h4>
            <BarList
              items={c.holders
                .filter((h) => h.openBal > 0)
                .sort((x, y) => y.openBal - x.openBal)
                .slice(0, 8)
                .map((h) => ({ label: h.name, value: Math.round(h.openBal), sub: h.open + " عهدة مفتوحة" + (h.overdue ? " · " + h.overdue + " متأخرة" : "") }))}
              empty="لا توجد عهد مفتوحة."
            />
          </div>
          <div>
            <h4>أعلى العهد قيمة</h4>
            <BarList items={c.top.map((x) => ({ label: (x.c.code || "") + " · " + x.holderName, value: Math.round(x.received), sub: "متبقى " + fmt(x.remaining) }))} empty="لا توجد عهد." />
          </div>
          <div>
            <h4>مؤشرات</h4>
            <div className="ins-kv">
              <span>عهد مفتوحة</span>
              <b>{c.live.length}</b>
              <span>رصيد مفتوح</span>
              <b className="num">{fmt(Math.round(c.live.reduce((a, x) => a + x.remaining, 0)))}</b>
              <span>متأخرة</span>
              <b>{c.holders.reduce((a, h) => a + h.overdue, 0)}</b>
              <span>تجاوزات</span>
              <b className="num red">{fmt(Math.round(c.holders.reduce((a, h) => a + h.over, 0)))}</b>
              <span>متوسط مدة الإغلاق</span>
              <b>{c.avgClose == null ? "—" : c.avgClose + " يوم"}</b>
              <span>عهد بها مصروفات غير مسواة</span>
              <b>{c.unsettled.length}</b>
            </div>
          </div>
        </div>
      )}

      {tab === "expenses" && (
        <div className="ins-grid">
          <div>
            <h4>المصروف الشهرى المعتمد</h4>
            <BarList items={FY_MONTHS.map((l, i) => ({ label: l, value: Math.round(e.byMonth[i]) })).filter((x) => x.value > 0)} empty="لا توجد مصروفات معتمدة." />
            {e.growth != null && (
              <small className={e.growth > 0 ? "red" : "green"}>
                {cur} مقارنة بـ{prev}: {e.growth > 0 ? "+" : ""}
                {Math.round(e.growth * 100)}%
              </small>
            )}
          </div>
          <div>
            <h4>أكثر البنود إنفاقاً</h4>
            <BarList items={e.topLines.map((x) => ({ label: x.r.line.name, value: Math.round(x.f.spent), sub: x.r.entity.name }))} empty="لا توجد مصروفات." />
          </div>
          {place === "all" && (
            <div>
              <h4>أكثر الأماكن صرفاً</h4>
              <BarList items={e.placeSpend.slice(0, 8).map((x) => ({ label: x.s.name, value: Math.round(x.v) }))} empty="لا توجد مصروفات." />
            </div>
          )}
          <div>
            <h4>بنود زاد صرفها عن الشهر السابق</h4>
            <BarList
              items={e.increased.map((x) => ({ label: x.r.line.name, value: Math.round(x.d), sub: x.r.entity.name + (x.b > 0 ? " · +" + Math.round((x.d / x.b) * 100) + "%" : " · جديد") }))}
              color="#c77a12"
              empty="لا توجد زيادات."
            />
          </div>
        </div>
      )}

      {tab === "payroll" && (
        <div className="ins-grid">
          {!p.pm ? (
            <div className="muted">لا توجد بيانات رواتب مستوردة للمكان المختار.</div>
          ) : (
            <>
              <div>
                <h4>تكلفة العمالة — {monthLabel(p.pm)}</h4>
                <div className="ins-kv">
                  <span>صافى الرواتب</span>
                  <b className="num" data-testid="ins-pay-net">{fmt(Math.round(p.now.net * 100) / 100)}</b>
                  <span>عدد العاملين</span>
                  <b>{p.now.n}</b>
                  <span>متوسط الراتب</span>
                  <b className="num">{fmt(Math.round(p.now.net / Math.max(1, p.now.n)))}</b>
                  <span>الحوافز والإضافات</span>
                  <b className="num green">{fmt(Math.round(p.now.earn))}</b>
                  <span>الخصومات</span>
                  <b className="num red">{fmt(Math.round(p.now.ded + p.now.adjDed))}</b>
                  <span>أيام الغياب</span>
                  <b>{p.now.absent}</b>
                  <span>منها انتداب حكومى</span>
                  <b className="num">{fmt(Math.round(p.now.gov))}</b>
                  {p.share != null && (
                    <>
                      <span>نسبة الرواتب من التكلفة</span>
                      <b>{Math.round(p.share * 100)}%</b>
                    </>
                  )}
                </div>
              </div>
              <div>
                <h4>صافى الرواتب حسب المكان</h4>
                <BarList items={p.byPlace.map((x) => ({ label: nameOf(x.id), value: Math.round(x.net), sub: x.n + " موظف" }))} />
              </div>
              <div>
                <h4>مقارنة الشهور</h4>
                <BarList items={p.series.map((x) => ({ label: monthLabel(x.m), value: Math.round(x.net) }))} color="#6a4fb3" />
                {p.cmp && p.cmp.prev.net > 0 && (
                  <small>
                    مقارنة بـ{monthLabel(p.pmPrev)} (نفس الأماكن): {p.cmp.now.net >= p.cmp.prev.net ? "+" : ""}
                    {Math.round(((p.cmp.now.net - p.cmp.prev.net) / p.cmp.prev.net) * 100)}%
                  </small>
                )}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}

function LegendPA() {
  return (
    <div className="ch-legend">
      <span>
        <i style={{ background: "#d5e5f8" }} />
        المخصص
      </span>
      <span>
        <i style={{ background: "#2a78d6" }} />
        المصروف
      </span>
      <span>
        <i style={{ background: "#d03b3b" }} />
        تجاوز المخصص
      </span>
    </div>
  );
}

function lastMonthWithData(arr) {
  // آخر شهر به مصروف، أو الشهر المالى الحالى (أيهما أكبر) لعرض الاتجاه حتى اليوم
  let k = 0;
  arr.forEach((v, i) => v > 0 && (k = i + 1));
  return Math.max(k, Math.min(12, currentFyMonth()));
}
