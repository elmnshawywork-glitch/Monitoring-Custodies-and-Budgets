// الإدارة (v6): أنواع العهد · أنواع الموازنات/الجهات · تعطيل الجهات والبنود · إعدادات الدورة · النسخ الاحتياطى والاستعادة
// كل ذلك للأدمن فقط — والخادم يرفض أى طلب من غير الأدمن.
import React, { useState } from "react";
import { fmt, yes, dlBlob } from "../lib/utils";
import { CAT_LABEL } from "../lib/model";
import { probe } from "../lib/api";
import { Modal, Field } from "../components/ui";

function MasterList({ title, hint, items, nameKey, onSave, testid }) {
  const [name, setName] = useState("");
  const [edit, setEdit] = useState(null);
  return (
    <div className="panel" data-testid={testid}>
      <h3 className="panel-title">{title}</h3>
      {hint && <p className="hint">{hint}</p>}
      <div className="filters" style={{ marginBottom: 12 }}>
        <div className="qf">
          <span>إضافة</span>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="الاسم" />
        </div>
        <button className="btn primary sm" disabled={!name.trim()} onClick={async () => (await onSave({ [nameKey]: name.trim() })) && setName("")}>
          + إضافة
        </button>
      </div>
      <table className="tbl">
        <thead>
          <tr>
            <th>الاسم</th>
            <th>الحالة</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {items.map((x) => (
            <tr key={x.id || x.code} className={yes(x.active) ? "" : "muted-row"}>
              <td>
                {edit && (edit.id || edit.code) === (x.id || x.code) ? (
                  <input value={edit[nameKey]} onChange={(e) => setEdit(Object.assign({}, edit, { [nameKey]: e.target.value }))} />
                ) : (
                  <b>{x[nameKey]}</b>
                )}
              </td>
              <td>{yes(x.active) ? <span className="chip green">مفعّل</span> : <span className="chip gray">معطّل</span>}</td>
              <td style={{ whiteSpace: "nowrap" }}>
                {edit && (edit.id || edit.code) === (x.id || x.code) ? (
                  <button className="btn primary sm" onClick={async () => (await onSave(edit)) && setEdit(null)}>
                    حفظ
                  </button>
                ) : (
                  <button className="btn ghost sm" onClick={() => setEdit(Object.assign({}, x))}>
                    تعديل
                  </button>
                )}{" "}
                <button className="btn ghost sm" onClick={() => onSave(Object.assign({}, x, { active: yes(x.active) ? "لا" : "نعم" }))}>
                  {yes(x.active) ? "تعطيل" : "تفعيل"}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function AdminCustodyKinds({ data, act, showToast }) {
  const save = async (item) => {
    try {
      await act("saveCustodyKind", { item });
      showToast("تم الحفظ");
      return true;
    } catch (e) {
      return false;
    }
  };
  return (
    <MasterList
      title="أنواع العهد"
      hint="النوع المعطّل لا يظهر عند إنشاء عهدة جديدة، ويبقى على العهد القديمة. تغيير الاسم ينعكس على العهد المسجلة بنفس النوع."
      items={data.custody_kinds || []}
      nameKey="name"
      onSave={save}
      testid="adm-kinds"
    />
  );
}

export function AdminEntityTypes({ data, act, showToast }) {
  const save = async (item) => {
    try {
      await act("saveEntityType", { item });
      showToast("تم الحفظ");
      return true;
    } catch (e) {
      return false;
    }
  };
  return (
    <MasterList
      title="أنواع الموازنات / الجهات"
      hint="تصنيف الجهة (مدرسة، الشركة، تدريب…) هو نوع موازنتها فى التقارير ولوحة المتابعة. النوع المعطّل لا يُختار لجهة جديدة."
      items={data.entity_types || []}
      nameKey="label"
      onSave={save}
      testid="adm-types"
    />
  );
}

// تعطيل/تفعيل الجهات والبنود — لا حذف للتاريخ المالى
export function AdminActivation({ data, act, showToast }) {
  const [sid, setSid] = useState(data.schools[0] ? String(data.schools[0].id) : "");
  const lines = (data.lines || []).filter((l) => String(l.school_id) === sid);
  const run = async (action, payload, msg) => {
    try {
      await act(action, payload);
      showToast(msg);
    } catch (e) {}
  };
  return (
    <div className="stack" data-testid="adm-activation">
      <div className="panel">
        <h3 className="panel-title">تعطيل الجهات والبنود</h3>
        <p className="hint">
          الجهة أو البند المعطّل لا يقبل إدخالات جديدة (عهد، مصروفات، طلبات، توزيع)، لكن المصروفات والعهد القديمة تبقى كما هى ويمكن الرجوع إليها فى
          التقارير وتتبع التعديلات. لا يتم حذف أى بيانات تاريخية.
        </p>
        <table className="tbl">
          <thead>
            <tr>
              <th>الجهة</th>
              <th>النوع</th>
              <th>الحالة</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {data.schools.map((s) => (
              <tr key={s.id} className={yes(s.active) ? "" : "muted-row"}>
                <td>
                  <b>{s.name}</b>
                </td>
                <td>{CAT_LABEL[s.category || "school"] || s.category}</td>
                <td>{yes(s.active) ? <span className="chip green">مفعّلة</span> : <span className="chip gray">معطّلة</span>}</td>
                <td>
                  <button
                    className="btn ghost sm"
                    onClick={() => run("updateSchool", { id: s.id, patch: { active: yes(s.active) ? "لا" : "نعم" } }, yes(s.active) ? "تم تعطيل الجهة" : "تم تفعيل الجهة")}
                  >
                    {yes(s.active) ? "تعطيل" : "تفعيل"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="panel">
        <div className="toolbar">
          <h3 className="panel-title" style={{ margin: 0 }}>
            بنود الموازنة
          </h3>
          <select value={sid} onChange={(e) => setSid(e.target.value)} data-testid="act-school">
            {data.schools.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>
        <table className="tbl" style={{ marginTop: 10 }}>
          <thead>
            <tr>
              <th>القسم</th>
              <th>البند</th>
              <th>المخصص</th>
              <th>الحالة</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {lines.map((l) => {
              const on = l.active == null || yes(l.active);
              return (
                <tr key={l.id} className={on ? "" : "muted-row"}>
                  <td>{l.section}</td>
                  <td>
                    <b>{l.name}</b>
                  </td>
                  <td className="num">{fmt(l.allocated)}</td>
                  <td>{on ? <span className="chip green">مفعّل</span> : <span className="chip gray">معطّل</span>}</td>
                  <td>
                    <button className="btn ghost sm" onClick={() => run("setLineActive", { id: l.id, active: on ? "لا" : "نعم" }, on ? "تم تعطيل البند" : "تم تفعيل البند")}>
                      {on ? "تعطيل" : "تفعيل"}
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function AdminWorkflowSettings({ data, act, showToast }) {
  const st = data.settings || {};
  const [days, setDays] = useState(String(st.custody_overdue_days || 30));
  const run = async (key, value) => {
    try {
      await act("setSetting", { key, value });
      showToast("تم حفظ الإعداد");
    } catch (e) {}
  };
  return (
    <div className="panel" data-testid="adm-settings">
      <h3 className="panel-title">إعدادات دورة المصروف والعهد</h3>
      <div className="setting-row">
        <div>
          <b>اشتراط المستند المؤيد قبل «تمت التسوية»</b>
          <p className="hint">عند التفعيل لا يستطيع المدير المالى تسوية مصروف بدون رابط أو ملف مستند (الأدمن مستثنى).</p>
        </div>
        <button className={"btn sm " + (st.require_doc_to_settle === "yes" ? "primary" : "ghost")} onClick={() => run("require_doc_to_settle", st.require_doc_to_settle === "yes" ? "no" : "yes")}>
          {st.require_doc_to_settle === "yes" ? "مفعّل — إيقاف" : "غير مفعّل — تفعيل"}
        </button>
      </div>
      <div className="setting-row">
        <div>
          <b>العهدة متأخرة بعد (يوم)</b>
          <p className="hint">العهدة المفتوحة التى مضى على فتحها أكثر من هذا العدد تظهر «متأخرة» فى المتابعة والتقارير والتنبيهات.</p>
        </div>
        <span>
          <input value={days} onChange={(e) => setDays(e.target.value)} style={{ width: 80 }} />{" "}
          <button className="btn ghost sm" onClick={() => run("custody_overdue_days", days.trim())}>
            حفظ
          </button>
        </span>
      </div>
    </div>
  );
}

const sizeOf = (b) => (b > 1048576 ? (b / 1048576).toFixed(1) + " ميجا" : Math.max(1, Math.round(b / 1024)) + " كيلو");
const KIND = { manual: "يدوية", safety: "نسخة أمان تلقائية (قبل استعادة)" };

export function AdminBackups({ data, act, showToast }) {
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [restore, setRestore] = useState(null);
  const list = data.backups || [];
  const create = async () => {
    setBusy(true);
    try {
      const r = await act("createBackup", { note: note.trim() });
      showToast("تم إنشاء النسخة " + (r.backup && r.backup.name));
      setNote("");
    } catch (e) {}
    setBusy(false);
  };
  const download = async (b) => {
    try {
      const r = await probe("downloadBackup", { id: b.id });
      dlBlob(b.name + ".json", "application/json", JSON.stringify(r.data));
    } catch (e) {
      showToast(e.message, "err");
    }
  };
  return (
    <div className="stack" data-testid="adm-backups">
      <div className="panel">
        <h3 className="panel-title">النسخ الاحتياطى</h3>
        <p className="hint">
          النسخة تشمل كل البيانات: المستخدمين والصلاحيات، والأماكن، والموازنات والبنود، والعهد والمصروفات وروابط المستندات، والرواتب والعاملين، والإعدادات، وتتبع
          التعديلات. تُحفظ داخل قاعدة البيانات ولا يصل إليها إلا الأدمن من داخل النظام (لا يوجد رابط عام لها)، ويمكن تنزيلها كملف JSON.
          الملفات المرفوعة على مستودع Supabase (Storage) تُنسخ روابطها فقط؛ انسخ المستودع نفسه من لوحة Supabase.
        </p>
        <div className="filters">
          <div className="qf" style={{ flex: 1 }}>
            <span>ملاحظة (اختيارى)</span>
            <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="مثال: قبل إقفال الشهر" />
          </div>
          <button className="btn primary" disabled={busy} onClick={create} data-testid="bk-create">
            {busy ? "جارٍ إنشاء النسخة…" : "إنشاء نسخة احتياطية الآن"}
          </button>
        </div>
      </div>
      <div className="panel">
        <h3 className="panel-title">النسخ المتاحة ({list.length})</h3>
        {!list.length ? (
          <div className="empty">لا توجد نسخ بعد.</div>
        ) : (
          <table className="tbl" data-testid="bk-list">
            <thead>
              <tr>
                <th>النسخة</th>
                <th>النوع</th>
                <th>التاريخ والوقت</th>
                <th>الحجم</th>
                <th>المحتوى</th>
                <th>بواسطة</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {list.map((b) => (
                <tr key={b.id}>
                  <td>
                    <b>{b.name}</b>
                    {b.note && <span className="cust-sub">{b.note}</span>}
                  </td>
                  <td>{KIND[b.kind] || b.kind}</td>
                  <td className="num">{String(b.created_at || "").slice(0, 19).replace("T", " ")}</td>
                  <td className="num">{sizeOf(b.size_bytes || 0)}</td>
                  <td style={{ fontSize: 12 }}>
                    {["users", "schools", "lines", "custodies", "expenses", "employees", "payslips", "audit_log"]
                      .filter((t) => b.counts && b.counts[t] != null)
                      .map((t) => LABEL[t] + " " + fmt(b.counts[t]))
                      .join(" · ")}
                  </td>
                  <td>{b.created_by}</td>
                  <td style={{ whiteSpace: "nowrap" }}>
                    <button className="btn ghost sm" onClick={() => download(b)}>
                      تنزيل
                    </button>{" "}
                    <button className="btn danger-ghost sm" onClick={() => setRestore(b)} data-testid="bk-restore">
                      استعادة
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      {restore && <RestoreModal b={restore} act={act} showToast={showToast} close={() => setRestore(null)} />}
    </div>
  );
}
const LABEL = { users: "مستخدمون", schools: "أماكن", lines: "بنود", custodies: "عهد", expenses: "مصروفات", employees: "عاملون", payslips: "رواتب", audit_log: "سجل" };

function RestoreModal({ b, act, showToast, close }) {
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(null);
  const go = async () => {
    setBusy(true);
    try {
      const r = await act("restoreBackup", { id: b.id, confirm });
      setDone(r);
      showToast("تمت الاستعادة — " + b.name);
    } catch (e) {}
    setBusy(false);
  };
  return (
    <Modal title="استعادة نسخة احتياطية" close={close}>
      {done ? (
        <>
          <div className="imp-done">
            <div style={{ fontSize: 30 }}>✅</div>
            <h3>تمت استعادة {done.restored}</h3>
          </div>
          <p className="hint">
            أُنشئت قبلها نسخة أمان تلقائية للحالة السابقة: <b>{done.safety_backup && done.safety_backup.name}</b> — يمكنك استعادتها إن اخترت نسخة خاطئة.
          </p>
          <div className="modal-actions">
            <span className="spacer" />
            <button className="btn primary" onClick={close}>
              تم
            </button>
          </div>
        </>
      ) : (
        <>
          <div className="kv">
            <div>
              <span>النسخة</span>
              <b>{b.name}</b>
            </div>
            <div>
              <span>وقت الإنشاء</span>
              <b>{String(b.created_at || "").slice(0, 19).replace("T", " ")}</b>
            </div>
            <div>
              <span>الحجم</span>
              <b>{sizeOf(b.size_bytes || 0)}</b>
            </div>
            <div>
              <span>بواسطة</span>
              <b>{b.created_by || "—"}</b>
            </div>
          </div>
          <div className="warn-banner over" style={{ marginTop: 10 }}>
            ستعود كل البيانات إلى حالتها وقت هذه النسخة. قبل التنفيذ يُنشئ النظام تلقائياً نسخة أمان للحالة الحالية، ولا يُمسح «تتبع التعديلات».
            المستخدمون وكلمات السر تعود أيضاً لحالتها وقت النسخة.
          </div>
          <Field label={"للتأكيد اكتب اسم النسخة: " + b.name}>
            <input value={confirm} onChange={(e) => setConfirm(e.target.value)} dir="ltr" data-testid="bk-confirm" />
          </Field>
          <div className="modal-actions">
            <button className="btn ghost" onClick={close}>
              تراجع
            </button>
            <span className="spacer" />
            <button className="btn danger-ghost" disabled={busy || confirm !== b.name} onClick={go} data-testid="bk-go">
              {busy ? "جارٍ الاستعادة…" : "استعادة النسخة"}
            </button>
          </div>
        </>
      )}
    </Modal>
  );
}
