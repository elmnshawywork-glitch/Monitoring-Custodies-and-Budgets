// شاشة المصروفات: كل مصروف = صف منظم (رقم · تاريخ · مكان · عهدة · مسئول · بند · قيمة · حالة)
// وعند فتحه: بيانات المصروف + المستند + مراحل الـ Workflow (من قام بالإجراء ومتى والملاحظات) + سجل التعديلات.
// مع الخادم: البحث والفلترة والترقيم تتم داخل قاعدة البيانات (searchExpenses)؛ وفى الوضع التجريبى على بيانات المتصفح.
import React, { useEffect, useMemo, useState } from "react";
import { fmt } from "../lib/utils";
import { CAT_LABEL } from "../lib/model";
import { REMOTE, probe } from "../lib/api";
import { ApprovalChip, DocLink, Modal, Field } from "../components/ui";
import { STAGES, stageInfo, workflowSteps, expenseActions, fmtTs, hasDoc } from "../lib/expense";
import { localSearch, STATUS_FILTERS } from "../lib/expenseSearch";
import { can } from "../lib/perms";

const PAGE = 50;
const STATUS_OPTIONS = [
  ["all", "كل الحالات"],
  ["queue", "المطلوب منى"],
  ["draft", "مسودات"],
  ["pending", "بانتظار الاعتماد"],
  ["returned", "معاد للتعديل"],
  ["approved", "معتمد"],
  ["fin", "بانتظار الاعتماد المالى"],
  ["needdoc", "معتمد بلا مستند"],
  ["review", "بانتظار مراجعة المحاسب"],
  ["incomplete", "مستندات ناقصة"],
  ["settled", "تمت التسوية"],
  ["rejected", "مرفوض"],
  ["cancelled", "ملغى"],
];

export function Approvals({ data, isMgr, canApprove, canReview, act, setModal, showToast, initialStatus }) {
  const init = { school_id: "", holder: "", custody_id: "", line_id: "", manager_id: "", status: initialStatus || "all", from: "", to: "", spend_item: "", q: "" };
  const [f, setF] = useState(init);
  const [page, setPage] = useState(1);
  const [res, setRes] = useState(null);
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState(null);
  const [reason, setReason] = useState(null); // {kind, e}
  const set = (k, v) => (setF(Object.assign({}, f, { [k]: v }, k === "school_id" ? { holder: "", custody_id: "", line_id: "" } : {})), setPage(1));
  const filtersOn = Object.keys(init).some((k) => k !== "status" && f[k]) || f.status !== "all";
  const perms = { approve: canApprove, fin: canReview };

  const serverFilters = useMemo(() => {
    const out = Object.assign({}, STATUS_FILTERS[f.status] || {});
    ["school_id", "holder", "custody_id", "line_id", "manager_id", "from", "to", "spend_item", "q"].forEach((k) => f[k] && (out[k] = f[k]));
    return out;
  }, [f]);

  // إعادة البحث عند تغيير الفلاتر أو بعد أى إجراء (data تتغير بعد إعادة التحميل)
  useEffect(() => {
    let live = true;
    const run = async () => {
      setBusy(true);
      try {
        const r = REMOTE ? await probe("searchExpenses", { filters: serverFilters, page: 1, page_size: PAGE * page }) : localSearch(data, serverFilters, 1, PAGE * page);
        if (live) setRes(r);
      } catch (e) {
        if (live) showToast(e.message, "err");
      }
      if (live) setBusy(false);
    };
    run();
    return () => (live = false);
  }, [serverFilters, page, data]);

  const schools = data.schools || [];
  const custs = (data.custodies || []).filter((c) => !f.school_id || String(c.school_id) === String(f.school_id));
  const holders = Array.from(new Set(custs.map((c) => c.holder || c.label).filter(Boolean))).sort();
  const lines = (data.lines || []).filter((l) => !f.school_id || String(l.school_id) === String(f.school_id));
  const rows = (res && res.rows) || [];

  const run = async (action, payload, msg) => {
    try {
      await act(action, payload);
      showToast(msg);
    } catch (e) {}
  };

  return (
    <div className="stack">
      {can(data, "expense.import") && setModal && (
        <div className="exp-import-bar">
          <span className="muted">لديك ملف مصروفات وعهد جاهز؟ ارفعه وسيتعرف النظام على العهد والبنود والشهور تلقائياً.</span>
          <button className="btn primary sm" onClick={() => setModal({ type: "importExpenses" })} data-testid="expimp-btn">
            📥 استيراد ملف المصروفات والعهد
          </button>
        </div>
      )}
      <div className="panel" style={{ padding: 12 }}>
        <div className="filters exp-filters">
          <F label="المكان">
            <select value={f.school_id} onChange={(e) => set("school_id", e.target.value)}>
              <option value="">الكل</option>
              {schools.map((s) => (
                <option key={s.id} value={s.id}>
                  {CAT_LABEL[s.category || "school"]} · {s.name}
                  {String(s.active || "نعم").indexOf("نعم") < 0 ? " (معطّلة)" : ""}
                </option>
              ))}
            </select>
          </F>
          <F label="مسئول العهدة">
            <select value={f.holder} onChange={(e) => set("holder", e.target.value)} data-testid="ex-holder">
              <option value="">الكل</option>
              {holders.map((h) => (
                <option key={h} value={h}>
                  {h}
                </option>
              ))}
            </select>
          </F>
          <F label="العهدة">
            <select value={f.custody_id} onChange={(e) => set("custody_id", e.target.value)}>
              <option value="">الكل</option>
              {custs.map((c) => (
                <option key={c.id} value={c.id}>
                  {(c.code || "") + " · " + (c.title || c.label || "")}
                </option>
              ))}
            </select>
          </F>
          <F label="البند">
            <select value={f.line_id} onChange={(e) => set("line_id", e.target.value)}>
              <option value="">الكل</option>
              {lines.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                  {l.section ? " — " + l.section : ""}
                </option>
              ))}
            </select>
          </F>
          {(data.managers || []).length > 0 && (
            <F label="المدير المباشر">
              <select value={f.manager_id} onChange={(e) => set("manager_id", e.target.value)} data-testid="ex-manager">
                <option value="">الكل</option>
                {data.managers.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </select>
            </F>
          )}
          <F label="الحالة">
            <select value={f.status} onChange={(e) => set("status", e.target.value)} data-testid="ex-status">
              {STATUS_OPTIONS.map(([k, l]) => (
                <option key={k} value={k}>
                  {l}
                </option>
              ))}
            </select>
          </F>
          <F label="نوع المصروف">
            <select value={f.spend_item} onChange={(e) => set("spend_item", e.target.value)}>
              <option value="">الكل</option>
              {(data.spendItems || []).map((s) => (
                <option key={s.id} value={s.name}>
                  {s.name}
                </option>
              ))}
            </select>
          </F>
          <F label="من تاريخ">
            <input type="date" value={f.from} onChange={(e) => set("from", e.target.value)} />
          </F>
          <F label="إلى تاريخ">
            <input type="date" value={f.to} onChange={(e) => set("to", e.target.value)} />
          </F>
          <F label="بحث">
            <input value={f.q} placeholder="رقم المصروف أو الوصف أو المورد أو رقم المستند" onChange={(e) => set("q", e.target.value)} data-testid="ex-q" />
          </F>
          <button className="btn ghost sm" disabled={!filtersOn} onClick={() => (setF(Object.assign({}, init, { status: "all" })), setPage(1))}>
            مسح الفلاتر
          </button>
        </div>
        <div className="exp-count" data-testid="ex-count">
          {"عدد المصروفات: "}
          <b>{res ? res.total : "…"}</b>
          {" · الإجمالى المعروض: "}
          <b>{res ? fmt(res.sum) : "…"}</b>
          {" ج.م"}
          {res &&
            Object.entries(res.by_stage || {}).map(([k, v]) => (
              <span key={k} className={"chip " + ((STAGES[k] || {}).tone || "gray")}>
                {((STAGES[k] || {}).short || (STAGES[k] || {}).label || k) + ": " + v.n}
              </span>
            ))}
          {busy && <span className="muted"> · جارٍ التحميل…</span>}
        </div>
      </div>

      <div className="exp-table">
        <div className="exp-row head">
          <span>رقم المصروف</span>
          <span>التاريخ</span>
          <span>المكان</span>
          <span>العهدة</span>
          <span>مسئول العهدة</span>
          <span>البند</span>
          <span>القيمة</span>
          <span>الحالة</span>
        </div>
        {rows.map((e) => {
          const st = stageInfo(e);
          const acts = expenseActions(data, e, perms);
          const isOpen = open === e.id;
          return (
            <div key={e.id} className={"exp-item " + (isOpen ? "open" : "")} data-stage={e.stage}>
              <div className="exp-row" onClick={() => setOpen(isOpen ? null : e.id)} role="button">
                <span className="exp-no">{e.txn_no || "—"}</span>
                <span className="num">{e.date}</span>
                <span>{e.school}</span>
                <span>
                  {e.custody_code}
                  {e.custody_title ? <small>{e.custody_title}</small> : null}
                </span>
                <span>{e.holder || "—"}</span>
                <span>
                  {e.line || e.spend_item || "—"}
                  {e.section ? <small>{e.section}</small> : null}
                </span>
                <span className="num exp-amt">{fmt(e.amount)}</span>
                <span>
                  <span className={"chip " + st.tone}>{st.short || st.label}</span>
                </span>
              </div>
              <div className="exp-quick">
                <ApprovalChip s={e.approval} sett={String(e.settled || "").indexOf("نعم") >= 0} fin={e.fin_approval || ""} />
                {e.review_status === "ناقص" && <span className="chip red">مستندات ناقصة</span>}
                {hasDoc(e) ? (
                  <DocLink expense={e} className="chip navy" style={{ textDecoration: "none" }}>
                    {"📎 عرض المستند"}
                  </DocLink>
                ) : (
                  e.approval === "approved" && <span className="chip amber">بلا مستند</span>
                )}
                <span className="spacer" />
                {acts.indexOf("approve") >= 0 && (
                  <button className="btn primary sm" onClick={() => setModal({ type: "approve", payload: e })}>
                    مراجعة واعتماد
                  </button>
                )}
                {acts.indexOf("fin") >= 0 && (
                  <>
                    <button
                      className="btn primary sm"
                      onClick={() =>
                        (typeof window == "undefined" || window.confirm("اعتماد هذا المصروف مالياً؟ سيُخصم من الموازنة")) &&
                        run("reviewExpense", { id: e.id, patch: { fin_approval: "approved" } }, "تم الاعتماد المالى")
                      }
                    >
                      اعتماد مالى
                    </button>
                    <button className="btn ghost sm" onClick={() => setReason({ kind: "fin_returned", e })}>
                      إعادة للتعديل
                    </button>
                    <button className="btn danger-ghost sm" onClick={() => setReason({ kind: "fin_rejected", e })}>
                      رفض مالى
                    </button>
                  </>
                )}
                {acts.indexOf("settle") >= 0 && (
                  <button className="btn teal sm" onClick={() => setModal({ type: "review", payload: e })}>
                    التسوية / مراجعة المستند
                  </button>
                )}
                {acts.indexOf("submit") >= 0 && (
                  <button className="btn primary sm" onClick={() => run("submitExpense", { id: e.id }, "تم الإرسال للاعتماد")}>
                    {e.stage === "draft" ? "إرسال للاعتماد" : "إعادة الإرسال"}
                  </button>
                )}
                {acts.indexOf("doc") >= 0 && (
                  <button className="btn ghost sm" onClick={() => setModal({ type: "uploaddoc", payload: e })}>
                    {hasDoc(e) ? "تغيير المستند" : "رفع مستند"}
                  </button>
                )}
              </div>
              {isOpen && <ExpenseDetail data={data} e={e} acts={acts} setModal={setModal} run={run} setReason={setReason} />}
            </div>
          );
        })}
        {res && rows.length === 0 && <div className="empty">لا توجد مصروفات مطابقة.</div>}
        {res && rows.length < res.total && (
          <button className="btn ghost" onClick={() => setPage(page + 1)} data-testid="ex-more">
            عرض المزيد ({fmt(res.total - rows.length)} متبقى)
          </button>
        )}
      </div>
      {reason && <ReasonModal kind={reason.kind} e={reason.e} close={() => setReason(null)} run={run} />}
    </div>
  );
}

function F({ label, children }) {
  return (
    <div className="qf">
      <span>{label}</span>
      {children}
    </div>
  );
}

const STEP_ICON = { done: "✔", current: "●", wait: "○", returned: "↩", rejected: "✖" };
const STEP_LABEL = { done: "تم", current: "قيد الإجراء", wait: "لم يبدأ", returned: "معاد للتعديل", rejected: "مرفوض / ملغى" };

function ExpenseDetail({ data, e, acts, setModal, run, setReason }) {
  const [hist, setHist] = useState(null);
  const loadHist = async () => {
    try {
      const r = REMOTE ? await probe("expenseHistory", { id: e.id }) : { items: [] };
      setHist(r.items || []);
    } catch (x) {
      setHist([]);
    }
  };
  const kv = [
    ["المكان", e.school],
    ["اسم العهدة", e.custody_title || e.custody_code],
    ["نوع العهدة", e.custody_kind || "—"],
    ["مسئول العهدة", e.holder || "—"],
    ["المدير المباشر", e.manager || "حسب نطاق المكان"],
    ["البند", (e.line || "—") + (e.section ? " — " + e.section : "")],
    ["القيمة", fmt(e.amount) + " ج.م"],
    ["التاريخ", e.date],
    ["طريقة الدفع", e.pay_method || "—"],
    ["نوع المصروف", e.spend_item || "—"],
  ];
  return (
    <div className="exp-detail">
      <section>
        <h4>بيانات المصروف</h4>
        <div className="kv">
          {kv.map(([k, v]) => (
            <div key={k}>
              <span>{k}</span>
              <b>{v}</b>
            </div>
          ))}
          <div className="wide">
            <span>الوصف</span>
            <b>{e.description || "—"}</b>
          </div>
          {e.cancelled_at && (
            <div className="wide red">
              <span>سبب الإلغاء</span>
              <b>
                {e.cancel_reason} — {e.cancelled_by} · {fmtTs(e.cancelled_at)}
              </b>
            </div>
          )}
        </div>
      </section>
      <section>
        <h4>المستند</h4>
        {hasDoc(e) ? (
          <div className="doc-box">
            <span>
              {e.doc_type ? e.doc_type + " — " : ""}
              {e.doc_name || "مستند"}
            </span>
            <DocLink expense={e} className="btn primary sm">
              عرض المستند
            </DocLink>
          </div>
        ) : (
          <div className="muted">لا يوجد مستند مؤيد بعد{acts.indexOf("doc") >= 0 ? " — أضف رابط المستند أو ارفعه" : ""}.</div>
        )}
      </section>
      <section>
        <h4>مراحل المصروف (Workflow)</h4>
        <ol className="wf">
          {workflowSteps(e).map((s) => (
            <li key={s.key} className={"wf-" + s.state}>
              <i>{STEP_ICON[s.state]}</i>
              <div>
                <b>{s.title}</b>
                <span className="wf-st">{STEP_LABEL[s.state]}</span>
                {(s.by || s.at) && (
                  <span className="wf-by">
                    {s.by}
                    {s.at ? " · " + fmtTs(s.at) : ""}
                  </span>
                )}
                {s.note && <span className="wf-note">{s.note}</span>}
              </div>
            </li>
          ))}
        </ol>
        {REMOTE && (
          <div style={{ marginTop: 8 }}>
            {hist === null ? (
              <button className="btn ghost sm" onClick={loadHist}>
                سجل التعديلات الكامل
              </button>
            ) : hist.length ? (
              <ul className="hist">
                {hist.map((h, i) => (
                  <li key={i}>
                    <b>{fmtTs(h.ts)}</b> · {h.actor} ({h.role}) · {h.action}
                    <small>{Object.keys(h.new || {}).filter((k) => ["updated_at", "updated_by"].indexOf(k) < 0).join("، ")}</small>
                  </li>
                ))}
              </ul>
            ) : (
              <span className="muted">لا توجد تعديلات مسجلة.</span>
            )}
          </div>
        )}
      </section>
      <div className="exp-acts">
        {acts.indexOf("edit") >= 0 && (
          <button className="btn ghost sm" onClick={() => setModal({ type: "editExpense", payload: e })}>
            تعديل
          </button>
        )}
        {acts.indexOf("delete") >= 0 && (
          <button
            className="btn danger-ghost sm"
            onClick={() => (typeof window == "undefined" || window.confirm("حذف هذا المصروف؟")) && run("deleteExpense", { id: e.id }, "تم الحذف")}
          >
            حذف
          </button>
        )}
        {acts.indexOf("unsettle") >= 0 && (
          <button className="btn ghost sm" onClick={() => setModal({ type: "review", payload: e })}>
            تعديل المراجعة
          </button>
        )}
        {acts.indexOf("unapprove") >= 0 && (
          <button className="btn ghost sm" onClick={() => setReason({ kind: "unapprove", e })}>
            إلغاء الاعتماد
          </button>
        )}
        {acts.indexOf("cancel") >= 0 && (
          <button className="btn danger-ghost sm" onClick={() => setReason({ kind: "cancel", e })}>
            إلغاء المصروف
          </button>
        )}
      </div>
    </div>
  );
}

const REASON = {
  fin_returned: { title: "إعادة المصروف للتعديل (المدير المالى)", label: "سبب الإعادة", btn: "إعادة للتعديل" },
  fin_rejected: { title: "رفض المصروف مالياً", label: "سبب الرفض", btn: "رفض مالى" },
  cancel: { title: "إلغاء المصروف (الأدمن)", label: "سبب الإلغاء", btn: "تأكيد الإلغاء", warn: "لن يُحذف المصروف؛ يصبح «ملغى» ويخرج من الموازنة ورصيد العهدة، ويبقى فى التقارير وتتبع التعديلات." },
  unapprove: { title: "إلغاء الاعتماد (الأدمن)", label: "السبب", btn: "إلغاء الاعتماد", warn: "يعود المصروف لاعتماد المدير المباشر، ويُلغى الاعتماد المالى والتسوية." },
};

function ReasonModal({ kind, e, close, run }) {
  const [txt, setTxt] = useState("");
  const [busy, setBusy] = useState(false);
  const R = REASON[kind];
  const go = async () => {
    setBusy(true);
    if (kind === "fin_returned") await run("reviewExpense", { id: e.id, patch: { fin_approval: "returned", fin_note: txt.trim() } }, "أُعيد المصروف لصاحبه للتعديل");
    if (kind === "fin_rejected") await run("reviewExpense", { id: e.id, patch: { fin_approval: "rejected", fin_note: txt.trim() } }, "تم الرفض المالى");
    if (kind === "cancel") await run("cancelExpense", { id: e.id, reason: txt.trim() }, "تم إلغاء المصروف");
    if (kind === "unapprove") await run("unapproveExpense", { id: e.id, reason: txt.trim() }, "تم إلغاء الاعتماد");
    close();
  };
  return (
    <Modal title={R.title} close={close}>
      <div className="mini-sum">
        <b>{e.txn_no}</b> · {fmt(e.amount)} ج.م · {e.holder} · {e.line || e.spend_item}
      </div>
      {R.warn && <div className="warn-banner">{R.warn}</div>}
      <Field label={R.label + " (إلزامى)"}>
        <input value={txt} onChange={(x) => setTxt(x.target.value)} autoFocus data-testid="reason-input" />
      </Field>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          تراجع
        </button>
        <span className="spacer" />
        <button className="btn danger-ghost" disabled={busy || txt.trim().length < 3} onClick={go}>
          {R.btn}
        </button>
      </div>
    </Modal>
  );
}
