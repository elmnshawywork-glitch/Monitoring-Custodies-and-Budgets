import React from "react";
import { fmt, yes } from "../lib/utils";
import { custIssued, activeOnCustody, useCalc, CAT_LABEL } from "../lib/model";
import { Kpi } from "../components/ui";
import { ExecDashboard } from "./ExecDashboard";

// لوحة المتابعة حسب الدور: «المطلوب منك» ثم اللوحة التنفيذية (مؤشرات ورسوم حسب المكان).
// سجل العمليات لا يظهر هنا — مكانه تبويب «تتبع التعديلات».
export function RoleDashboard({ data, onGo }) {
  const role = data.me.role;
  return (
    <div className="stack">
      {role === "manager" && <AdminHome data={data} onGo={onGo} />}
      {role === "accountant" && <FinanceHome data={data} onGo={onGo} />}
      {role === "supervisor" && <DirectManagerHome data={data} onGo={onGo} />}
      {role === "custody" && <CustodyOfficerHome data={data} onGo={onGo} />}
      {role !== "custody" && <ExecDashboard data={data} onGo={onGo} />}
    </div>
  );
}

// ---------------------------------------------------------------- مساعدات
const schoolName = (data, id) => (data.schools.find((s) => String(s.id) === String(id)) || {}).name || "—";
const isTraining = (s) => String(s.category || "").indexOf("training") === 0;
const openCustody = (c) => ["open", "pending_settlement", "", undefined].indexOf(c.status) >= 0;
const sum = (arr, f) => arr.reduce((a, x) => a + Number(f(x) || 0), 0);

function ActionCard({ label, count, amount, tone, onClick, hint }) {
  return (
    <button className={"action-card " + tone + (count ? "" : " done")} onClick={onClick}>
      <span className="ac-count">{count}</span>
      <span className="ac-label">{label}</span>
      {amount != null && count > 0 && <span className="ac-amount">{fmt(amount)} ج.م</span>}
      {hint && <span className="ac-hint">{hint}</span>}
    </button>
  );
}

function Section({ title, children, right }) {
  return (
    <div className="panel">
      <div className="toolbar" style={{ marginBottom: 12 }}>
        <h3 className="panel-title" style={{ margin: 0 }}>
          {title}
        </h3>
        {right}
      </div>
      {children}
    </div>
  );
}

// ---------------------------------------------------------------- الأدمن
function AdminHome({ data, onGo }) {
  const openC = data.custodies.filter(openCustody).length;
  const pendingReq = (data.requests || []).filter(
    (r) => r.status === "pending_supervisor" || r.status === "pending_accountant",
  ).length;
  const finQueue = data.expenses.filter((e) => e.approval === "approved" && !e.fin_approval);
  const schools = data.schools.filter((s) => (s.category || "school") === "school").length;
  const training = data.schools.filter(isTraining).length;
  return (
    <div className="action-row">
      <ActionCard label="المدارس" count={schools} tone="navy" onClick={() => onGo("monthly")} />
      <ActionCard label="مشروعات وبرامج التدريب" count={training} tone="teal" onClick={() => onGo("monthly")} />
      <ActionCard label="عهد مفتوحة" count={openC} tone="amber" onClick={() => onGo("tracker")} />
      <ActionCard label="طلبات عهد معلّقة" count={pendingReq} tone="red" onClick={() => onGo("requests")} />
      <ActionCard
        label="بانتظار الاعتماد المالى"
        count={finQueue.length}
        amount={sum(finQueue, (e) => e.amount)}
        tone="red"
        onClick={() => onGo("approvals", { status: "fin" })}
      />
    </div>
  );
}

export const ACTION_LABEL = {
  addExpense: "تسجيل مصروف",
  updateExpense: "تعديل/اعتماد مصروف",
  reviewExpense: "اعتماد مالى/تسوية مصروف",
  deleteExpense: "حذف مصروف",
  addCentral: "شراء مركزى",
  uploadDoc: "رفع مستند",
  addCustody: "إنشاء عهدة",
  updateCustody: "تحديث عهدة",
  deleteCustody: "حذف عهدة",
  addTranche: "إضافة دفعة لعهدة",
  addRequest: "طلب عهدة",
  decideRequest: "قرار المدير المباشر على طلب",
  transferRequest: "اعتماد مالى/تحويل طلب",
  addLine: "إضافة بند",
  updateLine: "تعديل بند",
  deleteLine: "حذف بند",
  importBudget: "استيراد موازنة",
  addUser: "إضافة مستخدم",
  updateUser: "تعديل مستخدم",
  deleteUser: "حذف مستخدم",
  resetPin: "تصفير كلمة سر",
  setPassword: "تغيير كلمة السر",
  addSchool: "إضافة جهة",
  updateSchool: "تعديل جهة",
  login: "تسجيل دخول",
  loginFailed: "محاولة دخول فاشلة",
};

// ---------------------------------------------------------------- المدير المالى
function FinanceHome({ data, onGo }) {
  const finQueue = data.expenses.filter((e) => e.approval === "approved" && !e.fin_approval);
  const docQueue = data.expenses.filter((e) => e.fin_approval === "approved" && e.doc_url && !yes(e.settled));
  const noDoc = data.expenses.filter((e) => e.fin_approval === "approved" && !e.doc_url && !yes(e.settled));
  const reqQueue = (data.requests || []).filter((r) => r.status === "pending_accountant");
  const custQueue = data.custodies.filter((c) => c.status === "pending_settlement");
  return (
    <>
      <h3 className="section-h">المطلوب منك</h3>
      <div className="action-row">
        <ActionCard
          label="مصروفات بانتظار الاعتماد المالى"
          count={finQueue.length}
          amount={sum(finQueue, (e) => e.amount)}
          tone="red"
          onClick={() => onGo("approvals", { status: "fin" })}
        />
        <ActionCard
          label="مستندات بانتظار المراجعة والتسوية"
          count={docQueue.length}
          amount={sum(docQueue, (e) => e.amount)}
          tone="teal"
          onClick={() => onGo("approvals", { status: "review" })}
        />
        <ActionCard
          label="طلبات عهد بانتظار الاعتماد المالى"
          count={reqQueue.length}
          amount={sum(reqQueue, (r) => r.total)}
          tone="amber"
          onClick={() => onGo("requests")}
        />
        <ActionCard label="عهد مقدّمة للتسوية" count={custQueue.length} tone="navy" onClick={() => onGo("tracker")} />
      </div>
      {noDoc.length > 0 && (
        <div className="warn-banner">
          ⚠ {noDoc.length} مصروف معتمد مالياً بدون مستند — بإجمالى {fmt(sum(noDoc, (e) => e.amount))} ج.م
        </div>
      )}
    </>
  );
}

// ---------------------------------------------------------------- المدير المباشر
function DirectManagerHome({ data, onGo }) {
  const mine = (e) => {
    const c = data.custodies.find((x) => String(x.id) === String(e.custody_id));
    return c && String(c.user || "") === String(data.me.username);
  };
  // المدير المباشر المكلَّف فقط (أو حسب النطاق إن لم يُحدَّد مدير لمسئول العهدة)
  const assigned = (e) => {
    const c = data.custodies.find((x) => String(x.id) === String(e.custody_id));
    return !c || !c.manager_id || c.manager_id === data.me.id;
  };
  const expQueue = data.expenses.filter((e) => e.approval === "pending" && !e.cancelled_at && !mine(e) && assigned(e) && e.created_by_id !== data.me.id);
  const reqQueue = (data.requests || []).filter(
    (r) => r.status === "pending_supervisor" && r.requester !== data.me.username,
  );
  return (
    <>
      <h3 className="section-h">المطلوب منك</h3>
      <div className="action-row">
        <ActionCard
          label="مصروفات بانتظار اعتمادك"
          count={expQueue.length}
          amount={sum(expQueue, (e) => e.amount)}
          tone="red"
          onClick={() => onGo("approvals", { status: "queue" })}
        />
        <ActionCard
          label="طلبات عهد بانتظار اعتمادك"
          count={reqQueue.length}
          amount={sum(reqQueue, (r) => r.total)}
          tone="amber"
          onClick={() => onGo("requests")}
        />
      </div>
    </>
  );
}

// ---------------------------------------------------------------- مسئول العهدة
function CustodyOfficerHome({ data, onGo }) {
  const calc = useCalc(data);
  const mineC = data.custodies.filter((c) => String(c.user || "") === String(data.me.username));
  const ids = new Set(mineC.map((c) => String(c.id)));
  const exps = data.expenses.filter((e) => ids.has(String(e.custody_id)));
  const received = sum(mineC, (c) => custIssued(data, c));
  const spent = sum(exps.filter(activeOnCustody), (e) => e.amount);
  const pending = exps.filter((e) => e.approval === "pending");
  const approved = exps.filter((e) => e.approval === "approved" && e.fin_approval !== "rejected");
  const unsettled = approved.filter((e) => !yes(e.settled));
  const rejected = exps.filter((e) => e.approval === "rejected" || e.fin_approval === "rejected");
  const needDoc = approved.filter((e) => !e.doc_url);
  const toFix = exps.filter((e) => !e.cancelled_at && (e.approval === "draft" || e.approval === "returned" || e.fin_approval === "returned"));
  const openOnes = mineC.filter((c) => (c.status || "open") === "open");
  return (
    <>
      <div className="kpi-row">
        <Kpi
          label="رصيد العهدة المتاح"
          v={fmt(received - spent)}
          u="ج.م"
          tone={received - spent < 0 ? "red" : "green"}
        />
        <Kpi label="إجمالى المستلم" v={fmt(received)} u="ج.م" tone="navy" />
        <Kpi label="إجمالى المصروف" v={fmt(spent)} u="ج.م" tone="teal" />
        <Kpi label="عدد المصروفات" v={String(exps.length)} u="" tone="amber" />
      </div>
      <div className="action-row">
        <ActionCard
          label="بانتظار الاعتماد"
          count={pending.length}
          amount={sum(pending, (e) => e.amount)}
          tone="amber"
          onClick={() => onGo("approvals", { status: "pending" })}
        />
        <ActionCard
          label="معتمدة"
          count={approved.length}
          amount={sum(approved, (e) => e.amount)}
          tone="teal"
          onClick={() => onGo("approvals", { status: "approved" })}
        />
        <ActionCard
          label="لم تتم تسويتها"
          count={unsettled.length}
          amount={sum(unsettled, (e) => e.amount)}
          tone="navy"
          onClick={() => onGo("approvals", { status: "approved" })}
        />
        <ActionCard
          label="تحتاج رفع مستند"
          count={needDoc.length}
          tone="red"
          onClick={() => onGo("approvals", { status: "needdoc" })}
        />
      </div>
      {toFix.length > 0 && (
        <div className="warn-banner over click" onClick={() => onGo("approvals", { status: "queue" })} data-testid="to-fix">
          ↩ {toFix.length} مصروف (مسودة أو معاد للتعديل) يحتاج إجراءً منك — اضغط لعرضها.
        </div>
      )}
      {rejected.length > 0 && (
        <div className="warn-banner">✖ {rejected.length} مصروف مرفوض — راجع الملاحظات فى تبويب المصروفات.</div>
      )}
      {openOnes.length === 0 && mineC.length > 0 && (
        <div className="warn-banner">
          لا توجد عهدة مفتوحة حالياً — يمكنك إرسال{" "}
          <a href="#" onClick={(e) => (e.preventDefault(), onGo("requests"))}>
            طلب عهدة جديدة
          </a>
          .
        </div>
      )}
      <Section title="عُهدى">
        {mineC.length ? (
          <div className="table-wrap">
            <table className="tbl">
              <thead>
                <tr>
                  <th>العهدة</th>
                  <th>الجهة</th>
                  <th>المستلم</th>
                  <th>المصروف</th>
                  <th>المتبقى</th>
                  <th>الحالة</th>
                </tr>
              </thead>
              <tbody>
                {mineC.map((c) => {
                  const r = custIssued(data, c),
                    s = calc.spentByCustody[c.id] || 0;
                  return (
                    <tr key={c.id} style={{ cursor: "pointer" }} onClick={() => onGo("custodies")}>
                      <td style={{ fontWeight: 600 }}>{c.code || c.label}</td>
                      <td>{schoolName(data, c.school_id)}</td>
                      <td className="num">{fmt(r)}</td>
                      <td className="num teal">{fmt(s)}</td>
                      <td className={"num " + (r - s < 0 ? "red" : "green")}>{fmt(r - s)}</td>
                      <td>
                        <CustodyStatus c={c} spent={s} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="empty">لا توجد عهد مسندة إليك بعد.</div>
        )}
      </Section>
    </>
  );
}

export const CUSTODY_STATUS = {
  open: ["مفتوحة", "green"],
  pending_settlement: ["فى انتظار التسوية", "amber"],
  settled: ["تمت التسوية", "navy"],
  closed: ["مغلقة", "gray"],
};

export function CustodyStatus({ c, spent }) {
  let [txt, cls] = CUSTODY_STATUS[c.status || "open"] || CUSTODY_STATUS.open;
  if ((c.status || "open") === "open" && spent > 0) [txt, cls] = ["بها مصروفات", "teal"];
  return <span className={"chip " + cls}>{txt}</span>;
}
