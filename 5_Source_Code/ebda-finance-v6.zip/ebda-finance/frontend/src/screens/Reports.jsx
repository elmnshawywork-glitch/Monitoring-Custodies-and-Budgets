import { WindowNote } from "../components/ui";
import React, { useState } from "react";
import { b64utf8, daysSince, dedupe, dedupeEmails, exportAs, fmt, reportHTML, yes } from "../lib/utils";
import { CAT_FILTER, CAT_LABEL, custIssued, lineName, unitCat, useCalc } from "../lib/model";
import { ApprovalChip, Field, Kpi, Modal } from "../components/ui";

export function Reports({ data, act, showToast }) {
  let n = useCalc(data),
    [i, u] = useState("tx"),
    [s, o] = useState(""),
    [d, c] = useState(""),
    [p, m] = useState("all"),
    [r, v] = useState("all"),
    [S, N] = useState("all"),
    [b, f] = useState("all"),
    [h, y] = useState("all"),
    [g, x] = useState("all"),
    [C, _] = useState(null),
    A = (B) => B.spend_item || lineName(data, B.line_id) || "غير مصنّف",
    z = (B) => {
      let w = data.custodies.find((O) => String(O.id) === String(B));
      return w ? w.label : "—";
    },
    E = (B) => {
      let w = data.schools.find((O) => String(O.id) === String(B));
      return w ? w.name : "—";
    },
    j = (B) => (!s || B >= s) && (!d || B <= d),
    q = data.expenses.filter((B) => {
      if (
        B.approval === "rejected" ||
        !j(B.date) ||
        (h !== "all" && unitCat(data, B.school_id) !== h) ||
        (p !== "all" && String(B.school_id) !== p)
      )
        return !1;
      if (g !== "all") {
        let w = data.custodies.find((O) => String(O.id) === String(B.custody_id));
        if (!w || (w.holder || w.user) !== g) return !1;
      }
      return !(
        (r !== "all" && String(B.custody_id) !== r) ||
        (S !== "all" && A(B) !== S) ||
        (b === "pending" && B.approval !== "pending") ||
        (b === "approved" && B.approval !== "approved") ||
        (b === "settled" && !yes(B.settled)) ||
        (b === "unsettled" && !(B.approval === "approved" && !yes(B.settled)))
      );
    }),
    $ = Array.from(new Set(data.expenses.map(A))),
    I = q.reduce((B, w) => B + Number(w.amount || 0), 0),
    J = `الفترة: ${s || "البداية"} إلى ${d || "الآن"}`,
    ft = () => {
      if (i === "byItem") {
        let w = {};
        q.forEach((U) => {
          let H = A(U);
          w[H] = (w[H] || 0) + Number(U.amount || 0);
        });
        let O = Object.entries(w)
          .sort((U, H) => H[1] - U[1])
          .map(([U, H]) => [U, Math.round(H), (I ? Math.round((H / I) * 100) : 0) + "%"]);
        return {
          title: "تقرير المصروف حسب البند",
          header: ["البند", "المبلغ", "النسبة"],
          rows: O,
          meta: J,
        };
      }
      if (i === "balances") {
        let O = data.custodies
          .filter((U) => (r === "all" || String(U.id) === r) && (p === "all" || String(U.school_id) === p))
          .map((U) => {
            let H = custIssued(data, U),
              mt = n.spentByCustody[U.id] || 0;
            return [U.label, U.holder, H, mt, H - mt, H ? Math.round(((H - mt) / H) * 100) + "%" : "-"];
          });
        return {
          title: "تقرير أرصدة العهد",
          header: ["العهدة", "المسئول", "المستلمة", "المصروف", "المتبقى", "نسبة المتبقى"],
          rows: O,
          meta: J,
        };
      }
      if (i === "budget") {
        let w = {};
        q.forEach((H) => {
          H.line_id && yes(H.settled) && (w[H.line_id] = (w[H.line_id] || 0) + Number(H.amount || 0));
        });
        let O = p === "all" ? data.schools : data.schools.filter((H) => String(H.id) === p),
          U = [];
        return (
          O.forEach((H) =>
            data.lines
              .filter((mt) => String(mt.school_id) === String(H.id))
              .forEach((mt) => {
                let Nl = Number(mt.allocated || 0),
                  Hu = w[mt.id] || 0;
                U.push([H.name, mt.section, mt.name, Nl, Hu, Nl - Hu, Nl ? Math.round((Hu / Nl) * 100) + "%" : "-"]);
              }),
          ),
          {
            title: "تقرير تحليل الموازنة",
            header: ["المدرسة", "القسم", "البند", "الموازنة", "الفعلى المُسوّى", "المتبقى", "التنفيذ"],
            rows: U,
            meta: J,
          }
        );
      }
      if (i === "docs") {
        let w = q
          .filter((O) => O.approval === "approved" && !yes(O.settled))
          .sort((O, U) => daysSince(U.date) - daysSince(O.date))
          .map((O) => [
            O.date,
            z(O.custody_id),
            A(O),
            O.amount,
            daysSince(O.date) + " يوم",
            O.doc_url ? "مرفوع" : "بلا مستند",
            O.review_status === "ناقص" ? "ناقص" : "بانتظار المراجعة",
          ]);
        return {
          title: "تقرير متابعة المستندات",
          header: ["التاريخ", "العهدة", "البند", "المبلغ", "العمر", "المستند", "المراجعة"],
          rows: w,
          meta: J,
        };
      }
      if (i === "pettySchool") {
        let w = {};
        data.custodies
          .filter(
            (U) => (p === "all" || String(U.school_id) === p) && (h === "all" || unitCat(data, U.school_id) === h),
          )
          .forEach((U) => {
            let H = U.school_id,
              mt = custIssued(data, U),
              Nl = n.spentByCustody[U.id] || 0;
            ((w[H] = w[H] || {
              iss: 0,
              sp: 0,
              n: 0,
            }),
              (w[H].iss += mt),
              (w[H].sp += Nl),
              (w[H].n += 1));
          });
        let O = Object.entries(w).map(([U, H]) => [E(U), CAT_LABEL[unitCat(data, U)], H.n, H.iss, H.sp, H.iss - H.sp]);
        return {
          title: "تقرير Petty Cash — السيولة لكل مدرسة",
          header: ["المدرسة / الجهة", "النوع", "عدد العهد", "إجمالى المستلم", "المصروف", "المتبقى (السيولة)"],
          rows: O,
          meta: J,
        };
      }
      if (i === "officer") {
        let w = {};
        data.custodies.forEach((U) => {
          let H = U.holder || U.user || "—",
            mt = custIssued(data, U),
            Nl = n.spentByCustody[U.id] || 0;
          ((w[H] = w[H] || {
            iss: 0,
            sp: 0,
            n: 0,
          }),
            (w[H].iss += mt),
            (w[H].sp += Nl),
            (w[H].n += 1));
        });
        let O = Object.entries(w)
          .sort((U, H) => H[1].iss - H[1].sp - (U[1].iss - U[1].sp))
          .map(([U, H]) => [U, H.n, H.iss, H.sp, H.iss - H.sp]);
        return {
          title: "تقرير لكل مسئول عهدة",
          header: ["المسئول", "عدد العهد", "إجمالى المستلم", "المصروف", "المتبقى"],
          rows: O,
          meta: J,
        };
      }
      let B = q.map((w) => [
        w.date,
        E(w.school_id),
        z(w.custody_id),
        A(w),
        w.description,
        w.amount,
        w.approval === "approved" ? "معتمد" : w.approval === "pending" ? "بانتظار" : "-",
        yes(w.settled) ? "مسوّى" : "-",
        w.doc_url ? "نعم" : "لا",
      ]);
      return {
        title: "تقرير حركات المصروفات",
        header: ["التاريخ", "المدرسة", "العهدة", "البند", "البيان", "المبلغ", "الاعتماد", "التسوية", "مستند"],
        rows: B,
        meta: `${J} · الإجمالى ${fmt(I)} ج.م · عدد ${q.length}`,
      };
    },
    [Ht, nl] = useState("excel"),
    qu = () => {
      let B = ft();
      exportAs(Ht, B.title, B.header, B.rows, B.meta);
    },
    Ae = [
      ["tx", "الحركات"],
      ["byItem", "حسب البند"],
      ["balances", "أرصدة العهد"],
      ["pettySchool", "سيولة المدارس"],
      ["officer", "لكل مسئول"],
      ["budget", "تحليل الموازنة"],
      ["docs", "متابعة المستندات"],
    ];
  return (
    <div className="stack">
      <WindowNote data={data} />
      <div className="panel">
        <div
          style={{
            display: "flex",
            gap: 8,
            flexWrap: "wrap",
            alignItems: "end",
          }}
        >
          <div
            className="qf"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 4,
            }}
          >
            <span
              style={{
                fontSize: 11,
                color: "var(--ink-soft)",
              }}
            >
              من
            </span>
            <input
              type="date"
              value={s}
              onChange={(B) => o(B.target.value)}
              style={{
                padding: "8px 10px",
                border: "1px solid var(--line)",
                borderRadius: 8,
              }}
            />
          </div>
          <div
            className="qf"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 4,
            }}
          >
            <span
              style={{
                fontSize: 11,
                color: "var(--ink-soft)",
              }}
            >
              إلى
            </span>
            <input
              type="date"
              value={d}
              onChange={(B) => c(B.target.value)}
              style={{
                padding: "8px 10px",
                border: "1px solid var(--line)",
                borderRadius: 8,
              }}
            />
          </div>
          <select value={h} onChange={(B) => y(B.target.value)}>
            {CAT_FILTER.map(([B, w]) => (
              <option key={B} value={B}>
                {w}
              </option>
            ))}
          </select>
          <select
            value={p}
            onChange={(B) => {
              (m(B.target.value), x("all"));
            }}
          >
            <option value="all">كل المدارس</option>
            {data.schools.map((B) => (
              <option key={B.id} value={B.id}>
                {CAT_LABEL[B.category || "school"]}
                {" · "}
                {B.name}
              </option>
            ))}
          </select>
          <select value={g} onChange={(B) => x(B.target.value)}>
            <option value="all">كل المسئولين</option>
            {Array.from(
              new Set(
                data.custodies
                  .filter((B) => p === "all" || String(B.school_id) === p)
                  .map((B) => B.holder || B.user)
                  .filter(Boolean),
              ),
            ).map((B) => (
              <option key={B} value={B}>
                {B}
              </option>
            ))}
          </select>
          <select value={r} onChange={(B) => v(B.target.value)}>
            <option value="all">كل العهد</option>
            {data.custodies.map((B) => (
              <option key={B.id} value={B.id}>
                {B.label}
              </option>
            ))}
          </select>
          <select value={S} onChange={(B) => N(B.target.value)}>
            <option value="all">كل البنود</option>
            {$.map((B) => (
              <option key={B} value={B}>
                {B}
              </option>
            ))}
          </select>
          <select value={b} onChange={(B) => f(B.target.value)}>
            <option value="all">كل الحالات</option>
            <option value="approved">معتمد</option>
            <option value="pending">بانتظار الاعتماد</option>
            <option value="settled">مسوّى</option>
            <option value="unsettled">معتمد غير مسوّى</option>
          </select>
          <div
            className="qf"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 4,
            }}
          >
            <span
              style={{
                fontSize: 11,
                color: "var(--ink-soft)",
              }}
            >
              صيغة
            </span>
            <select value={Ht} onChange={(B) => nl(B.target.value)}>
              <option value="excel">Excel</option>
              <option value="word">Word</option>
              <option value="pdf">PDF</option>
              <option value="csv">CSV</option>
            </select>
          </div>
          <button className="btn ghost sm" onClick={qu}>
            تصدير
          </button>
          <button className="btn teal sm" onClick={() => _(ft())}>
            إرسال بالإيميل
          </button>
        </div>
        <div
          className="tabs"
          style={{
            position: "static",
            borderRadius: 10,
            border: "1px solid var(--line)",
            marginTop: 12,
          }}
        >
          {Ae.map(([B, w]) => (
            <button key={B} className={"tab " + (i === B ? "active" : "")} onClick={() => u(B)}>
              {w}
            </button>
          ))}
        </div>
      </div>
      {i === "tx" && <RepTx flt={q} total={I} custName={z} catName={A} />}
      {i === "byItem" && <RepByItem flt={q} catName={A} total={I} />}
      {i === "balances" && <RepBalances data={data} calc={n} flt={q} cust={r} school={p} typeF={h} />}
      {i === "pettySchool" && <RepPettySchool data={data} calc={n} school={p} typeF={h} />}
      {i === "officer" && <RepOfficer data={data} calc={n} />}
      {i === "budget" && <RepBudget data={data} flt={q} school={p} typeF={h} />}
      {i === "docs" && <RepDocs flt={q} custName={z} catName={A} />}
      {C && <EmailModal data={data} report={C} act={act} showToast={showToast} close={() => _(null)} />}
    </div>
  );
}

export function EmailModal({ data, report, act, showToast, close }) {
  let u = dedupeEmails([
      ...(data.users || []).map((b) => ({
        email: b.email,
        label: b.name,
      })),
      ...(data.approvers || []).map((b) => ({
        email: b.email,
        label: b.name,
      })),
      ...(data.emails || []).map((b) => ({
        email: b.email,
        label: b.label || b.email,
      })),
    ]),
    [s, o] = useState(u.map((b) => b.email)),
    [d, c] = useState(""),
    [p, m] = useState("pdf"),
    [r, v] = useState(!1),
    S = (b) => o((f) => (f.indexOf(b) >= 0 ? f.filter((h) => h !== b) : [...f, b])),
    N = async () => {
      let b = dedupe([...s, ...d.split(/[,;\s]+/).filter((y) => y.indexOf("@") > 0)]);
      if (!b.length) {
        alert("اختر مستلماً واحداً على الأقل");
        return;
      }
      v(!0);
      let f = reportHTML(report.title, report.header, report.rows, report.meta),
        h = {
          recipients: b,
          subject: report.title + " — ابدأ إديو",
          html: f,
        };
      p === "excel"
        ? (h.attachment = {
            filename: report.title + ".xls",
            mimeType: "application/vnd.ms-excel",
            dataBase64: b64utf8("﻿" + f),
          })
        : p === "word"
          ? (h.attachment = {
              filename: report.title + ".doc",
              mimeType: "application/msword",
              dataBase64: b64utf8("﻿" + f),
            })
          : p === "pdf" &&
            (h.attachment = {
              filename: report.title + ".pdf",
              mimeType: "application/pdf",
              html: f,
            });
      try {
        let y = await act("emailReport", h);
        (showToast(
          y && y.demo
            ? "وضع تجريبى: لا يُرسل إيميل فعلى — يعمل بعد ربط جوجل شيت"
            : "تم الإرسال إلى " + b.length + " مستلم",
        ),
          close());
      } catch (y) {
        v(!1);
      }
    };
  return (
    <Modal title="إرسال التقرير بالإيميل" close={close} wide={!0}>
      <div
        style={{
          marginBottom: 12,
          fontSize: 13,
          color: "var(--ink-soft)",
        }}
      >
        {report.title}
        {" · "}
        {report.meta}
      </div>
      <Field label="ما الذى يُرسل؟">
        <select value={p} onChange={(b) => m(b.target.value)}>
          <option value="pdf">التقرير كـ PDF</option>
          <option value="excel">التقرير كـ Excel</option>
          <option value="word">التقرير كـ Word</option>
          <option value="summary">ملخص فى نص الرسالة فقط</option>
        </select>
      </Field>
      <div className="field">
        <span>المستلمون (من إيميلات المستخدمين المسجّلة)</span>
        <div className="chips-list">
          {u.length === 0 ? (
            <span
              style={{
                fontSize: 12,
                color: "var(--ink-soft)",
              }}
            >
              لا إيميلات مسجّلة — أضف إيميلات المستخدمين من الإدارة.
            </span>
          ) : (
            u.map((b) => (
              <label
                key={b.email}
                className="cat-chip"
                style={{
                  cursor: "pointer",
                }}
              >
                <input type="checkbox" checked={s.indexOf(b.email) >= 0} onChange={() => S(b.email)} /> {b.label}{" "}
                <span
                  style={{
                    color: "var(--ink-soft)",
                  }}
                >
                  ({b.email})
                </span>
              </label>
            ))
          )}
        </div>
      </div>
      <Field label="إيميلات إضافية (اختيارى، بفاصلة)">
        <input value={d} onChange={(b) => c(b.target.value)} placeholder="name@example.com, ..." />
      </Field>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" disabled={r} onClick={N}>
          {r ? "جارٍ الإرسال…" : "إرسال"}
        </button>
      </div>
    </Modal>
  );
}

export function RepTx({ flt, total, custName, catName }) {
  let i = flt.length ? Math.round(total / flt.length) : 0;
  return (
    <div className="stack">
      <div className="kpi-row">
        <Kpi label="عدد الحركات" v={flt.length} u="" tone="navy" />
        <Kpi label="إجمالى المصروف" v={fmt(total)} u="ج.م" tone="teal" />
        <Kpi label="متوسط الحركة" v={fmt(i)} u="ج.م" tone="amber" />
      </div>
      <div className="panel">
        <div className="table-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>التاريخ</th>
                <th>العهدة</th>
                <th>البند</th>
                <th>البيان</th>
                <th>المبلغ</th>
                <th>الحالة</th>
              </tr>
            </thead>
            <tbody>
              {flt
                .slice()
                .reverse()
                .map((u) => (
                  <tr key={u.id}>
                    <td
                      style={{
                        whiteSpace: "nowrap",
                        color: "var(--ink-soft)",
                      }}
                    >
                      {u.date}
                    </td>
                    <td>{custName(u.custody_id)}</td>
                    <td>{catName(u)}</td>
                    <td
                      style={{
                        color: "var(--ink-soft)",
                        fontSize: 12.5,
                      }}
                    >
                      {u.description}
                    </td>
                    <td className="num">{fmt(u.amount)}</td>
                    <td>
                      <ApprovalChip s={u.approval} sett={yes(u.settled)} />
                    </td>
                  </tr>
                ))}
              {flt.length === 0 && (
                <tr>
                  <td colSpan="6">
                    <div className="empty">لا توجد حركات مطابقة.</div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function RepByItem({ flt, catName, total }) {
  let n = {};
  flt.forEach((s) => {
    let o = catName(s);
    n[o] = (n[o] || 0) + Number(s.amount || 0);
  });
  let i = Object.entries(n)
      .map(([s, o]) => ({
        name: s,
        v: o,
      }))
      .sort((s, o) => o.v - s.v),
    u = i.length ? i[0].v : 1;
  return (
    <div className="panel">
      <h3 className="panel-title">
        {"المصروف حسب البند "}
        {i[0] && (
          <span
            style={{
              fontSize: 12,
              color: "var(--ink-soft)",
            }}
          >
            {"· أعلى بند: "}
            {i[0].name}
          </span>
        )}
      </h3>
      {i.length === 0 ? (
        <div className="empty">لا توجد بيانات.</div>
      ) : (
        <div className="table-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>البند</th>
                <th>المبلغ</th>
                <th>النسبة</th>
                <th>التوزيع</th>
              </tr>
            </thead>
            <tbody>
              {i.map((s, o) => (
                <tr key={o}>
                  <td
                    style={{
                      fontWeight: 600,
                    }}
                  >
                    {s.name}
                  </td>
                  <td className="num">{fmt(s.v)}</td>
                  <td className="num">{total ? Math.round((s.v / total) * 100) : 0}%</td>
                  <td
                    style={{
                      minWidth: 160,
                    }}
                  >
                    <div className="bar">
                      <div
                        className="bar-fill"
                        style={{
                          width: (s.v / u) * 100 + "%",
                          background: o === 0 ? "var(--red)" : "var(--teal)",
                        }}
                      />
                    </div>
                  </td>
                </tr>
              ))}
              <tr className="tot">
                <td>الإجمالى</td>
                <td className="num">{fmt(total)}</td>
                <td>100%</td>
                <td />
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function RepPettySchool({ data, calc, school, typeF }) {
  let i = data.custodies.filter(
      (d) =>
        (school === "all" || String(d.school_id) === school) &&
        (typeF === "all" || unitCat(data, d.school_id) === typeF),
    ),
    u = {};
  i.forEach((d) => {
    let c = d.school_id;
    ((u[c] = u[c] || {
      iss: 0,
      sp: 0,
      n: 0,
    }),
      (u[c].iss += custIssued(data, d)),
      (u[c].sp += calc.spentByCustody[d.id] || 0),
      (u[c].n += 1));
  });
  let s = Object.entries(u).map(([d, c]) => ({
      k: d,
      ...c,
      rem: c.iss - c.sp,
      name: (data.schools.find((p) => String(p.id) === String(d)) || {}).name || "—",
      cat: unitCat(data, d),
    })),
    o = s.reduce((d, c) => d + c.rem, 0);
  return (
    <div className="panel">
      <h3 className="panel-title">
        {"Petty Cash — السيولة المتاحة لكل مدرسة/جهة "}
        <span
          style={{
            fontSize: 12,
            color: "var(--ink-soft)",
          }}
        >
          {"· الإجمالى "}
          {fmt(o)}
          {" ج.م"}
        </span>
      </h3>
      {s.length === 0 ? (
        <div className="empty">لا توجد عهد.</div>
      ) : (
        <div className="table-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>المدرسة / الجهة</th>
                <th>النوع</th>
                <th>عدد العهد</th>
                <th>المستلم</th>
                <th>المصروف</th>
                <th>المتبقى (السيولة)</th>
              </tr>
            </thead>
            <tbody>
              {s.map((d) => (
                <tr key={d.k}>
                  <td
                    style={{
                      fontWeight: 600,
                    }}
                  >
                    {d.name}
                  </td>
                  <td>
                    <span className="chip navy">{CAT_LABEL[d.cat]}</span>
                  </td>
                  <td className="num">{d.n}</td>
                  <td className="num">{fmt(d.iss)}</td>
                  <td className="num amber">{fmt(d.sp)}</td>
                  <td className={"num " + (d.rem >= 0 ? "green" : "red")}>
                    <b>{fmt(d.rem)}</b>
                  </td>
                </tr>
              ))}
              <tr className="tot">
                <td>الإجمالى</td>
                <td />
                <td />
                <td className="num">{fmt(s.reduce((d, c) => d + c.iss, 0))}</td>
                <td className="num">{fmt(s.reduce((d, c) => d + c.sp, 0))}</td>
                <td className="num green">{fmt(o)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function RepOfficer({ data, calc }) {
  let e = {};
  data.custodies.forEach((i) => {
    let u = i.holder || i.user || "—";
    ((e[u] = e[u] || {
      iss: 0,
      sp: 0,
      n: 0,
      custodies: [],
    }),
      (e[u].iss += custIssued(data, i)),
      (e[u].sp += calc.spentByCustody[i.id] || 0),
      (e[u].n += 1),
      e[u].custodies.push(i.label));
  });
  let n = Object.entries(e)
    .map(([i, u]) => ({
      k: i,
      ...u,
      rem: u.iss - u.sp,
    }))
    .sort((i, u) => u.rem - i.rem);
  return (
    <div className="panel">
      <h3 className="panel-title">ملخص لكل مسئول عهدة</h3>
      {n.length === 0 ? (
        <div className="empty">لا توجد عهد.</div>
      ) : (
        <div className="table-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>المسئول</th>
                <th>العهد</th>
                <th>عددها</th>
                <th>المستلم</th>
                <th>المصروف</th>
                <th>المتبقى</th>
              </tr>
            </thead>
            <tbody>
              {n.map((i) => (
                <tr key={i.k}>
                  <td
                    style={{
                      fontWeight: 600,
                    }}
                  >
                    {i.k}
                  </td>
                  <td
                    style={{
                      fontSize: 12,
                      color: "var(--ink-soft)",
                    }}
                  >
                    {i.custodies.join("، ")}
                  </td>
                  <td className="num">{i.n}</td>
                  <td className="num">{fmt(i.iss)}</td>
                  <td className="num amber">{fmt(i.sp)}</td>
                  <td className={"num " + (i.rem >= 0 ? "green" : "red")}>
                    <b>{fmt(i.rem)}</b>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export function RepBalances({ data, calc, flt, cust, school, typeF }) {
  let s = data.custodies.filter(
      (d) =>
        (cust === "all" || String(d.id) === cust) &&
        (school === "all" || String(d.school_id) === school) &&
        (!typeF || typeF === "all" || unitCat(data, d.school_id) === typeF),
    ),
    o = {};
  return (
    flt.forEach((d) => {
      o[d.custody_id] = (o[d.custody_id] || 0) + Number(d.amount || 0);
    }),
    (
      <div className="panel">
        <h3 className="panel-title">أرصدة العهد المتبقية</h3>
        <div className="table-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>العهدة</th>
                <th>المسئول</th>
                <th>المستلمة</th>
                <th>المصروف الكلى</th>
                <th>المتبقى</th>
                <th>مصروف الفترة</th>
                <th>الحالة</th>
              </tr>
            </thead>
            <tbody>
              {s.map((d) => {
                let c = custIssued(data, d),
                  p = calc.spentByCustody[d.id] || 0,
                  m = c - p,
                  v = (c ? (m / c) * 100 : 0) <= 10;
                return (
                  <tr key={d.id} className={v ? "def" : ""}>
                    <td
                      style={{
                        fontWeight: 600,
                      }}
                    >
                      {d.label}
                    </td>
                    <td>{d.holder}</td>
                    <td className="num">{fmt(c)}</td>
                    <td className="num amber">{fmt(p)}</td>
                    <td className={"num " + (m <= 0 ? "red" : "green")}>
                      <b>{fmt(m)}</b>
                    </td>
                    <td className="num">{fmt(o[d.id] || 0)}</td>
                    <td>
                      {m <= 0 ? (
                        <span className="chip red">نفدت</span>
                      ) : v ? (
                        <span className="chip amber">أوشكت</span>
                      ) : (
                        <span className="chip green">جيدة</span>
                      )}
                    </td>
                  </tr>
                );
              })}
              {s.length === 0 && (
                <tr>
                  <td colSpan="7">
                    <div className="empty">لا توجد عهد.</div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    )
  );
}

export function RepBudget({ data, flt, school, typeF }) {
  if (!data.lines || data.lines.length === 0)
    return (
      <div className="panel">
        <div className="empty">تحليل الموازنة متاح للأدوار التى ترى الموازنات.</div>
      </div>
    );
  let i = data.schools.filter(
      (s) =>
        (school === "all" || String(s.id) === school) &&
        (!typeF || typeF === "all" || (s.category || "school") === typeF),
    ),
    u = {};
  return (
    flt.forEach((s) => {
      s.line_id && yes(s.settled) && (u[s.line_id] = (u[s.line_id] || 0) + Number(s.amount || 0));
    }),
    (
      <div className="stack">
        {i.map((s) => {
          let o = data.lines.filter((m) => String(m.school_id) === String(s.id)),
            d = {};
          o.forEach((m) => {
            (d[m.section] = d[m.section] || []).push(m);
          });
          let c = o.reduce((m, r) => m + Number(r.allocated || 0), 0),
            p = o.reduce((m, r) => m + (u[r.id] || 0), 0);
          return (
            <div className="panel" key={s.id}>
              <h3 className="panel-title">
                {s.name}
                {" — تنفيذ الموازنة "}
                <span
                  style={{
                    fontSize: 12,
                    color: "var(--ink-soft)",
                  }}
                >
                  ({c ? Math.round((p / c) * 100) : 0}% منفّذ)
                </span>
              </h3>
              <div className="table-wrap">
                <table className="tbl">
                  <thead>
                    <tr>
                      <th>البند</th>
                      <th>الموازنة</th>
                      <th>الفعلى (الفترة)</th>
                      <th>المتبقى</th>
                      <th>%</th>
                      <th>التنفيذ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(d).map(([m, r]) => {
                      let v = r.reduce((N, b) => N + Number(b.allocated || 0), 0),
                        S = r.reduce((N, b) => N + (u[b.id] || 0), 0);
                      return React.createElement(
                        React.Fragment,
                        {
                          key: m,
                        },
                        <tr className="sec">
                          <td>{m}</td>
                          <td className="num">{fmt(v)}</td>
                          <td className="num">{fmt(S)}</td>
                          <td className="num">{fmt(v - S)}</td>
                          <td className="num">{v ? Math.round((S / v) * 100) : 0}%</td>
                          <td />
                        </tr>,
                        r.map((N) => {
                          let b = Number(N.allocated || 0),
                            f = u[N.id] || 0,
                            h = b ? Math.min(100, Math.round((f / b) * 100)) : 0;
                          return (
                            <tr key={N.id}>
                              <td>{N.name}</td>
                              <td className="num">{fmt(b)}</td>
                              <td className="num teal">{fmt(f)}</td>
                              <td className={"num " + (b - f < 0 ? "red" : "green")}>{fmt(b - f)}</td>
                              <td className="num">{h}%</td>
                              <td
                                style={{
                                  minWidth: 120,
                                }}
                              >
                                <div className="bar">
                                  <div
                                    className="bar-fill"
                                    style={{
                                      width: h + "%",
                                      background: h > 90 ? "var(--red)" : "var(--teal)",
                                    }}
                                  />
                                </div>
                              </td>
                            </tr>
                          );
                        }),
                      );
                    })}
                    <tr className="tot">
                      <td>الإجمالى</td>
                      <td className="num">{fmt(c)}</td>
                      <td className="num teal">{fmt(p)}</td>
                      <td className="num green">{fmt(c - p)}</td>
                      <td className="num">{c ? Math.round((p / c) * 100) : 0}%</td>
                      <td />
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          );
        })}
      </div>
    )
  );
}

export function RepDocs({ flt, custName, catName }) {
  let n = flt
    .filter((i) => i.approval === "approved" && !yes(i.settled))
    .map((i) => ({
      e: i,
      age: daysSince(i.date),
      miss: !i.doc_url,
    }))
    .sort((i, u) => u.age - i.age);
  return (
    <div className="panel">
      <h3 className="panel-title">متابعة المستندات (معتمد وغير مُسوّى)</h3>
      {n.length === 0 ? (
        <div className="empty">لا توجد بنود معلّقة — كل شىء مُسوّى ✅</div>
      ) : (
        <div className="table-wrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>التاريخ</th>
                <th>العهدة</th>
                <th>البند</th>
                <th>المبلغ</th>
                <th>عمر البند</th>
                <th>المستند</th>
                <th>المراجعة</th>
              </tr>
            </thead>
            <tbody>
              {n.map(({ e, age, miss }) => (
                <tr key={e.id} className={age > 14 ? "def" : ""}>
                  <td
                    style={{
                      whiteSpace: "nowrap",
                      color: "var(--ink-soft)",
                    }}
                  >
                    {e.date}
                  </td>
                  <td>{custName(e.custody_id)}</td>
                  <td>{catName(e)}</td>
                  <td className="num">{fmt(e.amount)}</td>
                  <td className="num">
                    {age}
                    {" يوم"}
                  </td>
                  <td>
                    {miss ? <span className="chip amber">بلا مستند</span> : <span className="chip navy">مرفوع</span>}
                  </td>
                  <td>
                    {e.review_status === "ناقص" ? (
                      <span className="chip red">ناقص</span>
                    ) : (
                      <span className="chip gray">بانتظار المراجعة</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
