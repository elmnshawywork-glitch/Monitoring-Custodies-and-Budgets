import { WindowNote } from "../components/ui";
import React, { useState } from "react";
import { fmt, yes } from "../lib/utils";
import { CAT_FILTER, CAT_LABEL, custIssued, unitCat, useCalc } from "../lib/model";
import { Gauge, HBars, Kpi, PairBars, ShareList } from "../components/ui";

export function Analytics({ data }) {
  let l = useCalc(data),
    [e, n] = useState(""),
    [i, u] = useState(""),
    [s, o] = useState("all"),
    [d, c] = useState("all"),
    p = (O) => (!e || O >= e) && (!i || O <= i),
    m = (O) =>
      O.approval !== "rejected" &&
      p(O.date) &&
      (s === "all" || String(O.school_id) === s) &&
      (d === "all" || unitCat(data, O.school_id) === d),
    r = data.expenses.filter((O) => m(O) && yes(O.settled)),
    v = (O) => {
      let U = data.schools.find((H) => String(H.id) === String(O));
      return U ? U.name : "—";
    },
    S = (O) => {
      let U = (data.lines || []).find((H) => String(H.id) === String(O));
      return U ? U.name : "غير مصنّف";
    },
    N = {};
  r.forEach((O) => (N[O.school_id] = (N[O.school_id] || 0) + Number(O.amount || 0)));
  let b = {};
  r.forEach((O) => {
    let U = S(O.line_id);
    b[U] = (b[U] || 0) + Number(O.amount || 0);
  });
  let f = {};
  r.forEach((O) => {
    let U = String(O.date || "").slice(0, 7);
    U && (f[U] = (f[U] || 0) + Number(O.amount || 0));
  });
  let h = Object.entries(N)
      .map(([O, U]) => ({
        label: v(O),
        value: U,
        color: "var(--navy)",
      }))
      .sort((O, U) => U.value - O.value),
    y = Object.entries(b)
      .map(([O, U]) => ({
        label: O,
        value: U,
        color: "var(--teal)",
      }))
      .sort((O, U) => U.value - O.value)
      .slice(0, 8),
    g = Object.entries(f)
      .sort((O, U) => (O[0] < U[0] ? -1 : 1))
      .map(([O, U]) => ({
        label: O,
        value: U,
        color: "var(--amber)",
      })),
    x = r.reduce((O, U) => O + Number(U.amount || 0), 0),
    C = data.schools.filter(
      (O) => (s === "all" || String(O.id) === s) && (d === "all" || (O.category || "school") === d),
    ),
    _ = (data.lines || [])
      .filter((O) => C.some((U) => String(U.id) === String(O.school_id)))
      .reduce((O, U) => O + Number(U.allocated || 0), 0),
    z = data.custodies
      .filter((O) => C.some((U) => String(U.id) === String(O.school_id)))
      .reduce((O, U) => O + (custIssued(data, U) - (l.spentByCustody[U.id] || 0)), 0),
    E = data.expenses.filter((O) => m(O) && O.approval === "pending").length,
    j = (data.tempBudgets || []).filter((O) => s === "all" || String(O.school_id) === s),
    q = (O) =>
      data.expenses
        .filter(
          (U) =>
            String(U.school_id) === String(O.school_id) &&
            yes(U.settled) &&
            (!O.dfrom || U.date >= O.dfrom) &&
            (!O.dto || U.date <= O.dto),
        )
        .reduce((U, H) => U + Number(H.amount || 0), 0),
    $ = C.map((O) => {
      let U = (data.lines || [])
          .filter((mt) => String(mt.school_id) === String(O.id))
          .reduce((mt, Nl) => mt + Number(Nl.allocated || 0), 0),
        H = N[O.id] || 0;
      return {
        label: O.name,
        a: U,
        b: H,
      };
    })
      .filter((O) => O.a > 0 || O.b > 0)
      .sort((O, U) => U.b - O.b),
    I = {
      school: "var(--navy)",
      company: "var(--teal)",
      training_general: "var(--green)",
      training_vocational: "var(--amber)",
    },
    J = {};
  r.forEach((O) => {
    let U = unitCat(data, O.school_id);
    J[U] = (J[U] || 0) + Number(O.amount || 0);
  });
  let ft = Object.entries(J).map(([O, U]) => ({
      label: CAT_LABEL[O] || O,
      value: U,
      color: I[O] || "var(--gray)",
    })),
    Ht = (O) => {
      let U = data.custodies.find((H) => String(H.id) === String(O.custody_id));
      return (U && (U.holder || U.user)) || "";
    },
    nl = {};
  r.forEach((O) => {
    let U = Ht(O);
    U && (nl[U] = (nl[U] || 0) + Number(O.amount || 0));
  });
  let qu = Object.entries(nl)
      .map(([O, U]) => ({
        label: O,
        value: U,
        color: "var(--red)",
      }))
      .sort((O, U) => U.value - O.value)
      .slice(0, 8),
    Ae = data.expenses.filter((O) => m(O) && O.approval === "approved" && O.custody_id),
    B = Ae.filter((O) => O.doc_url).length,
    w = Ae.length ? Math.round((B / Ae.length) * 100) : 0;
  return (
    <div className="stack">
      <WindowNote data={data} />
      <div
        className="panel"
        style={{
          padding: 12,
        }}
      >
        <div
          style={{
            display: "flex",
            gap: 8,
            flexWrap: "wrap",
            alignItems: "end",
          }}
        >
          <div
            className="qf"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 4,
            }}
          >
            <span
              style={{
                fontSize: 11,
                color: "var(--ink-soft)",
              }}
            >
              من
            </span>
            <input
              type="date"
              value={e}
              onChange={(O) => n(O.target.value)}
              style={{
                padding: "8px 10px",
                border: "1px solid var(--line)",
                borderRadius: 8,
              }}
            />
          </div>
          <div
            className="qf"
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 4,
            }}
          >
            <span
              style={{
                fontSize: 11,
                color: "var(--ink-soft)",
              }}
            >
              إلى
            </span>
            <input
              type="date"
              value={i}
              onChange={(O) => u(O.target.value)}
              style={{
                padding: "8px 10px",
                border: "1px solid var(--line)",
                borderRadius: 8,
              }}
            />
          </div>
          <select value={d} onChange={(O) => c(O.target.value)}>
            {CAT_FILTER.map(([O, U]) => (
              <option key={O} value={O}>
                {U}
              </option>
            ))}
          </select>
          <select value={s} onChange={(O) => o(O.target.value)}>
            <option value="all">كل الجهات</option>
            {data.schools.map((O) => (
              <option key={O.id} value={O.id}>
                {CAT_LABEL[O.category || "school"]}
                {" · "}
                {O.name}
              </option>
            ))}
          </select>
        </div>
      </div>
      <div className="kpi-row">
        <Kpi label="الموازنة (المحدَّدة)" v={fmt(_)} u="ج.م" tone="navy" />
        <Kpi label="المصروف المُسوّى" v={fmt(x)} u="ج.م" tone="teal" />
        <Kpi label="سيولة العهد المتاحة" v={fmt(z)} u="ج.م" tone="amber" />
        <Kpi label="بانتظار الاعتماد" v={E} u="" tone="red" />
      </div>
      <div className="admin-grid">
        <div className="panel">
          <h3 className="panel-title">المصروف حسب الجهة</h3>
          <HBars items={h} />
        </div>
        <div className="panel">
          <h3 className="panel-title">أعلى البنود صرفاً</h3>
          <HBars items={y} />
        </div>
      </div>
      <div className="panel">
        <h3 className="panel-title">اتجاه الصرف الشهرى</h3>
        <HBars items={g} />
      </div>
      <div className="admin-grid">
        <div className="panel">
          <h3 className="panel-title">الموازنة مقابل الفعلى لكل جهة</h3>
          <PairBars items={$} />
        </div>
        <div className="panel">
          <h3 className="panel-title">توزيع المصروف حسب النوع</h3>
          <ShareList items={ft} />
        </div>
      </div>
      <div className="admin-grid">
        <div className="panel">
          <h3 className="panel-title">أعلى مسئولى العهد صرفاً</h3>
          <HBars items={qu} />
        </div>
        <div className="panel">
          <h3 className="panel-title">نسبة اكتمال مستندات الصرف</h3>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 18,
              flexWrap: "wrap",
            }}
          >
            <Gauge pct={w} />
            <div
              style={{
                flex: 1,
                minWidth: 160,
                fontSize: 13,
                color: "var(--ink-soft)",
                lineHeight: 1.9,
              }}
            >
              <div>
                {"المصروفات المعتمدة: "}
                <b
                  style={{
                    color: "var(--navy)",
                  }}
                >
                  {Ae.length}
                </b>
              </div>
              <div>
                {"لها مستند: "}
                <b className="green">{B}</b>
              </div>
              <div>
                {"بلا مستند: "}
                <b className="red">{Ae.length - B}</b>
              </div>
            </div>
          </div>
        </div>
      </div>
      {j.length > 0 && (
        <div className="panel">
          <h3 className="panel-title">الموازنات المؤقتة</h3>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: 12,
            }}
          >
            {j.map((O) => {
              let U = q(O),
                H = Number(O.amount || 0),
                mt = H ? Math.round((U / H) * 100) : 0;
              return (
                <div key={O.id}>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      fontSize: 13,
                      marginBottom: 4,
                    }}
                  >
                    <b
                      style={{
                        color: "var(--navy)",
                      }}
                    >
                      {O.name}{" "}
                      <span
                        style={{
                          color: "var(--ink-soft)",
                          fontWeight: 400,
                          fontSize: 11,
                        }}
                      >
                        ({O.dfrom}
                        {" ← "}
                        {O.dto})
                      </span>
                    </b>
                    <span>
                      {fmt(U)}
                      {" / "}
                      {fmt(H)}
                      {" ("}
                      {mt}%)
                    </span>
                  </div>
                  <div
                    className="bar"
                    style={{
                      height: 12,
                    }}
                  >
                    <div
                      className="bar-fill"
                      style={{
                        width: Math.min(100, mt) + "%",
                        background: mt > 90 ? "var(--red)" : "var(--teal)",
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
