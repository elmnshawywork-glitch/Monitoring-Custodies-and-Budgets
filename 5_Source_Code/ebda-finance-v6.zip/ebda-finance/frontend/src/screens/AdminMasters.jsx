// بيانات أساسية (Master Data) يديرها الأدمن: أسماء العهد · عناصر الراتب
import React, { useState } from "react";
import { yes } from "../lib/utils";

export function AdminCustodyNames({ data, act, showToast }) {
  const [name, setName] = useState("");
  const [sections, setSections] = useState("");
  const allSections = Array.from(new Set((data.lines || []).map((l) => l.section).filter(Boolean))).sort();
  const save = async (item, msg) => {
    try {
      await act("saveCustodyName", { item });
      showToast(msg || "تم الحفظ");
      return true;
    } catch (e) {
      return false;
    }
  };
  return (
    <div className="panel">
      <h3 className="panel-title">أسماء العهد</h3>
      <p className="hint">
        اسم العهدة مستقل عن نوعها وعن مسئولها. يمكن ربط الاسم بأقسام من الموازنة لتصفية البنود تلقائياً عند إنشاء العهدة أو تسجيل
        المصروف (اختيارى). الأسماء المعطّلة لا تظهر فى القوائم، وتبقى على العهد القديمة.
      </p>
      <div className="filters" style={{ marginBottom: 12 }}>
        <div className="qf">
          <span>اسم جديد</span>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="مثال: عهدة أنشطة طلابية" />
        </div>
        <div className="qf">
          <span>أقسام الموازنة المرتبطة (اختيارى)</span>
          <input list="all-sections" value={sections} onChange={(e) => setSections(e.target.value)} placeholder="قسم1، قسم2" />
          <datalist id="all-sections">
            {allSections.map((s) => (
              <option key={s} value={s} />
            ))}
          </datalist>
        </div>
        <button
          className="btn primary sm"
          onClick={async () => name.trim() && (await save({ name: name.trim(), sections }, "تمت إضافة الاسم")) && (setName(""), setSections(""))}
        >
          + إضافة
        </button>
      </div>
      <div className="table-wrap">
        <table className="tbl">
          <thead>
            <tr>
              <th>الاسم</th>
              <th>الأقسام المرتبطة</th>
              <th>الحالة</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {(data.custody_names || []).map((n) => (
              <NameRow key={n.id} n={n} save={save} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function NameRow({ n, save }) {
  const [edit, setEdit] = useState(false);
  const [name, setName] = useState(n.name);
  const [sections, setSections] = useState(n.sections || "");
  const active = yes(n.active);
  return (
    <tr>
      <td>{edit ? <input value={name} onChange={(e) => setName(e.target.value)} /> : <b>{n.name}</b>}</td>
      <td>{edit ? <input list="all-sections" value={sections} onChange={(e) => setSections(e.target.value)} /> : n.sections || "—"}</td>
      <td>
        <span className={"chip " + (active ? "green" : "gray")}>{active ? "مفعّل" : "معطّل"}</span>
      </td>
      <td style={{ whiteSpace: "nowrap" }}>
        {edit ? (
          <button className="btn primary sm" onClick={async () => (await save({ id: n.id, name, sections })) && setEdit(false)}>
            حفظ
          </button>
        ) : (
          <button className="btn ghost sm" onClick={() => setEdit(true)}>
            تعديل
          </button>
        )}{" "}
        <button className="btn ghost sm" onClick={() => save({ id: n.id, name: n.name, active: active ? "لا" : "نعم" }, active ? "تم التعطيل" : "تم التفعيل")}>
          {active ? "تعطيل" : "تفعيل"}
        </button>
      </td>
    </tr>
  );
}

export function AdminPayComponents({ data, act, showToast }) {
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [kind, setKind] = useState("deduction");
  const save = async (item, msg) => {
    try {
      await act("savePayrollComponent", { item });
      showToast(msg || "تم الحفظ");
      return true;
    } catch (e) {
      return false;
    }
  };
  return (
    <div className="panel">
      <h3 className="panel-title">عناصر الراتب (المؤثرات)</h3>
      <p className="hint">
        كل عنصر إما «إضافة» تُضاف لصافى الراتب (مكافأة، بدل…) أو «خصم» يُطرح منه (سلفة، تأمينات، ضرائب…). أى عنصر جديد يظهر فوراً فى
        شاشة الرواتب وفى تقرير الحسابات بدون أى تعديل فى البرنامج.
      </p>
      <div className="filters" style={{ marginBottom: 12 }}>
        <div className="qf">
          <span>الاسم</span>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="مثال: بدل انتقال" />
        </div>
        <div className="qf">
          <span>الرمز (إنجليزى)</span>
          <input value={code} onChange={(e) => setCode(e.target.value.toLowerCase())} placeholder="transport" dir="ltr" />
        </div>
        <div className="qf">
          <span>النوع</span>
          <select value={kind} onChange={(e) => setKind(e.target.value)}>
            <option value="earning">إضافة (+)</option>
            <option value="deduction">خصم (−)</option>
          </select>
        </div>
        <button
          className="btn primary sm"
          onClick={async () => name.trim() && (await save({ code, name: name.trim(), kind }, "تمت إضافة العنصر")) && (setName(""), setCode(""))}
        >
          + إضافة
        </button>
      </div>
      <div className="table-wrap">
        <table className="tbl">
          <thead>
            <tr>
              <th>العنصر</th>
              <th>الرمز</th>
              <th>النوع</th>
              <th>الحالة</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {(data.payroll_components || []).map((c) => {
              const active = yes(c.active);
              return (
                <tr key={c.id}>
                  <td>
                    <b>{c.name}</b>
                    {yes(c.system) && <span className="cust-sub">عنصر أساسى</span>}
                  </td>
                  <td dir="ltr" style={{ textAlign: "right" }}>
                    {c.code}
                  </td>
                  <td>
                    <span className={"chip " + (c.kind === "earning" ? "green" : "red")}>{c.kind === "earning" ? "إضافة (+)" : "خصم (−)"}</span>
                  </td>
                  <td>
                    <span className={"chip " + (active ? "green" : "gray")}>{active ? "مفعّل" : "معطّل"}</span>
                  </td>
                  <td>
                    <button
                      className="btn ghost sm"
                      onClick={() => save({ id: c.id, name: c.name, kind: c.kind, active: active ? "لا" : "نعم" }, active ? "تم التعطيل" : "تم التفعيل")}
                    >
                      {active ? "تعطيل" : "تفعيل"}
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
