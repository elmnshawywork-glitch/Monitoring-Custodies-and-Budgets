import React, { useEffect, useState } from "react";
import { fmt, yes } from "../lib/utils";
import { CAT_FILTER, CAT_LABEL, useCalc } from "../lib/model";
import { budgetModel, periodFigures } from "../lib/budget";

export function Budgets({ data, canCentral, isMgr, setModal, act }) {
  const u = useCalc(data);
  const [cat, setCat] = useState("all");
  const list = data.schools.filter((b) => cat === "all" || (b.category || "school") === cat);
  const [sid, setSid] = useState(list[0] ? list[0].id : "");
  useEffect(() => {
    list.find((b) => String(b.id) === String(sid)) || setSid(list[0] ? list[0].id : "");
  }, [cat]);
  const ent = data.schools.find((b) => String(b.id) === String(sid));
  const model = budgetModel(data, { schoolIds: new Set([String(sid)]) });
  const sections = [];
  model.lines.forEach((r) => {
    let g = sections.find((h) => h.name === (r.line.section || "عام"));
    if (!g) sections.push((g = { name: r.line.section || "عام", rows: [] }));
    g.rows.push(r);
  });
  const tot = periodFigures(model.lines, null);
  return (
    <div className="stack">
      <div className="toolbar">
        <h3 className="section-h">
          {"الموازنة السنوية "}
          <span style={{ fontSize: 12, color: "var(--ink-soft)", fontWeight: 400 }}>
            (المصروف = المعتمد من المدير المباشر والمعتمد مالياً)
          </span>
        </h3>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <select value={cat} onChange={(b) => setCat(b.target.value)}>
            {CAT_FILTER.map(([b, f]) => (
              <option key={b} value={b}>
                {f}
              </option>
            ))}
          </select>
          <select value={sid} onChange={(b) => setSid(b.target.value)}>
            {list.map((b) => (
              <option key={b.id} value={b.id}>
                {CAT_LABEL[b.category || "school"]}
                {" · "}
                {b.name}
              </option>
            ))}
          </select>
        </div>
      </div>
      {canCentral && (
        <div className="big-actions">
          <button className="big-action" onClick={() => setModal({ type: "budgetImport", payload: { school_id: sid } })}>
            <span className="ba-ico">⤓</span>
            <b>استيراد موازنة</b>
            <small>من ملف Excel — معاينة ومقارنة قبل الحفظ</small>
          </button>
          <button className="big-action" onClick={() => setModal({ type: "budgetLine", payload: { school_id: sid } })}>
            <span className="ba-ico">＋</span>
            <b>إضافة موازنة يدوياً</b>
            <small>بند جديد بمخصصه وتوزيعه الشهرى</small>
          </button>
          {sid && isMgr && model.lines.length > 0 && (
            <button className="big-action danger" onClick={() => setModal({ type: "budgetDelete", payload: { school_id: sid } })}>
              <span className="ba-ico">🗑</span>
              <b>حذف الموازنة</b>
              <small>للأدمن فقط — حذف منطقى قابل للاسترجاع</small>
            </button>
          )}
          {sid && (
            <button className="big-action" onClick={() => setModal({ type: "central", payload: { school_id: sid } })}>
              <span className="ba-ico">🛒</span>
              <b>شراء مركزى</b>
              <small>يُخصم من الموازنة مباشرة</small>
            </button>
          )}
        </div>
      )}
      {sid ? (
        <div className="panel">
          <div className="mini-kpis">
            <div>
              <span>المخصص السنوى</span>
              <b>{fmt(tot.alloc)}</b>
            </div>
            <div>
              <span>المصروف السنوى</span>
              <b className="teal">{fmt(tot.spent)}</b>
            </div>
            <div>
              <span>{tot.diff < -0.5 ? "التجاوز" : "المتبقى"}</span>
              <b className={tot.diff < -0.5 ? "red" : "green"}>{fmt(Math.abs(tot.diff))}</b>
            </div>
            <div>
              <span>نسبة الصرف</span>
              <b>{Math.round(tot.pct * 100)}%</b>
            </div>
            <div>
              <span>عدد البنود</span>
              <b>{model.lines.length}</b>
            </div>
          </div>
          {ent && ent.period && <div className="hint">السنة المالية {ent.period} (سبتمبر ← أغسطس)</div>}
          <div className="table-wrap">
            <table className="tbl">
              <thead>
                <tr>
                  <th>البند</th>
                  <th>المخصص السنوى</th>
                  <th>المخصص الشهرى</th>
                  <th>المصروف</th>
                  <th>الفرق</th>
                  <th>النسبة</th>
                  <th>الحالة</th>
                  {canCentral && <th />}
                </tr>
              </thead>
              <tbody>
                {sections.map((g) => {
                  const gf = periodFigures(g.rows, null);
                  return (
                    <React.Fragment key={g.name}>
                      <tr className="sec">
                        <td>{g.name}</td>
                        <td className="num">{fmt(gf.alloc)}</td>
                        <td className="num">{fmt(gf.alloc / 12)}</td>
                        <td className="num">{fmt(gf.spent)}</td>
                        <td className="num">{fmt(gf.diff)}</td>
                        <td className="num">{Math.round(gf.pct * 100)}%</td>
                        <td />
                        {canCentral && <td />}
                      </tr>
                      {g.rows.map((r) => {
                        const f = periodFigures([r], null);
                        const custom = !!r.line.monthly_plan;
                        return (
                          <tr key={r.line.id} className={f.status.key === "over" ? "def" : ""}>
                            <td>
                              {r.line.name}
                              {r.line.note ? <span className="cust-sub">{r.line.note}</span> : null}
                            </td>
                            <td className="num">{fmt(f.alloc)}</td>
                            <td className="num" title={custom ? "توزيع شهرى مخصص" : "بالتساوى"}>
                              {custom ? "مخصص" : fmt(f.alloc / 12)}
                            </td>
                            <td className="num teal">{fmt(f.spent)}</td>
                            <td className={"num " + (f.diff < -0.5 ? "red" : "green")}>{fmt(f.diff)}</td>
                            <td className="num">{Math.round(f.pct * 100)}%</td>
                            <td>
                              <span className={"chip " + f.status.tone}>{f.status.label}</span>
                            </td>
                            {canCentral && (
                              <td>
                                <button className="icon-btn" title="تعديل البند" onClick={() => setModal({ type: "budgetLine", payload: r.line })}>
                                  ✎
                                </button>
                              </td>
                            )}
                          </tr>
                        );
                      })}
                    </React.Fragment>
                  );
                })}
                <tr className="tot">
                  <td>الإجمالى العام</td>
                  <td className="num">{fmt(tot.alloc)}</td>
                  <td className="num">{fmt(tot.alloc / 12)}</td>
                  <td className="num teal">{fmt(tot.spent)}</td>
                  <td className={"num " + (tot.diff < -0.5 ? "red" : "green")}>{fmt(tot.diff)}</td>
                  <td className="num">{Math.round(tot.pct * 100)}%</td>
                  <td>
                    <span className={"chip " + tot.status.tone}>{tot.status.label}</span>
                  </td>
                  {canCentral && <td />}
                </tr>
              </tbody>
            </table>
            {!model.lines.length && <div className="empty">لا توجد بنود موازنة لهذه الجهة بعد — استوردها من Excel أو أضفها يدوياً.</div>}
          </div>
        </div>
      ) : (
        <div className="empty">لا توجد جهات فى هذا التصنيف.</div>
      )}
      {isMgr && (data.deletedBudgets || []).length > 0 && (
        <div className="panel">
          <h3 className="panel-title">موازنات محذوفة (قابلة للاسترجاع)</h3>
          <div className="table-wrap">
            <table className="tbl">
              <thead>
                <tr>
                  <th>المكان</th>
                  <th>عدد البنود</th>
                  <th>الإجمالى</th>
                  <th>حُذفت بواسطة</th>
                  <th>السبب</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {data.deletedBudgets.map((d) => (
                  <tr key={d.school_id}>
                    <td>{(data.schools.find((x) => String(x.id) === String(d.school_id)) || {}).name || d.school_id}</td>
                    <td className="num">{d.lines}</td>
                    <td className="num">{fmt(d.total)}</td>
                    <td>
                      {d.deleted_by}
                      <span className="cust-sub">{String(d.deleted_at || "").slice(0, 16)}</span>
                    </td>
                    <td>{d.reason}</td>
                    <td>
                      <button className="btn ghost sm" onClick={() => act("restoreBudget", { school_id: d.school_id }).catch(() => {})}>
                        استرجاع
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      {isMgr && <TempBudgets data={data} calc={u} setModal={setModal} act={act} />}
    </div>
  );
}

export function TempBudgets({ data, calc, setModal, act }) {
  let i = data.tempBudgets || [],
    u = (o) =>
      (data.expenses || []).reduce(
        (d, c) =>
          String(c.school_id) !== String(o.school_id) ||
          !yes(c.settled) ||
          (o.dfrom && c.date < o.dfrom) ||
          (o.dto && c.date > o.dto)
            ? d
            : d + Number(c.amount || 0),
        0,
      ),
    s = (o) => {
      let d = data.schools.find((c) => String(c.id) === String(o));
      return d ? d.name : "—";
    };
  return (
    <div className="panel">
      <div className="toolbar">
        <h3
          className="panel-title"
          style={{
            margin: 0,
          }}
        >
          موازنات مؤقتة (لفترة محددة)
        </h3>
        <button
          className="btn primary sm"
          onClick={() =>
            setModal({
              type: "temp",
            })
          }
        >
          + موازنة مؤقتة
        </button>
      </div>
      {i.length === 0 ? (
        <div
          className="empty"
          style={{
            padding: 14,
          }}
        >
          لا توجد موازنات مؤقتة. أنشئ واحدة لمتابعة صرف فترة معيّنة.
        </div>
      ) : (
        <div
          className="table-wrap"
          style={{
            marginTop: 10,
          }}
        >
          <table className="tbl">
            <thead>
              <tr>
                <th>الاسم</th>
                <th>الجهة</th>
                <th>الفترة</th>
                <th>الموازنة</th>
                <th>المصروف (مُسوّى)</th>
                <th>المتبقى</th>
                <th>التنفيذ</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {i.map((o) => {
                let d = u(o),
                  c = Number(o.amount || 0),
                  p = c - d,
                  m = c ? Math.round((d / c) * 100) : 0;
                return (
                  <tr key={o.id} className={p < 0 ? "def" : ""}>
                    <td
                      style={{
                        fontWeight: 600,
                      }}
                    >
                      {o.name}
                    </td>
                    <td
                      style={{
                        fontSize: 12,
                      }}
                    >
                      {s(o.school_id)}
                    </td>
                    <td
                      style={{
                        whiteSpace: "nowrap",
                        fontSize: 12,
                        color: "var(--ink-soft)",
                      }}
                    >
                      {o.dfrom}
                      {" ← "}
                      {o.dto}
                    </td>
                    <td className="num">{fmt(c)}</td>
                    <td className="num teal">{fmt(d)}</td>
                    <td className={"num " + (p >= 0 ? "green" : "red")}>{fmt(p)}</td>
                    <td
                      style={{
                        minWidth: 90,
                      }}
                    >
                      <div className="bar">
                        <div
                          className="bar-fill"
                          style={{
                            width: Math.min(100, m) + "%",
                            background: m > 90 ? "var(--red)" : "var(--teal)",
                          }}
                        />
                      </div>
                      <span
                        style={{
                          fontSize: 11,
                          color: "var(--ink-soft)",
                        }}
                      >
                        {m}%
                      </span>
                    </td>
                    <td>
                      <button
                        className="icon-btn"
                        onClick={() =>
                          act("deleteTempBudget", {
                            id: o.id,
                          })
                        }
                      >
                        ×
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
