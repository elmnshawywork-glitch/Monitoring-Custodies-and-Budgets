// التقارير المالية للإدارة: الموازنة · العهد · المصروفات — بفلاتر بسيطة وتصدير Excel / PDF / CSV.
// الأرقام من نفس محرك الحسابات (lib/budget.js, lib/custody.js) فتتطابق مع لوحة المتابعة والجداول.
import React, { useMemo, useState } from "react";
import { fmt, exportAs, yes } from "../lib/utils";
import { CAT_LABEL, lineName, activeOnCustody, countsInBudget } from "../lib/model";
import { budgetModel, periodFigures, groupFigures, FY_MONTHS } from "../lib/budget";
import { custodyInfo, CUSTODY_STATES } from "../lib/custody";
import { Reports } from "./Reports";
import { DynamicReports } from "./DynamicReports";

export function ReportsHub(props) {
  const [view, setView] = useState("fin");
  return (
    <div className="stack">
      <div className="seg">
        <button className={view === "fin" ? "on" : ""} onClick={() => setView("fin")}>
          التقارير المالية
        </button>
        <button className={view === "dyn" ? "on" : ""} onClick={() => setView("dyn")} data-testid="seg-dyn">
          تقارير الحالة الديناميكية
        </button>
        <button className={view === "old" ? "on" : ""} onClick={() => setView("old")}>
          تقارير تفصيلية وإرسال بالبريد
        </button>
      </div>
      {view === "fin" ? <FinancialReports data={props.data} /> : view === "dyn" ? <DynamicReports data={props.data} showToast={props.showToast} /> : <Reports {...props} />}
    </div>
  );
}

export function FinancialReports({ data }) {
  const [rep, setRep] = useState("budget");
  return (
    <div className="stack">
      <div className="rep-cards">
        {[
          ["budget", "تقرير الموازنة", "المخصص · المصروف · المتبقى · النسبة — حسب المكان أو البند أو القسم أو الشهر"],
          ["custody", "تقرير العهد", "رقم العهدة · المسئول · المكان · القيمة · المصروف · المتبقى · الحالة"],
          ["expenses", "تقرير المصروفات", "التاريخ · المكان · البند · العهدة · المسئول · القيمة · الوصف"],
        ].map(([k, t, d]) => (
          <button key={k} className={"rep-card " + (rep === k ? "on" : "")} onClick={() => setRep(k)}>
            <b>{t}</b>
            <small>{d}</small>
          </button>
        ))}
      </div>
      {rep === "budget" && <BudgetReport data={data} />}
      {rep === "custody" && <CustodyReport data={data} />}
      {rep === "expenses" && <ExpenseReport data={data} />}
    </div>
  );
}

function Exporter({ onExport }) {
  const [f, setF] = useState("excel");
  return (
    <>
      <div className="spacer" />
      <select value={f} onChange={(e) => setF(e.target.value)}>
        <option value="excel">Excel</option>
        <option value="pdf">PDF</option>
        <option value="csv">CSV</option>
      </select>
      <button className="btn primary sm" onClick={() => onExport(f)}>
        تصدير
      </button>
    </>
  );
}
const Q = ({ label, children }) => (
  <div className="qf">
    <span>{label}</span>
    {children}
  </div>
);
function usePeriods(data) {
  return useMemo(() => Array.from(new Set(data.schools.map((s) => s.period).filter(Boolean))).sort().reverse(), [data]);
}

// ---------------------------------------------------------------- تقرير الموازنة
function BudgetReport({ data }) {
  const periods = usePeriods(data);
  const [period, setPeriod] = useState(periods[0] || "all");
  const [place, setPlace] = useState("all");
  const [month, setMonth] = useState("all");
  const [by, setBy] = useState("place");
  const m = month === "all" ? null : Number(month);
  const model = budgetModel(data, { period, schoolIds: place === "all" ? null : new Set([place]) });
  let rows;
  if (by === "month") {
    let cumA = 0,
      cumS = 0;
    rows = FY_MONTHS.map((mn, i) => {
      const f = periodFigures(model.lines, i + 1);
      cumA += f.alloc;
      cumS += f.spent;
      return { label: mn, ...f, extra: [fmt(cumA), fmt(cumS)] };
    });
  } else {
    const key = by === "place" ? (r) => r.entity.id : by === "section" ? (r) => (r.entity.id + "|" + (r.line.section || "عام")) : (r) => r.line.id;
    const label =
      by === "place"
        ? (r) => r.entity.name
        : by === "section"
          ? (r) => (place === "all" ? r.entity.name + " — " : "") + (r.line.section || "عام")
          : (r) => (place === "all" ? r.entity.name + " — " : "") + r.line.name;
    rows = groupFigures(model.lines, key, label, m);
  }
  const tot = periodFigures(model.lines, by === "month" ? null : m);
  const head = [
    by === "place" ? "المكان" : by === "section" ? "القسم" : by === "line" ? "البند" : "الشهر",
    by === "month" || m ? "المخصص الشهرى" : "المخصص السنوى",
    by === "month" || m ? "المصروف الشهرى" : "المصروف السنوى",
    "المتبقى (الفرق)",
    "نسبة الصرف",
    "الحالة",
  ].concat(by === "month" ? ["المخصص التراكمى", "المصروف التراكمى"] : []);
  const body = rows.map((r) => [r.label, fmt(r.alloc), fmt(r.spent), fmt(r.diff), Math.round(r.pct * 100) + "%", r.status.label].concat(r.extra || []));
  const totRow = ["الإجمالى" + (by === "month" ? " السنوى" : ""), fmt(tot.alloc), fmt(tot.spent), fmt(tot.diff), Math.round(tot.pct * 100) + "%", tot.status.label].concat(by === "month" ? ["", ""] : []);
  const title =
    "تقرير الموازنة — " +
    (place === "all" ? "كل الأماكن" : (data.schools.find((s) => String(s.id) === place) || {}).name) +
    (period !== "all" ? " — " + period : "") +
    (by !== "month" && m ? " — شهر " + FY_MONTHS[m - 1] : "");
  return (
    <div className="panel">
      <div className="filters" style={{ marginBottom: 12 }}>
        <Q label="السنة المالية">
          <select value={period} onChange={(e) => setPeriod(e.target.value)}>
            <option value="all">كل السنوات</option>
            {periods.map((p) => (
              <option key={p}>{p}</option>
            ))}
          </select>
        </Q>
        <Q label="المكان">
          <select value={place} onChange={(e) => setPlace(e.target.value)}>
            <option value="all">كل الأماكن</option>
            {data.schools.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </Q>
        <Q label="التجميع">
          <select value={by} onChange={(e) => setBy(e.target.value)}>
            <option value="place">حسب المكان</option>
            <option value="section">حسب القسم</option>
            <option value="line">حسب البند</option>
            <option value="month">حسب الشهر</option>
          </select>
        </Q>
        {by !== "month" && (
          <Q label="الفترة">
            <select value={month} onChange={(e) => setMonth(e.target.value)}>
              <option value="all">السنة كاملة</option>
              {FY_MONTHS.map((x, i) => (
                <option key={x} value={i + 1}>
                  {x}
                </option>
              ))}
            </select>
          </Q>
        )}
        <Exporter onExport={(f) => exportAs(f, title, head, body.concat([totRow]), m || by === "month" ? "الفرق الشهرى = مخصص الشهر − مصروفه · الإجمالى السنوى = المخصص السنوى − المصروف السنوى" : "الفرق السنوى = المخصص السنوى − المصروف السنوى")} />
      </div>
      <ReportTable head={head} body={body} tot={totRow} tones={rows.map((r) => r.status)} />
    </div>
  );
}

// ---------------------------------------------------------------- تقرير العهد
function CustodyReport({ data }) {
  const [place, setPlace] = useState("all");
  const [holder, setHolder] = useState("all");
  const [state, setState] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const all = data.custodies.map((c) => custodyInfo(data, c));
  const holders = Array.from(new Set(all.map((x) => x.c.holder || x.c.label))).sort();
  const rows = all.filter(
    (x) =>
      (place === "all" || String(x.c.school_id) === place) &&
      (holder === "all" || (x.c.holder || x.c.label) === holder) &&
      (state === "all" || x.state === state) &&
      (!from || String(x.c.opened_at || "").slice(0, 10) >= from) &&
      (!to || String(x.c.opened_at || "").slice(0, 10) <= to),
  );
  const head = ["رقم العهدة", "مسئول العهدة", "المكان", "نوع العهدة", "تاريخ العهدة", "القيمة", "المصروف", "المتبقى", "نسبة الاستخدام", "الحالة"];
  const body = rows.map((x) => [x.c.code || x.c.label, x.c.holder || x.c.label, x.school ? x.school.name : "", x.kind, String(x.c.opened_at || "").slice(0, 10), fmt(x.received), fmt(x.spent), fmt(x.remaining), Math.round(x.usage * 100) + "%", x.stateInfo.label]);
  const t = rows.reduce((a, x) => ({ r: a.r + x.received, s: a.s + x.spent }), { r: 0, s: 0 });
  const totRow = ["الإجمالى", rows.length + " عهدة", "", "", "", fmt(t.r), fmt(t.s), fmt(t.r - t.s), t.r ? Math.round((t.s / t.r) * 100) + "%" : "", ""];
  return (
    <div className="panel">
      <div className="filters" style={{ marginBottom: 12 }}>
        <Q label="المكان">
          <select value={place} onChange={(e) => setPlace(e.target.value)}>
            <option value="all">الكل</option>
            {data.schools.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </Q>
        <Q label="مسئول العهدة">
          <select value={holder} onChange={(e) => setHolder(e.target.value)}>
            <option value="all">الكل</option>
            {holders.map((h) => (
              <option key={h}>{h}</option>
            ))}
          </select>
        </Q>
        <Q label="الحالة">
          <select value={state} onChange={(e) => setState(e.target.value)}>
            <option value="all">الكل</option>
            {Object.keys(CUSTODY_STATES).map((k) => (
              <option key={k} value={k}>
                {CUSTODY_STATES[k].label}
              </option>
            ))}
          </select>
        </Q>
        <Q label="من تاريخ">
          <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </Q>
        <Q label="إلى تاريخ">
          <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </Q>
        <Exporter onExport={(f) => exportAs(f, "تقرير العهد", head, body.concat([totRow]))} />
      </div>
      <ReportTable head={head} body={body} tot={totRow} />
    </div>
  );
}

// ---------------------------------------------------------------- تقرير المصروفات
function ExpenseReport({ data }) {
  const [place, setPlace] = useState("all");
  const [line, setLine] = useState("all");
  const [cust, setCust] = useState("all");
  const [status, setStatus] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const custOf = (e) => data.custodies.find((c) => String(c.id) === String(e.custody_id));
  const st = (e) =>
    e.approval === "rejected" || e.fin_approval === "rejected"
      ? "مرفوض"
      : yes(e.settled)
        ? "تمت التسوية"
        : countsInBudget(e)
          ? "معتمد مالياً"
          : e.approval === "approved"
            ? "بانتظار الاعتماد المالى"
            : "بانتظار المدير المباشر";
  const rows = data.expenses
    .filter(
      (e) =>
        (place === "all" || String(e.school_id) === place) &&
        (line === "all" || String(e.line_id) === line) &&
        (cust === "all" || String(e.custody_id) === cust) &&
        (!from || String(e.date) >= from) &&
        (!to || String(e.date) <= to) &&
        (status === "all" ||
          (status === "counted" && countsInBudget(e)) ||
          (status === "pending" && activeOnCustody(e) && !countsInBudget(e)) ||
          (status === "rejected" && !activeOnCustody(e))),
    )
    .sort((a, b) => String(a.date).localeCompare(String(b.date)));
  const sname = (id) => (data.schools.find((s) => String(s.id) === String(id)) || {}).name || "";
  const head = ["التاريخ", "رقم العملية", "المكان", "البند", "العهدة", "مسئول العهدة", "القيمة", "طريقة الدفع", "الوصف", "الحالة", "الملاحظات"];
  const body = rows.map((e) => {
    const c = custOf(e);
    return [e.date, e.txn_no || "", sname(e.school_id), lineName(data, e.line_id) || "", c ? c.code || c.label : "شراء مركزى", c ? c.holder || c.label : "", fmt(e.amount), e.pay_method || "", e.description || "", st(e), e.note || ""];
  });
  const sum = rows.reduce((a, e) => a + Number(e.amount || 0), 0);
  const totRow = ["الإجمالى", rows.length + " عملية", "", "", "", "", fmt(sum), "", "", "", ""];
  const lines = data.lines.filter((l) => place === "all" || String(l.school_id) === place);
  return (
    <div className="panel">
      <div className="filters" style={{ marginBottom: 12 }}>
        <Q label="المكان">
          <select value={place} onChange={(e) => (setPlace(e.target.value), setLine("all"), setCust("all"))}>
            <option value="all">الكل</option>
            {data.schools.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </Q>
        <Q label="البند">
          <select value={line} onChange={(e) => setLine(e.target.value)}>
            <option value="all">الكل</option>
            {lines.map((l) => (
              <option key={l.id} value={l.id}>
                {l.name}
              </option>
            ))}
          </select>
        </Q>
        <Q label="العهدة">
          <select value={cust} onChange={(e) => setCust(e.target.value)}>
            <option value="all">الكل</option>
            {data.custodies
              .filter((c) => place === "all" || String(c.school_id) === place)
              .map((c) => (
                <option key={c.id} value={c.id}>
                  {(c.code ? c.code + " · " : "") + (c.holder || c.label)}
                </option>
              ))}
          </select>
        </Q>
        <Q label="الحالة">
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="all">الكل</option>
            <option value="counted">المحتسب فى الموازنة (معتمد مالياً)</option>
            <option value="pending">قيد الاعتماد</option>
            <option value="rejected">المرفوض</option>
          </select>
        </Q>
        <Q label="من تاريخ">
          <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </Q>
        <Q label="إلى تاريخ">
          <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </Q>
        <Exporter onExport={(f) => exportAs(f, "تقرير المصروفات", head, body.concat([totRow]), from || to ? "الفترة: " + (from || "البداية") + " إلى " + (to || "الآن") : "")} />
      </div>
      <ReportTable head={head} body={body} tot={totRow} />
    </div>
  );
}

function ReportTable({ head, body, tot, tones }) {
  return (
    <div className="table-wrap" style={{ maxHeight: 560, overflow: "auto" }}>
      <table className="tbl">
        <thead>
          <tr>
            {head.map((h) => (
              <th key={h}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {body.map((r, i) => (
            <tr key={i} className={tones && tones[i] && tones[i].key === "over" ? "def" : ""}>
              {r.map((c, j) => (
                <td key={j} className={j > 0 && /^-?[\d,.]+%?$/.test(String(c)) ? "num" : ""}>
                  {tones && j === 5 && tones[i] ? <span className={"chip " + tones[i].tone}>{c}</span> : c}
                </td>
              ))}
            </tr>
          ))}
          {tot && (
            <tr className="tot">
              {tot.map((c, j) => (
                <td key={j} className={j > 0 && /^-?[\d,.]+%?$/.test(String(c)) ? "num" : ""}>
                  {c}
                </td>
              ))}
            </tr>
          )}
        </tbody>
      </table>
      {!body.length && <div className="empty">لا توجد بيانات مطابقة.</div>}
    </div>
  );
}
