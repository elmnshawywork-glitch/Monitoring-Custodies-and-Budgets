import React, { useMemo, useState } from "react";
import { fmt, exportAs } from "../lib/utils";
import { CAT_LABEL, CAT_FILTER } from "../lib/model";
import { budgetModel, periodFigures, FY_MONTHS, currentFyMonth } from "../lib/budget";
import { Meter } from "../components/charts";

// متابعة الموازنة حسب الشهر والسنة
//  • شهر محدد: مخصص الشهر · مصروف الشهر · الفرق الشهرى = المخصص − المصروف · النسبة · حالة الشهر
//  • السنة كاملة: إجمالى المخصص السنوى مقابل إجمالى المصروف السنوى · الفرق السنوى
//  تجاوز شهر واحد لا يعنى تجاوز السنة طالما أن إجمالى السنة داخل المخصص (يظهر عمود «حالة السنة» منفصلاً).
export function BudgetMonthly({ data }) {
  const periods = useMemo(
    () => Array.from(new Set(data.schools.map((s) => s.period).filter(Boolean))).sort().reverse(),
    [data],
  );
  const [period, setPeriod] = useState(periods[0] || "all");
  const [month, setMonth] = useState("all");
  const [cat, setCat] = useState("all");
  const [entity, setEntity] = useState("all");
  const [q, setQ] = useState("");
  const [onlyOver, setOnlyOver] = useState(false);
  const [fmtOut, setFmtOut] = useState("excel");
  const m = month === "all" ? null : Number(month);

  const entities = data.schools.filter(
    (s) => (period === "all" || s.period === period) && (cat === "all" || (s.category || "school") === cat),
  );
  const model = useMemo(
    () => budgetModel(data, { period, category: cat, q, schoolIds: entity === "all" ? null : new Set([entity]) }),
    [data, period, cat, entity, q],
  );
  const rows = model.lines
    .map((r) => ({ r, f: periodFigures([r], m), y: periodFigures([r], null) }))
    .filter((x) => !onlyOver || x.f.status.key === "over");
  const tot = periodFigures(
    rows.map((x) => x.r),
    m,
  );
  const totY = periodFigures(
    rows.map((x) => x.r),
    null,
  );
  const mName = m ? FY_MONTHS[m - 1] : "";

  const doExport = () => {
    const head = m
      ? ["الجهة", "نوع الجهة", "القسم", "البند", "مخصص " + mName, "مصروف " + mName, "الفرق الشهرى", "نسبة الصرف", "حالة الشهر", "المخصص السنوى", "المصروف السنوى", "حالة السنة"]
      : ["الجهة", "نوع الجهة", "القسم", "البند", "المخصص السنوى", "المصروف السنوى", "الفرق السنوى", "نسبة الصرف", "الحالة"];
    const body = rows.map(({ r, f, y }) =>
      [r.entity.name, CAT_LABEL[r.entity.category || "school"], r.line.section || "", r.line.name, fmt(f.alloc), fmt(f.spent), fmt(f.diff), Math.round(f.pct * 100) + "%", f.status.label].concat(
        m ? [fmt(y.alloc), fmt(y.spent), y.status.label] : [],
      ),
    );
    body.push(
      ["الإجمالى", "", "", rows.length + " بند", fmt(tot.alloc), fmt(tot.spent), fmt(tot.diff), Math.round(tot.pct * 100) + "%", tot.status.label].concat(
        m ? [fmt(totY.alloc), fmt(totY.spent), totY.status.label] : [],
      ),
    );
    exportAs(
      fmtOut,
      "متابعة الموازنة — " + (m ? "شهر " + mName : "السنة كاملة") + (period !== "all" ? " " + period : ""),
      head,
      body,
      m ? "الفرق الشهرى = مخصص الشهر − مصروف الشهر" : "الفرق السنوى = إجمالى المخصص السنوى − إجمالى المصروف السنوى",
    );
  };

  return (
    <div className="stack">
      <div className="panel" style={{ padding: 12 }}>
        <div className="filters">
          <Filter label="السنة المالية">
            <select value={period} onChange={(e) => (setPeriod(e.target.value), setEntity("all"))}>
              <option value="all">كل السنوات</option>
              {periods.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </Filter>
          <Filter label="الفترة">
            <select value={month} onChange={(e) => setMonth(e.target.value)}>
              <option value="all">كل الشهور (السنة كاملة)</option>
              {FY_MONTHS.map((mm, i) => (
                <option key={i} value={i + 1}>
                  {mm}
                  {i + 1 === currentFyMonth() ? " (الحالى)" : ""}
                </option>
              ))}
            </select>
          </Filter>
          <Filter label="نوع الجهة">
            <select value={cat} onChange={(e) => (setCat(e.target.value), setEntity("all"))}>
              {CAT_FILTER.map(([v, t]) => (
                <option key={v} value={v}>
                  {t}
                </option>
              ))}
            </select>
          </Filter>
          <Filter label="المدرسة / الجهة / المشروع">
            <select value={entity} onChange={(e) => setEntity(e.target.value)}>
              <option value="all">الكل</option>
              {entities.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </Filter>
          <Filter label="البند">
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث باسم البند" />
          </Filter>
          <label className="check">
            <input type="checkbox" checked={onlyOver} onChange={(e) => setOnlyOver(e.target.checked)} />{" "}
            {m ? "تجاوز الشهر فقط" : "تجاوز السنة فقط"}
          </label>
          <div className="spacer" />
          <select value={fmtOut} onChange={(e) => setFmtOut(e.target.value)}>
            <option value="excel">Excel</option>
            <option value="pdf">PDF</option>
            <option value="csv">CSV</option>
          </select>
          <button className="btn ghost sm" onClick={doExport}>
            تصدير
          </button>
        </div>
      </div>

      <div className="kpi-row">
        <Mini label={m ? "مخصص " + mName : "إجمالى المخصص السنوى"} v={tot.alloc} tone="navy" />
        <Mini label={m ? "مصروف " + mName : "إجمالى المصروف السنوى"} v={tot.spent} tone="teal" />
        <Mini
          label={m ? (tot.diff < -0.5 ? "تجاوز الشهر" : "المتبقى من مخصص الشهر") : tot.diff < -0.5 ? "التجاوز السنوى" : "المتبقى السنوى"}
          v={Math.abs(tot.diff)}
          tone={tot.diff < -0.5 ? "red" : "green"}
        />
        <div className="kpi navy">
          <div className="kpi-label">نسبة الصرف · {tot.status.label}</div>
          <div className="kpi-value">{Math.round(tot.pct * 100)}%</div>
          <Meter pct={tot.pct} />
        </div>
      </div>
      {m && (
        <div className="hint" style={{ margin: 0 }}>
          على مستوى السنة كاملة: المخصص {fmt(totY.alloc)} · المصروف {fmt(totY.spent)} · الفرق السنوى{" "}
          <b className={totY.diff < -0.5 ? "red" : "green"}>{fmt(totY.diff)}</b> ({totY.status.label})
        </div>
      )}

      <div className="table-wrap">
        <table className="tbl">
          <thead>
            <tr>
              <th>الجهة</th>
              <th>البند</th>
              <th>{m ? "مخصص " + mName : "المخصص السنوى"}</th>
              <th>{m ? "مصروف " + mName : "المصروف السنوى"}</th>
              <th>{m ? "الفرق الشهرى" : "الفرق السنوى"}</th>
              <th>نسبة الصرف</th>
              <th>{m ? "حالة الشهر" : "حالة البند"}</th>
              {m && <th>السنة (مصروف / مخصص)</th>}
            </tr>
          </thead>
          <tbody>
            {rows.map(({ r, f, y }) => (
              <tr key={r.line.id} className={f.status.key === "over" ? "def" : ""}>
                <td style={{ fontSize: 12.5 }}>{r.entity.name}</td>
                <td style={{ fontWeight: 600 }}>
                  {r.line.name}
                  {r.line.section ? <span className="cust-sub">{r.line.section}</span> : null}
                </td>
                <td className="num">{fmt(f.alloc)}</td>
                <td className="num teal">{fmt(f.spent)}</td>
                <td className={"num " + (f.diff < -0.5 ? "red" : "green")}>{fmt(f.diff)}</td>
                <td>
                  <div className="pct">
                    <Meter pct={f.pct} />
                    <span>{Math.round(f.pct * 100)}%</span>
                  </div>
                </td>
                <td>
                  <span className={"chip " + f.status.tone}>{f.status.label}</span>
                </td>
                {m && (
                  <td className="num" style={{ fontSize: 12.5 }}>
                    {fmt(y.spent)} / {fmt(y.alloc)} <span className={"chip " + y.status.tone}>{y.status.label}</span>
                  </td>
                )}
              </tr>
            ))}
            {rows.length > 0 && (
              <tr className="tot">
                <td colSpan={2}>الإجمالى ({rows.length} بند)</td>
                <td className="num">{fmt(tot.alloc)}</td>
                <td className="num">{fmt(tot.spent)}</td>
                <td className={"num " + (tot.diff < -0.5 ? "red" : "")}>{fmt(tot.diff)}</td>
                <td>{Math.round(tot.pct * 100)}%</td>
                <td>
                  <span className={"chip " + tot.status.tone}>{tot.status.label}</span>
                </td>
                {m && (
                  <td className="num">
                    {fmt(totY.spent)} / {fmt(totY.alloc)}
                  </td>
                )}
              </tr>
            )}
          </tbody>
        </table>
        {rows.length === 0 && <div className="empty">لا توجد بنود مطابقة للفلاتر.</div>}
      </div>
    </div>
  );
}

function Filter({ label, children }) {
  return (
    <div className="qf">
      <span>{label}</span>
      {children}
    </div>
  );
}

function Mini({ label, v, tone }) {
  return (
    <div className={"kpi " + tone}>
      <div className="kpi-label">{label}</div>
      <div className="kpi-value">
        {fmt(v)} <span className="kpi-unit">ج.م</span>
      </div>
    </div>
  );
}
