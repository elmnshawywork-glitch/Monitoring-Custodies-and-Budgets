import React, { useEffect, useRef, useState } from "react";
import { REMOTE, EDGE, SUPA, applyLocal, call, edgeCall, notify, setCurrentSession } from "./lib/api";
import { ROLE_LABEL, applyEntityTypes } from "./lib/model";
import { Logo, Toast } from "./components/ui";
import { PettyBar } from "./screens/Dashboard";
import { RoleDashboard } from "./screens/RoleDashboard";
import { Budgets } from "./screens/Budgets";
import { BudgetMonthly } from "./screens/BudgetMonthly";
import { Custodies } from "./screens/Custodies";
import { Approvals } from "./screens/Expenses";
import { Requests } from "./screens/Requests";
import { Salaries } from "./screens/Salaries";
import { Analytics } from "./screens/Analytics";
import { ReportsHub } from "./screens/FinancialReports";
import { Admin } from "./screens/Admin";
import { AuditTrail } from "./screens/AuditTrail";
import { CustodyTracker } from "./screens/CustodyTracker";
import { setExportHook } from "./lib/utils";
import { can } from "./lib/perms";
import { PayrollHub } from "./screens/Payroll";
import { Modals } from "./modals/Modals";

const SESSION_KEY = "ebda_session";

function loadSession() {
  try {
    return JSON.parse(localStorage.getItem(SESSION_KEY));
  } catch (e) {
    return null;
  }
}

// أى إجراء يُرسل إشعار بريد بعد نجاحه (عند تفعيل Edge Functions)
function notifyEventFor(action, payload, res) {
  const patch = (payload && payload.patch) || {};
  switch (action) {
    case "addExpense":
      return ["expense_new", res && res.item && res.item.id];
    case "updateExpense":
      return patch.approval ? ["expense_decided", payload.id] : null;
    case "reviewExpense":
      if (patch.fin_approval) return ["expense_fin", payload.id];
      if (patch.settled !== undefined || patch.review_status) return ["expense_review", payload.id];
      return null;
    case "addRequest":
      return ["request_new", res && res.id];
    case "decideRequest":
      return ["request_decided", payload.id];
    case "transferRequest":
      return ["request_transferred", payload.id];
    case "updateCustody":
      return patch.status === "pending_settlement" ? ["custody_submitted", payload.id] : null;
    default:
      return null;
  }
}

export function App() {
  const [session, setSession] = useState(loadSession);
  const [data, setData] = useState(null);
  const [tab, setTab] = useState("dashboard");
  const [tabOpts, setTabOpts] = useState({});
  const [toast, setToast] = useState(null);
  const [modal, setModal] = useState(null);
  const [loading, setLoading] = useState(false);
  // أحدث نسخة من البيانات: إجراءان متتاليان من نفس النموذج (مثل حفظ مصروف ثم رفع مرفقه) لا يعملان على نسخة قديمة
  const dataRef = useRef(null);
  dataRef.current = data;

  setCurrentSession(session);
  // كل تصدير لتقرير يُسجَّل فى «تتبع التعديلات» (بدون إزعاج المستخدم إن فشل التسجيل)
  setExportHook((info) => session && call("logExport", info, session).catch(() => {}));

  // تحذير الخادم (مثل تجاوز البند) لا تمحوه رسالة النجاح التالية؛ تُضاف إليه
  const lastWarn = useRef({ msg: "", until: 0 });
  const showToast = (msg, kind = "ok", ms) => {
    if (kind === "warn") lastWarn.current = { msg, until: Date.now() + 6500 };
    else if (kind === "ok" && Date.now() < lastWarn.current.until) {
      msg = msg + " — " + lastWarn.current.msg;
      kind = "warn";
    }
    setToast({ msg, kind });
    setTimeout(() => setToast(null), ms || (kind === "warn" ? 6500 : 2800));
  };
  const isSessionError = (e) => String((e && e.message) || "").indexOf("الجلسة") >= 0;

  const reload = async (s) => {
    setLoading(true);
    try {
      const d = await call("bootstrap", {}, s);
      applyEntityTypes(d && d.entity_types);
      setData(d);
    } catch (e) {
      showToast(e.message, "err");
      if (isSessionError(e)) logout();
    }
    setLoading(false);
  };

  useEffect(() => {
    if (session) reload(session);
  }, []);

  const login = async (username, pin) => {
    setLoading(true);
    try {
      const res = await call("login", { username, pin, ua: navigator.userAgent });
      if (res.error) {
        showToast(res.error, "err");
        setLoading(false);
        return;
      }
      // الخادم الحديث يُرجع توكن جلسة فلا نحفظ كلمة السر؛ والقديم/التجريبى يحتاج PIN مع كل طلب
      const s = res.token ? { username, token: res.token, user: res.user } : { username, pin, user: res.user };
      localStorage.setItem(SESSION_KEY, JSON.stringify(s));
      setSession(s);
      setCurrentSession(s);
      await reload(s);
    } catch (e) {
      showToast(e.message, "err");
    }
    setLoading(false);
  };

  const logout = () => {
    if (session && session.token) call("logout", {}, session).catch(() => {});
    localStorage.removeItem(SESSION_KEY);
    setSession(null);
    setData(null);
    setTab("dashboard");
  };

  // تنفيذ إجراء: يُحدّث العرض محلياً أو يعيد التحميل، ويُظهر تحذيرات الخادم، ويرسل الإشعارات
  const act = async (action, payload) => {
    try {
      let res;
      const hasFile = payload && payload.dataBase64 && !payload.link;
      if (EDGE && session && session.token && action === "uploadDoc" && hasFile) {
        // المستند يُرفع إلى Supabase Storage عبر Edge Function بدلاً من تخزينه داخل الجدول
        res = await edgeCall("docs", {
          token: session.token,
          action: "upload",
          expense_id: payload.id,
          filename: payload.filename,
          mime:
            payload.mimeType ||
            String(payload.dataUrl || "")
              .slice(5)
              .split(";")[0],
          dataBase64: payload.dataBase64,
          doc_type: payload.doc_type || "",
        });
        await reload(session);
        return res;
      }
      if (EDGE && session && session.token && action === "addCentral" && hasFile) {
        const { dataUrl, dataBase64, mimeType, filename, ...rest } = payload;
        res = await call("addCentral", rest, session);
        if (res && res.item) {
          await edgeCall("docs", {
            token: session.token,
            action: "upload",
            expense_id: res.item.id,
            filename: filename || "مستند",
            mime:
              mimeType ||
              String(dataUrl || "")
                .slice(5)
                .split(";")[0],
            dataBase64,
            doc_type: payload.doc_type || "",
          });
        }
        await reload(session);
      } else {
        res = await call(action, payload, session);
        const next = applyLocal(dataRef.current, action, payload, res);
        if (next) {
          dataRef.current = next;
          setData(next);
        }
        else await reload(session);
      }
      if (res && res.warning) showToast(res.warning, "warn");
      const ev = notifyEventFor(action, payload, res);
      if (ev && ev[1]) notify(session, ev[0], ev[1]);
      return res;
    } catch (e) {
      showToast(e.message, "err");
      if (isSessionError(e)) logout();
      throw e;
    }
  };
  const probe = (action, payload) => call(action, payload, session);
  const go = (t, opts) => {
    setTabOpts(opts || {});
    setTab(t);
  };

  if (!session)
    return (
      <>
        <Login onLogin={login} loading={loading} />
        <Toast toast={toast} />
      </>
    );
  if (!data)
    return (
      <div className="loading">
        <div className="spinner" />
        <p>جارٍ تحميل البيانات…</p>
      </div>
    );
  if (String(data.me.must_reset) === "نعم")
    return (
      <>
        <ForceResetPassword act={act} showToast={showToast} />
        <Toast toast={toast} />
      </>
    );

  // الأدوار (القيم المخزنة القديمة): manager=الأدمن، accountant=المدير المالى، supervisor=المدير المباشر، custody=مسئول العهدة
  const role = data.me.role;
  const isAdmin = role === "manager";
  const isFinance = role === "accountant";
  const isDirect = role === "supervisor";
  const isCustody = role === "custody";
  const canManageUsers = isAdmin || (isFinance && String(data.me.perms || "").indexOf("manage_users") >= 0);
  const seesBudgets = isAdmin || isFinance;
  // الصفحات حسب الصلاحيات (الدور + ما مُنح للمستخدم) — والخادم يطبّقها على البيانات والعمليات
  const P = (p) => can(data, p);
  const roleLabel = data.me.role_label || ROLE_LABEL[role] || role;

  const tabs = [["dashboard", "لوحة المتابعة"]];
  if (seesBudgets || isDirect) tabs.push(["monthly", "متابعة الموازنة"]);
  if (seesBudgets || P("budget.edit")) tabs.push(["budgets", "الموازنات"]);
  tabs.push(["custodies", "العهد"], ["tracker", "متابعة العهد"], ["approvals", "المصروفات"], ["requests", "طلبات العهد"]);
  if (seesBudgets || P("payroll.view")) tabs.push(["salaries", "الرواتب"]);
  if (seesBudgets) tabs.push(["analytics", "التحليلات"], ["reports", "التقارير"]);
  if (isAdmin) tabs.push(["audit", "تتبع التعديلات"]);
  if (canManageUsers) tabs.push(["admin", "الإدارة"]);

  return (
    <div>
      <div className="topbar">
        <div className="brand">
          <Logo />
          <div>
            <div className="brand-title">ابدأ إديو</div>
            <div className="brand-sub">متابعة الموازنات والعهد</div>
          </div>
        </div>
        <div className="user-box">
          {!REMOTE && (
            <span className="chip amber" title="البيانات على المتصفح فقط">
              وضع تجريبى · غير متصل
            </span>
          )}
          {REMOTE && <span className="chip green">{SUPA ? "متصل" : "متصل بجوجل شيت"}</span>}
          <span className="user-chip">
            {data.me.name}
            {String(data.me.name).trim() !== roleLabel && (
              <span className={"role-tag " + (isAdmin ? "" : "acc")}>{roleLabel}</span>
            )}
          </span>
          <button className="btn ghost sm" onClick={logout}>
            خروج
          </button>
        </div>
      </div>
      <div className="tabs">
        {tabs.map(([key, label]) => (
          <button key={key} className={"tab " + (tab === key ? "active" : "")} onClick={() => go(key)}>
            {label}
          </button>
        ))}
      </div>
      {(isCustody || isDirect) && <PettyBar data={data} />}
      <div className="content">
        {tab === "dashboard" && <RoleDashboard data={data} onGo={go} />}
        {tab === "monthly" && (seesBudgets || isDirect) && <BudgetMonthly data={data} />}
        {tab === "budgets" && (seesBudgets || P("budget.edit")) && (
          <Budgets data={data} canCentral={P("budget.edit")} isMgr={isAdmin} setModal={setModal} act={act} />
        )}
        {tab === "custodies" && (
          <Custodies
            data={data}
            isMgr={isAdmin}
            canRecord={P("expense.record")}
            canManageCustody={P("custody.create")}
            act={act}
            showToast={showToast}
            setModal={setModal}
          />
        )}
        {tab === "tracker" && (
          <CustodyTracker data={data} setModal={setModal} act={act} showToast={showToast} />
        )}
        {tab === "approvals" && (
          <Approvals
            data={data}
            isMgr={isAdmin}
            canApprove={P("expense.approve")}
            canReview={P("expense.fin_approve")}
            act={act}
            setModal={setModal}
            showToast={showToast}
            initialStatus={tabOpts.status}
          />
        )}
        {tab === "salaries" && (seesBudgets || P("payroll.view")) && (
          <PayrollHub data={data} canEdit={isAdmin} act={act} showToast={showToast} setModal={setModal} />
        )}
        {tab === "requests" && <Requests data={data} role={role} act={act} showToast={showToast} setModal={setModal} />}
        {tab === "analytics" && seesBudgets && <Analytics data={data} />}
        {tab === "reports" && seesBudgets && <ReportsHub data={data} act={act} showToast={showToast} />}
        {tab === "audit" && isAdmin && <AuditTrail data={data} />}
        {tab === "admin" && canManageUsers && (
          <Admin data={data} act={act} probe={probe} showToast={showToast} setModal={setModal} />
        )}
      </div>
      {modal && <Modals modal={modal} data={data} act={act} close={() => setModal(null)} showToast={showToast} />}
      <Toast toast={toast} />
    </div>
  );
}

export function ForceResetPassword({ act, showToast }) {
  const [pin, setPin] = useState("");
  const [confirm, setConfirm] = useState("");
  const [saving, setSaving] = useState(false);
  const save = async () => {
    if (String(pin).length < 4) return showToast("كلمة السر 4 خانات على الأقل", "err");
    if (pin !== confirm) return showToast("التأكيد غير مطابق", "err");
    setSaving(true);
    try {
      await act("setPassword", { pin });
      showToast("تم تعيين كلمة السر");
    } catch (e) {}
    setSaving(false);
  };
  return (
    <div className="login-wrap">
      <div className="login-card">
        <Logo big />
        <h1>تعيين كلمة سر جديدة</h1>
        <p>لأول مرة أو بعد التصفير — اختر كلمة سر (PIN) جديدة وأكّدها</p>
        <label className="field">
          <span>كلمة السر الجديدة</span>
          <input type="password" value={pin} onChange={(e) => setPin(e.target.value)} />
        </label>
        <label className="field">
          <span>تأكيد كلمة السر</span>
          <input
            type="password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && save()}
          />
        </label>
        <button className="btn primary" style={{ width: "100%" }} disabled={saving} onClick={save}>
          {saving ? "جارٍ الحفظ…" : "حفظ ودخول"}
        </button>
      </div>
    </div>
  );
}

export function Login({ onLogin, loading }) {
  const [username, setUsername] = useState("");
  const [pin, setPin] = useState("");
  const [showPin, setShowPin] = useState(false); // العرض محلى فقط — لا تخزين لكلمة السر
  const submit = () => username && pin && onLogin(username.trim(), pin.trim());
  return (
    <div className="login-wrap">
      <div className="login-card">
        <Logo big />
        <h1 className="company-name">إبدأ إديو للتطوير والتدريب</h1>
        <p>نظام إدارة الموازنات والعهد والرواتب</p>
        <label className="field">
          <span>اسم المستخدم</span>
          <input
            value={username}
            autoComplete="username"
            onChange={(e) => setUsername(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()}
          />
        </label>
        <label className="field">
          <span>كلمة السر (PIN)</span>
          <div className="pw-wrap">
            <input
              type={showPin ? "text" : "password"}
              value={pin}
              autoComplete="current-password"
              onChange={(e) => setPin(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && submit()}
            />
            <button
              type="button"
              className="pw-eye"
              aria-label={showPin ? "إخفاء كلمة السر" : "إظهار كلمة السر"}
              title={showPin ? "إخفاء كلمة السر" : "إظهار كلمة السر"}
              onClick={(e) => (e.preventDefault(), setShowPin(!showPin))}
            >
              {showPin ? <EyeOff /> : <Eye />}
            </button>
          </div>
        </label>
        <button className="btn primary" style={{ width: "100%" }} disabled={loading} onClick={submit}>
          {loading ? "جارٍ الدخول…" : "دخول"}
        </button>
        {!REMOTE && (
          <div className="demo-note">
            وضع تجريبى — جرّب: <b>admin / 1234</b> (الأدمن) · <b>acc1 / 2222</b> (المدير المالى) · <b>sup1 / 3333</b>{" "}
            (المدير المباشر) · <b>custody1 / 1111</b> (مسئول العهدة)
          </div>
        )}
      </div>
    </div>
  );
}

function Eye() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}
function EyeOff() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M17.94 17.94A10.07 10.07 0 0 1 12 19c-7 0-11-7-11-7a18.45 18.45 0 0 1 5.06-5.94" />
      <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 7 11 7a18.5 18.5 0 0 1-2.16 3.19" />
      <path d="M14.12 14.12a3 3 0 1 1-4.24-4.24" />
      <line x1="1" y1="1" x2="23" y2="23" />
    </svg>
  );
}
