// نماذج إدخال مبسّطة: «إضافة عهدة» و«إضافة مصروف» — البيانات الأساسية فقط، والحسابات والتصفية تلقائية.
// السلسلة: الموازنة ← البند ← العهدة ← المصروف ← المتبقى
import React, { useEffect, useMemo, useState } from "react";
import { Modal, Field } from "../components/ui";
import { fmt, today, yes } from "../lib/utils";
import { CAT_LABEL, DOC_TYPES, countsInBudget } from "../lib/model";
import { probe } from "../lib/api";
import { custodyInfo, custodyLines, lineStateInCustody } from "../lib/custody";
import { normAr } from "../lib/budget";
import { can } from "../lib/perms";

export const CUSTODY_KINDS = ["عهدة تشغيلية", "عهدة نثرية مستديمة", "عهدة لغرض محدد", "عهدة نشاط / تدريب", "أخرى"];
// أنواع العهد من Master Data (المفعّلة فقط للإدخال الجديد)، والقائمة الثابتة للوضع التجريبى/الخادم القديم
export const kindsOf = (data) =>
  data.custody_kinds && data.custody_kinds.length ? data.custody_kinds.filter((k) => yes(k.active)).map((k) => k.name) : CUSTODY_KINDS;
// الجهة/البند المعطّل لا يقبل إدخالات جديدة (ويبقى فى التقارير)
export const isActive = (x) => !x || x.active == null || x.active === "" || yes(x.active);
export const PAY_METHODS = ["نقدى", "تحويل بنكى", "شيك", "بطاقة / محفظة إلكترونية", "أخرى"];

const placeLabel = (s) => CAT_LABEL[s.category || "school"] + " · " + s.name;
const sectionsOf = (nameRow) =>
  String((nameRow && nameRow.sections) || "")
    .split(/[،,]/)
    .map((x) => normAr(x))
    .filter(Boolean);

// البنود المرتبطة بالاختيار: المكان + (أقسام اسم العهدة إن وُجدت)
export function smartLines(data, schoolId, titleName, showAll) {
  const lines = (data.lines || []).filter((l) => String(l.school_id) === String(schoolId) && isActive(l));
  const nm = (data.custody_names || []).find((n) => n.name === titleName);
  const secs = sectionsOf(nm);
  if (showAll || !secs.length) return { lines, filtered: false };
  const f = lines.filter((l) => secs.some((s) => normAr(l.section).indexOf(s) >= 0 || s.indexOf(normAr(l.section)) >= 0));
  return f.length ? { lines: f, filtered: true } : { lines, filtered: false };
}

// ============================================================================ إضافة / تعديل عهدة
export function CustodyForm({ data, initial, onSave, close }) {
  const editing = !!(initial && initial.id);
  const isAdmin = data.me.role === "manager";
  const locked = editing && (initial.approval || "approved") === "approved" && !isAdmin; // بعد الاعتماد: البيانات الأساسية للأدمن فقط
  const names = (data.custody_names || []).filter((n) => yes(n.active) || (initial && initial.title === n.name));
  const users = (data.users || []).filter((u) => u.role !== "manager");
  const emps = (data.employees || []).filter((e) => !yes(e.archived));
  const places = data.schools.filter((s) => isActive(s) || (initial && String(initial.school_id) === String(s.id)));
  const [school, setSchool] = useState(String((initial && initial.school_id) || (places[0] || {}).id || ""));
  const [title, setTitle] = useState((initial && initial.title) || (names[0] || {}).name || "");
  const kinds = kindsOf(data);
  const [kind, setKind] = useState((initial && initial.kind) || kinds[0]);
  const [holderSel, setHolderSel] = useState(
    initial ? (initial.user ? "u:" + initial.user : initial.holder_emp_id ? "e:" + initial.holder_emp_id : "") : "",
  );
  const [holder, setHolder] = useState((initial && initial.holder) || "");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(today());
  const [purpose, setPurpose] = useState((initial && initial.purpose) || "");
  const [note, setNote] = useState((initial && initial.note) || "");
  const [showAll, setShowAll] = useState(false);
  const existingAlloc = editing ? (data.custody_lines || []).filter((x) => String(x.custody_id) === String(initial.id)) : [];
  const [alloc, setAlloc] = useState(() => {
    const o = {};
    existingAlloc.forEach((x) => (o[x.line_id] = String(x.amount)));
    return o;
  });
  const [err, setErr] = useState("");
  const smart = smartLines(data, school, title, showAll);
  const allocSum = Object.values(alloc).reduce((a, x) => a + (Number(x) || 0), 0);
  const amt = Number(String(amount).replace(/,/g, "") || 0);

  const pickHolder = (v) => {
    setHolderSel(v);
    if (v.startsWith("u:")) {
      const u = users.find((x) => "u:" + x.username === v);
      if (u) setHolder(u.name);
    } else if (v.startsWith("e:")) {
      const e = emps.find((x) => "e:" + x.id === v);
      if (e) setHolder(e.name);
    }
  };
  const save = (approval) => {
    setErr("");
    if (!school) return setErr("اختر المكان");
    if (!title) return setErr("اختر اسم العهدة");
    if (!holder.trim()) return setErr("اختر مسئول العهدة من القائمة");
    if (!editing && !(amt >= 0)) return setErr("قيمة العهدة غير صحيحة");
    if (!editing && approval === "approved" && !(amt > 0)) return setErr("لا يمكن اعتماد عهدة بدون قيمة");
    const lines = Object.entries(alloc)
      .filter(([, v]) => Number(v) > 0)
      .map(([line_id, v]) => ({ line_id, amount: Number(v) }));
    const obj = {
      school_id: school,
      title,
      kind,
      user: holderSel.startsWith("u:") ? holderSel.slice(2) : "",
      holder_emp_id: holderSel.startsWith("e:") ? holderSel.slice(2) : "",
      holder: holder.trim(),
      label: title + " — " + holder.trim(),
      purpose: purpose.trim(),
      note: note.trim(),
    };
    if (editing) {
      const patch = locked ? { purpose: obj.purpose, note: obj.note } : obj;
      onSave(Object.assign({ id: initial.id, _lines: locked ? null : lines }, patch), false);
    } else onSave(Object.assign(obj, { amount: amt, date, approval, lines }), true);
  };

  return (
    <Modal title={editing ? "تعديل العهدة" : "إضافة عهدة"} close={close} wide>
      {locked && <div className="warn-banner">العهدة معتمدة — تعديل البيانات الأساسية للأدمن فقط. يمكنك تعديل الغرض والملاحظات.</div>}
      <div className="grid2">
        <Field label="المكان / المدرسة">
          <select value={school} disabled={locked} onChange={(e) => (setSchool(e.target.value), setAlloc({}))}>
            {places.map((s) => (
              <option key={s.id} value={s.id}>
                {placeLabel(s)}
              </option>
            ))}
          </select>
        </Field>
        <Field label="اسم العهدة">
          <select value={title} disabled={locked} onChange={(e) => setTitle(e.target.value)}>
            {!names.length && <option value="">— أضف أسماء العهد من الإدارة —</option>}
            {names.map((n) => (
              <option key={n.id} value={n.name}>
                {n.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="نوع العهدة">
          <select value={kind} disabled={locked} onChange={(e) => setKind(e.target.value)}>
            {kinds.concat(kinds.indexOf(kind) < 0 ? [kind] : []).map((k) => (
              <option key={k}>{k}</option>
            ))}
          </select>
        </Field>
        <Field label="مسئول العهدة">
          <select value={holderSel} disabled={locked} onChange={(e) => pickHolder(e.target.value)}>
            <option value="">— اختر من المستخدمين أو العاملين —</option>
            {users.length > 0 && (
              <optgroup label="مستخدمو النظام (يرى عهدته ويسجّل مصروفاتها)">
                {users.map((u) => (
                  <option key={u.id} value={"u:" + u.username}>
                    {u.name}
                  </option>
                ))}
              </optgroup>
            )}
            {emps.length > 0 && (
              <optgroup label="العاملون">
                {emps.map((e) => (
                  <option key={e.id} value={"e:" + e.id}>
                    {e.name}
                    {e.job ? " — " + e.job : ""}
                  </option>
                ))}
              </optgroup>
            )}
          </select>
        </Field>
        {!editing && (
          <>
            <Field label="قيمة العهدة (ج.م)">
              <input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0" />
            </Field>
            <Field label="التاريخ">
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </Field>
          </>
        )}
      </div>
      <Field label="الغرض">
        <input value={purpose} onChange={(e) => setPurpose(e.target.value)} placeholder="مثال: مصروفات تشغيل الفصل الدراسى الأول" />
      </Field>
      {!locked && (
        <div className="alloc-box">
          <div className="alloc-head">
            <b>توزيع العهدة على البنود (اختيارى)</b>
            <span>
              {smart.filtered ? "البنود المرتبطة باسم العهدة فقط · " : ""}
              <label className="check" style={{ display: "inline-flex", padding: 0 }}>
                <input type="checkbox" checked={showAll} onChange={(e) => setShowAll(e.target.checked)} /> كل بنود المكان
              </label>
            </span>
          </div>
          <div className="alloc-list">
            {smart.lines.map((l) => (
              <label key={l.id} className={"alloc-row " + (Number(alloc[l.id]) > 0 ? "on" : "")}>
                <span>
                  {l.name}
                  <small>{l.section}</small>
                </span>
                <input
                  inputMode="decimal"
                  placeholder="0"
                  value={alloc[l.id] || ""}
                  onChange={(e) => setAlloc(Object.assign({}, alloc, { [l.id]: e.target.value }))}
                />
              </label>
            ))}
            {!smart.lines.length && <div className="muted">لا توجد بنود موازنة لهذا المكان.</div>}
          </div>
          <div className={"alloc-sum " + (!editing && amt > 0 && allocSum > amt + 0.005 ? "red" : "")}>
            مجموع التوزيع: {fmt(allocSum)}
            {!editing && amt > 0 ? " من " + fmt(amt) + (allocSum > amt + 0.005 ? " — أكبر من قيمة العهدة" : "") : ""}
            <span className="muted"> · عند التوزيع لا يُسمح بالصرف إلا على هذه البنود</span>
          </div>
        </div>
      )}
      <Field label="ملاحظات">
        <input value={note} onChange={(e) => setNote(e.target.value)} />
      </Field>
      {err && <div className="warn-banner over">{err}</div>}
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <span className="spacer" />
        {editing ? (
          <button className="btn primary" onClick={() => save()}>
            حفظ التعديل
          </button>
        ) : (
          <>
            <button className="btn ghost" onClick={() => save("draft")}>
              حفظ كمسودة
            </button>
            {can(data, "custody.approve") && (
              <button className="btn primary" onClick={() => save("approved")}>
                حفظ واعتماد
              </button>
            )}
          </>
        )}
      </div>
    </Modal>
  );
}

// ============================================================================ إضافة مصروف
export function ExpenseForm({ data, initial, act, showToast, close }) {
  const me = data.me;
  const isCustody = me.role === "custody";
  const usable = (c) => (c.status || "open") === "open" && (c.approval || "approved") === "approved";
  const mine = data.custodies.filter((c) => !isCustody || String(c.user || "") === String(me.username));
  const openCusts = mine.filter(usable);
  const waiting = mine.filter((c) => (c.status || "open") === "open" && !usable(c));
  const firstCust = (initial && initial.custody_id) || (openCusts[0] || {}).id || "";
  const [custody, setCustody] = useState(String(firstCust));
  const cust = data.custodies.find((c) => String(c.id) === String(custody));
  const [school, setSchool] = useState(String((cust && cust.school_id) || ""));
  const [line, setLine] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(today());
  const [pay, setPay] = useState(PAY_METHODS[0]);
  const [item, setItem] = useState("");
  const [desc, setDesc] = useState("");
  const [note, setNote] = useState("");
  const [file, setFile] = useState(null);
  const [docLink, setDocLink] = useState("");
  const [docType, setDocType] = useState(DOC_TYPES[0]);
  const [warn, setWarn] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const places = data.schools.filter((s) => openCusts.some((c) => String(c.school_id) === String(s.id)));
  const custsHere = openCusts.filter((c) => !school || String(c.school_id) === school);
  const info = cust ? custodyInfo(data, cust) : null;
  const cLines = cust ? custodyLines(data, cust) : [];
  const allocated = cLines.filter((x) => x.alloc > 0);
  // البنود المتاحة: بنود العهدة الموزعة إن وُجدت، وإلا بنود المكان (مصفّاة حسب اسم العهدة)
  const options = useMemo(() => {
    if (!cust) return [];
    if (allocated.length) return allocated.map((x) => x.line).filter(isActive);
    return smartLines(data, cust.school_id, cust.title, false).lines;
  }, [custody, data]);
  const amt = Number(String(amount).replace(/,/g, "") || 0);
  const cl = cLines.find((x) => String(x.line.id) === String(line));
  const budgetLine = (data.lines || []).find((l) => String(l.id) === String(line));
  const seesAmounts = budgetLine && budgetLine.allocated != null;
  const budgetSpent = !seesAmounts
    ? 0
    : data.line_months
      ? (data.line_months[line] || []).reduce((a, x) => a + Number(x || 0), 0)
      : data.expenses.filter((e) => String(e.line_id) === String(line) && countsInBudget(e)).reduce((a, e) => a + Number(e.amount || 0), 0);
  const prev = data.expenses
    .filter((e) => String(e.custody_id) === String(custody) && String(e.line_id) === String(line))
    .sort((a, b) => String(b.date).localeCompare(String(a.date)))
    .slice(0, 4);

  useEffect(() => {
    if (cust && String(cust.school_id) !== school) setSchool(String(cust.school_id));
    setLine("");
  }, [custody]);
  useEffect(() => {
    if (!custsHere.find((c) => String(c.id) === custody)) setCustody(custsHere[0] ? String(custsHere[0].id) : "");
  }, [school]);
  useEffect(() => {
    setWarn("");
    if (!line || !(amt > 0)) return;
    const t = setTimeout(() => {
      probe("lineStatus", { line_id: line, amount: amt })
        .then((r) => setWarn(r && r.over ? r.message || "تنبيه: هذا المصروف يتجاوز المتبقى من البند" : ""))
        .catch(() => {});
    }, 450);
    return () => clearTimeout(t);
  }, [line, amount]);

  const save = async (draft) => {
    setErr("");
    if (docLink.trim() && !/^https?:\/\//i.test(docLink.trim())) return setErr("رابط المستند يجب أن يبدأ بـ http:// أو https://");
    if (!custody) return setErr("لا توجد عهدة معتمدة مفتوحة");
    if (!line) return setErr("اختر البند المالى");
    if (!(amt > 0)) return setErr("اكتب قيمة المصروف");
    if (!desc.trim()) return setErr("اكتب وصف المصروف");
    if (date > today()) return setErr("تاريخ المصروف لا يمكن أن يكون فى المستقبل");
    if (file && file.size > 10 * 1024 * 1024) return setErr("حجم المرفق أكبر من 10 ميجا");
    setBusy(true);
    try {
      const res = await act("addExpense", {
        expense: {
          custody_id: custody,
          line_id: line,
          amount: amt,
          date,
          description: desc.trim(),
          spend_item: item,
          pay_method: pay,
          note: note.trim(),
          draft: draft === true ? "1" : "",
          doc_link: !file ? docLink.trim() : "",
          doc_type: !file && docLink.trim() ? docType : "",
        },
      });
      if (file && res && res.item) {
        const dataUrl = await new Promise((ok, no) => {
          const r = new FileReader();
          r.onload = () => ok(r.result);
          r.onerror = no;
          r.readAsDataURL(file);
        });
        await act("uploadDoc", {
          id: res.item.id,
          filename: file.name,
          mimeType: file.type,
          dataBase64: String(dataUrl).split(",")[1],
          dataUrl,
          doc_type: docType,
        });
      }
      showToast(
        "تم تسجيل المصروف" +
          (res && res.item && res.item.txn_no ? " " + res.item.txn_no : "") +
          (draft === true ? " كمسودة — أرسله للاعتماد من شاشة المصروفات" : " — بانتظار اعتماد المدير المباشر"),
      );
      close();
    } catch (e) {
      setBusy(false);
    }
  };

  if (!openCusts.length)
    return (
      <Modal title="إضافة مصروف" close={close}>
        <div className="warn-banner">
          لا توجد عهدة معتمدة مفتوحة لتسجيل المصروف عليها.
          {waiting.length ? " توجد " + waiting.length + " عهدة بانتظار الاعتماد." : ""}{" "}
          {isCustody ? "أرسل طلب عهدة من تبويب «طلبات العهد»." : "أنشئ عهدة واعتمدها أولاً."}
        </div>
      </Modal>
    );

  const afterLine = cl ? cl.alloc - cl.spent - amt : null;
  return (
    <Modal title="إضافة مصروف" close={close} wide>
      <div className="grid2">
        <Field label="المكان / المدرسة">
          <select value={school} onChange={(e) => setSchool(e.target.value)}>
            {places.map((s) => (
              <option key={s.id} value={s.id}>
                {placeLabel(s)}
              </option>
            ))}
          </select>
        </Field>
        <Field label="العهدة">
          <select value={custody} onChange={(e) => setCustody(e.target.value)}>
            {custsHere.map((c) => (
              <option key={c.id} value={c.id}>
                {(c.code ? c.code + " · " : "") + (c.title ? c.title + " · " : "") + (c.holder || c.label)}
              </option>
            ))}
          </select>
        </Field>
        <Field label={"البند المالى" + (allocated.length ? " (بنود العهدة)" : "")}>
          <select value={line} onChange={(e) => setLine(e.target.value)}>
            <option value="">— اختر البند —</option>
            {Array.from(new Set(options.map((l) => l.section || "عام"))).map((sec) => (
              <optgroup key={sec} label={sec}>
                {options
                  .filter((l) => (l.section || "عام") === sec)
                  .map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name}
                    </option>
                  ))}
              </optgroup>
            ))}
          </select>
        </Field>
        <Field label="مسئول العهدة">
          <input value={cust ? cust.holder || cust.label : ""} disabled />
        </Field>
        <Field label="قيمة المصروف (ج.م)">
          <input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0" />
        </Field>
        <Field label="التاريخ">
          <input type="date" value={date} max={today()} onChange={(e) => setDate(e.target.value)} />
        </Field>
        <Field label="طريقة الدفع">
          <select value={pay} onChange={(e) => setPay(e.target.value)}>
            {PAY_METHODS.map((p) => (
              <option key={p}>{p}</option>
            ))}
          </select>
        </Field>
        <Field label="نوع المصروف (اختيارى)">
          <select value={item} onChange={(e) => setItem(e.target.value)}>
            <option value="">—</option>
            {(data.spendItems || []).map((s) => (
              <option key={s.id} value={s.name}>
                {s.name}
              </option>
            ))}
          </select>
        </Field>
      </div>

      {line && (
        <div className="chain">
          <div className="chain-path">
            <span>{(data.schools.find((s) => String(s.id) === String(cust && cust.school_id)) || {}).name}</span>
            <i>←</i>
            <span>{budgetLine ? budgetLine.name : ""}</span>
            <i>←</i>
            <span>{cust ? cust.code || "" : ""}</span>
            <i>←</i>
            <span>{cust ? cust.holder || cust.label : ""}</span>
          </div>
          <div className="chain-grid">
            {cl && cl.alloc > 0 && (
              <>
                <div>
                  <span>المخصص للبند فى العهدة</span>
                  <b>{fmt(cl.alloc)}</b>
                </div>
                <div>
                  <span>المصروف السابق</span>
                  <b>{fmt(cl.spent)}</b>
                </div>
                <div>
                  <span>المتبقى بعد العملية</span>
                  <b className={afterLine < -0.005 ? "red" : "green"}>{fmt(afterLine)}</b>
                </div>
                <div>
                  <span>الاستخدام / الحالة</span>
                  <b>
                    {cl.alloc ? Math.round(((cl.spent + amt) / cl.alloc) * 100) : 0}% · {lineStateInCustody(cl.alloc, cl.spent + amt).label}
                  </b>
                </div>
              </>
            )}
            {seesAmounts && (
              <>
                <div>
                  <span>مخصص البند فى الموازنة</span>
                  <b>{fmt(budgetLine.allocated)}</b>
                </div>
                <div>
                  <span>المصروف المعتمد من البند</span>
                  <b>{fmt(budgetSpent)}</b>
                </div>
                <div>
                  <span>متبقى الموازنة بعد العملية</span>
                  <b className={Number(budgetLine.allocated) - budgetSpent - amt < -0.005 ? "red" : "green"}>
                    {fmt(Number(budgetLine.allocated) - budgetSpent - amt)}
                  </b>
                </div>
              </>
            )}
          </div>
          {prev.length > 0 && (
            <div className="prev-list">
              مصروفات سابقة على هذا البند من العهدة:{" "}
              {prev.map((e) => (
                <span key={e.id}>
                  {e.date} · {fmt(e.amount)} · {e.description}
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      <Field label="وصف المصروف">
        <input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="ماذا صُرف؟" />
      </Field>
      <div className="grid2">
        <Field label="رابط المستند (فاتورة / إيصال / Drive / OneDrive / SharePoint)">
          <input
            value={docLink}
            onChange={(e) => setDocLink(e.target.value)}
            placeholder="https://…"
            disabled={!!file}
            dir="ltr"
            data-testid="doc-link"
          />
        </Field>
        <Field label="أو ارفع المرفق / الفاتورة (اختيارى)">
          <input type="file" accept="image/*,application/pdf" onChange={(e) => setFile(e.target.files[0] || null)} />
        </Field>
      </div>
      <div className="grid2">
        <Field label="نوع المستند">
          <select value={docType} onChange={(e) => setDocType(e.target.value)} disabled={!file && !docLink.trim()}>
            {DOC_TYPES.map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
        </Field>
      </div>
      <Field label="ملاحظات">
        <input value={note} onChange={(e) => setNote(e.target.value)} />
      </Field>
      {info && (
        <div className="cust-calc">
          <div>
            <span>إجمالى العهدة</span>
            <b>{fmt(info.received)}</b>
          </div>
          <div>
            <span>المصروف قبل هذا</span>
            <b>{fmt(info.spent)}</b>
          </div>
          <div>
            <span>المتبقى بعد هذا المصروف</span>
            <b className={info.remaining - amt < 0 ? "red" : "green"}>{fmt(info.remaining - amt)}</b>
          </div>
          <div>
            <span>نسبة الاستخدام</span>
            <b>{info.received > 0 ? Math.round(((info.spent + amt) / info.received) * 100) : 0}%</b>
          </div>
        </div>
      )}
      {info && info.remaining - amt < 0 && <div className="warn-banner">⚠ المصروف أكبر من رصيد العهدة المتاح — سيظهر المتبقى بالسالب (تجاوز).</div>}
      {warn && <div className="warn-banner over">{warn}</div>}
      {err && <div className="warn-banner over">{err}</div>}
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <span className="spacer" />
        <button className="btn ghost" disabled={busy} onClick={() => save(true)} data-testid="save-draft">
          حفظ كمسودة
        </button>
        <button className="btn primary" disabled={busy} onClick={() => save(false)}>
          {busy ? "جارٍ الحفظ…" : "تسجيل المصروف"}
        </button>
      </div>
    </Modal>
  );
}
