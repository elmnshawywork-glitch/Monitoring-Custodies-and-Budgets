// معالج استيراد العاملين الآمن: قراءة ← التعرف على النوع (متعاقد / حكومى-منتدب) ← ربط الأعمدة ← معاينة وتحقق
// (جديد · محدَّث · بدون تغيير · مكرر · خطأ) ← تأكيد ← استيراد. لا يُحذف أى موظف موجود، ولا يُنشأ الموظف مرة ثانية.
import React, { useRef, useState } from "react";
import { Modal } from "../components/ui";
import { EMP_FIELDS, readEmployeeWorkbook, sheetRecords, downloadEmployeeTemplate } from "../lib/employeeImport";
import { normAr } from "../lib/budget";

const ST = {
  new: ["جديد", "teal"],
  updated: ["محدَّث", "amber"],
  same: ["بدون تغيير", "gray"],
  duplicate: ["مكرر", "red"],
  error: ["خطأ", "red"],
};
const FIELD_LABEL = Object.fromEntries(EMP_FIELDS.map((f) => [f[0], f[1]]));

// المكان من اسم الشيت وعنوانه: كلمة مميِّزة لكل مكان (غير موجودة فى أسماء الأماكن الأخرى) مثل «بدر» أو «دمياط»
function guessPlace(data, sheet) {
  const t = " " + normAr(sheet.name + " " + sheet.title) + " ";
  const words = (s) => normAr(s.name).split(" ").filter((w) => w.length >= 3);
  const all = data.schools.map((s) => words(s));
  const hits = data.schools.filter((s, i) => {
    const own = all[i].filter((w) => all.every((ws, j) => j === i || ws.indexOf(w) < 0));
    return own.some((w) => t.indexOf(" " + w + " ") >= 0);
  });
  return hits.length === 1 ? String(hits[0].id) : "";
}

export function EmployeeImportWizard({ data, act, school_id, onDone, close }) {
  const [step, setStep] = useState(1);
  const [sheets, setSheets] = useState([]);
  const [fileName, setFileName] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState(null);
  const [result, setResult] = useState(null);
  const [showMap, setShowMap] = useState(null);
  const fileRef = useRef();

  const read = async (file) => {
    if (!file) return;
    setErr("");
    setBusy(true);
    try {
      const ss = await readEmployeeWorkbook(file);
      setFileName(file.name);
      setSheets(
        ss.map((s) => {
          const recs = sheetRecords(s, s.map);
          return Object.assign(s, { include: recs.length > 0 && !!s.map.name, school_id: school_id ? String(school_id) : guessPlace(data, s), recs });
        }),
      );
      setStep(2);
    } catch (e) {
      setErr("تعذّرت قراءة الملف: " + e.message);
    }
    setBusy(false);
  };
  const upd = (i, patch) =>
    setSheets(
      sheets.map((s, k) => {
        if (k !== i) return s;
        const n = Object.assign({}, s, patch);
        n.recs = sheetRecords(n, n.map);
        return n;
      }),
    );
  const active = sheets.filter((s) => s.include);
  const missingPlace = active.some((s) => !s.school_id);

  const call = async (mode) => {
    setBusy(true);
    setErr("");
    try {
      const out = [];
      for (const s of active) {
        const rows = s.recs.map(({ _row, ...r }) => r);
        const r = await act("importEmployeesSafe", { school_id: s.school_id, category: s.category, rows, mode, file_name: fileName });
        out.push({ sheet: s, res: r });
      }
      setBusy(false);
      return out;
    } catch (e) {
      setBusy(false);
      return null;
    }
  };
  const doPreview = async () => {
    const r = await call("preview");
    if (r) {
      setPreview(r);
      setStep(3);
    }
  };
  const doCommit = async () => {
    const r = await call("commit");
    if (r) {
      setResult(r);
      setStep(4);
    }
  };
  const total = (k, list) => (list || []).reduce((a, x) => a + ((x.res && x.res.counts && x.res.counts[k]) || 0), 0);

  return (
    <Modal title="استيراد العاملين (متعاقدون / حكوميون ومنتدبون)" close={close} xl>
      <div className="wizard-steps">
        {["اختيار الملف", "الأعمدة والمكان", "المعاينة والتحقق", "النتيجة"].map((t, i) => (
          <span key={i} className={"wstep " + (step === i + 1 ? "on" : step > i + 1 ? "done" : "")}>
            <b>{i + 1}</b> {t}
          </span>
        ))}
      </div>
      {err && <div className="warn-banner over">{err}</div>}

      {step === 1 && (
        <>
          <p className="hint">
            يقرأ النظام كشف المتعاقدين وكشف الحكوميين/المنتدبين كما هما (حتى لو كانت العناوين فى أكثر من صف أو خلايا مدمجة)، ويتعرف على نوع كل شيت
            وأعمدته تلقائياً. <b>الموظف لا يتكرر:</b> يُطابَق بالرقم القومى ثم بالكود ثم بالاسم، ويُحدَّث إن كان موجوداً. لا يُحذف أى موظف.
          </p>
          <div className="file-drop" onClick={() => fileRef.current && fileRef.current.click()}>
            <div style={{ fontSize: 28 }}>👥</div>
            <b>{busy ? "جارٍ القراءة…" : "اختر ملف العاملين (.xlsx)"}</b>
            <span>اضغط هنا لاختيار الملف</span>
            <input ref={fileRef} type="file" hidden accept=".xlsx,.xls" onChange={(e) => read(e.target.files[0])} data-testid="emp-file" />
          </div>
          <div style={{ marginTop: 10 }}>
            <button className="btn ghost sm" onClick={() => downloadEmployeeTemplate()}>
              تحميل قالب الاستيراد
            </button>
          </div>
        </>
      )}

      {step === 2 && (
        <>
          <p className="hint">📎 {fileName} — راجع نوع كل شيت ومكانه وربط أعمدته.</p>
          {sheets.map((s, i) => (
            <div key={s.name} className={"sheet-row " + (s.include ? "" : "off")} style={{ gridTemplateColumns: "1fr", marginBottom: 8 }} data-testid="emp-sheet">
              <div className="filters" style={{ alignItems: "center" }}>
                <label className="check">
                  <input type="checkbox" checked={s.include} onChange={(e) => upd(i, { include: e.target.checked })} /> <b>{s.name}</b>
                </label>
                <select value={s.category} onChange={(e) => upd(i, { category: e.target.value })} data-testid="emp-cat">
                  <option value="contract">متعاقدون</option>
                  <option value="gov">حكوميون / منتدبون</option>
                </select>
                <select value={s.school_id} onChange={(e) => upd(i, { school_id: e.target.value })} data-testid="emp-place">
                  <option value="">— اختر المكان —</option>
                  {data.schools.map((x) => (
                    <option key={x.id} value={x.id}>
                      {x.name}
                    </option>
                  ))}
                </select>
                <span className="chip navy">{s.recs.length} موظف</span>
                <span className="muted">
                  صف العناوين: {s.headerRow + 1}
                  {s.twoRows ? " + " + (s.headerRow + 2) + " (عناوين مدمجة)" : ""}
                </span>
                <button className="btn ghost sm" onClick={() => setShowMap(showMap === i ? null : i)}>
                  ربط الأعمدة ({Object.keys(s.map).length})
                </button>
              </div>
              {!s.map.name && s.include && <div className="warn-banner over">لم يُعثر على عمود «اسم الموظف» — اربطه يدوياً.</div>}
              {showMap === i && (
                <div className="map-grid">
                  {EMP_FIELDS.filter((f) => f[3].indexOf(s.category === "gov" ? "g" : "c") >= 0).map(([k, label]) => (
                    <label key={k}>
                      <span>{label}</span>
                      <select
                        value={s.map[k] == null ? "" : s.map[k]}
                        onChange={(e) => {
                          const m = Object.assign({}, s.map);
                          if (e.target.value === "") delete m[k];
                          else m[k] = Number(e.target.value);
                          upd(i, { map: m });
                        }}
                      >
                        <option value="">— غير موجود —</option>
                        {s.labels.map((l, c) =>
                          l ? (
                            <option key={c} value={c}>
                              {l}
                            </option>
                          ) : null,
                        )}
                      </select>
                    </label>
                  ))}
                </div>
              )}
            </div>
          ))}
          <div className="modal-actions">
            <button className="btn ghost" onClick={() => setStep(1)}>
              رجوع
            </button>
            <span className="spacer" />
            {missingPlace && <span className="imp-sum red">اختر المكان لكل شيت مفعّل</span>}
            <button className="btn primary" disabled={busy || !active.length || missingPlace} onClick={doPreview} data-testid="emp-preview">
              {busy ? "جارٍ التحقق…" : "معاينة وتحقق"}
            </button>
          </div>
        </>
      )}

      {step === 3 && preview && (
        <>
          <div className="mini-kpis" data-testid="emp-counts">
            {["new", "updated", "same", "duplicate", "error"].map((k) => (
              <div key={k}>
                <span>{ST[k][0]}</span>
                <b className={ST[k][1]}>{total(k, preview)}</b>
              </div>
            ))}
          </div>
          <p className="hint">
            لم يُحفظ شىء بعد. «مكرر» و«خطأ» لن يُستوردا. {total("warnings", preview)} سطر به بيانات ناقصة (يُستورد مع التنبيه).
          </p>
          <div className="table-wrap" style={{ maxHeight: 380 }}>
            <table className="tbl">
              <thead>
                <tr>
                  <th>الشيت</th>
                  <th>#</th>
                  <th>الاسم</th>
                  <th>الرقم القومى</th>
                  <th>الحالة</th>
                  <th>التغييرات / الملاحظات</th>
                </tr>
              </thead>
              <tbody>
                {preview.map((p) =>
                  ((p.res && p.res.rows) || []).map((r) => (
                    <tr key={p.sheet.name + r.i}>
                      <td style={{ fontSize: 12 }}>{p.sheet.name}</td>
                      <td>{r.i}</td>
                      <td>{r.name || "—"}</td>
                      <td className="num">{r.national_id || "—"}</td>
                      <td>
                        <span className={"chip " + ST[r.status][1]}>{ST[r.status][0]}</span>
                      </td>
                      <td style={{ fontSize: 12 }}>
                        {(r.changes || []).map((c) => FIELD_LABEL[c] || (c === "school_id" ? "المكان" : c)).join("، ")}
                        {(r.changes || []).length && (r.reasons || []).length ? " · " : ""}
                        <span className={r.status === "error" || r.status === "duplicate" ? "red" : "muted"}>{(r.reasons || []).join(" · ")}</span>
                      </td>
                    </tr>
                  )),
                )}
              </tbody>
            </table>
          </div>
          <div className="modal-actions">
            <button className="btn ghost" onClick={() => setStep(2)}>
              رجوع
            </button>
            <span className="spacer" />
            <button className="btn primary" disabled={busy || total("new", preview) + total("updated", preview) === 0} onClick={doCommit} data-testid="emp-commit">
              {busy ? "جارٍ الاستيراد…" : "تأكيد الاستيراد"}
            </button>
          </div>
        </>
      )}

      {step === 4 && result && (
        <>
          <div className="imp-done">
            <div style={{ fontSize: 34 }}>✅</div>
            <h3>تم استيراد العاملين</h3>
          </div>
          <div className="mini-kpis" data-testid="emp-result">
            <div>
              <span>موظفون جدد</span>
              <b className="teal">{total("new", result)}</b>
            </div>
            <div>
              <span>حُدّثت بياناتهم</span>
              <b className="amber">{total("updated", result)}</b>
            </div>
            <div>
              <span>بدون تغيير</span>
              <b>{total("same", result)}</b>
            </div>
            <div>
              <span>تم تخطيه (مكرر/خطأ)</span>
              <b className="red">{total("duplicate", result) + total("error", result)}</b>
            </div>
          </div>
          <p className="hint">كل تغيير مسجّل فى «تتبع التعديلات» بالقيمة القديمة والجديدة.</p>
          <div className="modal-actions">
            <span className="spacer" />
            <button className="btn primary" onClick={() => onDone("تم استيراد العاملين: " + total("new", result) + " جديد · " + total("updated", result) + " محدَّث")}>
              تم
            </button>
          </div>
        </>
      )}
    </Modal>
  );
}
