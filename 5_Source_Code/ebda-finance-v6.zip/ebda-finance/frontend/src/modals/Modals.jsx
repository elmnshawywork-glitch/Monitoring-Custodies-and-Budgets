import { EmployeeImportWizard } from "./EmployeeImport";
import { ExpenseImportWizard } from "./ExpenseImport";
import { DecisionModal } from "./ExpenseModals";
import { BudgetImportWizard, BudgetLineForm, BudgetDeleteModal } from "./BudgetModals";
import { CustodyForm, ExpenseForm } from "./EntryModals";
import { PERMS, ROLE_DEFAULTS, permsOf, permsString, roleKey } from "../lib/perms";
import React, { useEffect, useRef, useState } from "react";
import { fmt, today, yes } from "../lib/utils";
import { parseEmployeeRows, parseSalaryRows, readBudgetFile, readWorkbook } from "../lib/importers";
import { CAT_LABEL, CAT_OPTIONS, DEDUCTION_RATES, DOC_TYPES, lineName, salaryLabel } from "../lib/model";
import { Field, Modal, DocLink } from "../components/ui";

export function RequestModal({ data, act, onDone, close }) {
  let [i, u] = useState(data.schools[0] ? data.schools[0].id : ""),
    s = data.lines.filter((y) => String(y.school_id) === String(i)),
    [o, d] = useState([
      {
        line_id: s[0] ? s[0].id : "",
        name: "",
        amount: "",
      },
    ]),
    [c, p] = useState(""),
    [reason, setReason] = useState(""),
    [m, r] = useState(!1);
  useEffect(() => {
    let y = data.lines.filter((g) => String(g.school_id) === String(i));
    d([
      {
        line_id: y[0] ? y[0].id : "",
        name: "",
        amount: "",
      },
    ]);
  }, [i]);
  let v = (y, g, x) =>
      d((C) =>
        C.map((_, A) =>
          A === y
            ? {
                ..._,
                [g]: x,
              }
            : _,
        ),
      ),
    S = () =>
      d((y) => [
        ...y,
        {
          line_id: s[0] ? s[0].id : "",
          name: "",
          amount: "",
        },
      ]),
    N = (y) => d((g) => g.filter((x, C) => C !== y)),
    b = o.reduce((y, g) => y + Number(g.amount || 0), 0),
    f = (y) => {
      let g = s.find((x) => String(x.id) === String(y));
      return g ? g.name : "";
    },
    h = async () => {
      let y = o.filter((g) => g.line_id && g.amount);
      if (y.length) {
        r(!0);
        try {
          (await act("addRequest", {
            request: {
              school_id: i,
              note: c,
              reason: reason.trim(),
              items: y.map((g) => ({
                line_id: g.line_id,
                name: (g.name || "").trim() || f(g.line_id),
                amount: Number(g.amount) || 0,
              })),
            },
          }),
            onDone("تم إرسال طلب العهدة للمدير المباشر"));
        } catch (g) {
          r(!1);
        }
      }
    };
  return (
    <Modal title="طلب عهدة جديدة" close={close} wide={!0}>
      <Field label="الجهة">
        <select value={i} onChange={(y) => u(y.target.value)}>
          {data.schools.map((y) => (
            <option key={y.id} value={y.id}>
              {CAT_LABEL[y.category || "school"]}
              {" · "}
              {y.name}
            </option>
          ))}
        </select>
      </Field>
      {s.length === 0 ? (
        <div className="warn-banner">لا توجد بنود رئيسية لهذه الجهة.</div>
      ) : (
        <>
          <div
            style={{
              fontSize: 12.5,
              color: "var(--ink-soft)",
              marginBottom: 6,
            }}
          >
            لكل بند مطلوب اختر البند الرئيسى الذى يتبع له من الموازنة، والمبلغ.
          </div>
          {o.map((y, g) => (
            <div
              key={g}
              className="quick-row"
              style={{
                marginBottom: 8,
              }}
            >
              <div
                className="qf"
                style={{
                  minWidth: 160,
                }}
              >
                <span>البند الرئيسى</span>
                <select value={y.line_id} onChange={(x) => v(g, "line_id", x.target.value)}>
                  {s.map((x) => (
                    <option key={x.id} value={x.id}>
                      {x.section ? x.section + " — " : ""}
                      {x.name}
                    </option>
                  ))}
                </select>
              </div>
              <div
                className="qf"
                style={{
                  flex: 1,
                  minWidth: 140,
                }}
              >
                <span>وصف البند المطلوب</span>
                <input value={y.name} onChange={(x) => v(g, "name", x.target.value)} placeholder="اختيارى" />
              </div>
              <div className="qf">
                <span>المبلغ</span>
                <input
                  type="number"
                  step="any"
                  value={y.amount}
                  onChange={(x) => v(g, "amount", x.target.value)}
                  style={{
                    width: 100,
                  }}
                />
              </div>
              <button className="icon-btn" onClick={() => N(g)}>
                ×
              </button>
            </div>
          ))}
          <button className="btn ghost sm" onClick={S}>
            + بند آخر
          </button>
          <div
            style={{
              margin: "10px 0",
              fontWeight: 800,
              color: "var(--navy)",
              fontFamily: "Cairo",
            }}
          >
            {"الإجمالى المطلوب: "}
            {fmt(b)}
            {" ج.م"}
          </div>
          <Field label="سبب طلب العهدة">
            <input
              value={reason}
              onChange={(y) => setReason(y.target.value)}
              placeholder="مثال: مستلزمات معامل الفصل الدراسى الأول"
            />
          </Field>
          <Field label="ملاحظات الطلب">
            <input value={c} onChange={(y) => p(y.target.value)} />
          </Field>
        </>
      )}
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" disabled={m || s.length === 0} onClick={h}>
          {m ? "جارٍ الإرسال…" : "إرسال الطلب"}
        </button>
      </div>
    </Modal>
  );
}

export function RequestItemModal({ data, payload, onSave, close }) {
  let i = payload.it,
    u = data.lines.filter((S) => String(S.school_id) === String(payload.school_id)),
    [s, o] = useState(i.line_id),
    [d, c] = useState(i.name),
    [p, m] = useState(i.amount),
    [r, v] = useState(i.sup_note || "");
  return (
    <Modal title="تعديل بند الطلب" close={close}>
      <Field label="البند الرئيسى التابع له">
        <select value={s} onChange={(S) => o(S.target.value)}>
          {u.map((S) => (
            <option key={S.id} value={S.id}>
              {S.section ? S.section + " — " : ""}
              {S.name}
            </option>
          ))}
        </select>
      </Field>
      <div className="grid2">
        <Field label="وصف البند">
          <input value={d} onChange={(S) => c(S.target.value)} />
        </Field>
        <Field label="المبلغ">
          <input type="number" step="any" value={p} onChange={(S) => m(S.target.value)} />
        </Field>
      </div>
      <Field label="ملاحظات المدير المباشر">
        <input value={r} onChange={(S) => v(S.target.value)} />
      </Field>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button
          className="btn primary"
          onClick={() =>
            onSave({
              line_id: s,
              name: d.trim(),
              amount: Number(p) || 0,
              sup_note: r,
            })
          }
        >
          حفظ
        </button>
      </div>
    </Modal>
  );
}

export function EmployeeModal({ data, initial, onSave, close }) {
  let n = initial && initial.id,
    [i, u] = useState(
      Object.assign(
        {
          category: "contract",
          name: "",
          job: "",
          job_type: "",
          qualification: "",
          grad_year: "",
          national_id: "",
          phone: "",
          email: "",
          bank: "",
          branch: "",
          account_no: "",
          insurance_no: "",
          hire_date: "",
          ebda_start: "",
          base_salary: "",
          contract_type: "",
          gender: "",
          address: "",
          note: "",
        },
        initial || {},
      ),
    ),
    s = (d, c) =>
      u((p) =>
        Object.assign({}, p, {
          [d]: c,
        }),
      ),
    o = () => {
      if (!i.name || !String(i.name).trim()) return;
      let d = Object.assign({}, i, {
        base_salary: Number(i.base_salary) || 0,
      });
      n
        ? onSave(
            {
              id: initial.id,
              patch: d,
            },
            !1,
          )
        : ((d.school_id = initial.school_id),
          onSave(
            {
              emp: d,
            },
            !0,
          ));
    };
  return (
    <Modal title={n ? "تعديل موظف" : "موظف جديد"} close={close} wide={!0}>
      <div className="grid2">
        <label className="field">
          <span>التصنيف</span>
          <select value={i.category} onChange={(d) => s("category", d.target.value)}>
            <option value="contract">متعاقد (له راتب)</option>
            <option value="gov">حكومى/منتدب (له حافز)</option>
          </select>
        </label>
        <label className="field">
          <span>الاسم (رباعى)</span>
          <input value={i.name} onChange={(d) => s("name", d.target.value)} />
        </label>
        <label className="field">
          <span>المسمى / التخصص</span>
          <input value={i.job} onChange={(d) => s("job", d.target.value)} />
        </label>
        <label className="field">
          <span>معلم / إدارى</span>
          <input value={i.job_type} onChange={(d) => s("job_type", d.target.value)} />
        </label>
        <label className="field">
          <span>المؤهل</span>
          <input value={i.qualification} onChange={(d) => s("qualification", d.target.value)} />
        </label>
        <label className="field">
          <span>سنة التخرج</span>
          <input value={i.grad_year} onChange={(d) => s("grad_year", d.target.value)} />
        </label>
        <label className="field">
          <span>الرقم القومى</span>
          <input value={i.national_id} onChange={(d) => s("national_id", d.target.value)} />
        </label>
        <label className="field">
          <span>الهاتف</span>
          <input value={i.phone} onChange={(d) => s("phone", d.target.value)} />
        </label>
        <label className="field">
          <span>الإيميل</span>
          <input value={i.email} onChange={(d) => s("email", d.target.value)} />
        </label>
        <label className="field">
          <span>
            {salaryLabel(i.category)}
            {" (ج.م)"}
          </span>
          <input type="number" step="any" value={i.base_salary} onChange={(d) => s("base_salary", d.target.value)} />
        </label>
        <label className="field">
          <span>البنك</span>
          <input value={i.bank} onChange={(d) => s("bank", d.target.value)} />
        </label>
        <label className="field">
          <span>رقم الحساب</span>
          <input value={i.account_no} onChange={(d) => s("account_no", d.target.value)} />
        </label>
        <label className="field">
          <span>الرقم التأمينى</span>
          <input value={i.insurance_no} onChange={(d) => s("insurance_no", d.target.value)} />
        </label>
        <label className="field">
          <span>نظام التعاقد</span>
          <input value={i.contract_type} onChange={(d) => s("contract_type", d.target.value)} />
        </label>
        <label className="field">
          <span>تاريخ التعيين</span>
          <input value={i.hire_date} onChange={(d) => s("hire_date", d.target.value)} placeholder="YYYY-MM-DD" />
        </label>
        <label className="field">
          <span>بداية العمل مع ابدأ</span>
          <input value={i.ebda_start} onChange={(d) => s("ebda_start", d.target.value)} />
        </label>
      </div>
      <h4 className="sub-h">الربط بالنظام المالى والإدارى</h4>
      <div className="grid2">
        <label className="field">
          <span>القسم</span>
          <input value={i.dept || ""} onChange={(d) => s("dept", d.target.value)} data-testid="emp-dept" />
        </label>
        <label className="field">
          <span>المدير المباشر</span>
          <select value={i.manager_user_id || ""} onChange={(d) => s("manager_user_id", d.target.value)}>
            <option value="">—</option>
            {((data && (data.users || data.managers)) || [])
              .filter((x) => !x.role || x.role === "supervisor" || x.role === "manager" || x.role_key === "direct_manager" || x.role_key === "admin")
              .map((x) => (
                <option key={x.id} value={x.id}>
                  {x.name}
                </option>
              ))}
          </select>
        </label>
        {i.category === "gov" && (
          <label className="field">
            <span>حالة الندب / المأمورية</span>
            <input value={i.secondment_status || ""} onChange={(d) => s("secondment_status", d.target.value)} />
          </label>
        )}
        <label className="field">
          <span>مكان الميلاد</span>
          <input value={i.birth_place || ""} onChange={(d) => s("birth_place", d.target.value)} />
        </label>
      </div>
      <label className="field">
        <span>ملاحظات</span>
        <input value={i.note} onChange={(d) => s("note", d.target.value)} />
      </label>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" onClick={o}>
          حفظ
        </button>
      </div>
    </Modal>
  );
}

export function PayslipModal({ payload, onSave, close }) {
  let n = payload.edit,
    i = payload.employees || [],
    u = n || {
      employee_id: i[0] ? i[0].id : "",
      base: i[0] ? i[0].base_salary : 0,
      allowances: 0,
      incentive: 0,
      ded_medical: 0,
      ded_social: 0,
      ded_tax: 0,
      ded_other: 0,
    },
    [s, o] = useState(u.employee_id),
    [d, c] = useState(u.base || 0),
    [p, m] = useState(u.allowances || 0),
    [r, v] = useState(u.incentive || 0),
    [S, N] = useState(u.ded_medical || 0),
    [b, f] = useState(u.ded_social || 0),
    [h, y] = useState(u.ded_tax || 0),
    [g, x] = useState(u.ded_other || 0),
    C = (q) => {
      o(q);
      let $ = i.find((I) => String(I.id) === String(q));
      if ($ && !n) {
        let I = Number($.base_salary || 0);
        (c(I),
          N(Math.round(I * DEDUCTION_RATES.medical * 100) / 100),
          f(Math.round(I * DEDUCTION_RATES.social * 100) / 100),
          y(Math.round(I * DEDUCTION_RATES.tax * 100) / 100));
      }
    },
    _ = Number(d || 0) + Number(p || 0) + Number(r || 0),
    A = Number(S || 0) + Number(b || 0) + Number(h || 0) + Number(g || 0),
    z = _ - A,
    E = () => {
      let q = Number(d || 0);
      (N(Math.round(q * DEDUCTION_RATES.medical * 100) / 100),
        f(Math.round(q * DEDUCTION_RATES.social * 100) / 100),
        y(Math.round(q * DEDUCTION_RATES.tax * 100) / 100));
    },
    j = () => {
      if (!s) return;
      let q = i.find((I) => String(I.id) === String(s)),
        $ = {
          employee_id: s,
          emp_name: q ? q.name : "",
          school_id: payload.school_id,
          month: payload.month,
          base: Number(d) || 0,
          incentive: Number(r) || 0,
          allowances: Number(p) || 0,
          gross: _,
          ded_medical: Number(S) || 0,
          ded_social: Number(b) || 0,
          ded_tax: Number(h) || 0,
          ded_other: Number(g) || 0,
          ded_total: A,
          net: z,
        };
      n
        ? onSave(
            {
              id: n.id,
              patch: $,
            },
            !1,
          )
        : onSave(
            {
              slip: $,
            },
            !0,
          );
    };
  return (
    <Modal title={(n ? "تعديل راتب شهرى" : "راتب شهرى") + " · " + payload.month} close={close} wide={!0}>
      <label className="field">
        <span>الموظف</span>
        <select value={s} onChange={(q) => C(q.target.value)} disabled={!!n}>
          {i.map((q) => (
            <option key={q.id} value={q.id}>
              {q.name}
              {" — "}
              {q.job}
            </option>
          ))}
        </select>
      </label>
      <div className="grid2">
        <label className="field">
          <span>الأساسى</span>
          <input type="number" step="any" value={d} onChange={(q) => c(q.target.value)} />
        </label>
        <label className="field">
          <span>بدلات</span>
          <input type="number" step="any" value={p} onChange={(q) => m(q.target.value)} />
        </label>
        <label className="field">
          <span>حوافز</span>
          <input type="number" step="any" value={r} onChange={(q) => v(q.target.value)} />
        </label>
        <label className="field">
          <span>الإجمالى (تلقائى)</span>
          <input
            value={fmt(_)}
            readOnly={!0}
            style={{
              background: "#F6F9FB",
            }}
          />
        </label>
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          margin: "4px 0 8px",
        }}
      >
        <b
          style={{
            color: "var(--navy)",
            fontFamily: "Cairo",
          }}
        >
          الخصومات
        </b>
        <button className="btn ghost sm" onClick={E}>
          تطبيق النسب (8/8/10%)
        </button>
      </div>
      <div className="grid2">
        <label className="field">
          <span>تأمين طبى</span>
          <input type="number" step="any" value={S} onChange={(q) => N(q.target.value)} />
        </label>
        <label className="field">
          <span>تأمين اجتماعى</span>
          <input type="number" step="any" value={b} onChange={(q) => f(q.target.value)} />
        </label>
        <label className="field">
          <span>ضريبة دخل</span>
          <input type="number" step="any" value={h} onChange={(q) => y(q.target.value)} />
        </label>
        <label className="field">
          <span>خصم آخر</span>
          <input type="number" step="any" value={g} onChange={(q) => x(q.target.value)} />
        </label>
      </div>
      <div
        style={{
          display: "flex",
          gap: 16,
          padding: "10px 12px",
          background: "#F6F9FB",
          borderRadius: 10,
          fontFamily: "Cairo",
          fontWeight: 800,
        }}
      >
        <span
          style={{
            color: "var(--red)",
          }}
        >
          {"إجمالى الخصم: "}
          {fmt(A)}
        </span>
        <span
          style={{
            color: "var(--green)",
            marginInlineStart: "auto",
          }}
        >
          {"الصافى: "}
          {fmt(z)}
          {" ج.م"}
        </span>
      </div>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" onClick={j}>
          حفظ
        </button>
      </div>
    </Modal>
  );
}

export function ImportEmployeesModal({ data, school_id, act, onDone, close }) {
  let [u, s] = useState(school_id || (data.schools[0] ? data.schools[0].id : "")),
    [o, d] = useState(null),
    [c, p] = useState(""),
    [m, r] = useState("contract"),
    [v, S] = useState(null),
    [N, b] = useState(""),
    [f, h] = useState(!1),
    y = useRef(),
    g = async (E) => {
      if (E) {
        (b(""), S(null), d(null));
        try {
          let j = await readWorkbook(E);
          d(j);
          let q = j.sheets.find(($) => /متعاقد|رواتب|salar|كشف/i.test($)) || j.sheets[0];
          (p(q), C(j, q, x(q)));
        } catch (j) {
          b(j.message || "تعذّر قراءة الملف");
        }
      }
    },
    x = (E) => (/حكوم|منتدب|ندب/.test(E) ? "gov" : "contract"),
    C = (E, j, q) => {
      try {
        let $ = parseEmployeeRows(E.get(j), q);
        if (!$.rows.length) {
          (b("لم يتم العثور على عاملين — تأكد من الأعمدة (اسم الموظف/المسمى/الراتب أو الحافز)."), S(null));
          return;
        }
        (b(""), S($));
      } catch ($) {
        b($.message);
      }
    },
    _ = (E) => {
      let j = x(E);
      (p(E), r(j), o && C(o, E, j));
    },
    A = (E) => {
      (r(E), o && C(o, c, E));
    },
    z = async () => {
      if (!v) return;
      h(!0);
      let E = v.rows.map((j) =>
        Object.assign({}, j, {
          category: m,
        }),
      );
      try {
        let j = await act("importEmployees", {
          school_id: u,
          rows: E,
        });
        onDone("تم استيراد " + ((j && j.count) || E.length) + " موظف (أُضيفوا دون حذف الموجود)");
      } catch (j) {
        h(!1);
      }
    };
  return (
    <Modal title="استيراد عاملين من Excel" close={close} wide={!0}>
      <div
        style={{
          fontSize: 12.5,
          color: "var(--ink-soft)",
          marginBottom: 12,
          lineHeight: 1.7,
        }}
      >
        {
          "يقرأ النظام كشوف العاملين بنفس تنسيق نموذجك (كشف المتعاقدين / كشف الحكوميين). المتعاقد يؤخذ راتبه، والحكومى يؤخذ حافزه. الاستيراد "
        }
        <b>يُضيف</b>
        {" العاملين ولا يحذف الموجودين."}
      </div>
      <div className="grid2">
        <label className="field">
          <span>الجهة المستهدفة</span>
          <select value={u} onChange={(E) => s(E.target.value)}>
            {data.schools.map((E) => (
              <option key={E.id} value={E.id}>
                {CAT_LABEL[E.category || "school"]}
                {" · "}
                {E.name}
              </option>
            ))}
          </select>
        </label>
        <label className="field">
          <span>تصنيف العاملين</span>
          <select value={m} onChange={(E) => A(E.target.value)}>
            <option value="contract">متعاقدون (راتب)</option>
            <option value="gov">حكوميون/منتدبون (حافز)</option>
          </select>
        </label>
      </div>
      <label className="field">
        <span>الملف (.xlsx / .csv)</span>
        <div className="file-row">
          <button className="btn ghost sm" onClick={() => y.current && y.current.click()}>
            اختيار ملف
          </button>
          <input ref={y} type="file" hidden={!0} accept=".xlsx,.xls,.csv" onChange={(E) => g(E.target.files[0])} />
          {o && (
            <span className="file-name">
              {"📎 "}
              {o.sheets.length}
              {" ورقة"}
            </span>
          )}
        </div>
      </label>
      {o && o.sheets.length > 1 && (
        <label className="field">
          <span>اختر الورقة</span>
          <select value={c} onChange={(E) => _(E.target.value)}>
            {o.sheets.map((E) => (
              <option key={E} value={E}>
                {E}
              </option>
            ))}
          </select>
        </label>
      )}
      {N && (
        <div
          className="warn-banner"
          style={{
            background: "#FBE1E2",
            color: "#A31820",
          }}
        >
          {N}
        </div>
      )}
      {v && (
        <div
          style={{
            background: "#F4FBF7",
            border: "1px solid var(--line)",
            borderRadius: 10,
            padding: 12,
            marginBottom: 12,
          }}
        >
          <div
            style={{
              fontWeight: 700,
              color: "var(--green)",
            }}
          >
            {"تمت القراءة: "}
            {v.rows.length}
            {" موظف · إجمالى "}
            {salaryLabel(m)} {fmt(v.total)}
            {" ج.م"}
          </div>
          <div
            style={{
              fontSize: 12,
              color: "var(--ink-soft)",
              marginTop: 6,
              maxHeight: 120,
              overflow: "auto",
            }}
          >
            {v.rows.slice(0, 6).map((E, j) => (
              <div key={j}>
                {"• "}
                {E.name}
                {" — "}
                {E.job || "—"}
                {": "}
                {fmt(E.base_salary)}
              </div>
            ))}
            {v.rows.length > 6 && (
              <div>
                … و{v.rows.length - 6}
                {" موظف آخر"}
              </div>
            )}
          </div>
        </div>
      )}
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" disabled={!v || f} onClick={z}>
          {f ? "جارٍ الاستيراد…" : "استيراد وإضافة"}
        </button>
      </div>
    </Modal>
  );
}

export function Modals({ modal, data, act, close, showToast }) {
  let u = async (s, o, d) => {
    try {
      let c = await act(s, o);
      (showToast((d || "تم الحفظ") + (c && c.mail ? " · " + c.mail : "")), close());
    } catch (c) {}
  };
  if (modal.type === "budgetImport")
    return (
      <BudgetImportWizard
        data={data}
        school_id={modal.payload && modal.payload.school_id}
        act={act}
        onDone={(s) => (showToast(s), close())}
        close={close}
      />
    );
  if (modal.type === "budgetLine")
    return (
      <BudgetLineForm
        data={data}
        initial={modal.payload && modal.payload.id ? modal.payload : null}
        defaultSchool={modal.payload && modal.payload.school_id}
        act={act}
        onDone={(s) => (showToast(s), close())}
        close={close}
      />
    );
  if (modal.type === "budgetDelete")
    return (
      <BudgetDeleteModal data={data} school_id={modal.payload.school_id} act={act} onDone={(s) => (showToast(s), close())} close={close} />
    );
  if (modal.type === "newExpense")
    return <ExpenseForm data={data} initial={modal.payload} act={act} showToast={showToast} close={close} />;
  return modal.type === "custody" ? (
    <CustodyForm
      data={data}
      initial={modal.payload}
      onSave={async (s, isNew) => {
        try {
          if (isNew) {
            const r = await act("addCustody", { custody: s });
            showToast(r && r.item && r.item.approval === "approved" ? "تم حفظ العهدة واعتمادها" : "تم حفظ العهدة كمسودة — بانتظار الاعتماد");
          } else {
            const { id, _lines, ...patch } = s;
            await act("updateCustody", { id, patch });
            if (_lines) await act("setCustodyLines", { custody_id: id, lines: _lines });
            showToast("تم حفظ العهدة");
          }
          close();
        } catch (e) {}
      }}
      close={close}
    />
  ) : modal.type === "tranche" ? (
    <TrancheModal
      custody={modal.payload}
      onSave={(s) =>
        u(
          "addTranche",
          {
            tranche: s,
          },
          "تمت إضافة العهدة",
        )
      }
      close={close}
    />
  ) : modal.type === "approve" ? (
    <DecisionModal
      e={modal.payload}
      data={data}
      onDecide={(s, d) =>
        u(
          "updateExpense",
          { id: modal.payload.id, patch: { approval: s, note: d } },
          s === "approved" ? "تم الاعتماد" : s === "returned" ? "أُعيد المصروف لصاحبه للتعديل" : "تم الرفض",
        )
      }
      close={close}
    />
  ) : modal.type === "import" ? (
    <ImportModal
      data={data}
      school_id={modal.payload && modal.payload.school_id}
      act={act}
      onDone={(s) => {
        (showToast(s), close());
      }}
      close={close}
    />
  ) : modal.type === "editExpense" ? (
    <EditExpenseModal
      data={data}
      e={modal.payload}
      onSave={(s) =>
        u(
          "updateExpense",
          {
            id: modal.payload.id,
            patch: s,
          },
          "تم تعديل الصرف",
        )
      }
      close={close}
    />
  ) : modal.type === "request" ? (
    <RequestModal
      data={data}
      act={act}
      onDone={(s) => {
        (showToast(s), close());
      }}
      close={close}
    />
  ) : modal.type === "reqitem" ? (
    <RequestItemModal
      data={data}
      payload={modal.payload}
      onSave={(s) =>
        u(
          "updateRequestItem",
          {
            id: modal.payload.it.id,
            patch: s,
          },
          "تم تعديل البند",
        )
      }
      close={close}
    />
  ) : modal.type === "importSalaries" ? (
    <ImportSalariesModal
      data={data}
      school_id={modal.payload && modal.payload.school_id}
      act={act}
      onDone={(s) => {
        (showToast(s), close());
      }}
      close={close}
    />
  ) : modal.type === "salary" ? (
    <SalaryModal
      initial={modal.payload}
      onSave={(s, o) =>
        u(
          o ? "addSalary" : "updateSalary",
          o
            ? {
                salary: s,
              }
            : {
                id: s.id,
                patch: s,
              },
          "تم حفظ الراتب",
        )
      }
      close={close}
    />
  ) : modal.type === "employee" ? (
    <EmployeeModal
      data={data}
      initial={modal.payload}
      onSave={(s, o) => u(o ? "addEmployee" : "updateEmployee", s, "تم حفظ الموظف")}
      close={close}
    />
  ) : modal.type === "payslip" ? (
    <PayslipModal
      payload={modal.payload}
      onSave={(s, o) => u(o ? "addPayslip" : "updatePayslip", s, "تم حفظ الراتب الشهرى")}
      close={close}
    />
  ) : modal.type === "importExpenses" ? (
    <ExpenseImportWizard
      data={data}
      act={act}
      isAdmin={data.me.role === "manager"}
      onDone={(r) => {
        (showToast("تم استيراد " + ((r && r.summary && r.summary.importable) || 0) + " مصروف"), close());
      }}
      close={close}
    />
  ) : modal.type === "importEmployees" ? (
    <EmployeeImportWizard
      data={data}
      school_id={modal.payload && modal.payload.school_id}
      act={act}
      onDone={(s) => {
        (showToast(s), close());
      }}
      close={close}
    />
  ) : modal.type === "temp" ? (
    <TempBudgetModal
      data={data}
      onSave={(s) =>
        u(
          "addTempBudget",
          {
            tb: s,
          },
          "تم إنشاء الموازنة المؤقتة",
        )
      }
      close={close}
    />
  ) : modal.type === "uploaddoc" ? (
    <UploadDocModal e={modal.payload} act={act} showToast={showToast} close={close} />
  ) : modal.type === "central" ? (
    <CentralModal
      data={data}
      school_id={modal.payload.school_id}
      act={act}
      onDone={(s) => {
        (showToast(s || "تم تسجيل الشراء المركزى"), close());
      }}
      close={close}
    />
  ) : modal.type === "review" ? (
    <ReviewModal
      e={modal.payload}
      onSave={(s) =>
        u(
          "reviewExpense",
          {
            id: modal.payload.id,
            patch: s,
          },
          s.settled ? "تمت التسوية والخصم من الموازنة" : "تم إرسال الملاحظة لصاحب التسوية",
        )
      }
      close={close}
    />
  ) : modal.type === "school" ? (
    <SchoolModal
      initial={modal.payload}
      onSave={(s, o) =>
        u(
          o ? "addSchool" : "updateSchool",
          o
            ? {
                school: s,
              }
            : {
                id: s.id,
                patch: s,
              },
          "تم حفظ المدرسة",
        )
      }
      close={close}
    />
  ) : modal.type === "line" ? (
    <LineModal
      initial={modal.payload}
      onSave={(s, o) =>
        u(
          o ? "addLine" : "updateLine",
          o
            ? {
                line: s,
              }
            : {
                id: s.id,
                patch: s,
              },
          "تم حفظ البند",
        )
      }
      close={close}
    />
  ) : modal.type === "user" ? (
    <UserModal
      initial={modal.payload}
      data={data}
      onSave={(s, o) =>
        u(
          o ? "addUser" : "updateUser",
          o
            ? {
                user: s,
              }
            : {
                id: s.id,
                patch: s,
              },
          "تم حفظ المستخدم",
        )
      }
      close={close}
    />
  ) : null;
}

export function CustodyModal({ data, initial, onSave, close }) {
  let [i, u] = useState(initial ? initial.label : ""),
    [s, o] = useState(initial ? initial.holder : data.holders[0] ? data.holders[0].name : ""),
    [d, c] = useState(initial ? initial.school_id : data.schools[0] ? data.schools[0].id : ""),
    [p, m] = useState((initial && initial.user) || ""),
    [r, v] = useState(initial ? initial.note : ""),
    S = (data.users || []).filter((b) => b.role !== "manager"),
    N = () => {
      if (!i.trim()) return;
      let b = {
        label: i.trim(),
        holder: s,
        school_id: d,
        note: r,
        user: p,
      };
      initial ? ((b.id = initial.id), onSave(b, !1)) : onSave(b, !0);
    };
  return (
    <Modal title={initial ? "تعديل العهدة" : "عهدة جديدة"} close={close}>
      <Field label="مسمّى العهدة">
        <input value={i} onChange={(b) => u(b.target.value)} />
      </Field>
      <Field label="اسم المسئول (للعرض)">
        <select value={s} onChange={(b) => o(b.target.value)}>
          {data.holders.map((b) => (
            <option key={b.id} value={b.name}>
              {b.name}
              {" — "}
              {b.title}
            </option>
          ))}
        </select>
      </Field>
      <Field label="المستخدم المسئول (يرى هذه العهدة فقط)">
        <select value={p} onChange={(b) => m(b.target.value)}>
          <option value="">— بدون ربط —</option>
          {S.map((b) => (
            <option key={b.id} value={b.username}>
              {b.name}
              {" ("}
              {b.username})
            </option>
          ))}
        </select>
      </Field>
      <Field label="المدرسة">
        <select value={d} onChange={(b) => c(b.target.value)}>
          {data.schools.map((b) => (
            <option key={b.id} value={b.id}>
              {CAT_LABEL[b.category || "school"]}
              {" · "}
              {b.name}
            </option>
          ))}
        </select>
      </Field>
      <Field label="ملاحظات">
        <input value={r} onChange={(b) => v(b.target.value)} />
      </Field>
      {!initial && (
        <div
          style={{
            fontSize: 12,
            color: "var(--ink-soft)",
          }}
        >
          ملاحظة: أضف قيمة العهدة من زر «إضافة عهدة» بعد الحفظ.
        </div>
      )}
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" onClick={N}>
          حفظ
        </button>
      </div>
    </Modal>
  );
}

export function TrancheModal({ custody, onSave, close }) {
  let [n, i] = useState(""),
    [u, s] = useState(today()),
    [o, d] = useState("");
  return (
    <Modal title={"إضافة عهدة — " + custody.label} close={close}>
      <div className="grid2">
        <Field label="القيمة (ج.م)">
          <input type="number" step="any" value={n} onChange={(c) => i(c.target.value)} />
        </Field>
        <Field label="التاريخ">
          <input type="date" value={u} onChange={(c) => s(c.target.value)} />
        </Field>
      </div>
      <Field label="ملاحظة">
        <input value={o} onChange={(c) => d(c.target.value)} placeholder="تعزيز / دفعة ثانية…" />
      </Field>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button
          className="btn teal"
          onClick={() =>
            n &&
            onSave({
              custody_id: custody.id,
              amount: Number(n),
              date: u,
              note: o,
            })
          }
        >
          إضافة
        </button>
      </div>
    </Modal>
  );
}

export function ApproveModal({ e: t, data, onDecide, close }) {
  let [i, u] = useState(data.approvers[0] ? data.approvers[0].name : ""),
    [s, o] = useState("");
  return (
    <Modal title="مراجعة واعتماد المصروف" close={close}>
      <div
        style={{
          background: "#F6F9FB",
          border: "1px solid var(--line)",
          borderRadius: 12,
          padding: 14,
          marginBottom: 14,
        }}
      >
        <div
          style={{
            fontFamily: "Cairo",
            fontWeight: 800,
            fontSize: 22,
            color: "var(--navy)",
          }}
        >
          {fmt(t.amount)}
          {" ج.م"}
        </div>
        <div
          style={{
            margin: "6px 0",
          }}
        >
          {t.description}
        </div>
        <div
          style={{
            fontSize: 12,
            color: "var(--ink-soft)",
          }}
        >
          {"البند: "}
          {t.spend_item || lineName(data, t.line_id)}
          {" · "}
          {t.date}
          {" · أدخله: "}
          {t.created_by}
        </div>
      </div>
      <Field label="المعتمِد">
        <select value={i} onChange={(d) => u(d.target.value)}>
          {data.approvers.map((d) => (
            <option key={d.id} value={d.name}>
              {d.name}
            </option>
          ))}
        </select>
      </Field>
      <Field label="ملاحظة">
        <input value={s} onChange={(d) => o(d.target.value)} />
      </Field>
      <div className="modal-actions">
        <button className="btn danger-ghost" onClick={() => onDecide("rejected", i, s)}>
          رفض
        </button>
        <span className="spacer" />
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" onClick={() => onDecide("approved", i, s)}>
          اعتماد
        </button>
      </div>
    </Modal>
  );
}

export function ImportModal({ data, school_id, act, onDone, close }) {
  let [u, s] = useState(school_id ? "existing" : "new"),
    [o, d] = useState(school_id || (data.schools[0] ? data.schools[0].id : "")),
    [c, p] = useState(""),
    [m, r] = useState("school"),
    [v, S] = useState(null),
    [N, b] = useState(""),
    [f, h] = useState(!1),
    y = useRef(),
    g = async (C) => {
      if (C) {
        (b(""), S(null));
        try {
          let _ = await readBudgetFile(C);
          if (!_.lines.length) {
            b("لم يتم العثور على بنود — تأكد من أن الملف يحتوى عمود «البند» وعمود القيمة.");
            return;
          }
          S(
            Object.assign(
              {
                fileName: C.name,
              },
              _,
            ),
          );
        } catch (_) {
          b(_.message || "تعذّر قراءة الملف");
        }
      }
    },
    x = async () => {
      if (!v) return;
      if (u === "new" && !c.trim()) {
        b("اكتب اسم الجهة الجديدة");
        return;
      }
      h(!0);
      let C = {
        lines: v.lines,
      };
      u === "new"
        ? (C.newSchool = {
            name: c.trim(),
            category: m,
            type: CAT_LABEL[m],
            period: "2026/2027",
            students: 0,
          })
        : (C.school_id = o);
      try {
        let _ = await act("importBudget", C);
        onDone(`تم استيراد ${(_ && _.count) || v.lines.length} بنداً بنجاح`);
      } catch (_) {
        h(!1);
      }
    };
  return (
    <Modal title="استيراد موازنة من Excel / CSV" close={close} wide={!0}>
      <div
        style={{
          fontSize: 12.5,
          color: "var(--ink-soft)",
          marginBottom: 12,
          lineHeight: 1.7,
        }}
      >
        يقرأ النظام ملفات الموازنة بنفس تنسيق موازنات بدر ودمياط (عمود «البند» و«الأجمالى» مع الأقسام)، أو أى ملف
        بأعمدة: القسم / البند / الموازنة. تُستبدل بنود الجهة المختارة بالبنود المستوردة.
      </div>
      <div
        style={{
          display: "flex",
          gap: 8,
          marginBottom: 12,
        }}
      >
        <button className={"btn sm " + (u === "existing" ? "primary" : "ghost")} onClick={() => s("existing")}>
          جهة موجودة
        </button>
        <button className={"btn sm " + (u === "new" ? "primary" : "ghost")} onClick={() => s("new")}>
          جهة جديدة
        </button>
      </div>
      {u === "existing" ? (
        <Field label="الجهة المستهدفة (ستُستبدل موازنتها)">
          <select value={o} onChange={(C) => d(C.target.value)}>
            {data.schools.map((C) => (
              <option key={C.id} value={C.id}>
                {CAT_LABEL[C.category || "school"]}
                {" · "}
                {C.name}
              </option>
            ))}
          </select>
        </Field>
      ) : (
        <div className="grid2">
          <Field label="اسم الجهة الجديدة">
            <input value={c} onChange={(C) => p(C.target.value)} placeholder="مثال: مدرسة ابدأ — القاهرة" />
          </Field>
          <Field label="النوع">
            <select value={m} onChange={(C) => r(C.target.value)}>
              {CAT_OPTIONS.map(([C, _]) => (
                <option key={C} value={C}>
                  {_}
                </option>
              ))}
            </select>
          </Field>
        </div>
      )}
      <Field label="ملف الموازنة (.xlsx أو .csv)">
        <div className="file-row">
          <button className="btn ghost sm" onClick={() => y.current && y.current.click()}>
            اختيار ملف
          </button>
          <input ref={y} type="file" hidden={!0} accept=".xlsx,.xls,.csv" onChange={(C) => g(C.target.files[0])} />
          {v && (
            <span className="file-name">
              {"📎 "}
              {v.fileName}
            </span>
          )}
        </div>
      </Field>
      {N && (
        <div
          className="warn-banner"
          style={{
            background: "#FBE1E2",
            color: "#A31820",
          }}
        >
          {N}
        </div>
      )}
      {v && (
        <div
          style={{
            background: "#F4FBF7",
            border: "1px solid var(--line)",
            borderRadius: 10,
            padding: 12,
            marginBottom: 12,
          }}
        >
          <div
            style={{
              fontWeight: 700,
              color: "var(--green)",
            }}
          >
            {"تمت القراءة: "}
            {v.lines.length}
            {" بند · إجمالى "}
            {fmt(v.total)}
            {" ج.م"}
          </div>
          <div
            style={{
              fontSize: 12,
              color: "var(--ink-soft)",
              marginTop: 6,
              maxHeight: 120,
              overflow: "auto",
            }}
          >
            {v.lines.slice(0, 6).map((C, _) => (
              <div key={_}>
                {"• "}
                {C.section}
                {" — "}
                {C.name}
                {": "}
                {fmt(C.allocated)}
              </div>
            ))}
            {v.lines.length > 6 && (
              <div>
                … و{v.lines.length - 6}
                {" بند آخر"}
              </div>
            )}
          </div>
        </div>
      )}
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" disabled={!v || f} onClick={x}>
          {f ? "جارٍ الاستيراد…" : "استيراد وحفظ"}
        </button>
      </div>
    </Modal>
  );
}

export function EditExpenseModal({ data, e: l, onSave, close }) {
  let i = data.lines.filter((S) => String(S.school_id) === String(l.school_id)),
    [u, s] = useState(l.line_id || (i[0] ? i[0].id : "")),
    [o, d] = useState(l.amount),
    [c, p] = useState(l.date || today()),
    [m, r] = useState(l.description || ""),
    v = () => {
      o &&
        onSave({
          date: c,
          line_id: u,
          amount: Number(o) || 0,
          description: m.trim(),
        });
    };
  return (
    <Modal title="تعديل الصرف" close={close}>
      <div
        style={{
          fontSize: 12,
          color: "var(--ink-soft)",
          marginBottom: 10,
        }}
      >
        يمكن التعديل طالما لم يُعتمد الصرف بعد.
      </div>
      {i.length > 0 && (
        <Field label="بند الموازنة">
          <select value={u} onChange={(S) => s(S.target.value)}>
            {i.map((S) => (
              <option key={S.id} value={S.id}>
                {S.section ? S.section + " — " : ""}
                {S.name}
              </option>
            ))}
          </select>
        </Field>
      )}
      <div className="grid2">
        <Field label="المبلغ (ج.م)">
          <input type="number" step="any" value={o} onChange={(S) => d(S.target.value)} />
        </Field>
        <Field label="التاريخ">
          <input type="date" value={c} onChange={(S) => p(S.target.value)} />
        </Field>
      </div>
      <Field label="البيان">
        <input value={m} onChange={(S) => r(S.target.value)} />
      </Field>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" onClick={v}>
          حفظ
        </button>
      </div>
    </Modal>
  );
}

export function ImportSalariesModal({ data, school_id, act, onDone, close }) {
  let [u, s] = useState(school_id || (data.schools[0] ? data.schools[0].id : "")),
    [o, d] = useState(null),
    [c, p] = useState(""),
    [m, r] = useState(null),
    [v, S] = useState(12),
    [N, b] = useState(""),
    [f, h] = useState(!1),
    y = useRef(),
    g = async (A) => {
      if (A) {
        (b(""), r(null), d(null));
        try {
          let z = await readWorkbook(A);
          d(z);
          let E = z.sheets.find((j) => /رواتب|salar/i.test(j)) || z.sheets[0];
          (p(E), x(z, E));
        } catch (z) {
          b(z.message || "تعذّر قراءة الملف");
        }
      }
    },
    x = (A, z) => {
      try {
        let E = parseSalaryRows(A.get(z));
        if (!E.rows.length) {
          (b("لم يتم العثور على رواتب في هذه الورقة — تأكد من الأعمدة (اسم الموظف/المسمى الوظيفى/الراتب الشامل)."),
            r(null));
          return;
        }
        (b(""), r(E));
      } catch (E) {
        b(E.message);
      }
    },
    C = (A) => {
      (p(A), o && x(o, A));
    },
    _ = async () => {
      if (!m) return;
      h(!0);
      let A = m.rows.map((z) => ({
        name: z.name,
        job: z.job,
        monthly: z.monthly,
        months: Number(v) || 12,
      }));
      try {
        let z = await act("importSalaries", {
          school_id: u,
          rows: A,
        });
        onDone(`تم استيراد ${(z && z.count) || A.length} راتباً`);
      } catch (z) {
        h(!1);
      }
    };
  return (
    <Modal title="استيراد رواتب من Excel / CSV" close={close} wide={!0}>
      <div
        style={{
          fontSize: 12.5,
          color: "var(--ink-soft)",
          marginBottom: 12,
          lineHeight: 1.7,
        }}
      >
        يقرأ النظام ملفات الرواتب بنفس تنسيق ملفك (أعمدة: اسم الموظف / المسمى الوظيفى / الراتب الشامل)، أو تنسيق الشركة
        (رواتب الموظفين / الراتب الشهرى الشامل). تُستبدل رواتب الجهة المختارة بالمستوردة.
      </div>
      <div className="grid2">
        <Field label="الجهة المستهدفة">
          <select value={u} onChange={(A) => s(A.target.value)}>
            {data.schools.map((A) => (
              <option key={A.id} value={A.id}>
                {CAT_LABEL[A.category || "school"]}
                {" · "}
                {A.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="عدد الأشهر (لكل موظف)">
          <input type="number" step="any" value={v} onChange={(A) => S(A.target.value)} />
        </Field>
      </div>
      <Field label="الملف (.xlsx أو .csv)">
        <div className="file-row">
          <button className="btn ghost sm" onClick={() => y.current && y.current.click()}>
            اختيار ملف
          </button>
          <input ref={y} type="file" hidden={!0} accept=".xlsx,.xls,.csv" onChange={(A) => g(A.target.files[0])} />
          {o && (
            <span className="file-name">
              {"📎 "}
              {o.sheets.length}
              {" ورقة"}
            </span>
          )}
        </div>
      </Field>
      {o && o.sheets.length > 1 && (
        <Field label="اختر ورقة الرواتب">
          <select value={c} onChange={(A) => C(A.target.value)}>
            {o.sheets.map((A) => (
              <option key={A} value={A}>
                {A}
              </option>
            ))}
          </select>
        </Field>
      )}
      {N && (
        <div
          className="warn-banner"
          style={{
            background: "#FBE1E2",
            color: "#A31820",
          }}
        >
          {N}
        </div>
      )}
      {m && (
        <div
          style={{
            background: "#F4FBF7",
            border: "1px solid var(--line)",
            borderRadius: 10,
            padding: 12,
            marginBottom: 12,
          }}
        >
          <div
            style={{
              fontWeight: 700,
              color: "var(--green)",
            }}
          >
            {"تمت القراءة: "}
            {m.rows.length}
            {" موظف · إجمالى شهرى "}
            {fmt(m.total)}
            {" ج.م"}
          </div>
          <div
            style={{
              fontSize: 12,
              color: "var(--ink-soft)",
              marginTop: 6,
              maxHeight: 120,
              overflow: "auto",
            }}
          >
            {m.rows.slice(0, 6).map((A, z) => (
              <div key={z}>
                {"• "}
                {A.name}
                {" — "}
                {A.job}
                {": "}
                {fmt(A.monthly)}
              </div>
            ))}
            {m.rows.length > 6 && (
              <div>
                … و{m.rows.length - 6}
                {" موظف آخر"}
              </div>
            )}
          </div>
        </div>
      )}
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" disabled={!m || f} onClick={_}>
          {f ? "جارٍ الاستيراد…" : "استيراد وحفظ"}
        </button>
      </div>
    </Modal>
  );
}

export function SalaryModal({ initial, onSave, close }) {
  let n = initial && initial.id,
    [i, u] = useState(n ? initial.name : ""),
    [s, o] = useState(n ? initial.job : ""),
    [d, c] = useState(n ? initial.monthly : ""),
    [p, m] = useState(n ? initial.months : 12),
    r = () => {
      if (!i.trim() || !d) return;
      let v = {
        school_id: initial.school_id,
        name: i.trim(),
        job: s.trim(),
        monthly: Number(d) || 0,
        months: Number(p) || 0,
      };
      n ? ((v.id = initial.id), onSave(v, !1)) : onSave(v, !0);
    };
  return (
    <Modal title={n ? "تعديل راتب" : "إضافة راتب موظف"} close={close}>
      <div className="grid2">
        <Field label="اسم الموظف">
          <input value={i} onChange={(v) => u(v.target.value)} />
        </Field>
        <Field label="الوظيفة">
          <input value={s} onChange={(v) => o(v.target.value)} />
        </Field>
      </div>
      <div className="grid2">
        <Field label="الراتب الشهرى (ج.م)">
          <input type="number" step="any" value={d} onChange={(v) => c(v.target.value)} />
        </Field>
        <Field label="عدد الأشهر">
          <input type="number" step="any" value={p} onChange={(v) => m(v.target.value)} />
        </Field>
      </div>
      <div
        style={{
          fontSize: 12.5,
          color: "var(--ink-soft)",
          marginBottom: 8,
        }}
      >
        {"الإجمالى: "}
        {fmt((Number(d) || 0) * (Number(p) || 0))}
        {" ج.م"}
      </div>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" onClick={r}>
          حفظ
        </button>
      </div>
    </Modal>
  );
}

export function TempBudgetModal({ data, onSave, close }) {
  let [n, i] = useState(data.schools[0] ? data.schools[0].id : ""),
    [u, s] = useState(""),
    [o, d] = useState(today()),
    [c, p] = useState(""),
    [m, r] = useState(""),
    v = () => {
      !u.trim() ||
        !m ||
        !o ||
        !c ||
        onSave({
          school_id: n,
          name: u.trim(),
          dfrom: o,
          dto: c,
          amount: Number(m) || 0,
        });
    };
  return (
    <Modal title="موازنة مؤقتة لفترة" close={close}>
      <Field label="الجهة">
        <select value={n} onChange={(S) => i(S.target.value)}>
          {data.schools.map((S) => (
            <option key={S.id} value={S.id}>
              {CAT_LABEL[S.category || "school"]}
              {" · "}
              {S.name}
            </option>
          ))}
        </select>
      </Field>
      <Field label="اسم الموازنة">
        <input value={u} onChange={(S) => s(S.target.value)} placeholder="مثال: حملة تسويق صيفية" />
      </Field>
      <div className="grid2">
        <Field label="من">
          <input type="date" value={o} onChange={(S) => d(S.target.value)} />
        </Field>
        <Field label="إلى">
          <input type="date" value={c} onChange={(S) => p(S.target.value)} />
        </Field>
      </div>
      <Field label="قيمة الموازنة (ج.م)">
        <input type="number" step="any" value={m} onChange={(S) => r(S.target.value)} />
      </Field>
      <div
        style={{
          fontSize: 12,
          color: "var(--ink-soft)",
        }}
      >
        يُتابَع الصرف تلقائياً من المصروفات المُسوّاة لهذه الجهة خلال الفترة.
      </div>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" onClick={v}>
          إنشاء
        </button>
      </div>
    </Modal>
  );
}

export function UploadDocModal({ e: t, act, showToast, close }) {
  let [i, u] = useState("file"),
    [s, o] = useState(t.doc_type || DOC_TYPES[0]),
    [d, c] = useState(null),
    [p, m] = useState(""),
    r = useRef(),
    [v, S] = useState(!1),
    N = (f) => {
      if (f) {
        if (f.size > 4.5 * 1024 * 1024) {
          showToast("حجم الملف أكبر من 4.5 ميجا", "err");
          return;
        }
        c(f);
      }
    },
    b = () => {
      if (i === "link") {
        if (!/^https?:\/\//i.test(p.trim())) {
          showToast("أدخل رابطاً صحيحاً يبدأ بـ http", "err");
          return;
        }
        (S(!0),
          act("uploadDoc", {
            id: t.id,
            link: p.trim(),
            filename: "رابط مستند",
            doc_type: s,
          })
            .then(() => {
              (showToast("تم حفظ رابط المستند"), close());
            })
            .catch(() => S(!1)));
        return;
      }
      if (!d) {
        showToast("اختر ملفاً", "err");
        return;
      }
      S(!0);
      let f = new FileReader();
      ((f.onload = async () => {
        let h = f.result,
          y = String(h).split(",")[1];
        try {
          (await act("uploadDoc", {
            id: t.id,
            filename: d.name,
            mimeType: d.type,
            dataBase64: y,
            dataUrl: h,
            doc_type: s,
          }),
            showToast("تم رفع المستند"),
            close());
        } catch (g) {
          S(!1);
        }
      }),
        f.readAsDataURL(d));
    };
  return (
    <Modal title="مستند الصرف" close={close}>
      <div
        style={{
          marginBottom: 10,
        }}
      >
        {fmt(t.amount)}
        {" ج.م — "}
        {t.description}
      </div>
      <div
        style={{
          display: "flex",
          gap: 8,
          marginBottom: 12,
        }}
      >
        <button className={"btn sm " + (i === "file" ? "primary" : "ghost")} onClick={() => u("file")}>
          رفع ملف
        </button>
        <button className={"btn sm " + (i === "link" ? "primary" : "ghost")} onClick={() => u("link")}>
          رابط (لينك)
        </button>
      </div>
      <Field label="نوع المستند">
        <select value={s} onChange={(f) => o(f.target.value)}>
          {DOC_TYPES.map((f) => (
            <option key={f} value={f}>
              {f}
            </option>
          ))}
        </select>
      </Field>
      {i === "file" ? (
        <Field label="الملف (صورة / PDF)">
          <div className="file-row">
            <button className="btn ghost sm" onClick={() => r.current && r.current.click()}>
              {d ? "تغيير الملف" : "اختيار ملف"}
            </button>
            <input
              ref={r}
              type="file"
              hidden={!0}
              accept="image/*,application/pdf"
              onChange={(f) => N(f.target.files[0])}
            />
            {d && (
              <span className="file-name">
                {"📎 "}
                {d.name}
              </span>
            )}
          </div>
        </Field>
      ) : (
        <Field label="رابط المستند">
          <input
            value={p}
            onChange={(f) => m(f.target.value)}
            placeholder="https://drive.google.com/..."
            style={{
              direction: "ltr",
              textAlign: "left",
            }}
          />
        </Field>
      )}
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" disabled={v} onClick={b}>
          {v ? "جارٍ الحفظ…" : "حفظ"}
        </button>
      </div>
    </Modal>
  );
}

export function CentralModal({ data, school_id, act, onDone, close }) {
  let [u, s] = useState(school_id || (data.schools[0] ? data.schools[0].id : "")),
    o = data.lines.filter((z) => String(z.school_id) === String(u)),
    [d, c] = useState(o[0] ? o[0].id : ""),
    [p, m] = useState(""),
    [r, v] = useState(today()),
    [S, N] = useState(""),
    [b, f] = useState(null),
    h = useRef(),
    [y, g] = useState(!1),
    [x, C] = useState(DOC_TYPES[0]);
  useEffect(() => {
    let z = data.lines.filter((E) => String(E.school_id) === String(u));
    c(z[0] ? z[0].id : "");
  }, [u]);
  let _ = (z) => {
      if (!z) return;
      if (z.size > 4.5 * 1024 * 1024) {
        alert("حجم الملف أكبر من 4.5 ميجا");
        return;
      }
      let E = new FileReader();
      ((E.onload = () =>
        f({
          name: z.name,
          type: z.type,
          dataUrl: E.result,
        })),
        E.readAsDataURL(z));
    },
    A = async () => {
      if (!p || !d) return;
      g(!0);
      let z = {
        expense: {
          school_id: u,
          line_id: d,
          amount: Number(p) || 0,
          date: r,
          description: S.trim(),
        },
      };
      b &&
        ((z.dataUrl = b.dataUrl),
        (z.dataBase64 = String(b.dataUrl).split(",")[1]),
        (z.mimeType = b.type),
        (z.filename = b.name),
        (z.doc_type = x));
      try {
        (await act("addCentral", z), onDone("تم تسجيل الشراء المركزى وخصمه من الموازنة"));
      } catch (E) {
        g(!1);
      }
    };
  return (
    <Modal title="تسجيل شراء مركزى (يُخصم من الموازنة مباشرة)" close={close}>
      <Field label="المدرسة">
        <select value={u} onChange={(z) => s(z.target.value)}>
          {data.schools.map((z) => (
            <option key={z.id} value={z.id}>
              {CAT_LABEL[z.category || "school"]}
              {" · "}
              {z.name}
            </option>
          ))}
        </select>
      </Field>
      <Field label="بند الموازنة">
        <select value={d} onChange={(z) => c(z.target.value)}>
          {o.map((z) => (
            <option key={z.id} value={z.id}>
              {z.section ? z.section + " — " : ""}
              {z.name}
            </option>
          ))}
        </select>
      </Field>
      <div className="grid2">
        <Field label="المبلغ (ج.م)">
          <input type="number" step="any" value={p} onChange={(z) => m(z.target.value)} />
        </Field>
        <Field label="التاريخ">
          <input type="date" value={r} onChange={(z) => v(z.target.value)} />
        </Field>
      </div>
      <Field label="البيان">
        <input value={S} onChange={(z) => N(z.target.value)} placeholder="ما تم شراؤه مركزياً" />
      </Field>
      <Field label="نوع المستند">
        <select value={x} onChange={(z) => C(z.target.value)}>
          {DOC_TYPES.map((z) => (
            <option key={z} value={z}>
              {z}
            </option>
          ))}
        </select>
      </Field>
      <Field label="مستند الشراء (اختيارى)">
        <div className="file-row">
          <button className="btn ghost sm" onClick={() => h.current && h.current.click()}>
            {b ? "تغيير الملف" : "رفع ملف"}
          </button>
          <input
            ref={h}
            type="file"
            hidden={!0}
            accept="image/*,application/pdf"
            onChange={(z) => _(z.target.files[0])}
          />
          {b && (
            <span className="file-name">
              {"📎 "}
              {b.name}
            </span>
          )}
        </div>
      </Field>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" disabled={y} onClick={A}>
          {y ? "…" : "تسجيل الشراء"}
        </button>
      </div>
    </Modal>
  );
}

export function ReviewModal({ e: t, onSave, close }) {
  let [n, i] = useState(t.review_status || "مستوفى"),
    [u, s] = useState(t.review_note || ""),
    o = () => {
      if (n === "مستوفى")
        onSave({
          review_status: "مستوفى",
          settled: "نعم",
          review_note: u.trim(),
        });
      else {
        if (!u.trim()) {
          alert("اكتب ملاحظة توضّح النقص المطلوب استيفاؤه");
          return;
        }
        onSave({
          review_status: "ناقص",
          settled: "",
          review_note: u.trim(),
        });
      }
    };
  return (
    <Modal title="مراجعة المستند" close={close}>
      <div
        style={{
          marginBottom: 10,
        }}
      >
        {fmt(t.amount)}
        {" ج.م — "}
        {t.description}
      </div>
      {t.doc_url && (
        <DocLink expense={t} className="btn ghost sm" style={{ marginBottom: 12, display: "inline-block" }}>
          📎 فتح المستند المرفوع
        </DocLink>
      )}
      <Field label="نتيجة المراجعة">
        <select value={n} onChange={(d) => i(d.target.value)}>
          <option value="مستوفى">المستند مستوفٍ — تمت التسوية</option>
          <option value="ناقص">المستند ناقص — إرسال ملاحظة لمسئول العهدة</option>
        </select>
      </Field>
      <Field label="ملاحظة">
        <input
          value={u}
          onChange={(d) => s(d.target.value)}
          placeholder={n === "ناقص" ? "سبب عدم الاستيفاء المطلوب" : "اختيارى"}
        />
      </Field>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className={"btn " + (n === "مستوفى" ? "teal" : "primary")} onClick={o}>
          {n === "مستوفى" ? "تأكيد التسوية" : "إرسال الملاحظة"}
        </button>
      </div>
    </Modal>
  );
}

export function SchoolModal({ initial, onSave, close }) {
  let [n, i] = useState(initial ? initial.name : ""),
    [u, s] = useState((initial && initial.category) || "school"),
    [o, d] = useState(initial ? initial.period : "2026/2027"),
    [c, p] = useState(initial ? initial.students : ""),
    m = () => {
      if (!n.trim()) return;
      let r = {
        name: n.trim(),
        category: u,
        type: CAT_LABEL[u] || "جهة",
        period: o,
        students: Number(c) || 0,
      };
      initial ? ((r.id = initial.id), (r.active = initial.active), onSave(r, !1)) : onSave(r, !0);
    };
  return (
    <Modal title={initial ? "تعديل الجهة" : "جهة / وحدة جديدة"} close={close}>
      <Field label="الاسم">
        <input value={n} onChange={(r) => i(r.target.value)} placeholder="اسم المدرسة / الشركة / الدورة" />
      </Field>
      <div className="grid2">
        <Field label="النوع (التصنيف)">
          <select value={u} onChange={(r) => s(r.target.value)}>
            {CAT_OPTIONS.map(([r, v]) => (
              <option key={r} value={r}>
                {v}
              </option>
            ))}
          </select>
        </Field>
        <Field label="عدد الطلاب/المتدربين">
          <input type="number" step="any" value={c} onChange={(r) => p(r.target.value)} />
        </Field>
      </div>
      <Field label="الفترة">
        <input value={o} onChange={(r) => d(r.target.value)} />
      </Field>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" onClick={m}>
          حفظ
        </button>
      </div>
    </Modal>
  );
}

export function LineModal({ initial, onSave, close }) {
  let [n, i] = useState(initial && initial.name ? initial.name : ""),
    [u, s] = useState(initial && initial.section ? initial.section : "تكلفة التشغيل"),
    [o, d] = useState(initial && initial.allocated !== void 0 ? initial.allocated : ""),
    [c, p] = useState(initial && initial.note ? initial.note : ""),
    m = initial && initial.id;
  return (
    <Modal title={m ? "تعديل البند" : "إضافة بند"} close={close}>
      <Field label="القسم">
        <input value={u} onChange={(v) => s(v.target.value)} placeholder="تكلفة التدريس / التشغيل / إدارية…" />
      </Field>
      <Field label="اسم البند">
        <input value={n} onChange={(v) => i(v.target.value)} />
      </Field>
      <Field label="الموازنة السنوية (ج.م)">
        <input type="number" step="any" value={o} onChange={(v) => d(v.target.value)} />
      </Field>
      <Field label="ملاحظات">
        <input value={c} onChange={(v) => p(v.target.value)} />
      </Field>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button
          className="btn primary"
          onClick={() => {
            if (!n.trim()) return;
            let v = {
              school_id: initial.school_id,
              section: u.trim(),
              name: n.trim(),
              allocated: Number(o) || 0,
              note: c,
            };
            m ? ((v.id = initial.id), onSave(v, !1)) : onSave(v, !0);
          }}
        >
          حفظ
        </button>
      </div>
    </Modal>
  );
}

const ROLE_LABEL_V6 = { manager: "الأدمن", supervisor: "مدير مباشر", accountant: "المدير المالى", custody: "مسئول عهدة" };
export function UserModal({ initial, data, onSave, close }) {
  let [i, u] = useState(initial ? initial.name : ""),
    [s, o] = useState(initial ? initial.username : ""),
    [d, c] = useState(""),
    [p, m] = useState((initial && initial.email) || ""),
    [r, v] = useState(initial ? initial.role : "custody"),
    [S, N] = useState(initial ? initial.schools === "*" : !1),
    [b, f] = useState(
      initial && initial.schools !== "*"
        ? String(initial.schools)
            .split(",")
            .map((C) => C.trim())
            .filter(Boolean)
        : [],
    ),
    [h, y] = useState(initial ? yes(initial.active) : !0),
    [pm, setPm] = useState(permsOf(initial ? { role: initial.role, perms: initial.perms } : { role: "custody" })),
    [pmTouched, setPmTouched] = useState(!!(initial && initial.perms)),
    [mgr, setMgr] = useState((initial && initial.manager_id) || ""),
    [dept, setDept] = useState((initial && initial.dept) || ""),
    g = (C) => f((_) => (_.indexOf(C) >= 0 ? _.filter((A) => A !== C) : [..._, C])),
    x = () => {
      if (!i.trim() || !s.trim() || (!initial && !d)) return;
      let C = {
        name: i.trim(),
        username: s.trim(),
        pin: d ? String(d) : "",
        email: p.trim(),
        role: r,
        schools: r === "manager" || S ? "*" : b.join(","),
        active: h ? "نعم" : "لا",
        manager_id: r === "manager" ? "" : mgr,
        dept: dept.trim(),
      };
      // الصلاحيات يعدّلها الأدمن فقط (الخادم يرفض غير ذلك)
      if (data.me.role === "manager") C.perms = r === "manager" ? "" : permsString(r, pmTouched ? pm : ROLE_DEFAULTS[roleKey(r)] || []);
      initial ? ((C.id = initial.id), onSave(C, !1)) : onSave(C, !0);
    };
  return (
    <Modal title={initial ? "تعديل مستخدم" : "مستخدم جديد"} close={close}>
      <div className="grid2">
        <Field label="الاسم">
          <input value={i} onChange={(C) => u(C.target.value)} />
        </Field>
        <Field label="الإيميل (للإشعارات)">
          <input value={p} onChange={(C) => m(C.target.value)} placeholder="name@ebda.com.eg" />
        </Field>
      </div>
      <div className="grid2">
        <Field label="اسم المستخدم">
          <input value={s} onChange={(C) => o(C.target.value)} />
        </Field>
        <Field label="كلمة السر (PIN)">
          <input value={d} onChange={(C) => c(C.target.value)} />
        </Field>
      </div>
      <Field label="الدور">
        <select value={r} onChange={(C) => (v(C.target.value), pmTouched || setPm(ROLE_DEFAULTS[roleKey(C.target.value)] || []))}>
          <option value="manager">الأدمن (كل الصلاحيات وإدارة المستخدمين)</option>
          <option value="accountant">المدير المالى (الموازنات والعهد والاعتماد المالى والتسوية)</option>
          <option value="supervisor">المدير المباشر (اعتماد طلبات ومصروفات جهاته فقط)</option>
          <option value="custody">مسئول العهدة (عهدته فقط: تسجيل الصرف والمستندات وطلب عهدة)</option>
        </select>
      </Field>
      {r !== "manager" && (
        <div className="grid2">
          <Field label={r === "custody" ? "المدير المباشر (يعتمد مصروفاته وطلباته)" : "المدير المباشر (اختيارى)"}>
            <select value={mgr} onChange={(C) => setMgr(C.target.value)} data-testid="user-manager">
              <option value="">— حسب نطاق المكان (أى مدير مباشر للمكان) —</option>
              {(data.users || [])
                .filter((x) => (x.role === "supervisor" || x.role === "manager") && (!initial || x.id !== initial.id) && yes(x.active))
                .map((x) => (
                  <option key={x.id} value={x.id}>
                    {x.name} — {ROLE_LABEL_V6[x.role] || x.role}
                  </option>
                ))}
            </select>
          </Field>
          <Field label="القسم (اختيارى)">
            <input value={dept} onChange={(C) => setDept(C.target.value)} placeholder="مثال: شئون الطلاب" />
          </Field>
        </div>
      )}
      {r !== "manager" && (
        <div
          style={{
            marginBottom: 12,
          }}
        >
          <label
            style={{
              display: "flex",
              gap: 8,
              alignItems: "center",
              fontSize: 13,
              marginBottom: 8,
            }}
          >
            <input type="checkbox" checked={S} onChange={(C) => N(C.target.checked)} />
            {" كل المدارس"}
          </label>
          {!S && (
            <div className="chips-list">
              {data.schools.map((C) => (
                <label
                  key={C.id}
                  className="cat-chip"
                  style={{
                    cursor: "pointer",
                  }}
                >
                  <input type="checkbox" checked={b.indexOf(C.id) >= 0} onChange={() => g(C.id)} /> {C.name}
                </label>
              ))}
            </div>
          )}
          {r === "custody" && (
            <div
              style={{
                fontSize: 12,
                color: "var(--ink-soft)",
                marginTop: 6,
              }}
            >
              اربط هذا المستخدم بعهدته من تبويب «العهد ‹ المستخدم المسئول».
            </div>
          )}
        </div>
      )}
      {r !== "manager" && data.me.role === "manager" && (
        <details className="perm-box" open={pmTouched}>
          <summary>الصلاحيات (ماذا يستطيع) — الافتراضى حسب الدور، ويمكن منح أو سحب صلاحية لهذا المستخدم</summary>
          <div className="perm-grid">
            {PERMS.map(([k, label, grp]) => {
              const def = (ROLE_DEFAULTS[roleKey(r)] || []).indexOf(k) >= 0;
              const on = pm.indexOf(k) >= 0;
              return (
                <label key={k} className={"perm " + (on !== def ? "changed" : "")}>
                  <input
                    type="checkbox"
                    checked={on}
                    onChange={() => (setPmTouched(true), setPm(on ? pm.filter((x) => x !== k) : pm.concat([k])))}
                  />
                  <span>
                    {label}
                    <small>
                      {grp}
                      {on !== def ? (on ? " · ممنوحة إضافياً" : " · مسحوبة") : def ? " · افتراضى للدور" : ""}
                    </small>
                  </span>
                </label>
              );
            })}
          </div>
          <div className="hint">النطاق (أين) يُحدَّد من اختيار المدارس أعلاه. الخادم يطبّق الصلاحيات على كل العمليات وليس الأزرار فقط.</div>
        </details>
      )}
      <label
        style={{
          display: "flex",
          gap: 8,
          alignItems: "center",
          fontSize: 13,
        }}
      >
        <input type="checkbox" checked={h} onChange={(C) => y(C.target.checked)} />
        {" الحساب مفعّل"}
      </label>
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" onClick={x}>
          حفظ
        </button>
      </div>
    </Modal>
  );
}
