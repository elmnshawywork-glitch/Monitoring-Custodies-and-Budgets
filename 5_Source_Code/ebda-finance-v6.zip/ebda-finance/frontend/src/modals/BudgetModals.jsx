import React, { useMemo, useRef, useState } from "react";
import { Modal, Field } from "../components/ui";
import { fmt } from "../lib/utils";
import { CAT_LABEL, FY_MONTHS, monthlyPlan } from "../lib/model";
import { lineKey, normAr } from "../lib/budget";
import {
  readBudgetWorkbook,
  parseBudgetSheet,
  guessEntity,
  looksLikeBudgetSheet,
  buildPreview,
  previewToPayload,
  downloadTemplate,
  STATUS_INFO,
} from "../lib/budgetImport";

const entityLabel = (s) => (s ? CAT_LABEL[s.category || "school"] + " · " + s.name + (s.period ? " · " + s.period : "") : "");

// ============================================================================ استيراد موازنة (معاينة قبل الحفظ)
export function BudgetImportWizard({ data, school_id, act, onDone, close, isAdmin }) {
  const [step, setStep] = useState(1); // 1 ملف · 2 ربط الشيتات + معاينة · 3 النتيجة
  const [sheets, setSheets] = useState([]);
  const [fileName, setFileName] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState("issues");
  const [actions, setActions] = useState({}); // تعديل المستخدم لإجراء سطر: idx → add/update/skip
  const [renameSimilar, setRenameSimilar] = useState(false);
  const [result, setResult] = useState(null);
  const fileRef = useRef();

  const readFile = async (f) => {
    if (!f) return;
    setErr("");
    setBusy(true);
    try {
      const raw = await readBudgetWorkbook(f);
      const list = raw.map((s) => {
        const parsed = parseBudgetSheet(s.rows);
        const include = looksLikeBudgetSheet(s.name, parsed);
        const g = include ? guessEntity(data.schools, s.name, parsed.title) : null;
        return { name: s.name, parsed, include, school_id: include ? (g ? g.id : raw.length === 1 && school_id ? school_id : "") : "" };
      });
      if (!list.some((s) => s.parsed.lines.length)) {
        setErr("لم يتم العثور على بنود موازنة — يجب أن يحتوى الشيت عمود «البند» وعمود المبلغ. حمّل القالب الجاهز للصيغة الصحيحة.");
        setBusy(false);
        return;
      }
      setSheets(list);
      setFileName(f.name);
      setActions({});
      setStep(2);
    } catch (e) {
      setErr(e.message || "تعذّر قراءة الملف");
    }
    setBusy(false);
  };

  const active = sheets.filter((s) => s.include);
  const preview = useMemo(() => buildPreview(data, active.map((s) => ({ name: s.name, parsed: s.parsed, school_id: s.school_id }))), [sheets, data]);
  const rows = preview.rows.map((r, i) => (actions[i] ? { ...r, action: actions[i] } : r));
  const count = (st) => rows.filter((r) => r.status === st).length;
  const willAdd = rows.filter((r) => (r.status === "new" && r.action !== "skip") || r.action === "add").length;
  const willUpdate = rows.filter((r) => r.match && r.action === "update" && (r.amountChanged || (renameSimilar && r.how !== "exact"))).length;
  const unmapped = active.filter((s) => !s.school_id);
  const shown = rows
    .map((r, i) => [r, i])
    .filter(([r]) =>
      filter === "all" ? true : filter === "issues" ? r.status !== "same" : filter === "changed" ? r.status === "changed" || r.amountChanged : r.status === filter,
    );

  const setSheet = (i, patch) => setSheets(sheets.map((s, j) => (j === i ? { ...s, ...patch } : s)));

  const doImport = async () => {
    if (unmapped.length) return setErr("اختر الجهة لكل شيت مُفعّل أو ألغِ تفعيله.");
    const lines = previewToPayload({ rows }, { renameSimilar });
    if (!lines.length) return setErr("لا توجد بنود للاستيراد.");
    setBusy(true);
    setErr("");
    try {
      const res = await act("importBudget", { mode: "merge", lines });
      setResult({
        added: res.added || 0,
        updated: res.updated || 0,
        unchanged: res.unchanged || 0,
        skipped: count("duplicate") + rows.filter((r) => r.action === "skip").length,
        errors: count("error"),
      });
      setStep(3);
    } catch (e) {
      setErr(e.message || "تعذّر الاستيراد");
    }
    setBusy(false);
  };

  return (
    <Modal title="استيراد موازنة من Excel" close={close} xl>
      <div className="wizard-steps">
        {["اختيار الملف", "المعاينة والمقارنة", "النتيجة"].map((t, i) => (
          <span key={i} className={"wstep " + (step === i + 1 ? "on" : step > i + 1 ? "done" : "")}>
            <b>{i + 1}</b> {t}
          </span>
        ))}
      </div>
      {err && <div className="warn-banner over">{err}</div>}

      {step === 1 && (
        <div>
          <p className="hint">
            يقرأ النظام كل شيتات الملف، ويربط كل شيت موازنة بجهته تلقائياً، ثم يقارن كل بند ببنود النظام ويعرض لك
            <b> الجديد والمختلف والمطابق والمكرر والأخطاء</b> قبل أى حفظ. <b>لا يُحذف أى بند موجود.</b>
          </p>
          <p className="hint">
            الصيغ المدعومة: ملفات موازنات المدارس الحالية (البند / التكلفة / العدد / المدة / الإجمالى مع عناوين الأقسام)،
            أو القالب الجدولى: القسم · البند · المبلغ · الملاحظات · وتوزيع شهرى اختيارى (سبتمبر ← أغسطس).
          </p>
          <div className="file-drop" onClick={() => fileRef.current && fileRef.current.click()}>
            <div style={{ fontSize: 28 }}>📄</div>
            <b>{busy ? "جارٍ القراءة…" : "اختر ملف الموازنة (.xlsx أو .csv)"}</b>
            <span>اضغط هنا لاختيار الملف</span>
            <input ref={fileRef} type="file" hidden accept=".xlsx,.xls,.csv" onChange={(e) => readFile(e.target.files[0])} />
          </div>
          <div className="modal-actions">
            <button className="btn ghost sm" onClick={() => downloadTemplate().catch((e) => setErr(e.message))}>
              تحميل قالب الاستيراد
            </button>
            <span className="spacer" />
            <button className="btn ghost" onClick={close}>
              إلغاء
            </button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div>
          <div className="hint" style={{ marginTop: 0 }}>
            📎 {fileName} — اختر الشيتات المطلوبة وجهة كل شيت:
          </div>
          <div className="sheet-map">
            {sheets.map((s, i) => (
              <div key={s.name} className={"sheet-row " + (s.include ? "" : "off")}>
                <label className="check">
                  <input
                    type="checkbox"
                    checked={s.include}
                    disabled={!s.parsed.lines.length}
                    onChange={(e) => setSheet(i, { include: e.target.checked })}
                  />{" "}
                  <b>{s.name}</b>
                </label>
                <span className="sheet-meta">
                  {s.parsed.lines.length
                    ? s.parsed.lines.length + " بند · " + fmt(s.parsed.lines.reduce((a, x) => a + (x.allocated || 0), 0)) + " ج.م"
                    : "لا يحتوى بنود موازنة"}
                </span>
                {s.include && (
                  <select value={s.school_id} onChange={(e) => setSheet(i, { school_id: e.target.value })}>
                    <option value="">— اختر الجهة —</option>
                    {data.schools.map((x) => (
                      <option key={x.id} value={x.id}>
                        {entityLabel(x)}
                      </option>
                    ))}
                  </select>
                )}
                {s.include && s.parsed.title && <span className="sheet-title">{s.parsed.title}</span>}
              </div>
            ))}
          </div>

          {!unmapped.length && active.length > 0 && (
            <>
              <div className="imp-kpis">
                {[
                  ["new", "جديد"],
                  ["changed", "مبلغ مختلف"],
                  ["similar", "اسم مشابه"],
                  ["same", "مطابق"],
                  ["duplicate", "مكرر"],
                  ["error", "أخطاء"],
                ].map(([k, t]) => (
                  <button key={k} className={"imp-kpi " + STATUS_INFO[k][1] + (filter === k ? " on" : "")} onClick={() => setFilter(filter === k ? "issues" : k)}>
                    <b>{k === "changed" ? rows.filter((r) => r.status === "changed" || r.amountChanged).length : count(k)}</b>
                    <span>{t}</span>
                  </button>
                ))}
                <div className="imp-kpi gray">
                  <b>{preview.missing.length}</b>
                  <span>فى النظام فقط</span>
                </div>
              </div>
              <div className="filters" style={{ marginBottom: 8 }}>
                <select value={filter} onChange={(e) => setFilter(e.target.value)}>
                  <option value="issues">ما يحتاج مراجعة (غير المطابق)</option>
                  <option value="all">كل البنود</option>
                  <option value="new">الجديد</option>
                  <option value="changed">المبالغ المختلفة</option>
                  <option value="similar">الأسماء المشابهة</option>
                  <option value="same">المطابق</option>
                  <option value="duplicate">المكرر</option>
                  <option value="error">الأخطاء</option>
                </select>
                <label className="check">
                  <input type="checkbox" checked={renameSimilar} onChange={(e) => setRenameSimilar(e.target.checked)} /> توحيد
                  أسماء البنود المشابهة حسب ملف Excel
                </label>
              </div>
              <div className="table-wrap" style={{ maxHeight: 380, overflow: "auto" }}>
                <table className="tbl imp-tbl">
                  <thead>
                    <tr>
                      <th>الحالة</th>
                      <th>الجهة</th>
                      <th>البند فى الملف</th>
                      <th>البند فى النظام</th>
                      <th>المبلغ الحالى</th>
                      <th>المبلغ فى الملف</th>
                      <th>الفرق</th>
                      <th>الإجراء</th>
                    </tr>
                  </thead>
                  <tbody>
                    {shown.map(([r, i]) => {
                      const sch = data.schools.find((x) => String(x.id) === String(r.school_id));
                      const diff = r.match ? r.allocated - r.old : null;
                      return (
                        <tr key={i} className={r.status === "error" ? "def" : ""}>
                          <td>
                            <span className={"chip " + STATUS_INFO[r.status][1]}>{STATUS_INFO[r.status][0]}</span>
                            {r.status === "similar" && r.amountChanged && <span className="chip amber" style={{ marginInlineStart: 4 }}>مبلغ مختلف</span>}
                          </td>
                          <td style={{ fontSize: 12 }}>{sch ? sch.name : ""}</td>
                          <td>
                            {r.name}
                            <span className="cust-sub">
                              {r.section} · سطر {r.row}
                              {r.msg ? " · " + r.msg : ""}
                            </span>
                          </td>
                          <td>{r.match ? <>{r.match.name}<span className="cust-sub">{r.match.section}</span></> : "—"}</td>
                          <td className="num">{r.match ? fmt(r.old) : "—"}</td>
                          <td className="num">{isFinite(r.allocated) ? fmt(r.allocated) : "—"}</td>
                          <td className={"num " + (diff > 0 ? "red" : diff < 0 ? "green" : "")}>
                            {diff == null || Math.abs(diff) < 0.005 ? "—" : (diff > 0 ? "+" : "") + fmt(diff)}
                          </td>
                          <td>
                            {r.status === "error" || r.status === "duplicate" ? (
                              <span className="muted">يُتجاهل</span>
                            ) : r.status === "same" ? (
                              <span className="muted">لا تغيير</span>
                            ) : (
                              <select value={r.action} onChange={(e) => setActions({ ...actions, [i]: e.target.value })}>
                                {r.match && <option value="update">تحديث البند الموجود</option>}
                                <option value="add">إضافة كبند جديد</option>
                                <option value="skip">تخطى</option>
                              </select>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                {!shown.length && <div className="empty">لا توجد بنود فى هذا التصنيف.</div>}
              </div>
              {preview.missing.length > 0 && (
                <details className="missing-box">
                  <summary>
                    {preview.missing.length} بند موجود فى النظام وغير موجود فى الملف — <b>لن يُحذف</b> (للعلم فقط)
                  </summary>
                  <ul>
                    {preview.missing.map((l) => (
                      <li key={l.id}>
                        {l.section} — {l.name}: {fmt(l.allocated)}
                      </li>
                    ))}
                  </ul>
                </details>
              )}
            </>
          )}
          {unmapped.length > 0 && <div className="warn-banner">اختر الجهة للشيتات المفعّلة لعرض المقارنة.</div>}

          <div className="modal-actions">
            <button className="btn ghost" onClick={() => setStep(1)}>
              رجوع
            </button>
            <span className="spacer" />
            <span className="imp-sum">
              سيتم: إضافة <b>{willAdd}</b> · تحديث <b>{willUpdate}</b> · بدون حذف
            </span>
            <button className="btn primary" disabled={busy || !!unmapped.length || !active.length || willAdd + willUpdate === 0} onClick={doImport}>
              {busy ? "جارٍ الاستيراد…" : "تأكيد الاستيراد"}
            </button>
          </div>
        </div>
      )}

      {step === 3 && result && (
        <div>
          <div className="imp-done">
            <div style={{ fontSize: 34 }}>✅</div>
            <h3>تم الاستيراد بنجاح</h3>
          </div>
          <div className="mini-kpis">
            <div>
              <span>بنود جديدة</span>
              <b className="teal">{result.added}</b>
            </div>
            <div>
              <span>بنود عُدّلت</span>
              <b className="amber">{result.updated}</b>
            </div>
            <div>
              <span>بدون تغيير</span>
              <b className="green">{result.unchanged}</b>
            </div>
            <div>
              <span>متجاهَل (مكرر/تخطى)</span>
              <b>{result.skipped}</b>
            </div>
            <div>
              <span>أخطاء لم تُستورد</span>
              <b className="red">{result.errors}</b>
            </div>
          </div>
          <p className="hint">كل التغييرات مسجّلة فى «تتبع التعديلات» بالقيمة القديمة والجديدة.</p>
          <div className="modal-actions">
            <span className="spacer" />
            <button className="btn primary" onClick={() => onDone("تم استيراد الموازنة")}>
              تم
            </button>
          </div>
        </div>
      )}
    </Modal>
  );
}

// ============================================================================ إضافة / تعديل بند موازنة يدوياً
export function BudgetLineForm({ data, initial, defaultSchool, act, onDone, close }) {
  const editing = !!(initial && initial.id);
  const [school, setSchool] = useState(String((initial && initial.school_id) || defaultSchool || (data.schools[0] || {}).id || ""));
  const [section, setSection] = useState((initial && initial.section) || "");
  const [name, setName] = useState((initial && initial.name) || "");
  const [amount, setAmount] = useState(initial ? String(initial.allocated ?? "") : "");
  const [note, setNote] = useState((initial && initial.note) || "");
  const hasPlan = !!(initial && initial.monthly_plan);
  const [mode, setMode] = useState(hasPlan ? "custom" : "equal");
  const [plan, setPlan] = useState(initial ? monthlyPlan(initial).map((x) => String(Math.round(x * 100) / 100)) : Array(12).fill(""));
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const ent = data.schools.find((s) => String(s.id) === school);
  const sections = [...new Set(data.lines.filter((l) => String(l.school_id) === school).map((l) => l.section).filter(Boolean))];
  const dup = data.lines.find(
    (l) => String(l.school_id) === school && l.id !== (initial && initial.id) && lineKey(l.school_id, l.section, l.name) === lineKey(school, section, name),
  );
  const amt = Number(String(amount).replace(/,/g, ""));
  const planSum = plan.reduce((a, x) => a + (Number(x) || 0), 0);

  const save = async () => {
    setErr("");
    if (!school) return setErr("اختر الجهة");
    if (!name.trim()) return setErr("اكتب اسم البند");
    if (!(amount !== "" && isFinite(amt) && amt >= 0)) return setErr("اكتب مبلغاً صحيحاً (صفر أو أكبر)");
    if (dup) return setErr("هذا البند موجود بالفعل فى نفس القسم لهذه الجهة — عدّله بدلاً من إضافته");
    if (mode === "custom" && Math.abs(planSum - amt) > 1)
      return setErr("مجموع التوزيع الشهرى (" + fmt(planSum) + ") لا يساوى المبلغ السنوى (" + fmt(amt) + ")");
    const line = {
      school_id: school,
      section: section.trim(),
      name: name.trim(),
      allocated: amt,
      note: note.trim(),
      monthly_plan: mode === "custom" ? JSON.stringify(plan.map((x) => Number(x) || 0)) : "",
    };
    setBusy(true);
    try {
      if (editing) await act("updateLine", { id: initial.id, patch: line });
      else await act("addLine", { line });
      onDone(editing ? "تم تعديل البند" : "تمت إضافة البند");
    } catch (e) {
      setBusy(false);
    }
  };

  return (
    <Modal title={editing ? "تعديل بند موازنة" : "إضافة موازنة يدوياً"} close={close} wide>
      <div className="grid2">
        <Field label="المكان / الجهة">
          <select value={school} disabled={editing} onChange={(e) => setSchool(e.target.value)}>
            {data.schools.map((s) => (
              <option key={s.id} value={s.id}>
                {entityLabel(s)}
              </option>
            ))}
          </select>
        </Field>
        <Field label="السنة المالية">
          <input value={ent && ent.period ? ent.period + " (سبتمبر ← أغسطس)" : "—"} disabled />
        </Field>
        <Field label="القسم">
          <input list="sec-list" value={section} onChange={(e) => setSection(e.target.value)} placeholder="مثال: تكلفة التشغيل" />
          <datalist id="sec-list">
            {sections.map((s) => (
              <option key={s} value={s} />
            ))}
          </datalist>
        </Field>
        <Field label="البند">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="اسم البند" />
        </Field>
        <Field label="المخصص السنوى (ج.م)">
          <input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0" />
        </Field>
        <Field label="التوزيع الشهرى">
          <select value={mode} onChange={(e) => setMode(e.target.value)}>
            <option value="equal">بالتساوى على 12 شهر</option>
            <option value="custom">توزيع مخصص لكل شهر</option>
          </select>
        </Field>
      </div>
      {dup && (
        <div className="warn-banner over">
          البند «{dup.name}» موجود بالفعل فى قسم «{dup.section}» بمخصص {fmt(dup.allocated)} ج.م — لا يمكن تكراره.
        </div>
      )}
      {mode === "custom" && (
        <div className="plan-grid">
          {FY_MONTHS.map((m, i) => (
            <label key={m}>
              <span>{m}</span>
              <input inputMode="decimal" value={plan[i]} onChange={(e) => setPlan(plan.map((x, j) => (j === i ? e.target.value : x)))} />
            </label>
          ))}
          <div className={"plan-sum " + (Math.abs(planSum - (amt || 0)) > 1 ? "red" : "green")}>
            المجموع: {fmt(planSum)} / {fmt(amt || 0)}
            <button
              className="btn ghost sm"
              type="button"
              onClick={() => setPlan(Array(12).fill(String(Math.round(((amt || 0) / 12) * 100) / 100)))}
            >
              وزّع بالتساوى
            </button>
          </div>
        </div>
      )}
      {mode === "equal" && isFinite(amt) && amt > 0 && <div className="hint">المخصص الشهرى: {fmt(amt / 12)} ج.م</div>}
      <Field label="ملاحظات (اختيارى)">
        <input value={note} onChange={(e) => setNote(e.target.value)} />
      </Field>
      {err && <div className="warn-banner over">{err}</div>}
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <span className="spacer" />
        <button className="btn primary" disabled={busy || !!dup} onClick={save}>
          {busy ? "جارٍ الحفظ…" : editing ? "حفظ التعديل" : "إضافة البند"}
        </button>
      </div>
    </Modal>
  );
}

// ============================================================================ حذف الموازنة (للأدمن فقط — حذف منطقى قابل للاسترجاع)
export function BudgetDeleteModal({ data, school_id, act, onDone, close }) {
  const s = data.schools.find((x) => String(x.id) === String(school_id)) || {};
  const lines = data.lines.filter((l) => String(l.school_id) === String(school_id));
  const ids = new Set(lines.map((l) => String(l.id)));
  const linked =
    data.agg && data.agg.line_exp_count
      ? Array.from(ids).reduce((a, id) => a + Number(data.agg.line_exp_count[id] || 0), 0)
      : data.expenses.filter((e) => ids.has(String(e.line_id))).length;
  const allocs = (data.custody_lines || []).filter((c) => ids.has(String(c.line_id))).length;
  const total = lines.reduce((a, l) => a + Number(l.allocated || 0), 0);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const blocked = linked > 0 || allocs > 0;
  return (
    <Modal title="حذف الموازنة" close={close}>
      <div className="warn-banner over" style={{ fontSize: 13.5 }}>
        هل أنت متأكد من حذف هذه الموازنة؟
      </div>
      <div className="kv" style={{ marginBottom: 12 }}>
        <div>
          <span>المكان</span>
          <b>{s.name}</b>
        </div>
        <div>
          <span>السنة المالية</span>
          <b>{s.period || "—"}</b>
        </div>
        <div>
          <span>نوع الموازنة</span>
          <b>{CAT_LABEL[s.category || "school"]}</b>
        </div>
        <div>
          <span>إجمالى القيمة</span>
          <b>
            {fmt(total)} ج.م ({lines.length} بند)
          </b>
        </div>
      </div>
      {blocked ? (
        <div className="warn-banner">
          لا يمكن الحذف: الموازنة مرتبطة بـ {linked} مصروف{allocs ? " و" + allocs + " توزيع عهدة" : ""}. الحذف سيكسر العلاقات المالية؛ عدّل البنود
          بدلاً من ذلك.
        </div>
      ) : (
        <>
          <p className="hint">
            الحذف منطقى (Soft Delete): تختفى الموازنة من كل الشاشات والتقارير، وتبقى محفوظة ويمكن للأدمن استرجاعها، وتُسجَّل العملية فى «تتبع
            التعديلات».
          </p>
          <Field label="سبب الحذف (إلزامى)">
            <input value={reason} onChange={(e) => setReason(e.target.value)} />
          </Field>
        </>
      )}
      <div className="modal-actions">
        <button className="btn ghost" onClick={close}>
          تراجع
        </button>
        <span className="spacer" />
        {!blocked && (
          <button
            className="btn danger-ghost"
            disabled={busy || reason.trim().length < 3}
            onClick={async () => {
              setBusy(true);
              try {
                await act("deleteBudget", { school_id, reason: reason.trim() });
                onDone("تم حذف الموازنة");
              } catch (e) {
                setBusy(false);
              }
            }}
          >
            تأكيد الحذف
          </button>
        )}
      </div>
    </Modal>
  );
}
