// قرار المدير المباشر على المصروف: اعتماد · إعادة للتعديل · رفض (السبب إلزامى للإعادة والرفض)
import React, { useState } from "react";
import { fmt } from "../lib/utils";
import { Modal, Field, DocLink } from "../components/ui";
import { hasDoc } from "../lib/expense";
import { custodyInfo } from "../lib/custody";

export function DecisionModal({ data, e, onDecide, close }) {
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const cust = (data.custodies || []).find((c) => String(c.id) === String(e.custody_id));
  const ci = cust ? custodyInfo(data, cust) : null;
  const line = (data.lines || []).find((l) => String(l.id) === String(e.line_id));
  const need = note.trim().length >= 2;
  const go = async (decision) => {
    setBusy(true);
    try {
      await onDecide(decision, note.trim());
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal title="مراجعة واعتماد المصروف" close={close}>
      <div className="decide-box">
        <div className="decide-amt">
          {fmt(e.amount)} <i>ج.م</i>
        </div>
        <div>{e.description}</div>
        <div className="muted">
          {e.txn_no} · {e.date} · البند: {(line && line.name) || e.line || e.spend_item || "—"} · أدخله: {e.created_by}
        </div>
        {ci && (
          <div className="muted">
            العهدة {cust.code} — {ci.holderName}: القيمة {fmt(ci.received)} · المصروف {fmt(ci.spent)} · المتبقى{" "}
            <b className={ci.remaining < 0 ? "red" : ""}>{fmt(ci.remaining)}</b>
          </div>
        )}
        <div style={{ marginTop: 6 }}>
          {hasDoc(e) ? (
            <DocLink expense={e} className="chip navy">
              📎 عرض المستند
            </DocLink>
          ) : (
            <span className="chip amber">لا يوجد مستند مؤيد</span>
          )}
        </div>
      </div>
      <Field label="ملاحظة / سبب (إلزامى عند الإعادة أو الرفض)">
        <input value={note} onChange={(x) => setNote(x.target.value)} data-testid="decide-note" />
      </Field>
      <div className="modal-actions">
        <button className="btn danger-ghost" disabled={busy || !need} onClick={() => go("rejected")} title={need ? "" : "اكتب سبب الرفض"}>
          رفض
        </button>
        <button className="btn ghost" disabled={busy || !need} onClick={() => go("returned")} title={need ? "" : "اكتب سبب الإعادة"}>
          إعادة للتعديل
        </button>
        <span className="spacer" />
        <button className="btn ghost" onClick={close}>
          إلغاء
        </button>
        <button className="btn primary" disabled={busy} onClick={() => go("approved")}>
          اعتماد
        </button>
      </div>
    </Modal>
  );
}
