// استيراد ملف المصروفات والعهد بضغطة واحدة: رفع الملف ← (تحليل تلقائى) ← «استيراد»
// لا يوجد ربط أعمدة يدوى: النظام يتعرف على الأعمدة والمدرسة والعهدة والبند والشهر وحده، ويُظهر قبل التنفيذ ملخصاً
// وتقرير استثناءات بالسجلات التى تحتاج مراجعة فقط (لا يتوقف الاستيراد بسببها). المكرر لا يُستورد مرتين.
import React, { useRef, useState } from "react";
import { Modal } from "../components/ui";
import { fmt } from "../lib/utils";
import { loadXLSX } from "../lib/importers";
import { probe } from "../lib/api";
import { readExpenseWorkbook, downloadExpenseTemplate, FIELD_LABEL, TEMPLATE_COLUMNS } from "../lib/expenseImport";

const ST = {
  ok: ["سليم", "teal"],
  warning: ["ملاحظة", "amber"],
  duplicate: ["مكرر", "red"],
  error: ["يحتاج مراجعة", "red"],
};
const BSTATE = { within: ["ضمن الموازنة", "teal"], near: ["قارب على النفاد", "amber"], reached: ["مستنفد", "amber"], over: ["تجاوز", "red"], none: ["بدون موازنة", "gray"] };
const AR_MONTH = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
const monthLabel = (m) => (m && /^\d{4}-\d{2}$/.test(m) ? AR_MONTH[+m.slice(5) - 1] + " " + m.slice(0, 4) : m || "—");

async function exportExceptions(res, fileName) {
  const X = await loadXLSX();
  const rows = (res.rows || []).filter((r) => r.status !== "ok");
  const aoa = [["الحالة", "موضع السجل فى الملف", "المدرسة", "رقم العهدة", "مسئول العهدة", "التاريخ", "البند الرئيسى", "البند الفرعى", "الوصف", "المورد / المستفيد", "رقم المستند", "القيمة", "السبب / الملاحظة"]];
  rows.forEach((r) =>
    aoa.push([ST[r.status][0], r.r, r.school, r.custody_no || r.custody, r.holder, r.date, r.main, r.sub, r.description, r.supplier, r.doc_no, r.amount, [].concat(r.errors || [], r.duplicate_of ? [r.duplicate_of] : [], r.warnings || []).join(" · ")]),
  );
  const wb = X.utils.book_new();
  X.utils.book_append_sheet(wb, X.utils.aoa_to_sheet(aoa), "الاستثناءات");
  X.writeFile(wb, "تقرير_استثناءات_" + String(fileName || "الاستيراد").replace(/\.[^.]+$/, "") + ".xlsx");
}

export function ExpenseImportWizard({ data, act, close, onDone, isAdmin }) {
  const [phase, setPhase] = useState("pick"); // pick → analyzing → review → importing → done
  const [parsed, setParsed] = useState(null);
  const [res, setRes] = useState(null);
  const [done, setDone] = useState(null);
  const [err, setErr] = useState("");
  const [filter, setFilter] = useState("issues");
  const [amode, setAmode] = useState(isAdmin ? "approved" : "workflow");
  const [sheetSch, setSheetSch] = useState({}); // أوراق لم تُعرف مدرستها تلقائياً: اسم الورقة ← المدرسة المختارة ("" = لا تُستورد)
  const fileRef = useRef();

  // الصفوف المرسلة: صفوف الأوراق المعروفة مدرستها (أو بها عمود مدرسة)، وأوراق اختار المستخدم مدرستها فقط
  const rowsFor = (p, ss) =>
    p.rows
      .map((r) => (r.school_id || r.school ? r : ss[r.sheet] ? Object.assign({}, r, { school_id: ss[r.sheet] }) : null))
      .filter(Boolean);
  const unresolved = (p) => {
    const m = {};
    (p ? p.rows : []).forEach((r) => {
      if (!r.school_id && !r.school) m[r.sheet] = (m[r.sheet] || 0) + 1;
    });
    return Object.entries(m);
  };

  const analyze = async (file, mode) => {
    if (!file) return;
    setErr("");
    setPhase("analyzing");
    try {
      const p = await readExpenseWorkbook(file, data);
      setParsed(p);
      if (!p.rows.length) {
        setErr("لم يُتعرَّف على جدول مصروفات فى الملف.");
        setPhase("pick");
        return;
      }
      setSheetSch({});
      const send = rowsFor(p, {});
      if (!send.length) {
        setRes({ summary: { rows: 0, importable: 0, amount: 0, months: {}, new_custodies: 0, existing_custodies: 0, duplicate: 0, error: 0, warning: 0 }, rows: [], custodies: [], lines: [] });
        setPhase("review");
        return;
      }
      const r = await probe("importExpensesFile", { mode: "preview", rows: send, file_name: p.fileName, approve_mode: mode || amode });
      if (!r || !r.summary) throw new Error((r && r.error) || "تعذّر تحليل الملف");
      setRes(r);
      setPhase("review");
    } catch (e) {
      setErr("تعذّر تحليل الملف: " + ((e && e.message) || e));
      setPhase("pick");
    }
  };
  const reanalyze = async (mode, ss) => {
    setAmode(mode);
    if (!parsed) return;
    const sch = ss || sheetSch;
    if (ss) setSheetSch(ss);
    setPhase("analyzing");
    try {
      const r = await probe("importExpensesFile", { mode: "preview", rows: rowsFor(parsed, sch), file_name: parsed.fileName, approve_mode: mode });
      setRes(r);
    } catch (e) {
      setErr("تعذّر التحليل: " + ((e && e.message) || e));
    }
    setPhase("review");
  };
  const doImport = async () => {
    setPhase("importing");
    try {
      const r = await act("importExpensesFile", { mode: "commit", rows: rowsFor(parsed, sheetSch), file_name: parsed.fileName, approve_mode: amode });
      if (!r || !r.summary) throw new Error((r && r.error) || "تعذّر الاستيراد");
      setDone(r);
      setRes(r);
      setPhase("done");
    } catch (e) {
      setErr("تعذّر الاستيراد: " + ((e && e.message) || e));
      setPhase("review");
    }
  };

  const S = (res && res.summary) || {};
  const shown = ((res && res.rows) || []).filter((r) => (filter === "all" ? true : filter === "issues" ? r.status !== "ok" : r.status === filter));
  const months = Object.entries(S.months || {}).sort();
  const recognizedSheets = parsed ? parsed.sheets.filter((s) => s.recognized) : [];
  const ignoredSheets = parsed ? parsed.sheets.filter((s) => !s.recognized) : [];

  return (
    <Modal title="استيراد ملف المصروفات والعهد" close={close} xl>
      {err && <div className="warn-banner over">{err}</div>}

      {(phase === "pick" || phase === "analyzing") && (
        <>
          <p className="hint">
            ارفع ملف المصروفات والعهد بالشكل المعتمد، وسيتعرف النظام تلقائياً على: المدرسة، رقم العهدة ومسئولها وقيمتها وتاريخها، تاريخ المصروف والشهر،
            البند الرئيسى والفرعى، الوصف، المورد/المستفيد، رقم المستند والقيمة. <b>لا يلزم ربط أى أعمدة.</b> العهد غير الموجودة تُنشأ تلقائياً، وتتحدث
            الموازنة وأرصدة العهد والتقارير فوراً.
          </p>
          <div className="file-drop" onClick={() => phase === "pick" && fileRef.current && fileRef.current.click()} data-testid="expimp-drop">
            <div style={{ fontSize: 28 }}>📥</div>
            <b>{phase === "analyzing" ? "جارٍ قراءة الملف وتحليله…" : "اختر ملف المصروفات والعهد (.xlsx)"}</b>
            <span>{phase === "analyzing" ? "التعرف على الأعمدة والمدارس والعهد والبنود واكتشاف التكرار" : "اضغط هنا لاختيار الملف"}</span>
            <input
              ref={fileRef}
              type="file"
              hidden
              accept=".xlsx,.xls,.csv"
              onChange={(e) => {
                analyze(e.target.files[0]);
                e.target.value = "";
              }}
              data-testid="expimp-file"
            />
          </div>
          {parsed && !parsed.rows.length && (
            <div className="hint" style={{ marginTop: 8 }}>
              {parsed.sheets.map((s) => (
                <div key={s.name}>
                  ورقة «{s.name}»: {s.reason || "لا توجد صفوف"}
                </div>
              ))}
              الأعمدة المعتمدة: {TEMPLATE_COLUMNS.join(" · ")}
            </div>
          )}
          <div style={{ marginTop: 10 }}>
            <button className="btn ghost sm" onClick={() => downloadExpenseTemplate(data)} data-testid="expimp-template">
              تحميل القالب المعتمد
            </button>
          </div>
        </>
      )}

      {(phase === "review" || phase === "importing" || phase === "done") && res && (
        <>
          <p className="hint">
            📎 {parsed.fileName} — {recognizedSheets.map((s) => "«" + s.name + "» (" + s.rows + " صف)").join("، ")}
            {ignoredSheets.length > 0 && <span className="muted"> · أوراق لا تحتوى جدول مصروفات: {ignoredSheets.map((s) => s.name).join("، ")}</span>}
          </p>
          <details className="muted" style={{ marginBottom: 8 }}>
            <summary>الأعمدة التى تعرّف عليها النظام</summary>
            {recognizedSheets.map((s) => (
              <div key={s.name} style={{ margin: "4px 0" }}>
                <b>{s.name}:</b>{" "}
                {Object.entries(s.columns).map(([k, l]) => (
                  <span key={k} className="chip gray" style={{ margin: 2 }}>
                    {FIELD_LABEL[k]} ← {l}
                  </span>
                ))}
                {s.extra.length > 0 && <span> · تُحفظ كملاحظات: {s.extra.join("، ")}</span>}
                {s.swapped && <span> · حُدِّد البند من محتوى عمود «{s.swapped[1]}» والوصف من «{s.swapped[0]}»</span>}
                {s.receipts && s.receipts.length > 0 && <span> · استلام العهدة: {s.receipts.map((x) => fmt(x.amount)).join(" + ")}</span>}
              </div>
            ))}
          </details>

          {phase === "review" && unresolved(parsed).length > 0 && (
            <div className="warn-banner" data-testid="expimp-unresolved">
              <b>أوراق لم يتعرف النظام على مدرستها</b> (لا يوجد بها عمود مدرسة ولا يدل اسمها على مدرسة مسجلة) — لن تُستورد إلا إذا حددت مدرستها:
              {unresolved(parsed).map(([sh, n]) => (
                <div key={sh} style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 6, flexWrap: "wrap" }}>
                  <span>
                    «{sh}» ({n} صف)
                  </span>
                  <select value={sheetSch[sh] || ""} onChange={(e) => reanalyze(amode, Object.assign({}, sheetSch, { [sh]: e.target.value }))} data-testid="expimp-sheet-school">
                    <option value="">لا تُستورد</option>
                    {(data.schools || []).map((x) => (
                      <option key={x.id} value={x.id}>
                        {x.name}
                      </option>
                    ))}
                  </select>
                </div>
              ))}
            </div>
          )}

          {phase === "done" && (
            <div className="warn-banner ok" data-testid="expimp-done">
              ✅ تم استيراد {S.importable} مصروف بإجمالى {fmt(S.amount)} ج على {S.existing_custodies + S.new_custodies} عهدة
              {S.new_custodies > 0 && <> (منها {S.new_custodies} عهدة جديدة أُنشئت تلقائياً)</>}.{" "}
              {res.approve_mode === "approved" ? "احتُسبت فوراً فى المنصرف الفعلى للموازنة." : "دخلت دورة الاعتماد (المدير المباشر ← المالية) وتُحتسب فى المنصرف الفعلى بعد الاعتماد."}
              {S.error + S.duplicate > 0 && <> لم يُستورد {S.error + S.duplicate} سجل (انظر تقرير الاستثناءات).</>}
            </div>
          )}

          <div className="mini-kpis" data-testid="expimp-counts">
            <div>
              <span>صفوف الملف</span>
              <b>{S.rows}</b>
            </div>
            <div>
              <span>{phase === "done" ? "تم استيرادها" : "جاهزة للاستيراد"}</span>
              <b className="teal">{S.importable}</b>
            </div>
            <div>
              <span>إجمالى القيمة</span>
              <b>{fmt(S.amount)}</b>
            </div>
            <div>
              <span>عهد جديدة / موجودة</span>
              <b>
                {S.new_custodies} / {S.existing_custodies}
              </b>
            </div>
            <div>
              <span>مكرر (لن يُستورد)</span>
              <b className={S.duplicate ? "red" : ""}>{S.duplicate}</b>
            </div>
            <div>
              <span>يحتاج مراجعة</span>
              <b className={S.error ? "red" : ""}>{S.error}</b>
            </div>
            <div>
              <span>ملاحظات</span>
              <b className={S.warning ? "amber" : ""}>{S.warning}</b>
            </div>
          </div>

          {months.length > 0 && (
            <p className="hint">
              حسب الشهر (من تاريخ المصروف):{" "}
              {months.map(([m, v]) => (
                <span key={m} className="chip navy" style={{ margin: 2 }}>
                  {monthLabel(m)}: {fmt(v)}
                </span>
              ))}
            </p>
          )}

          {isAdmin && phase === "review" && (
            <label className="check" style={{ margin: "6px 0", display: "flex" }}>
              <input type="checkbox" checked={amode === "approved"} onChange={(e) => reanalyze(e.target.checked ? "approved" : "workflow")} data-testid="expimp-approved" />
              <span>
                مصروفات فعلية معتمدة (تُحتسب فوراً فى المنصرف الفعلى للموازنة) — بدون التأشير تدخل دورة الاعتماد العادية (المدير المباشر ← المالية)
              </span>
            </label>
          )}

          <div className="seg" style={{ margin: "8px 0" }}>
            {[
              ["issues", "الاستثناءات فقط"],
              ["all", "كل السجلات"],
              ["error", "يحتاج مراجعة"],
              ["duplicate", "مكرر"],
              ["warning", "ملاحظات"],
            ].map(([k, l]) => (
              <button key={k} className={filter === k ? "on" : ""} onClick={() => setFilter(k)}>
                {l}
              </button>
            ))}
            <span className="spacer" />
            {S.error + S.duplicate + S.warning > 0 && (
              <button className="btn ghost sm" onClick={() => exportExceptions(res, parsed.fileName)} data-testid="expimp-exceptions">
                تنزيل تقرير الاستثناءات
              </button>
            )}
          </div>
          <div className="table-wrap" style={{ maxHeight: 300 }}>
            <table className="tbl" data-testid="expimp-rows">
              <thead>
                <tr>
                  <th>الحالة</th>
                  <th>الموضع</th>
                  <th>المدرسة</th>
                  <th>العهدة</th>
                  <th>المسئول</th>
                  <th>التاريخ</th>
                  <th>البند</th>
                  <th>الوصف</th>
                  <th>القيمة</th>
                  <th>السبب / الملاحظة</th>
                </tr>
              </thead>
              <tbody>
                {shown.slice(0, 500).map((r) => (
                  <tr key={r.i}>
                    <td>
                      <span className={"chip " + ST[r.status][1]}>{ST[r.status][0]}</span>
                    </td>
                    <td className="muted">{r.r}</td>
                    <td>{r.school || "—"}</td>
                    <td>
                      {r.custody || r.custody_no || "—"}
                      {r.custody_new && <span className="chip teal" style={{ marginInlineStart: 4 }}>جديدة</span>}
                    </td>
                    <td>{r.holder || "—"}</td>
                    <td className="num">{r.date || "—"}</td>
                    <td>{r.line || [r.main, r.sub].filter(Boolean).join(" / ") || "—"}</td>
                    <td>{r.description || "—"}</td>
                    <td className="num">{r.amount != null ? fmt(r.amount) : "—"}</td>
                    <td>
                      <span className={r.status === "error" || r.status === "duplicate" ? "red" : "muted"}>
                        {[].concat(r.errors || [], r.duplicate_of ? [r.duplicate_of] : [], r.warnings || []).join(" · ") || "—"}
                      </span>
                    </td>
                  </tr>
                ))}
                {!shown.length && (
                  <tr>
                    <td colSpan={10} className="muted" style={{ textAlign: "center" }}>
                      {filter === "issues" ? "لا توجد استثناءات — كل السجلات سليمة" : "لا توجد سجلات"}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {(res.custodies || []).length > 0 && (
            <>
              <h4 style={{ margin: "12px 0 4px" }}>أرصدة العهد بعد الاستيراد</h4>
              <div className="table-wrap" style={{ maxHeight: 220 }}>
                <table className="tbl" data-testid="expimp-custodies">
                  <thead>
                    <tr>
                      <th>العهدة</th>
                      <th>المسئول</th>
                      <th>المدرسة</th>
                      <th>قيمة العهدة</th>
                      <th>منصرف سابق</th>
                      <th>المستورد</th>
                      <th>المتبقى</th>
                    </tr>
                  </thead>
                  <tbody>
                    {res.custodies.map((c) => (
                      <tr key={c.key}>
                        <td>
                          {c.code || (c.ext_ref ? "رقم " + c.ext_ref : "—")} {c.new && <span className="chip teal">{phase === "done" ? "أُنشئت" : "ستُنشأ"}</span>}
                        </td>
                        <td>
                          {c.holder}
                          {!c.linked_user && <span className="muted"> (بدون حساب)</span>}
                        </td>
                        <td>{c.school}</td>
                        <td className="num">{fmt(c.received)}</td>
                        <td className="num">{fmt(c.spent_before)}</td>
                        <td className="num">{fmt(c.imported)}</td>
                        <td className={"num " + (c.remaining_after < 0 ? "red" : "")}>{fmt(c.remaining_after)}{c.remaining_after < 0 ? " (تجاوز)" : ""}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}

          {(res.lines || []).length > 0 && (
            <>
              <h4 style={{ margin: "12px 0 4px" }}>
                أثر الاستيراد على الموازنة {res.approve_mode !== "approved" && <span className="muted">(يُحتسب فى المنصرف الفعلى بعد اعتماد المصروفات)</span>}
              </h4>
              <div className="table-wrap" style={{ maxHeight: 240 }}>
                <table className="tbl" data-testid="expimp-lines">
                  <thead>
                    <tr>
                      <th>المدرسة</th>
                      <th>البند</th>
                      <th>المخصص</th>
                      <th>الفعلى قبل</th>
                      <th>المستورد</th>
                      <th>الفعلى بعد</th>
                      <th>المتبقى / العجز</th>
                      <th>نسبة التنفيذ</th>
                      <th>الحالة</th>
                    </tr>
                  </thead>
                  <tbody>
                    {res.lines.map((l) => (
                      <tr key={l.line_id}>
                        <td>{l.school}</td>
                        <td>
                          {l.section ? <span className="muted">{l.section} / </span> : null}
                          {l.line}
                        </td>
                        <td className="num">{fmt(l.allocated)}</td>
                        <td className="num">{fmt(l.actual_before)}</td>
                        <td className="num">{fmt(l.imported)}</td>
                        <td className="num">{fmt(l.actual_after)}</td>
                        <td className={"num " + (l.remaining_after < 0 ? "red" : "")}>{fmt(l.remaining_after)}</td>
                        <td className="num">{l.pct_after == null ? "—" : l.pct_after + "%"}</td>
                        <td>
                          <span className={"chip " + (BSTATE[l.state] || BSTATE.none)[1]}>{(BSTATE[l.state] || BSTATE.none)[0]}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}

          <div className="modal-actions">
            {phase !== "done" ? (
              <>
                <button
                  className="btn ghost"
                  onClick={() => {
                    setRes(null);
                    setParsed(null);
                    setPhase("pick");
                  }}
                >
                  ملف آخر
                </button>
                <span className="spacer" />
                <button className="btn primary" disabled={phase === "importing" || !S.importable} onClick={doImport} data-testid="expimp-commit">
                  {phase === "importing" ? "جارٍ الاستيراد…" : "استيراد " + S.importable + " مصروف"}
                </button>
              </>
            ) : (
              <>
                <span className="spacer" />
                <button className="btn primary" onClick={() => onDone(done)} data-testid="expimp-close">
                  تم
                </button>
              </>
            )}
          </div>
        </>
      )}
    </Modal>
  );
}
