import React, { useState } from "react";
import { docUrl, getCurrentSession, probe } from "../lib/api";
import { fmt } from "../lib/utils";

export function PairBars({ items }) {
  let l = Math.max(1, ...items.flatMap((e) => [e.a, e.b]));
  return items.length ? (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 12,
      }}
    >
      <div
        style={{
          display: "flex",
          gap: 16,
          fontSize: 12,
          color: "var(--ink-soft)",
        }}
      >
        <span>
          <i
            style={{
              display: "inline-block",
              width: 12,
              height: 12,
              background: "var(--navy)",
              borderRadius: 3,
              marginInlineEnd: 5,
            }}
          />
          الموازنة
        </span>
        <span>
          <i
            style={{
              display: "inline-block",
              width: 12,
              height: 12,
              background: "var(--teal)",
              borderRadius: 3,
              marginInlineEnd: 5,
            }}
          />
          الفعلى المُسوّى
        </span>
      </div>
      {items.map((e, n) => {
        let i = (e.a / l) * 100,
          u = (e.b / l) * 100,
          s = e.b > e.a;
        return (
          <div key={n}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                fontSize: 12.5,
                marginBottom: 4,
              }}
            >
              <b
                style={{
                  color: "var(--navy)",
                }}
              >
                {e.label}
              </b>
              <span
                style={{
                  color: s ? "var(--red)" : "var(--ink-soft)",
                }}
              >
                {fmt(e.b)}
                {" / "}
                {fmt(e.a)}
                {" · "}
                {e.a ? Math.round((e.b / e.a) * 100) : 0}%
              </span>
            </div>
            <div
              style={{
                background: "#EDF1F5",
                borderRadius: 8,
                height: 12,
                marginBottom: 4,
              }}
            >
              <div
                style={{
                  width: i + "%",
                  height: "100%",
                  background: "var(--navy)",
                  borderRadius: 8,
                }}
              />
            </div>
            <div
              style={{
                background: "#EDF1F5",
                borderRadius: 8,
                height: 12,
              }}
            >
              <div
                style={{
                  width: u + "%",
                  height: "100%",
                  background: s ? "var(--red)" : "var(--teal)",
                  borderRadius: 8,
                }}
              />
            </div>
          </div>
        );
      })}
    </div>
  ) : (
    <div
      className="empty"
      style={{
        padding: 12,
      }}
    >
      لا توجد بيانات.
    </div>
  );
}

export function ShareList({ items }) {
  let l = items.reduce((s, o) => s + o.value, 0);
  if (!l)
    return (
      <div
        className="empty"
        style={{
          padding: 12,
        }}
      >
        لا توجد بيانات.
      </div>
    );
  let e = 60,
    n = 2 * Math.PI * e,
    i = 0,
    u = items
      .filter((s) => s.value > 0)
      .map((s) => {
        let o = s.value / l,
          d = {
            ...s,
            dash: o * n,
            off: i,
            pct: Math.round(o * 100),
          };
        return ((i += o * n), d);
      });
  return (
    <div
      style={{
        display: "flex",
        gap: 18,
        alignItems: "center",
        flexWrap: "wrap",
      }}
    >
      <svg width="150" height="150" viewBox="0 0 150 150">
        <g transform="translate(75,75) rotate(-90)">
          <circle r={e} fill="none" stroke="#EDF1F5" strokeWidth="22" />
          {u.map((s, o) => (
            <circle
              key={o}
              r={e}
              fill="none"
              stroke={s.color}
              strokeWidth="22"
              strokeDasharray={`${s.dash} ${n - s.dash}`}
              strokeDashoffset={-s.off}
            />
          ))}
        </g>
        <text
          x="75"
          y="72"
          textAnchor="middle"
          style={{
            fontFamily: "Cairo",
            fontWeight: 800,
            fontSize: 15,
            fill: "var(--navy)",
          }}
        >
          {fmt(l)}
        </text>
        <text
          x="75"
          y="90"
          textAnchor="middle"
          style={{
            fontSize: 10,
            fill: "var(--ink-soft)",
          }}
        >
          ج.م
        </text>
      </svg>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 7,
          flex: 1,
          minWidth: 160,
        }}
      >
        {u.map((s, o) => (
          <div
            key={o}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              fontSize: 13,
            }}
          >
            <i
              style={{
                width: 12,
                height: 12,
                background: s.color,
                borderRadius: 3,
                flex: "none",
              }}
            />
            <span
              style={{
                flex: 1,
              }}
            >
              {s.label}
            </span>
            <b
              className="num"
              style={{
                fontSize: 12.5,
              }}
            >
              {fmt(s.value)}
            </b>
            <span
              style={{
                color: "var(--ink-soft)",
                fontSize: 12,
              }}
            >
              {s.pct}%
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function HBars({ items, tone }) {
  let e = Math.max(1, ...items.map((n) => n.value));
  return items.length ? (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 8,
      }}
    >
      {items.map((n, i) => (
        <div
          key={i}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
          }}
        >
          <div
            style={{
              width: 140,
              fontSize: 12.5,
              color: "var(--ink)",
              overflow: "hidden",
              textOverflow: "ellipsis",
              whiteSpace: "nowrap",
            }}
            title={n.label}
          >
            {n.label}
          </div>
          <div
            style={{
              flex: 1,
              background: "#EDF1F5",
              borderRadius: 20,
              height: 16,
              overflow: "hidden",
            }}
          >
            <div
              style={{
                width: (n.value / e) * 100 + "%",
                height: "100%",
                borderRadius: 20,
                background: n.color || tone || "var(--teal)",
              }}
            />
          </div>
          <div
            className="num"
            style={{
              width: 90,
              textAlign: "start",
              fontSize: 12.5,
            }}
          >
            {fmt(n.value)}
          </div>
        </div>
      ))}
    </div>
  ) : (
    <div
      className="empty"
      style={{
        padding: 12,
      }}
    >
      لا توجد بيانات.
    </div>
  );
}

export function Gauge({ pct }) {
  let e = 2 * Math.PI * 52,
    n = Math.max(0, Math.min(100, pct)),
    i = n >= 80 ? "var(--green)" : n >= 50 ? "var(--amber)" : "var(--red)";
  return (
    <svg width="130" height="130" viewBox="0 0 130 130">
      <g transform="translate(65,65) rotate(-90)">
        <circle r={52} fill="none" stroke="#EDF1F5" strokeWidth="16" />
        <circle
          r={52}
          fill="none"
          stroke={i}
          strokeWidth="16"
          strokeLinecap="round"
          strokeDasharray={`${(n / 100) * e} ${e}`}
        />
      </g>
      <text
        x="65"
        y="66"
        textAnchor="middle"
        style={{
          fontFamily: "Cairo",
          fontWeight: 800,
          fontSize: 24,
          fill: i,
        }}
      >
        {n}%
      </text>
      <text
        x="65"
        y="84"
        textAnchor="middle"
        style={{
          fontSize: 10,
          fill: "var(--ink-soft)",
        }}
      >
        مكتملة
      </text>
    </svg>
  );
}

export function Catalog({ title, items, cols, labels, onAdd, onDel }) {
  let [s, o] = useState({}),
    d = () => {
      (s[cols[0]] || "").trim() && (onAdd(s), o({}));
    };
  return (
    <div className="panel">
      <h3 className="panel-title">{title}</h3>
      <div className="catalog-add">
        {cols.map((c, p) => (
          <input
            key={c}
            placeholder={labels[p]}
            value={s[c] || ""}
            onChange={(m) =>
              o((r) =>
                Object.assign({}, r, {
                  [c]: m.target.value,
                }),
              )
            }
            onKeyDown={(m) => m.key === "Enter" && d()}
          />
        ))}
        <button className="btn primary sm" onClick={d}>
          إضافة
        </button>
      </div>
      <div className="chips-list">
        {items.map((c) => (
          <span key={c.id} className="cat-chip">
            {cols
              .map((p) => c[p])
              .filter(Boolean)
              .join(" — ")}
            <button className="chip-x" onClick={() => onDel(c.id)}>
              ×
            </button>
          </span>
        ))}
        {items.length === 0 && (
          <span
            style={{
              color: "var(--ink-soft)",
              fontSize: 13,
            }}
          >
            لا توجد عناصر.
          </span>
        )}
      </div>
    </div>
  );
}

export function Modal({ title, children, close, wide, xl }) {
  return (
    <div className="overlay" onMouseDown={close}>
      <div className={"modal " + (xl ? "xl" : wide ? "wide" : "")} onMouseDown={(i) => i.stopPropagation()}>
        <div className="modal-head">
          <h3>{title}</h3>
          <button className="close" onClick={close}>
            ×
          </button>
        </div>
        <div className="modal-body">{children}</div>
      </div>
    </div>
  );
}

export function Field({ label, children }) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
    </label>
  );
}

export function Kpi({ label, v, u, tone }) {
  return (
    <div className={"kpi " + tone}>
      <div className="kpi-label">{label}</div>
      <div className="kpi-value">
        {v} <span className="kpi-unit">{u}</span>
      </div>
    </div>
  );
}

export function ApprovalChip({ s, sett, fin }) {
  let e = {
      pending: ["بانتظار الاعتماد", "amber"],
      approved: ["معتمد", "green"],
      rejected: ["مرفوض", "red"],
      draft: ["مسودة", "gray"],
      returned: ["معاد للتعديل", "red"],
    },
    [n, i] = e[s] || ["—", "gray"];
  return (
    <span>
      <span className={"chip " + i}>{n}</span>
      {s === "approved" &&
        fin !== void 0 &&
        (fin === "approved" ? (
          <span className="chip green">{" معتمد مالياً"}</span>
        ) : fin === "rejected" ? (
          <span className="chip red">{" مرفوض مالياً"}</span>
        ) : fin === "returned" ? (
          <span className="chip red">{" معاد للتعديل (مالى)"}</span>
        ) : (
          <span className="chip amber">{" بانتظار الاعتماد المالى"}</span>
        ))}
      {s === "approved" &&
        (sett ? <span className="chip navy">{" مُسوّى"}</span> : <span className="chip gray">{" لم يُسوّ"}</span>)}
    </span>
  );
}

export function Toast({ toast }) {
  return toast ? <div className={"toast " + toast.kind}>{toast.msg}</div> : null;
}

export function Logo({ big }) {
  return (
    <img
      src="logo.png"
      alt="ابدأ إديو"
      style={{
        height: big ? 66 : 40,
        width: "auto",
        display: "block",
      }}
      onError={(l) => {
        l.target.style.display = "none";
      }}
    />
  );
}

// رابط مستند: الروابط العادية تُفتح مباشرة، والمستندات المخزّنة على Storage («storage:...»)
// تُطلب لها رابط مؤقت (ساعة) من Edge Function «docs» عند الضغط.
// فتح مستند مرفوع داخل قاعدة البيانات: لا يُرسَل محتواه مع تحميل الصفحة (doc_url = "inline:")، بل يُطلب عند الضغط فقط
async function openInline(expense, w) {
  let url = String(expense.doc_url || "");
  if (url === "inline:") {
    const r = await probe("getDoc", { id: expense.id });
    url = String((r && r.url) || "");
  }
  if (url.indexOf("data:") === 0) {
    const blob = await (await fetch(url)).blob();
    url = URL.createObjectURL(blob);
  }
  if (w) w.location.href = url;
  else window.open(url, "_blank");
}

export function DocLink({ expense, className, style, children }) {
  const url = String(expense.doc_url || "");
  if (url === "inline:" || url.indexOf("data:") === 0) {
    const open = async (ev) => {
      ev.preventDefault();
      const w = window.open("", "_blank");
      try {
        await openInline(expense, w);
      } catch (e) {
        if (w) w.close();
        alert(e.message || "تعذّر فتح المستند");
      }
    };
    return (
      <a className={className} href="#" onClick={open} style={style} data-doc="inline">
        {children}
      </a>
    );
  }
  if (url.indexOf("storage:") !== 0)
    return (
      <a className={className} href={url} target="_blank" rel="noreferrer" style={style}>
        {children}
      </a>
    );
  const open = async (ev) => {
    ev.preventDefault();
    const w = window.open("", "_blank");
    try {
      const signed = await docUrl(getCurrentSession(), expense.id);
      if (w) w.location.href = signed;
      else window.location.href = signed;
    } catch (e) {
      if (w) w.close();
      alert(e.message || "تعذّر فتح المستند");
    }
  };
  return (
    <a className={className} href="#" onClick={open} style={style}>
      {children}
    </a>
  );
}

// تنبيه «نافذة البيانات»: عند كثرة المصروفات يرسل الخادم آخر فترة + كل غير المكتمل فقط لهذه القوائم،
// بينما المجاميع ولوحة المتابعة والتقارير الديناميكية محسوبة على الخادم من كل البيانات.
export function WindowNote({ data }) {
  const w = data && data.window;
  if (!w || !w.windowed) return null;
  return (
    <div className="warn-banner" data-testid="window-note">
      ℹ هذه القائمة تعرض مصروفات آخر فترة (منذ {w.since}) وكل المصروفات غير المكتملة: {w.shipped} من {w.total}. المجاميع والأرصدة محسوبة من كل
      البيانات؛ وللبحث فى الأقدم استخدم شاشة «المصروفات» أو «تقارير الحالة الديناميكية».
    </div>
  );
}
