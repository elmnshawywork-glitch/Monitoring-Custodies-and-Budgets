// رسوم بيانية خفيفة (SVG/HTML) بدون مكتبات خارجية — اتجاه عربى (RTL)، تلميح عند المرور، ألوان ثابتة الدور.
//  المخصص = أزرق فاتح (مسار) · المصروف = أزرق · خط المخصص الشهرى = برتقالى · التجاوز = أحمر حالة (مع نص)
import React, { useRef, useState } from "react";
import { fmt } from "../lib/utils";

export const C = {
  spent: "#2a78d6",
  plan: "#eb6834",
  track: "#d5e5f8",
  over: "#d03b3b",
  good: "#0ca30c",
  warn: "#fab219",
  serious: "#ec835a",
  grid: "#e8ecf1",
  axis: "#c9d2dc",
  muted: "#7b8794",
};

const short = (v) => {
  const a = Math.abs(v);
  if (a >= 1e6) return (v / 1e6).toFixed(a >= 1e7 ? 0 : 1).replace(/\.0$/, "") + " م";
  if (a >= 1e3) return Math.round(v / 1e3) + " ألف";
  return fmt(v);
};

// ---------------------------------------------------------------- تلميح مشترك
function useTip() {
  const [tip, setTip] = useState(null);
  const box = useRef();
  const show = (e, content) => {
    const r = box.current && box.current.getBoundingClientRect();
    if (!r) return;
    setTip({ x: e.clientX - r.left, y: e.clientY - r.top, w: r.width, content });
  };
  const el = tip && (
    <div className="ch-tip" style={{ top: tip.y + 14, left: Math.min(Math.max(tip.x - 90, 4), tip.w - 190) }}>
      {tip.content}
    </div>
  );
  return { box, show, hide: () => setTip(null), el };
}
const TipRow = ({ color, label, value, line }) => (
  <div className="ch-tip-row">
    <i style={{ background: color, height: line ? 3 : 10, borderRadius: line ? 2 : 3 }} />
    <b>{value}</b>
    <span>{label}</span>
  </div>
);

export function Legend({ items }) {
  return (
    <div className="ch-legend">
      {items.map(([label, color, kind]) => (
        <span key={label}>
          <i className={kind === "line" ? "ln" : ""} style={{ background: color }} />
          {label}
        </span>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------- مخصص مقابل مصروف (أشرطة أفقية)
// items: [{ label, plan, actual, sub }]
export function PlanActualBars({ items, max, onPick }) {
  const t = useTip();
  const top = max || Math.max(1, ...items.map((x) => Math.max(x.plan, x.actual)));
  if (!items.length) return <div className="empty">لا توجد بيانات.</div>;
  return (
    <div className="pab" ref={t.box} onMouseLeave={t.hide}>
      {items.map((x) => {
        const within = Math.min(x.actual, x.plan);
        const over = Math.max(0, x.actual - x.plan);
        const pct = x.plan > 0 ? Math.round((x.actual / x.plan) * 100) : x.actual > 0 ? 100 : 0;
        const tip = (
          <>
            <div className="ch-tip-h">{x.label}</div>
            <TipRow color={C.track} label="المخصص" value={fmt(x.plan)} />
            <TipRow color={C.spent} label="المصروف" value={fmt(x.actual)} />
            <TipRow color={over ? C.over : C.good} label={over ? "تجاوز" : "المتبقى"} value={fmt(over ? over : x.plan - x.actual)} />
          </>
        );
        return (
          <div
            key={x.label}
            className={"pab-row" + (onPick ? " click" : "")}
            onMouseMove={(e) => t.show(e, tip)}
            onClick={() => onPick && onPick(x)}
            tabIndex={0}
            onFocus={(e) => t.show({ clientX: e.target.getBoundingClientRect().left + 100, clientY: e.target.getBoundingClientRect().top }, tip)}
          >
            <div className="pab-label" title={x.label}>
              {x.label}
              {x.sub && <small>{x.sub}</small>}
            </div>
            <div className="pab-track">
              <div className="pab-plan" style={{ width: (x.plan / top) * 100 + "%" }} />
              <div className="pab-act" style={{ width: (within / top) * 100 + "%" }} />
              {over > 0 && <div className="pab-over" style={{ right: (x.plan / top) * 100 + "%", width: (over / top) * 100 + "%" }} />}
            </div>
            <div className={"pab-val" + (over > 0 ? " red" : "")}>
              {short(x.actual)} <span>{pct}%</span>
            </div>
          </div>
        );
      })}
      {t.el}
    </div>
  );
}

// ---------------------------------------------------------------- المصروف الشهرى (أعمدة) + المخصص الشهرى (خط)
export function MonthlyChart({ labels, plan, spent, selected, height = 230 }) {
  const t = useTip();
  const W = 640,
    H = height,
    padT = 14,
    padB = 30,
    padX = 46;
  const top = niceMax(Math.max(1, ...plan, ...spent));
  const n = labels.length;
  const band = (W - padX - 10) / n;
  // RTL: الشهر الأول على اليمين
  const cx = (i) => W - 10 - band * (i + 0.5);
  const y = (v) => padT + (H - padT - padB) * (1 - v / top);
  const bw = Math.min(24, band * 0.55);
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((k) => top * k);
  const linePts = plan.map((v, i) => cx(i) + "," + y(v)).join(" ");
  return (
    <div className="ch-box" ref={t.box} onMouseLeave={t.hide}>
      <svg viewBox={`0 0 ${W} ${H}`} className="ch-svg" role="img" aria-label="المصروف الشهرى مقابل المخصص الشهرى">
        {ticks.map((v) => (
          <g key={v}>
            <line x1={padX} x2={W - 6} y1={y(v)} y2={y(v)} stroke={C.grid} strokeWidth="1" />
            <text x={padX - 6} y={y(v) + 4} textAnchor="end" className="ch-ax">
              {short(v)}
            </text>
          </g>
        ))}
        {spent.map((v, i) => {
          const over = v > plan[i] + 0.5;
          const h = Math.max(0, y(0) - y(v));
          const x = cx(i) - bw / 2;
          return (
            <g key={i}>
              {selected === i + 1 && <rect x={cx(i) - band / 2} y={padT} width={band} height={H - padT - padB} fill="#f2f6fb" />}
              {h > 0 && <path d={roundTop(x, y(v), bw, h, 4)} fill={over ? C.over : C.spent} />}
              <text x={cx(i)} y={H - 10} textAnchor="middle" className={"ch-ax" + (selected === i + 1 ? " sel" : "")}>
                {labels[i]}
              </text>
            </g>
          );
        })}
        <polyline points={linePts} fill="none" stroke={C.plan} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
        {plan.map((v, i) => (
          <circle key={i} cx={cx(i)} cy={y(v)} r="4" fill={C.plan} stroke="#fff" strokeWidth="2" />
        ))}
        {labels.map((m, i) => (
          <rect
            key={"h" + i}
            x={cx(i) - band / 2}
            y={0}
            width={band}
            height={H}
            fill="transparent"
            onMouseMove={(e) =>
              t.show(
                e,
                <>
                  <div className="ch-tip-h">{m}</div>
                  <TipRow color={C.plan} line label="المخصص الشهرى" value={fmt(plan[i])} />
                  <TipRow color={spent[i] > plan[i] + 0.5 ? C.over : C.spent} label="المصروف" value={fmt(spent[i])} />
                  <TipRow color={C.muted} line label="الفرق" value={fmt(plan[i] - spent[i])} />
                </>,
              )
            }
          />
        ))}
      </svg>
      <Legend items={[["المصروف الشهرى", C.spent], ["المخصص الشهرى", C.plan, "line"], ["شهر تجاوز مخصصه", C.over]]} />
      {t.el}
    </div>
  );
}

// ---------------------------------------------------------------- التراكمى: المصروف (مساحة) مقابل المخصص (خط)
export function CumulativeChart({ labels, plan, spent, upTo, height = 250, width = 380 }) {
  const t = useTip();
  const cum = (a) => a.reduce((o, v, i) => (o.push((o[i - 1] || 0) + v), o), []);
  const P = cum(plan),
    S = cum(spent);
  const last = upTo || 12;
  const W = width,
    H = height,
    padT = 14,
    padB = 30,
    padX = 46;
  const top = niceMax(Math.max(1, ...P, ...S));
  const n = labels.length;
  const step = (W - padX - 20) / (n - 1);
  const x = (i) => W - 12 - step * i;
  const y = (v) => padT + (H - padT - padB) * (1 - v / top);
  const sPts = S.slice(0, last).map((v, i) => [x(i), y(v)]);
  const area = sPts.length ? `M${sPts.map((p) => p.join(",")).join(" L")} L${x(last - 1)},${y(0)} L${x(0)},${y(0)} Z` : "";
  return (
    <div className="ch-box" ref={t.box} onMouseLeave={t.hide}>
      <svg viewBox={`0 0 ${W} ${H}`} className="ch-svg" role="img" aria-label="المصروف التراكمى مقابل المخصص التراكمى">
        {[0, 0.5, 1].map((k) => (
          <g key={k}>
            <line x1={padX} x2={W - 6} y1={y(top * k)} y2={y(top * k)} stroke={C.grid} />
            <text x={padX - 6} y={y(top * k) + 4} textAnchor="end" className="ch-ax">
              {short(top * k)}
            </text>
          </g>
        ))}
        {labels.map((m, i) => (
          <text key={m} x={x(i)} y={H - 10} textAnchor="middle" className="ch-ax">
            {i % 2 === 0 ? m : ""}
          </text>
        ))}
        {area && <path d={area} fill={C.spent} opacity="0.12" />}
        <polyline points={P.map((v, i) => x(i) + "," + y(v)).join(" ")} fill="none" stroke={C.plan} strokeWidth="2" strokeLinejoin="round" />
        <polyline points={sPts.map((p) => p.join(",")).join(" ")} fill="none" stroke={C.spent} strokeWidth="2" strokeLinejoin="round" />
        {sPts.length > 0 && <circle cx={sPts[sPts.length - 1][0]} cy={sPts[sPts.length - 1][1]} r="4.5" fill={C.spent} stroke="#fff" strokeWidth="2" />}
        {labels.map((m, i) => (
          <rect
            key={"h" + i}
            x={x(i) - step / 2}
            y={0}
            width={step}
            height={H}
            fill="transparent"
            onMouseMove={(e) =>
              t.show(
                e,
                <>
                  <div className="ch-tip-h">حتى نهاية {m}</div>
                  <TipRow color={C.plan} line label="المخصص التراكمى" value={fmt(P[i])} />
                  {i < last && <TipRow color={C.spent} line label="المصروف التراكمى" value={fmt(S[i])} />}
                  {i < last && <TipRow color={C.muted} line label="الفرق" value={fmt(P[i] - S[i])} />}
                </>,
              )
            }
          />
        ))}
      </svg>
      <Legend items={[["المصروف التراكمى", C.spent, "line"], ["المخصص التراكمى", C.plan, "line"]]} />
      {t.el}
    </div>
  );
}

// ---------------------------------------------------------------- قائمة أشرطة (سلسلة واحدة)
export function BarList({ items, color = C.spent, valueFmt = fmt, empty = "لا توجد بيانات." }) {
  const t = useTip();
  const top = Math.max(1, ...items.map((x) => x.value));
  if (!items.length) return <div className="empty">{empty}</div>;
  return (
    <div className="pab" ref={t.box} onMouseLeave={t.hide}>
      {items.map((x, i) => (
        <div
          key={i + ":" + x.label}
          className="pab-row"
          onMouseMove={(e) =>
            t.show(
              e,
              <>
                <div className="ch-tip-h">{x.label}</div>
                <TipRow color={color} label={x.sub || "القيمة"} value={valueFmt(x.value)} />
              </>,
            )
          }
        >
          <div className="pab-label" title={x.label + (x.sub ? " — " + x.sub : "")}>
            {x.label}
            {x.sub && <small>{x.sub}</small>}
          </div>
          <div className="pab-track plain">
            <div className="pab-act" style={{ width: (x.value / top) * 100 + "%", background: color }} />
          </div>
          <div className="pab-val">{valueFmt === fmt ? short(x.value) : valueFmt(x.value)}</div>
        </div>
      ))}
      {t.el}
    </div>
  );
}

// ---------------------------------------------------------------- شريط حالات (100%) + مفتاح بالأعداد
export function StatusBar({ segments }) {
  const t = useTip();
  const total = segments.reduce((a, s) => a + s.value, 0);
  return (
    <div ref={t.box} onMouseLeave={t.hide} style={{ position: "relative" }}>
      <div className="stbar">
        {total === 0 && <div className="stbar-empty" />}
        {segments
          .filter((s) => s.value > 0)
          .map((s) => (
            <div
              key={s.label}
              style={{ flexGrow: s.value, background: s.color }}
              onMouseMove={(e) =>
                t.show(
                  e,
                  <>
                    <TipRow color={s.color} label={s.label} value={s.value + " (" + Math.round((s.value / total) * 100) + "%)"} />
                    {s.amount != null && <div className="ch-tip-sub">الرصيد: {fmt(s.amount)} ج.م</div>}
                  </>,
                )
              }
            />
          ))}
      </div>
      <div className="stlegend">
        {segments.map((s) => (
          <div key={s.label}>
            <i style={{ background: s.color }} />
            <span>{s.label}</span>
            <b>{s.value}</b>
          </div>
        ))}
      </div>
      {t.el}
    </div>
  );
}

// ---------------------------------------------------------------- مقياس نسبة (مؤشر واحد مقابل حد)
export function Meter({ pct }) {
  const p = Math.max(0, pct);
  const color = p > 1.0001 ? C.over : p >= 0.9 ? C.warn : C.spent;
  return (
    <div className="meter">
      <div style={{ width: Math.min(100, p * 100) + "%", background: color }} />
    </div>
  );
}

function niceMax(v) {
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  for (const m of [1, 1.2, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10]) if (m * p >= v) return m * p;
  return 10 * p;
}
function roundTop(x, y, w, h, r) {
  r = Math.min(r, w / 2, h);
  return `M${x},${y + h} L${x},${y + r} Q${x},${y} ${x + r},${y} L${x + w - r},${y} Q${x + w},${y} ${x + w},${y + r} L${x + w},${y + h} Z`;
}
